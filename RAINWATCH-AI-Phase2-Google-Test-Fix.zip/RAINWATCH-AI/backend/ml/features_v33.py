"""v3.3 GFS feature engineering (new information, not new algorithms).

Builds additional GFS features on top of the v3.2 53-feature set, from:
- data/processed/ifs/gfs_v33_bhubaneswar.csv (25 new Historical Forecast
  variables at Bhubaneswar: pressure levels 925/850/700/500 hPa,
  vertical velocity, CIN, lifted index, dew point, gusts, cloud layers,
  geopotential heights)
- data/processed/ifs/gfs_v33_spatial.csv (GFS at Puri Coast + Offshore
  Bay, same points as the ERA5 upwind grids)
- data/processed/ifs/gfs_previous_runs.csv (Previous Runs API:
  precipitation forecast for valid time t issued 24 h / 48 h earlier;
  available 2024-01-01 onwards only — all-null before that)

LEAKAGE RULE (enforced by construction): every feature at row time t
uses only values with valid time <= t. Rolling sums / lags look
backwards. Previous-Runs values at valid time t were issued at
t-24h / t-48h, so they were available at t. Nothing uses a value with
valid time > t. The audit is in docs/V33_TECHNICAL.md.

Notes on what is NOT here:
- Precipitable water: the variable name ``precipitable_water`` is
  INVALID in the Open-Meteo Historical Forecast API (HTTP 400, probed
  2026-11-23). ``gfs_rh_column_mean`` (mean RH at 925/850/700/500 hPa)
  is used as a documented moisture-column PROXY, not true PW.
- True multi-lead precipitation (same valid time from different model
  runs) is only available via the Previous Runs API at whole-day
  offsets, and only from 2024-01-01. The day1/day2 features below are
  therefore a scoped 2024+ experiment, not part of the main training
  protocol (train 2021-2023 has no multi-lead data).
- GFS pressure-level variables are 0.25 deg resolution; surface GFS is
  0.11 deg. The API snaps the requested point to each resolution's grid
  independently, so pressure-level values may come from a cell up to
  ~12 km away. Same mesoscale environment; recorded, not hidden.
"""

from __future__ import annotations

import os

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
BACKEND = os.path.dirname(HERE)

# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------

def _wind_uv(speed: pd.Series, direction_deg: pd.Series) -> tuple[pd.Series, pd.Series]:
    """Decompose speed + direction (deg, direction wind comes FROM) into u, v.

    Same convention as v3 (features.py): u = -speed * sin(dir), v = -speed * cos(dir).
    """
    rad = np.radians(direction_deg)
    return -speed * np.sin(rad), -speed * np.cos(rad)


def _dewpoint_from_rh(temp_c: pd.Series, rh_pct: pd.Series) -> pd.Series:
    """Magnus approximation of dew point from temperature + RH."""
    rh = rh_pct.clip(1, 100) / 100.0
    a, b = 17.625, 243.04
    alpha = np.log(rh) + (a * temp_c) / (b + temp_c)
    return (b * alpha) / (a - alpha)


# ----------------------------------------------------------------------
# Feature builders
# ----------------------------------------------------------------------

def build_bhub_features(gfs: pd.DataFrame) -> pd.DataFrame:
    """New Bhubaneswar GFS features. Input: gfs_v33_bhubaneswar.csv."""
    df = gfs.copy().sort_values("timestamp").reset_index(drop=True)
    out = pd.DataFrame({"timestamp": df["timestamp"]})

    # -- Vector winds at 925 / 850 / 700 hPa ---------------------------
    for level in ("925", "850", "700"):
        sp = df[f"wind_speed_{level}hPa"]
        dr = df[f"wind_direction_{level}hPa"]
        u, v = _wind_uv(sp, dr)
        out[f"gfs_wind_u_{level}"] = u
        out[f"gfs_wind_v_{level}"] = v
    # Wind shear (speed differences between levels).
    out["gfs_shear_925_850"] = df["wind_speed_925hPa"] - df["wind_speed_850hPa"]
    out["gfs_shear_850_700"] = df["wind_speed_850hPa"] - df["wind_speed_700hPa"]
    out["gfs_shear_925_700"] = df["wind_speed_925hPa"] - df["wind_speed_700hPa"]

    # -- Vertical velocity (Pa/s; negative = ascent) --------------------
    out["gfs_vv_850"] = df["vertical_velocity_850hPa"]
    out["gfs_vv_700"] = df["vertical_velocity_700hPa"]
    out["gfs_vv_850_3h_mean"] = df["vertical_velocity_850hPa"].rolling(3).mean()
    out["gfs_vv_850_min_3h"] = df["vertical_velocity_850hPa"].rolling(3).min()
    out["gfs_vv_700_3h_mean"] = df["vertical_velocity_700hPa"].rolling(3).mean()

    # -- Stability -------------------------------------------------------
    # CIN is negative (energy needed to lift a parcel); net available
    # energy = CAPE + CIN (CIN < 0 reduces it). CAPE comes from the
    # v3.2 GFS file; it is merged in build_v33_table, not here.
    out["gfs_cin"] = df["convective_inhibition"]
    out["gfs_lifted_index"] = df["lifted_index"]

    # -- Moisture profile -------------------------------------------------
    out["gfs_rh_925"] = df["relative_humidity_925hPa"]
    out["gfs_rh_850"] = df["relative_humidity_850hPa"]
    out["gfs_rh_700"] = df["relative_humidity_700hPa"]
    out["gfs_rh_500"] = df["relative_humidity_500hPa"]
    # Column-moisture PROXY (mean RH 925-500 hPa). NOT true precipitable
    # water — the API has no such variable. Documented as a proxy.
    out["gfs_rh_column_mean"] = df[
        ["relative_humidity_925hPa", "relative_humidity_850hPa",
         "relative_humidity_700hPa", "relative_humidity_500hPa"]].mean(axis=1)
    out["gfs_rh_850_700"] = df[
        ["relative_humidity_850hPa", "relative_humidity_700hPa"]].mean(axis=1)
    out["gfs_dewpoint_2m"] = df["dew_point_2m"]
    out["gfs_dewpoint_dep_850"] = (
        df["temperature_850hPa"]
        - _dewpoint_from_rh(df["temperature_850hPa"], df["relative_humidity_850hPa"])
    )

    # -- Temperature profile / lapse rate ----------------------------------
    out["gfs_temp_850"] = df["temperature_850hPa"]
    out["gfs_temp_700"] = df["temperature_700hPa"]
    out["gfs_temp_500"] = df["temperature_500hPa"]
    out["gfs_lapse_850_500"] = df["temperature_850hPa"] - df["temperature_500hPa"]
    out["gfs_thickness_850_500"] = (
        df["geopotential_height_500hPa"] - df["geopotential_height_850hPa"]
    )

    # -- Gusts / clouds ------------------------------------------------------
    out["gfs_wind_gusts"] = df["wind_gusts_10m"]
    out["gfs_cloud_low"] = df["cloud_cover_low"]
    out["gfs_cloud_mid"] = df["cloud_cover_mid"]
    out["gfs_cloud_high"] = df["cloud_cover_high"]
    return out


def build_spatial_features(spatial: pd.DataFrame, bhub_gfs_precip: pd.Series,
                           bhub_gfs_precip_3h: pd.Series) -> pd.DataFrame:
    """GFS spatial features from the coast/bay grids.

    ``bhub_gfs_precip`` / ``bhub_gfs_precip_3h`` are the Bhubaneswar GFS
    precipitation (mm/h) and its 3 h sum, aligned by timestamp (they
    come from the v3.2 GFS file).
    """
    df = spatial.copy().sort_values("timestamp").reset_index(drop=True)
    out = pd.DataFrame({"timestamp": df["timestamp"]})
    # The spatial file has coast_*/bay_ prefixed columns.
    out["gfs_coast_precip"] = df["coast_precipitation"]
    out["gfs_coast_precip_3h_sum"] = df["coast_precipitation"].rolling(3).sum()
    out["gfs_bay_precip"] = df["bay_precipitation"]
    out["gfs_bay_precip_3h_sum"] = df["bay_precipitation"].rolling(3).sum()
    # Spatial lead: upwind coast rain minus Bhubaneswar GFS rain.
    out["gfs_spatial_rain_lead"] = out["gfs_coast_precip_3h_sum"] - bhub_gfs_precip_3h
    out["gfs_bay_cape_excess"] = df["bay_cape"] - df["coast_cape"]
    out["gfs_coast_rh_excess"] = df["coast_relative_humidity_2m"]
    return out


def build_prevruns_features(prev: pd.DataFrame) -> pd.DataFrame:
    """Multi-lead precipitation features (Previous Runs API, 2024+ only).

    precipitation_previous_day1 at valid time t is the GFS forecast for
    t issued 24 h earlier (init = t - 24 h); _day2 was issued 48 h
    earlier. Both were available at prediction time t. All-null before
    2024-01-01 (probed 2026-11-23) — rows before then get NaN.
    """
    df = prev.copy().sort_values("timestamp").reset_index(drop=True)
    out = pd.DataFrame({"timestamp": df["timestamp"]})
    out["gfs_precip_day1"] = df["precipitation_previous_day1"]
    out["gfs_precip_day2"] = df["precipitation_previous_day2"]
    out["gfs_precip_day1_3h_sum"] = df["precipitation_previous_day1"].rolling(3).sum()
    out["gfs_precip_day2_3h_sum"] = df["precipitation_previous_day2"].rolling(3).sum()
    return out


def build_v33_features_at(last_ts: pd.Timestamp, window_h: int = 72) -> dict:
    """Build the new (v3.3-only) GFS features for a single timestamp.

    Slices the processed GFS files to a window ending at ``last_ts`` and
    runs the same builders as ``build_v33_table`` (rolling windows look
    backwards only, so this is leakage-free). Returns {feature: value}
    for the row at ``last_ts``. Previous-Runs features are NOT included:
    they are not in the frozen 94-feature schema. Raises ValueError
    when the timestamp is not covered by the GFS files (the caller then
    falls back to NaN, which the models handle natively).
    """
    lo = last_ts - pd.Timedelta(hours=window_h)

    def _load(name: str) -> pd.DataFrame:
        df = pd.read_csv(os.path.join(BACKEND, "data", "processed", "ifs", name),
                         parse_dates=["timestamp"])
        df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True).dt.tz_localize(None)
        return df[(df["timestamp"] >= lo) & (df["timestamp"] <= last_ts)] \
            .sort_values("timestamp").reset_index(drop=True)

    gfs_bhub = _load("gfs_v33_bhubaneswar.csv")
    gfs_old = _load("gfs_global_processed.csv")
    spatial = _load("gfs_v33_spatial.csv")
    for name, df in (("gfs_v33_bhubaneswar", gfs_bhub),
                     ("gfs_global", gfs_old), ("gfs_v33_spatial", spatial)):
        if len(df) == 0 or df["timestamp"].iloc[-1] != last_ts:
            raise ValueError(f"{name} has no data at {last_ts}")

    new_feats = build_bhub_features(gfs_bhub)
    # CAPE + CIN net energy (CAPE from the v3.2 GFS file).
    cape = gfs_old.set_index("timestamp")["cape_jkg"]
    new_feats["gfs_cape_plus_cin"] = (
        new_feats["timestamp"].map(cape) + new_feats["gfs_cin"]
    )
    # Multi-window GFS precipitation (seamless series, valid time <= t).
    gfs_precip = gfs_old.set_index("timestamp")["precipitation_mm"]
    prec = new_feats["timestamp"].map(gfs_precip)
    new_feats["gfs_precip_12h_sum"] = prec.rolling(12).sum().to_numpy()
    new_feats["gfs_precip_24h_sum"] = prec.rolling(24).sum().to_numpy()
    new_feats["gfs_precip_lag3"] = prec.shift(3).to_numpy()
    new_feats["gfs_precip_lag6"] = prec.shift(6).to_numpy()
    new_feats["gfs_precip_3h_max"] = prec.rolling(3).max().to_numpy()
    # GFS pressure tendencies (from GFS pressure_msl).
    mslp = new_feats["timestamp"].map(gfs_old.set_index("timestamp")["pressure_hpa"])
    new_feats["gfs_pressure_tendency_3h"] = (mslp - mslp.shift(3)).to_numpy()
    new_feats["gfs_pressure_tendency_6h"] = (mslp - mslp.shift(6)).to_numpy()
    # GFS gust factor (needs the v3.2 10 m wind speed).
    wspd = new_feats["timestamp"].map(gfs_old.set_index("timestamp")["wind_speed_kmh"])
    new_feats["gfs_gust_factor"] = new_feats["gfs_wind_gusts"] - wspd

    # Spatial GFS features.
    gfs_precip_3h = prec.rolling(3).sum()
    spat_feats = build_spatial_features(
        spatial,
        bhub_gfs_precip=prec,
        bhub_gfs_precip_3h=gfs_precip_3h,
    )

    out: dict = {}
    for df in (new_feats, spat_feats):
        row = df[df["timestamp"] == last_ts]
        if len(row) == 0:
            raise ValueError(f"no built features at {last_ts}")
        for c in df.columns:
            if c != "timestamp":
                out[c] = row[c].iloc[0]
    return out


def build_v33_table() -> tuple[pd.DataFrame, list[str]]:
    """Build the full v3.3 feature table.

    Starts from the v3.2 table (53 features + targets) and merges the
    new GFS features. Also adds ``gfs_cape_plus_cin`` (needs CAPE from
    the v3.2 GFS file) and the multi-window GFS precipitation features
    (12 h / 24 h sums, lags, 3 h max) from the v3.2 GFS processed file.

    Returns (table, new_feature_names). The table covers 2021-2026;
    Previous-Runs features are NaN before 2024-01-01 by construction.
    """
    v32 = pd.read_csv(
        os.path.join(BACKEND, "data", "model_ready", "bhubaneswar_features_v32.csv"),
        parse_dates=["timestamp"],
    )
    v32["timestamp"] = pd.to_datetime(v32["timestamp"], utc=True).dt.tz_localize(None)

    gfs_bhub = pd.read_csv(
        os.path.join(BACKEND, "data", "processed", "ifs", "gfs_v33_bhubaneswar.csv"),
        parse_dates=["timestamp"],
    )
    gfs_bhub["timestamp"] = pd.to_datetime(
        gfs_bhub["timestamp"], utc=True).dt.tz_localize(None)
    gfs_old = pd.read_csv(
        os.path.join(BACKEND, "data", "processed", "ifs", "gfs_global_processed.csv"),
        parse_dates=["timestamp"],
    )
    gfs_old["timestamp"] = pd.to_datetime(
        gfs_old["timestamp"], utc=True).dt.tz_localize(None)

    new_feats = build_bhub_features(gfs_bhub)
    # CAPE + CIN net energy (CAPE from the v3.2 GFS file).
    cape = gfs_old.set_index("timestamp")["cape_jkg"]
    cin = new_feats.set_index("timestamp")["gfs_cin"]
    new_feats["gfs_cape_plus_cin"] = (
        new_feats["timestamp"].map(cape) + new_feats["gfs_cin"]
    )
    # Multi-window GFS precipitation (seamless series, valid time <= t).
    gfs_precip = gfs_old.set_index("timestamp")["precipitation_mm"]
    prec = new_feats["timestamp"].map(gfs_precip)
    new_feats["gfs_precip_12h_sum"] = prec.rolling(12).sum().to_numpy()
    new_feats["gfs_precip_24h_sum"] = prec.rolling(24).sum().to_numpy()
    new_feats["gfs_precip_lag3"] = prec.shift(3).to_numpy()
    new_feats["gfs_precip_lag6"] = prec.shift(6).to_numpy()
    new_feats["gfs_precip_3h_max"] = prec.rolling(3).max().to_numpy()
    # GFS pressure tendencies (from GFS pressure_msl).
    mslp = new_feats["timestamp"].map(gfs_old.set_index("timestamp")["pressure_hpa"])
    new_feats["gfs_pressure_tendency_3h"] = (mslp - mslp.shift(3)).to_numpy()
    new_feats["gfs_pressure_tendency_6h"] = (mslp - mslp.shift(6)).to_numpy()
    # GFS gust factor (needs the v3.2 10 m wind speed).
    wspd = new_feats["timestamp"].map(gfs_old.set_index("timestamp")["wind_speed_kmh"])
    new_feats["gfs_gust_factor"] = new_feats["gfs_wind_gusts"] - wspd

    # Spatial GFS features.
    spatial = pd.read_csv(
        os.path.join(BACKEND, "data", "processed", "ifs", "gfs_v33_spatial.csv"),
        parse_dates=["timestamp"],
    )
    spatial["timestamp"] = pd.to_datetime(
        spatial["timestamp"], utc=True).dt.tz_localize(None)
    gfs_precip_3h = prec.rolling(3).sum()
    spat_feats = build_spatial_features(
        spatial,
        bhub_gfs_precip=prec,
        bhub_gfs_precip_3h=gfs_precip_3h,
    )

    # Previous-Runs multi-lead features (2024+ only).
    prev = pd.read_csv(
        os.path.join(BACKEND, "data", "processed", "ifs", "gfs_previous_runs.csv"),
        parse_dates=["timestamp"],
    )
    prev["timestamp"] = pd.to_datetime(
        prev["timestamp"], utc=True).dt.tz_localize(None)
    prev_feats = build_prevruns_features(prev)
    # Forecast-consistency signal (day1 forecast minus current analysis)
    # is computed after the merge, once gfs_precip is aligned.

    table = v32.merge(new_feats, on="timestamp", how="left", validate="one_to_one")
    table = table.merge(spat_feats, on="timestamp", how="left", validate="one_to_one")
    table = table.merge(prev_feats, on="timestamp", how="left", validate="one_to_one")
    # Day1-minus-day0 disagreement, aligned on the merged table.
    table["gfs_precip_day1_minus_day0"] = (
        table["gfs_precip_day1"] - table["gfs_precip"]
    )
    table = table.sort_values("timestamp").reset_index(drop=True)

    new_names = [c for c in new_feats.columns if c != "timestamp"]
    new_names += [c for c in spat_feats.columns if c != "timestamp"]
    new_names += [c for c in prev_feats.columns if c != "timestamp"]
    new_names += ["gfs_precip_day1_minus_day0"]
    return table, new_names


V33_NEW_FEATURES: list[str] = []  # populated by build_v33_table at runtime
