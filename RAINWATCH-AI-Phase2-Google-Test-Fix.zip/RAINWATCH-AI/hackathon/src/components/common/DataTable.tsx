import type { ReactNode } from 'react'
import { StatePanel } from './Skeleton'

export interface Column<T> {
  key: string
  header: ReactNode
  render: (row: T, index: number) => ReactNode
  align?: 'left' | 'right' | 'center'
  width?: string
  /** Collapse on small screens (keeps mobile tables readable). */
  secondary?: boolean
}

export function DataTable<T>({
  columns,
  rows,
  rowKey,
  emptyMessage = 'No records match the current filters.',
  onRowClick,
  maxHeight,
  caption,
}: {
  columns: Array<Column<T>>
  rows: T[]
  rowKey: (row: T, index: number) => string
  emptyMessage?: string
  onRowClick?: (row: T) => void
  maxHeight?: number
  caption?: string
}) {
  if (!rows.length) {
    return <StatePanel title="Nothing to show" message={emptyMessage} />
  }

  return (
    <div className="-mx-1 overflow-x-auto" style={maxHeight ? { maxHeight, overflowY: 'auto' } : undefined}>
      <table className="w-full min-w-[520px] border-collapse text-left text-[13px]">
        {caption ? <caption className="sr-only">{caption}</caption> : null}
        <thead className="sticky top-0 z-10 bg-card">
          <tr className="border-b border-line text-[11px] tracking-wider text-muted uppercase">
            {columns.map((c) => (
              <th
                key={c.key}
                scope="col"
                style={c.width ? { width: c.width } : undefined}
                className={`px-3 py-2.5 font-semibold ${
                  c.align === 'right' ? 'text-right' : c.align === 'center' ? 'text-center' : 'text-left'
                } ${c.secondary ? 'hidden md:table-cell' : ''}`}
              >
                {c.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr
              key={rowKey(row, i)}
              onClick={onRowClick ? () => onRowClick(row) : undefined}
              className={`border-b border-line/60 transition-colors last:border-0 ${
                onRowClick ? 'cursor-pointer hover:bg-accent/6' : 'hover:bg-surface/60'
              }`}
            >
              {columns.map((c) => (
                <td
                  key={c.key}
                  className={`px-3 py-2.5 align-middle ${c.align === 'right' ? 'text-right' : c.align === 'center' ? 'text-center' : ''} ${
                    c.secondary ? 'hidden md:table-cell' : ''
                  }`}
                >
                  {c.render(row, i)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
