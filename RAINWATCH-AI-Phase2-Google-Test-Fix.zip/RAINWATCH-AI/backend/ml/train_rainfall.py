"""Train rainfall-v3 (Spatial-Thermodynamic Ensemble).

Two-stage architecture (same as v2) but with a multi-family ensemble:
- Mean regressors (1h/3h/6h): XGBoost + LightGBM + HistGradientBoosting,
  blended with non-negative weights learned on the 2024 validation set.
- Heavy-event classifiers (3h>=10mm, 6h>=10mm, 3h>=5mm): the same three
  families, blended, Platt-calibrated on validation, with TWO operating
  thresholds per event: ``elevated`` (Watch, F2-optimal, high recall) and
  ``high`` (Warning, F1-optimal, high precision).
- P90 quantile regressors (3h/6h): XGBoost + LightGBM + HistGB quantile,
  blended the same way.

Steps
-----
1. Load the v3 feature table (62 features incl. spatial-thermodynamic).
2. Validation-based feature pruning: permutation importance on the 2024
   validation set for a baseline XGBoost 3h regressor (MAE) and a 3h>=10mm
   classifier (PR-AUC). A feature is pruned only when its importance is
   <= 0 for BOTH tasks (conservative — it helps neither).
3. Train the three families on Train (2021-2023) with pruned features.
4. Learn non-negative ensemble weights on Validation (grid search over
   the weight simplex, step 0.1) maximising the task metric.
5. Calibrate the ensemble classifier probabilities (Platt, on validation)
   and tune the two thresholds (elevated = F2-optimal, high = F1-optimal).
6. Refit every member on Train+Validation, evaluate once on the untouched
   2025 test set, and save all artifacts.

Artifacts are saved under ``models/rainfall_xgb_v3/`` (the v2 artifacts in
``models/rainfall_xgb/`` are left untouched).

Chronological split: train 2021-2023 / validation 2024 / test 2025.
Seed 42 throughout. No leakage: targets are strictly in the future.

Usage:  python ml/train_rainfall.py [--skip-pruning]
"""

import argparse
import json
import os
import sys
import time

import joblib
import lightgbm as lgbm
import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    average_precision_score,
    f1_score,
    fbeta_score,
    log_loss,
    mean_absolute_error,
    mean_squared_error,
    precision_score,
    recall_score,
    roc_auc_score,
)

HERE = os.path.dirname(os.path.abspath(__file__))
BACKEND = os.path.dirname(HERE)
sys.path.insert(0, HERE)

import features as feat  # noqa: E402

FEATURES_CSV = os.path.join(BACKEND, "data", "model_ready", "bhubaneswar_features.csv")
OUT_DIR = os.path.join(BACKEND, "models", "rainfall_xgb_v3")
SEED = 42

# Fixed hyperparameters (kept modest; the ensemble, not per-family tuning,
# is what v3 adds). XGBoost uses the v2 best params as a starting point.
XGB_REG_PARAMS = {
    "max_depth": 5, "learning_rate": 0.05, "n_estimators": 400,
    "subsample": 0.9, "colsample_bytree": 0.9, "min_child_weight": 3,
    "reg_lambda": 5.0, "objective": "reg:squarederror",
    "random_state": SEED, "n_jobs": 4, "tree_method": "hist",
}
XGB_CLF_PARAMS = {
    "max_depth": 3, "learning_rate": 0.1, "n_estimators": 200,
    "subsample": 0.8, "colsample_bytree": 0.9, "min_child_weight": 1,
    "reg_lambda": 10.0, "objective": "binary:logistic",
    "random_state": SEED, "n_jobs": 4, "tree_method": "hist",
    "eval_metric": "logloss",
}
LGBM_REG_PARAMS = {
    "max_depth": 5, "learning_rate": 0.05, "n_estimators": 400,
    "subsample": 0.9, "colsample_bytree": 0.9, "min_child_samples": 20,
    "reg_lambda": 5.0, "objective": "regression",
    "random_state": SEED, "n_jobs": 4, "verbose": -1,
}
LGBM_CLF_PARAMS = {
    "max_depth": 3, "learning_rate": 0.1, "n_estimators": 200,
    "subsample": 0.8, "colsample_bytree": 0.9, "min_child_samples": 20,
    "reg_lambda": 10.0, "objective": "binary",
    "random_state": SEED, "n_jobs": 4, "verbose": -1,
}
HGB_REG_PARAMS = {
    "max_depth": 5, "learning_rate": 0.05, "max_iter": 400,
    "min_samples_leaf": 20, "l2_regularization": 5.0,
    "random_state": SEED,
}
HGB_CLF_PARAMS = {
    "max_depth": 3, "learning_rate": 0.1, "max_iter": 200,
    "min_samples_leaf": 20, "l2_regularization": 10.0,
    "random_state": SEED, "class_weight": "balanced",
}

BINARY = {
    "y_3h_ge_10mm": ("y_3h", 10.0),
    "y_6h_ge_10mm": ("y_6h", 10.0),
    "y_3h_ge_5mm": ("y_3h", 5.0),
}
HORIZONS = (1, 3, 6)
FAMILIES = ("xgb", "lgbm", "hgb")


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------

def persistence_baseline(feats: pd.DataFrame, horizon: int) -> np.ndarray:
    """Persistence: the accumulation over the last H hours repeats."""
    if horizon == 1:
        return feats["precip_lag1"].to_numpy()
    return feats[f"precip_sum{horizon}h"].to_numpy()


def climatology_baseline(feats: pd.DataFrame, target: str, train_feats: pd.DataFrame) -> np.ndarray:
    """Climatology: mean target for the same (month, hour) from training data only."""
    key = train_feats[["month", "hour_sin", "hour_cos"]].copy()
    key["target"] = train_feats[target].to_numpy()
    means = key.groupby(["month", "hour_sin", "hour_cos"])["target"].mean()
    global_mean = train_feats[target].mean()
    out = []
    for _, row in feats[["month", "hour_sin", "hour_cos"]].iterrows():
        out.append(means.get((row["month"], row["hour_sin"], row["hour_cos"]), global_mean))
    return np.array(out)


def _platt_fit(raw_probs: np.ndarray, y: np.ndarray):
    """Fit Platt scaling (logistic regression on logit of raw probability)."""
    p = np.clip(raw_probs, 1e-6, 1 - 1e-6)
    z = np.log(p / (1 - p)).reshape(-1, 1)
    lr = LogisticRegression(C=1.0, solver="lbfgs", random_state=SEED)
    lr.fit(z, y)
    return float(lr.coef_[0][0]), float(lr.intercept_[0])


def _platt_apply(raw_probs: np.ndarray, w: float, b: float) -> np.ndarray:
    p = np.clip(raw_probs, 1e-6, 1 - 1e-6)
    z = np.log(p / (1 - p))
    out = 1.0 / (1.0 + np.exp(-(w * z + b)))
    return np.clip(out, 0.0, 1.0)


def _best_threshold(y: np.ndarray, probs: np.ndarray, beta: float):
    """Threshold maximising F-beta on the given (validation) labels."""
    best_t, best_f = 0.5, -1.0
    for t in np.arange(0.01, 0.99, 0.01):
        pred = (probs >= t).astype(int)
        f = fbeta_score(y, pred, beta=beta, zero_division=0)
        if f > best_f:
            best_f, best_t = f, float(t)
    return best_t, best_f


def _simplex_grid(step: float = 0.1):
    """All (w1, w2, w3) with wi >= 0, sum = 1, on a grid of `step`."""
    n = int(round(1.0 / step))
    combos = []
    for i in range(n + 1):
        for j in range(n + 1 - i):
            k = n - i - j
            combos.append((i * step, j * step, k * step))
    return combos


def _ensemble_weights(preds_list, y, metric: str):
    """Learn non-negative weights (sum 1) on validation by grid search.

    metric: 'mae' (minimise) for regressors, 'pr_auc' (maximise) for
    classifiers, 'pinball' (minimise) for P90.
    Returns (weights, best_score).
    """
    P = np.column_stack(preds_list)
    best_w, best_s = None, None
    for w in _simplex_grid(0.1):
        wv = np.array(w)
        ens = P @ wv
        if metric == "mae":
            s = mean_absolute_error(y, ens)
            better = best_s is None or s < best_s
        elif metric == "pr_auc":
            s = average_precision_score(y, ens)
            better = best_s is None or s > best_s
        elif metric == "pinball":
            u = y - ens
            s = np.mean(np.where(u >= 0, 0.9 * u, -0.1 * u))
            better = best_s is None or s < best_s
        else:
            raise ValueError(metric)
        if better:
            best_w, best_s = w, float(s)
    return best_w, best_s


# --------------------------------------------------------------------------
# Model factories (one per family / task)
# --------------------------------------------------------------------------

def _make_regressor(family: str):
    if family == "xgb":
        return xgb.XGBRegressor(**XGB_REG_PARAMS)
    if family == "lgbm":
        return lgbm.LGBMRegressor(**LGBM_REG_PARAMS)
    return HistGradientBoostingRegressor(**HGB_REG_PARAMS)


def _make_p90_regressor(family: str):
    if family == "xgb":
        p = dict(XGB_REG_PARAMS)
        p.update({"objective": "reg:quantileerror", "quantile_alpha": 0.9})
        return xgb.XGBRegressor(**p)
    if family == "lgbm":
        p = dict(LGBM_REG_PARAMS)
        p.update({"objective": "quantile", "alpha": 0.9})
        return lgbm.LGBMRegressor(**p)
    p = dict(HGB_REG_PARAMS)
    p.update({"loss": "quantile", "quantile": 0.9})
    return HistGradientBoostingRegressor(**p)


def _make_classifier(family: str, pos_weight: float):
    if family == "xgb":
        p = dict(XGB_CLF_PARAMS)
        p["scale_pos_weight"] = pos_weight
        return xgb.XGBClassifier(**p)
    if family == "lgbm":
        p = dict(LGBM_CLF_PARAMS)
        p["scale_pos_weight"] = pos_weight
        return lgbm.LGBMClassifier(**p)
    return HistGradientBoostingClassifier(**HGB_CLF_PARAMS)


def _save_member(model, family: str, kind: str):
    """Save one ensemble member. XGBoost -> JSON, LightGBM -> txt, HistGB -> joblib."""
    if family == "xgb":
        model.save_model(os.path.join(OUT_DIR, f"{kind}_xgb.json"))
    elif family == "lgbm":
        model.booster_.save_model(os.path.join(OUT_DIR, f"{kind}_lgbm.txt"))
    else:
        joblib.dump(model, os.path.join(OUT_DIR, f"{kind}_hgb.pkl"))


# --------------------------------------------------------------------------
# Feature pruning (permutation importance on validation)
# --------------------------------------------------------------------------

def prune_features(train, val, feature_cols):
    """Prune features whose permutation importance is <= 0 for BOTH the
    3h regressor (MAE) and the 3h>=10mm classifier (PR-AUC) on validation.

    Returns (kept_features, pruned_features, importance_table).
    """
    print("\n--- Feature pruning (permutation importance on 2024 validation) ---")
    X_tr = train[feature_cols].to_numpy()
    X_va = val[feature_cols].to_numpy()
    y3_tr = train["y_3h"].to_numpy()
    y3_va = val["y_3h"].to_numpy()
    yb_tr = train["y_3h_ge_10mm"].to_numpy()
    yb_va = val["y_3h_ge_10mm"].to_numpy()

    reg = xgb.XGBRegressor(**XGB_REG_PARAMS)
    reg.fit(X_tr, y3_tr)
    base_mae = mean_absolute_error(y3_va, reg.predict(X_va))
    pos = max(1, int(yb_tr.sum()))
    neg = max(1, int((1 - yb_tr).sum()))
    clf = xgb.XGBClassifier(**{**XGB_CLF_PARAMS, "scale_pos_weight": neg / pos})
    clf.fit(X_tr, yb_tr)
    base_pr = average_precision_score(yb_va, clf.predict_proba(X_va)[:, 1])

    rng = np.random.RandomState(SEED)
    rows = []
    for j, name in enumerate(feature_cols):
        Xp = X_va.copy()
        Xp[:, j] = rng.permutation(Xp[:, j])
        mae_imp = base_mae - mean_absolute_error(y3_va, reg.predict(Xp))
        pr_imp = base_pr - average_precision_score(yb_va, clf.predict_proba(Xp)[:, 1])
        rows.append({"feature": name, "mae_importance": float(mae_imp),
                     "pr_auc_importance": float(pr_imp)})
    imp = pd.DataFrame(rows).sort_values("mae_importance")
    pruned = imp[(imp["mae_importance"] <= 0) & (imp["pr_auc_importance"] <= 0)]["feature"].tolist()
    kept = [c for c in feature_cols if c not in pruned]
    print(f"baseline MAE {base_mae:.4f} | baseline PR-AUC {base_pr:.4f}")
    print(f"pruned {len(pruned)} features (<= 0 importance for both tasks): {pruned}")
    print(f"kept {len(kept)} features")
    return kept, pruned, imp


# --------------------------------------------------------------------------
# Main training
# --------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip-pruning", action="store_true",
                    help="Keep all features (skip permutation-importance pruning).")
    args = ap.parse_args()

    t0 = time.time()
    os.makedirs(OUT_DIR, exist_ok=True)

    m = pd.read_csv(FEATURES_CSV, parse_dates=["timestamp"])
    feature_cols = feat.feature_columns_for(m)
    print(f"loaded {len(m)} rows; {len(feature_cols)} features (v3)")
    train, val, test = feat.chronological_split(m)
    print(f"train {len(train)} | val {len(val)} | test {len(test)}")

    # ---- Step 1: feature pruning ----
    if args.skip_pruning:
        kept, pruned, imp = feature_cols, [], pd.DataFrame()
        print("pruning skipped (--skip-pruning): keeping all features")
    else:
        kept, pruned, imp = prune_features(train, val, feature_cols)

    X_tr = train[kept].to_numpy()
    X_va = val[kept].to_numpy()
    X_te = test[kept].to_numpy()

    evaluation = {
        "model": "rainfall-xgb-v3",
        "version": "v3",
        "split": {"train": "2021-2023", "validation": "2024", "test": "2025"},
        "seed": SEED,
        "features": {"total": len(feature_cols), "kept": len(kept),
                     "pruned": pruned},
        "families": list(FAMILIES),
    }
    weights_out = {}
    thresholds_out = {}
    platt_out = {}

    # ---- Step 2: regression ensembles (mean + P90) ----
    print("\n--- Regression ensembles ---")
    reg_results = {}
    for h in HORIZONS:
        target = f"y_{h}h"
        y_tr = train[target].to_numpy()
        y_va = val[target].to_numpy()
        y_te = test[target].to_numpy()

        val_preds, test_preds = {}, {}
        for fam in FAMILIES:
            mdl = _make_regressor(fam)
            mdl.fit(X_tr, y_tr)
            val_preds[fam] = mdl.predict(X_va)
            test_preds[fam] = mdl.predict(X_te)
        w, val_mae = _ensemble_weights([val_preds[f] for f in FAMILIES], y_va, "mae")
        weights_out[f"reg_{h}h"] = {f: float(wi) for f, wi in zip(FAMILIES, w)}
        ens_te = sum(wi * test_preds[f] for f, wi in zip(FAMILIES, w))
        mae = mean_absolute_error(y_te, ens_te)
        rmse = float(np.sqrt(mean_squared_error(y_te, ens_te)))
        mae_p = mean_absolute_error(y_te, persistence_baseline(test, h))
        rmse_p = float(np.sqrt(mean_squared_error(y_te, persistence_baseline(test, h))))
        mae_c = mean_absolute_error(y_te, climatology_baseline(test, target, train))
        rmse_c = float(np.sqrt(mean_squared_error(y_te, climatology_baseline(test, target, train))))
        reg_results[target] = {
            "mae": float(mae), "rmse": rmse,
            "persistence_mae": float(mae_p), "persistence_rmse": rmse_p,
            "climatology_mae": float(mae_c), "climatology_rmse": rmse_c,
            "ensemble_weights": weights_out[f"reg_{h}h"],
            "validation_mae": float(val_mae),
        }
        print(f"  {target}: ensemble MAE {mae:.4f} RMSE {rmse:.4f} "
              f"(persistence {mae_p:.4f}/{rmse_p:.4f}, climatology {mae_c:.4f}/{rmse_c:.4f}) "
              f"weights {weights_out[f'reg_{h}h']}")

        if h in (3, 6):
            val_q, test_q = {}, {}
            for fam in FAMILIES:
                mdl = _make_p90_regressor(fam)
                mdl.fit(X_tr, y_tr)
                val_q[fam] = mdl.predict(X_va)
                test_q[fam] = mdl.predict(X_te)
            wq, val_pin = _ensemble_weights([val_q[f] for f in FAMILIES], y_va, "pinball")
            weights_out[f"p90_{h}h"] = {f: float(wi) for f, wi in zip(FAMILIES, wq)}
            ens_q_te = sum(wi * test_q[f] for f, wi in zip(FAMILIES, wq))
            coverage = float(np.mean(y_te <= ens_q_te))
            reg_results[f"p90_{h}h"] = {
                "coverage": coverage,
                "mean_p90": float(np.mean(ens_q_te)),
                "ensemble_weights": weights_out[f"p90_{h}h"],
                "validation_pinball": float(val_pin),
            }
            print(f"  p90_{h}h: coverage {coverage:.3f} (target 0.90), "
                  f"mean P90 {np.mean(ens_q_te):.2f} mm, weights {weights_out[f'p90_{h}h']}")

    evaluation["regression"] = reg_results

    # ---- Step 3: calibrated heavy-event ensembles + dual thresholds ----
    print("\n--- Heavy-event classifier ensembles ---")
    clf_results = {}
    for name, (src, thresh_mm) in BINARY.items():
        y_tr = train[name].to_numpy()
        y_va = val[name].to_numpy()
        y_te = test[name].to_numpy()
        pos = max(1, int(y_tr.sum()))
        neg = max(1, int((1 - y_tr).sum()))
        spw = neg / pos

        val_probs, test_probs = {}, {}
        for fam in FAMILIES:
            mdl = _make_classifier(fam, spw)
            mdl.fit(X_tr, y_tr)
            val_probs[fam] = mdl.predict_proba(X_va)[:, 1]
            test_probs[fam] = mdl.predict_proba(X_te)[:, 1]
        w, val_pr = _ensemble_weights([val_probs[f] for f in FAMILIES], y_va, "pr_auc")
        weights_out[f"clf_{name}"] = {f: float(wi) for f, wi in zip(FAMILIES, w)}
        ens_va = sum(wi * val_probs[f] for f, wi in zip(FAMILIES, w))
        ens_te_raw = sum(wi * test_probs[f] for f, wi in zip(FAMILIES, w))
        pw, pb = _platt_fit(ens_va, y_va)
        platt_out[name] = {"w": float(pw), "b": float(pb)}
        ens_te = _platt_apply(ens_te_raw, pw, pb)
        ens_va_cal = _platt_apply(ens_va, pw, pb)
        t_watch, f2_watch = _best_threshold(y_va, ens_va_cal, beta=2.0)
        t_warn, f1_warn = _best_threshold(y_va, ens_va_cal, beta=1.0)
        thresholds_out[name] = {"elevated": float(t_watch), "high": float(t_warn)}

        def _metrics(y_true, probs, t):
            pred = (probs >= t).astype(int)
            return {
                "threshold": float(t),
                "precision": float(precision_score(y_true, pred, zero_division=0)),
                "recall": float(recall_score(y_true, pred, zero_division=0)),
                "f1": float(f1_score(y_true, pred, zero_division=0)),
                "f2": float(fbeta_score(y_true, pred, beta=2, zero_division=0)),
                "caught": int(pred[y_true == 1].sum()),
                "n_actual": int(y_true.sum()),
                "n_predicted": int(pred.sum()),
            }

        clf_results[name] = {
            "pr_auc": float(average_precision_score(y_te, ens_te)),
            "roc_auc": float(roc_auc_score(y_te, ens_te)),
            "brier": float(np.mean((ens_te - y_te) ** 2)),
            "ensemble_weights": weights_out[f"clf_{name}"],
            "platt": platt_out[name],
            "thresholds": thresholds_out[name],
            "elevated": _metrics(y_te, ens_te, t_watch),
            "high": _metrics(y_te, ens_te, t_warn),
            "validation_pr_auc": float(val_pr),
        }
        e = clf_results[name]["elevated"]
        hh = clf_results[name]["high"]
        print(f"  {name}: PR-AUC {clf_results[name]['pr_auc']:.3f} ROC-AUC {clf_results[name]['roc_auc']:.3f} "
              f"weights {weights_out[f'clf_{name}']}")
        print(f"    elevated (t={t_watch:.2f}): P {e['precision']:.3f} R {e['recall']:.3f} F1 {e['f1']:.3f} "
              f"caught {e['caught']}/{e['n_actual']}")
        print(f"    high     (t={t_warn:.2f}): P {hh['precision']:.3f} R {hh['recall']:.3f} F1 {hh['f1']:.3f} "
              f"caught {hh['caught']}/{hh['n_actual']}")

    evaluation["classifiers"] = clf_results

    # ---- Step 4: refit every member on train+validation and save ----
    print("\n--- Refitting on train+validation and saving artifacts ---")
    X_tv = np.vstack([X_tr, X_va])
    for h in HORIZONS:
        target = f"y_{h}h"
        y_tv = np.concatenate([train[target].to_numpy(), val[target].to_numpy()])
        for fam in FAMILIES:
            mdl = _make_regressor(fam)
            mdl.fit(X_tv, y_tv)
            _save_member(mdl, fam, f"reg_{h}h")
        if h in (3, 6):
            for fam in FAMILIES:
                mdl = _make_p90_regressor(fam)
                mdl.fit(X_tv, y_tv)
                _save_member(mdl, fam, f"p90_{h}h")
    for name, (src, thresh_mm) in BINARY.items():
        y_tv = np.concatenate([train[name].to_numpy(), val[name].to_numpy()])
        pos = max(1, int(y_tv.sum()))
        neg = max(1, int((1 - y_tv).sum()))
        for fam in FAMILIES:
            mdl = _make_classifier(fam, neg / pos)
            mdl.fit(X_tv, y_tv)
            _save_member(mdl, fam, f"clf_{name}")

    with open(os.path.join(OUT_DIR, "ensemble_weights.json"), "w") as f:
        json.dump(weights_out, f, indent=2)
    with open(os.path.join(OUT_DIR, "thresholds.json"), "w") as f:
        json.dump(thresholds_out, f, indent=2)
    with open(os.path.join(OUT_DIR, "platt.json"), "w") as f:
        json.dump(platt_out, f, indent=2)
    with open(os.path.join(OUT_DIR, "feature_schema.json"), "w") as f:
        json.dump({
            "model": "rainfall-xgb-v3",
            "features": kept,
            "feature_count": len(kept),
            "pruned": pruned,
            "targets": list(feat.TARGET_COLUMNS),
            "binary_targets": list(BINARY.keys()),
            "families": list(FAMILIES),
        }, f, indent=2)
    with open(os.path.join(OUT_DIR, "metadata.json"), "w") as f:
        json.dump({
            "model": "rainfall-xgb-v3",
            "version": "v3",
            "trained": time.strftime("%Y-%m-%d %H:%M:%S"),
            "data_source": "Open-Meteo ERA5 archive (Bhubaneswar grid cell + Puri Coast + Offshore Bay)",
            "features": len(kept),
            "split": evaluation["split"],
            "seed": SEED,
            "families": list(FAMILIES),
            "note": "CAPE not used (all nulls from Open-Meteo). See data/README.md.",
        }, f, indent=2)
    with open(os.path.join(OUT_DIR, "evaluation.json"), "w") as f:
        json.dump(evaluation, f, indent=2)
    if not imp.empty:
        imp.to_csv(os.path.join(OUT_DIR, "permutation_importance.csv"), index=False)

    print(f"\nartifacts saved to {OUT_DIR}")
    print(f"total time: {time.time() - t0:.1f}s")
    return 0


if __name__ == "__main__":
    sys.exit(main())
