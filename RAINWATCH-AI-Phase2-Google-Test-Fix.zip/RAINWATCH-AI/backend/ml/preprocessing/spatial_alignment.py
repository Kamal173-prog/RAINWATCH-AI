"""Spatial alignment for RAINWATCH AI multi-source data (v3.2).

Rules (from the v3.2 brief):
- Verify coordinate reference systems and lat/lon ordering.
- Map Bhubaneswar to the correct pixel/grid cell for each source.
- Preserve neighbouring pixels.
- Extract coastal and offshore regions.
- Record the exact spatial extraction method.
- Do not silently combine mismatched spatial resolutions.

All sources use WGS84 (EPSG:4326) latitude/longitude unless stated
otherwise. Grid cells are identified by their centre coordinates.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

import numpy as np
import pandas as pd

# Reference locations (WGS84).
BHUBANESWAR = (20.281195, 85.843376)
PURI_COAST = (19.81, 85.83)
OFFSHORE_BAY = (19.50, 86.30)
CUTTACK = (20.4625, 85.8830)
PARADIP = (20.3167, 86.6167)
KHORDHA = (20.1833, 85.6167)
GOPALPUR = (19.2667, 84.9167)

# Grid resolutions (degrees) per source — used to snap a point to the
# correct cell centre. ERA5 is 0.25 deg, ERA5-Land / MSWEP / GSMaP are
# 0.1 deg, INSAT HEM/IMSRA are ~0.04 deg (4 km), GFS/IFS 0.11/0.25 deg.
GRID_RESOLUTION_DEG: dict[str, float] = {
    "era5": 0.25,
    "era5_land": 0.1,
    "mswep": 0.1,
    "gsmap": 0.1,
    "imerg": 0.1,
    "insat": 0.04,
    "gfs": 0.25,
    "ifs": 0.25,
    "imd_station": 0.0,  # point observation, no grid
}


@dataclass
class SpatialExtraction:
    """Records exactly how a value was extracted for a location."""

    source: str
    product: str
    lat: float
    lon: float
    grid_lat: float
    grid_lon: float
    grid_resolution_deg: float
    method: str  # "nearest_cell_centre" | "bilinear" | "point"
    neighbours: Optional[list[tuple[float, float]]] = None


def snap_to_grid(lat: float, lon: float, resolution_deg: float) -> tuple[float, float]:
    """Snap a lat/lon to the nearest grid-cell centre for a regular
    lat/lon grid with the given resolution. ERA5-style grids have cell
    centres at multiples of the resolution (e.g. 20.25, 20.50 for 0.25 deg
    when the grid origin is 0). Returns (grid_lat, grid_lon)."""
    if resolution_deg <= 0:
        return lat, lon
    glat = round(lat / resolution_deg) * resolution_deg
    glon = round(lon / resolution_deg) * resolution_deg
    return round(glat, 6), round(glon, 6)


def extract_point(
    source: str,
    lat: float,
    lon: float,
    product: str = "",
) -> SpatialExtraction:
    """Compute the grid cell for a location in a given source and record
    the extraction method. Use this whenever a value is taken from a
    gridded product so the provenance is explicit."""
    res = GRID_RESOLUTION_DEG.get(source, 0.1)
    if res <= 0:
        return SpatialExtraction(
            source=source, product=product, lat=lat, lon=lon,
            grid_lat=lat, grid_lon=lon, grid_resolution_deg=0.0,
            method="point",
        )
    glat, glon = snap_to_grid(lat, lon, res)
    return SpatialExtraction(
        source=source, product=product, lat=lat, lon=lon,
        grid_lat=glat, grid_lon=glon, grid_resolution_deg=res,
        method="nearest_cell_centre",
    )


def neighbour_cells(lat: float, lon: float, resolution_deg: float) -> list[tuple[float, float]]:
    """Return the 8 neighbouring grid-cell centres around a point
    (3x3 stencil excluding the centre). Used for spatial gradient and
    neighbour-max features."""
    glat, glon = snap_to_grid(lat, lon, resolution_deg)
    out = []
    for dlat in (-resolution_deg, 0.0, resolution_deg):
        for dlon in (-resolution_deg, 0.0, resolution_deg):
            if dlat == 0.0 and dlon == 0.0:
                continue
            out.append((round(glat + dlat, 6), round(glon + dlon, 6)))
    return out


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance in kilometres."""
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def spatial_gradient(
    centre: float,
    neighbours: list[float],
) -> dict[str, float]:
    """Compute spatial gradient statistics from a centre value and its
    8 neighbour values (same order as ``neighbour_cells``). Returns max,
    min, range and the neighbour maximum minus the centre."""
    if not neighbours:
        return {"neighbour_max": float("nan"), "neighbour_min": float("nan"),
                "spatial_range": float("nan"), "neighbour_max_minus_centre": float("nan")}
    arr = np.asarray(neighbours, dtype=float)
    return {
        "neighbour_max": float(np.nanmax(arr)),
        "neighbour_min": float(np.nanmin(arr)),
        "spatial_range": float(np.nanmax(arr) - np.nanmin(arr)),
        "neighbour_max_minus_centre": float(np.nanmax(arr) - centre),
    }
