"""Train rainfall-v3.2: v3 ensemble + NWP (GFS / ECMWF IFS) features.

Protocol (v3.2):
- Features: v3 41-feature set + GFS features (12) and/or IFS features (12).
  GFS covers 2021-03-23 onwards (95.7%); IFS covers 2024-02-02 onwards
  (47.1%) — IFS can only be evaluated on 2024+ data.
- Split: train 2021–2023, validation 2024, test 2025 (historical
  benchmark — 2025 was used for model selection in v3/v3.1, so it is
  NOT an untouched holdout), fresh evaluation 2026 (Jan–Nov, never used
  for any model selection). Seed 42.
- Classifiers: XGBoost + LightGBM + HistGradientBoosting ensemble with
  the v3.1 tuned hyperparameters (fixed; no re-tuning in this run),
  Platt calibration on validation, dual thresholds (elevated / high)
  optimised on validation for max precision subject to the v3.1 recall
  floors.
- Regressors: carried over from v3 unchanged (this script trains
  classifiers only; the v3.2 model directory stores classifier
  artifacts + the evaluation, and references the v3 regressors).
- Evaluation: PR-AUC, precision/recall/F1, Brier, calibration, and
  event-level metrics on BOTH 2025 (benchmark) and 2026 (fresh).
  The 2026 numbers are the primary evidence for whether v3.2 improves
  on v3.

Usage:
    python ml/train_rainfall_v32.py [--variant gfs|ifs|gfs_ifs|base]
    python ml/train_rainfall_v32.py --variant gfs --skip-tuning
"""

from __future__ import annotations

import argparse
import itertools
import json
import logging
import os
import sys
from datetime import datetime

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from sklearn.metrics import average_precision_score, brier_score_loss, roc_auc_score
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier
from lightgbm import LGBMClassifier
from xgboost import XGBClassifier

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger("train_rainfall_v32")

BACKEND_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.join(BACKEND_DIR, "models", "rainfall_xgb_v3_2")
os.makedirs(OUT_DIR, exist_ok=True)

SEED = 42

# v3 41-feature set (from models/rainfall_xgb_v3/feature_schema.json).
def load_v3_features() -> list[str]:
    with open(os.path.join(BACKEND_DIR, "models", "rainfall_xgb_v3", "feature_schema.json")) as f:
        return json.load(f)["features"]

GFS_FEATURES = [
    "gfs_precip", "gfs_precip_3h_sum", "gfs_precip_6h_sum", "gfs_precip_accel",
    "gfs_cape", "gfs_cape_3h_max", "gfs_cape_3h_change", "gfs_cape_x_humidity",
    "gfs_rh_tendency_3h", "gfs_wind_u", "gfs_wind_v", "gfs_precip_minus_era5",
]
IFS_FEATURES = [
    "ifs_precip", "ifs_precip_3h_sum", "ifs_precip_6h_sum", "ifs_precip_accel",
    "ifs_cape", "ifs_cape_3h_max", "ifs_cape_3h_change", "ifs_cape_x_humidity",
    "ifs_rh_tendency_3h", "ifs_wind_u", "ifs_wind_v", "ifs_precip_minus_era5",
]

# v3.1 tuned hyperparameters (per family, 3h>=10mm) — reused as fixed params.
BEST_PARAMS = {
    "y_3h_ge_10mm": {
        "xgb": {"max_depth": 4, "learning_rate": 0.05, "n_estimators": 300,
                "subsample": 0.8, "colsample_bytree": 0.8, "min_child_weight": 3,
                "reg_lambda": 10.0},
        "lgbm": {"max_depth": 4, "learning_rate": 0.05, "n_estimators": 300,
                 "subsample": 0.8, "colsample_bytree": 0.8, "min_child_samples": 30,
                 "reg_lambda": 10.0},
        "hgb": {"max_depth": 2, "learning_rate": 0.1, "max_iter": 300,
                "min_samples_leaf": 40, "l2_regularization": 20.0},
    },
    "y_6h_ge_10mm": {
        "xgb": {"max_depth": 5, "learning_rate": 0.1, "n_estimators": 300,
                "subsample": 0.9, "colsample_bytree": 0.9, "min_child_weight": 1,
                "reg_lambda": 5.0},
        "lgbm": {"max_depth": 5, "learning_rate": 0.1, "n_estimators": 300,
                 "subsample": 0.9, "colsample_bytree": 0.9, "min_child_samples": 20,
                 "reg_lambda": 5.0},
        "hgb": {"max_depth": 3, "learning_rate": 0.1, "max_iter": 300,
                "min_samples_leaf": 20, "l2_regularization": 5.0},
    },
    "y_3h_ge_5mm": {
        "xgb": {"max_depth": 5, "learning_rate": 0.1, "n_estimators": 300,
                "subsample": 0.9, "colsample_bytree": 0.9, "min_child_weight": 1,
                "reg_lambda": 5.0},
        "lgbm": {"max_depth": 5, "learning_rate": 0.1, "n_estimators": 300,
                 "subsample": 0.9, "colsample_bytree": 0.9, "min_child_samples": 20,
                 "reg_lambda": 5.0},
        "hgb": {"max_depth": 3, "learning_rate": 0.1, "max_iter": 300,
                "min_samples_leaf": 20, "l2_regularization": 5.0},
    },
}

RECALL_FLOORS = {
    "y_3h_ge_10mm": {"elevated": 0.25, "high": 0.20},
    "y_6h_ge_10mm": {"elevated": 0.50, "high": 0.25},
    "y_3h_ge_5mm": {"elevated": 0.50, "high": 0.30},
}

TARGETS = ("y_3h_ge_10mm", "y_6h_ge_10mm", "y_3h_ge_5mm")


def make_classifier(family: str, params: dict, pos_weight: float):
    if family == "xgb":
        return XGBClassifier(
            max_depth=params["max_depth"], learning_rate=params["learning_rate"],
            n_estimators=params["n_estimators"], subsample=params["subsample"],
            colsample_bytree=params["colsample_bytree"],
            min_child_weight=params["min_child_weight"],
            reg_lambda=params["reg_lambda"], scale_pos_weight=pos_weight,
            eval_metric="logloss", random_state=SEED, n_jobs=-1,
        )
    if family == "lgbm":
        return LGBMClassifier(
            max_depth=params["max_depth"], learning_rate=params["learning_rate"],
            n_estimators=params["n_estimators"], subsample=params["subsample"],
            colsample_bytree=params["colsample_bytree"],
            min_child_samples=params["min_child_samples"],
            reg_lambda=params["reg_lambda"],
            class_weight={0: 1.0, 1: pos_weight},
            random_state=SEED, n_jobs=-1, verbose=-1,
        )
    return HistGradientBoostingClassifier(
        max_depth=params["max_depth"], learning_rate=params["learning_rate"],
        max_iter=params["max_iter"], min_samples_leaf=params["min_samples_leaf"],
        l2_regularization=params["l2_regularization"],
        class_weight={0: 1.0, 1: pos_weight}, random_state=SEED,
    )


def _sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-np.clip(x, -500, 500)))


def platt_fit(p_raw: np.ndarray, y: np.ndarray) -> tuple[float, float]:
    eps = 1e-6
    p = np.clip(p_raw, eps, 1 - eps)
    logit = np.log(p / (1 - p)).reshape(-1, 1)
    lr = LogisticRegression(C=1.0, solver="lbfgs", max_iter=1000)
    lr.fit(logit, y)
    return float(lr.coef_[0][0]), float(lr.intercept_[0])


def platt_apply(p_raw: np.ndarray, w: float, b: float) -> np.ndarray:
    eps = 1e-6
    p = np.clip(p_raw, eps, 1 - eps)
    logit = np.log(p / (1 - p))
    return _sigmoid(w * logit + b)


def threshold_max_precision(y: np.ndarray, p: np.ndarray, recall_floor: float):
    """Threshold maximising precision subject to recall >= floor."""
    best = None
    for t in np.arange(0.02, 0.96, 0.01):
        pred = p >= t
        tp = int(((y == 1) & pred).sum())
        fp = int(((y == 0) & pred).sum())
        fn = int(((y == 1) & ~pred).sum())
        rec = tp / max(1, tp + fn)
        prec = tp / max(1, tp + fp)
        if rec < recall_floor:
            continue
        if best is None or prec > best[1]:
            best = (float(t), float(prec), float(rec))
    if best is None:
        # No threshold meets the floor: use the threshold with max recall.
        best_rec, best_t = -1.0, 0.5
        for t in np.arange(0.02, 0.96, 0.01):
            pred = p >= t
            tp = int(((y == 1) & pred).sum())
            fn = int(((y == 1) & ~pred).sum())
            rec = tp / max(1, tp + fn)
            if rec > best_rec:
                best_rec, best_t = rec, float(t)
        return best_t, None, best_rec
    return best


def hour_metrics(y: np.ndarray, p: np.ndarray, threshold: float) -> dict:
    pred = p >= threshold
    tp = int(((y == 1) & pred).sum())
    fp = int(((y == 0) & pred).sum())
    fn = int(((y == 1) & ~pred).sum())
    tn = int(((y == 0) & ~pred).sum())
    prec = tp / max(1, tp + fp)
    rec = tp / max(1, tp + fn)
    f1 = 2 * prec * rec / max(1e-9, prec + rec)
    return {
        "threshold": float(threshold), "precision": prec, "recall": rec, "f1": f1,
        "tp": tp, "fp": fp, "fn": fn, "tn": tn,
        "alerts_per_100h": 100.0 * (tp + fp) / max(1, len(y)),
    }


def event_metrics(y: np.ndarray, p: np.ndarray, threshold: float) -> dict:
    """Event-level metrics: group consecutive positive hours into events."""
    pred = (p >= threshold).astype(int)
    true = y.astype(int)
    def _events(arr: np.ndarray) -> list[tuple[int, int]]:
        ev, start = [], None
        for i, v in enumerate(arr):
            if v == 1 and start is None:
                start = i
            elif v == 0 and start is not None:
                ev.append((start, i - 1))
                start = None
        if start is not None:
            ev.append((start, len(arr) - 1))
        return ev
    true_ev = _events(true)
    pred_ev = _events(pred)
    hit = 0
    for s, e in true_ev:
        if any(ps <= e and pe >= s for ps, pe in pred_ev):
            hit += 1
    tp_ev = 0
    for s, e in pred_ev:
        if any(ts <= e and te >= s for ts, te in true_ev):
            tp_ev += 1
    return {
        "n_true_events": len(true_ev),
        "n_pred_events": len(pred_ev),
        "tp_events": hit,
        "event_recall": hit / max(1, len(true_ev)),
        "event_precision": tp_ev / max(1, len(pred_ev)),
    }


def main() -> None:
    ap = argparse.ArgumentParser(description="Train rainfall-v3.2 classifiers")
    ap.add_argument("--variant", default="gfs",
                    choices=["base", "gfs", "ifs", "gfs_ifs"],
                    help="Feature variant: base (v3 41 only), gfs, ifs, gfs_ifs")
    ap.add_argument("--out-dir", default=OUT_DIR)
    args = ap.parse_args()

    v3_feats = load_v3_features()
    extra: list[str] = []
    if args.variant in ("gfs", "gfs_ifs"):
        extra += GFS_FEATURES
    if args.variant in ("ifs", "gfs_ifs"):
        extra += IFS_FEATURES
    features = v3_feats + extra
    log.info("variant=%s features=%d (v3=%d + extra=%d)",
             args.variant, len(features), len(v3_feats), len(extra))

    df = pd.read_csv(
        os.path.join(BACKEND_DIR, "data", "model_ready", "bhubaneswar_features_v32.csv"),
        parse_dates=["timestamp"],
    )
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True).dt.tz_localize(None)
    # Chronological split: train 2021-23, val 2024, test 2025 (benchmark),
    # fresh eval 2026.
    train = df[df["timestamp"].dt.year.isin([2021, 2022, 2023])].reset_index(drop=True)
    val = df[df["timestamp"].dt.year == 2024].reset_index(drop=True)
    test = df[df["timestamp"].dt.year == 2025].reset_index(drop=True)
    fresh = df[df["timestamp"].dt.year == 2026].reset_index(drop=True)
    # Drop features that are entirely NaN in the training set (e.g. IFS
    # features, which only exist from 2024-02). A feature with no training
    # data cannot be learned; HistGB also fails on all-NaN columns.
    # This is recorded in the evaluation metadata.
    all_nan = [c for c in features if train[c].isna().all()]
    if all_nan:
        log.warning("dropping %d features with no training data: %s", len(all_nan), all_nan)
        features = [c for c in features if c not in all_nan]
    log.info("train=%d val=%d test(2025)=%d fresh(2026)=%d",
             len(train), len(val), len(test), len(fresh))
    for t in TARGETS:
        log.info("  %s positives: train=%d val=%d test=%d fresh=%d",
                 t, int(train[t].sum()), int(val[t].sum()),
                 int(test[t].sum()), int(fresh[t].sum()))

    out_dir = os.path.join(args.out_dir, args.variant)
    os.makedirs(out_dir, exist_ok=True)

    evaluation: dict = {
        "model": f"rainfall-xgb-v3.2-{args.variant}",
        "variant": args.variant,
        "features": features,
        "features_dropped_no_training_data": all_nan,
        "n_features": len(features),
        "split": {"train": "2021-2023", "validation": "2024",
                  "test_2025_benchmark": "2025",
                  "fresh_eval_2026": "2026 (never used for model selection)"},
        "note": (
            "2025 is a historical benchmark (used for model selection in "
            "v3/v3.1). 2026 is the fresh evaluation period. The 2026 "
            "numbers are the primary evidence for improvement."
        ),
        "classifiers": {},
    }

    for target in TARGETS:
        y_tr = train[target].to_numpy()
        y_va = val[target].to_numpy()
        y_te = test[target].to_numpy()
        y_fr = fresh[target].to_numpy()
        X_tr = train[features].to_numpy(dtype=float)
        X_va = val[features].to_numpy(dtype=float)
        X_te = test[features].to_numpy(dtype=float)
        X_fr = fresh[features].to_numpy(dtype=float)
        pos = max(1, int(y_tr.sum()))
        neg = max(1, int((1 - y_tr).sum()))
        pos_weight = neg / pos

        # Train each family on train; ensemble weights on validation.
        val_probs: dict[str, np.ndarray] = {}
        for family in ("xgb", "lgbm", "hgb"):
            model = make_classifier(family, BEST_PARAMS[target][family], pos_weight)
            model.fit(X_tr, y_tr)
            val_probs[family] = model.predict_proba(X_va)[:, 1]
        P_va = np.column_stack([val_probs[f] for f in ("xgb", "lgbm", "hgb")])
        best_w, best_s = None, None
        for w in itertools.product([0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0], repeat=3):
            if abs(sum(w) - 1.0) > 1e-9:
                continue
            s = average_precision_score(y_va, P_va @ np.array(w))
            if best_s is None or s > best_s:
                best_w, best_s = w, float(s)
        ens_va = P_va @ np.array(best_w)
        w_p, b_p = platt_fit(ens_va, y_va)
        cal_va = platt_apply(ens_va, w_p, b_p)
        thresholds: dict[str, float] = {}
        for level, floor in RECALL_FLOORS[target].items():
            t, _, _ = threshold_max_precision(y_va, cal_va, floor)
            thresholds[level] = t

        # Refit on train+val, evaluate on 2025 (benchmark) and 2026 (fresh).
        tv = pd.concat([train, val], ignore_index=True)
        X_tv = tv[features].to_numpy(dtype=float)
        y_tv = tv[target].to_numpy()
        pos2 = max(1, int(y_tv.sum()))
        neg2 = max(1, int((1 - y_tv).sum()))
        te_probs: dict[str, np.ndarray] = {}
        fr_probs: dict[str, np.ndarray] = {}
        saved: dict[str, object] = {}
        for family in ("xgb", "lgbm", "hgb"):
            model = make_classifier(family, BEST_PARAMS[target][family], neg2 / pos2)
            model.fit(X_tv, y_tv)
            te_probs[family] = model.predict_proba(X_te)[:, 1]
            fr_probs[family] = model.predict_proba(X_fr)[:, 1]
            saved[family] = model
        # Save the refit members.
        for family, model in saved.items():
            if family == "xgb":
                model.save_model(os.path.join(out_dir, f"clf_{target.replace('y_', '')}_{family}.json"))
            elif family == "lgbm":
                model.booster_.save_model(os.path.join(out_dir, f"clf_{target.replace('y_', '')}_{family}.txt"))
            else:
                import joblib
                joblib.dump(model, os.path.join(out_dir, f"clf_{target.replace('y_', '')}_{family}.pkl"))

        def _eval(y: np.ndarray, probs: dict[str, np.ndarray]) -> dict:
            ens = np.column_stack([probs[f] for f in ("xgb", "lgbm", "hgb")]) @ np.array(best_w)
            cal = platt_apply(ens, w_p, b_p)
            out = {
                "pr_auc": float(average_precision_score(y, cal)),
                "roc_auc": float(roc_auc_score(y, cal)),
                "brier": float(brier_score_loss(y, cal)),
                "levels": {},
            }
            for level, t in thresholds.items():
                hm = hour_metrics(y, cal, t)
                em = event_metrics(y, cal, t)
                out["levels"][level] = {**hm, **em}
            return out

        res = {
            "ensemble_weights": dict(zip(("xgb", "lgbm", "hgb"), [float(x) for x in best_w])),
            "val_pr_auc": float(best_s),
            "platt": {"w": w_p, "b": b_p},
            "thresholds": thresholds,
            "test_2025_benchmark": _eval(y_te, te_probs),
            "fresh_2026": _eval(y_fr, fr_probs),
        }
        evaluation["classifiers"][target] = res
        t25 = res["test_2025_benchmark"]
        t26 = res["fresh_2026"]
        log.info("%s: 2025 PR-AUC %.4f | 2026 PR-AUC %.4f | "
                 "2026 elevated P %.3f R %.3f | high P %.3f R %.3f",
                 target, t25["pr_auc"], t26["pr_auc"],
                 t26["levels"]["elevated"]["precision"], t26["levels"]["elevated"]["recall"],
                 t26["levels"]["high"]["precision"], t26["levels"]["high"]["recall"])

    # Save evaluation + thresholds + weights + feature schema.
    with open(os.path.join(out_dir, "evaluation.json"), "w") as f:
        json.dump(evaluation, f, indent=2)
    with open(os.path.join(out_dir, "thresholds.json"), "w") as f:
        json.dump({t: evaluation["classifiers"][t]["thresholds"] for t in TARGETS}, f, indent=2)
    with open(os.path.join(out_dir, "ensemble_weights.json"), "w") as f:
        json.dump({t: evaluation["classifiers"][t]["ensemble_weights"] for t in TARGETS}, f, indent=2)
    with open(os.path.join(out_dir, "platt.json"), "w") as f:
        json.dump({t: evaluation["classifiers"][t]["platt"] for t in TARGETS}, f, indent=2)
    with open(os.path.join(out_dir, "feature_schema.json"), "w") as f:
        json.dump({"features": features, "targets": list(TARGETS)}, f, indent=2)
    with open(os.path.join(out_dir, "metadata.json"), "w") as f:
        json.dump({
            "model": evaluation["model"],
            "variant": args.variant,
            "created_utc": datetime.now().isoformat() + "Z",
            "regressors": "carried over from rainfall-xgb-v3 (unchanged)",
            "data_sources": ["ERA5 (Open-Meteo)", "upwind spatial (ERA5)"] +
                            (["GFS (Open-Meteo Historical Forecast API)"] if "gfs" in args.variant else []) +
                            (["ECMWF IFS (Open-Meteo Historical Forecast API)"] if "ifs" in args.variant else []),
            "split": evaluation["split"],
        }, f, indent=2)
    log.info("v3.2-%s saved to %s", args.variant, out_dir)


if __name__ == "__main__":
    main()
