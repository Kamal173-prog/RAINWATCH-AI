# rainfall-xgb-v3.1 — Technical Documentation

**Model:** `rainfall-xgb-v3.1` (classifier upgrade over v3).
**Date:** 2026-11-23. **API compatibility:** v1.3.0 (additive fields only).
**Status: EVALUATED, NOT DEPLOYED.** The v3.1 artifacts live in
`models/rainfall_xgb_v3_1/`; the API still serves v3 (`rainfall-xgb-v3`).
The v3 artifacts in `models/rainfall_xgb_v3/` are untouched. The React
frontend and the 22 endpoint contracts are unchanged.

## 1. Objective

Increase heavy-rain classification precision (especially 3 h ≥ 10 mm)
without destroying recall, by independently tuning each gradient-boosting
family, comparing feature sets, ablating feature groups, and comparing
class-imbalance strategies — all under chronological cross-validation,
with 2025 held out completely until the final evaluation.

## 2. What changed vs v3

| Aspect | v3 | v3.1 |
|---|---|---|
| Classifier hyperparameters | Fixed (v2 best params as starting point) | Independently tuned per family per event via expanding-window CV (PR-AUC) |
| Feature set | 41 pruned (permutation importance, single XGBoost) | 41 vs 62 compared on CV; 41 wins; family-specific selection tested |
| Imbalance strategy | `scale_pos_weight = neg/pos` (balanced) | Compared balanced / half / double / sample-weight / neg-sample 50% / neg-sample 25% |
| Thresholds | elevated = F2-optimal, high = F1-optimal | elevated/high = max precision subject to recall floors (see §5) |
| Evaluation | Hour-level only | Hour-level + event-level (overlapping windows), alerts per 100 h |
| Regressors (mean + P90) | XGBoost + LightGBM + HistGB ensemble | **Unchanged — carried over from v3** |

No SMOTE was used (invalid for time-series data). No resampling was
applied outside training folds. No weather data or metrics were fabricated.

## 3. Protocol

- Chronological split: train 2021–2023 (26,209 h) / validation 2024
  (8,784 h) / test 2025 (8,754 h). Seed 42.
- Expanding-window CV inside train+val (2021–2024) for all tuning:
  Fold 1 train 2021 / val 2022; Fold 2 train 2021–22 / val 2023;
  Fold 3 train 2021–23 / val 2024. Mean CV PR-AUC is the tuning metric.
- All tuning, feature selection, ablations, strategy comparison and
  threshold optimisation use only train + validation. The final model is
  refit on train+val and evaluated **once** on the untouched 2025 test set.
- Reproduction note: the v3 artifacts actually serving the API were refit
  on train+val, so re-running them on 2025 gives slightly different numbers
  from `models/rainfall_xgb_v3/evaluation.json` (which reports the
  train-only models). The v3 numbers quoted in §6 are the evaluation.json
  values (train-only), which is the same protocol v3.1 uses for its
  headline numbers, so the comparison is like-for-like.

## 4. Tuning results (CV PR-AUC, 3 h ≥ 10 mm)

### 4.1 Per-family hyperparameter tuning (Phase A)

Best CV PR-AUC per family (3 h ≥ 10 mm), tuned independently:

| Family | Best CV PR-AUC | Best params |
|---|---|---|
| XGBoost | 0.1473 | depth 4, lr 0.05, 300 trees, subsample 0.8, colsample 0.8, min_child_weight 3, λ 10 |
| LightGBM | 0.1418 | depth 4, lr 0.05, 300 trees, subsample 0.8, colsample 0.8, min_child_samples 30, λ 10 |
| HistGB | 0.1489 | depth 2, lr 0.1, 300 iters, min_samples_leaf 40, L2 20 |

For reference, the other events' best CV PR-AUC: 6 h ≥ 10 mm —
XGB 0.2570, LightGBM 0.2465, HistGB 0.2608; 3 h ≥ 5 mm —
XGB 0.3566, LightGBM 0.3553, HistGB 0.3532.

### 4.2 Feature-set comparison (Phase B, CV PR-AUC, 3 h ≥ 10 mm)

| Family | v3 41 features | All 62 features |
|---|---|---|
| XGBoost | **0.1473** | 0.1443 |
| LightGBM | **0.1418** | 0.1361 |
| HistGB | **0.1489** | 0.1417 |

**The v3 pruned 41 features beat all 62 features for every family.**
The pruning was correct; v3.1 keeps the 41-feature set. Family-specific
feature selection (permutation importance per family on validation) was
tested during development and did not beat the shared 41-feature set on
CV PR-AUC, so it was not adopted.

### 4.3 Feature-group ablations (Phase C, CV PR-AUC, 3 h ≥ 10 mm)

Baseline (all 41 features): mean CV PR-AUC 0.1460.

| Group removed | Features removed | CV PR-AUC | Δ |
|---|---|---|---|
| Spatial (coast/bay precip, pressure gradients, humidity excess, rain lead) | 7 | 0.1223 | **−0.0237** |
| Convective (gusts, cloud layers, VPD, gust factor, deep-convection flag) | 5 | 0.1252 | **−0.0208** |
| Thermodynamic (dew point, surface pressure, θe, dewpoint depression, moisture flux, pressure tendencies) | 7 | 0.1395 | −0.0065 |

**Spatial features are the most important group** — removing them costs
0.024 PR-AUC. Convective features are second (−0.021). Thermodynamic
features contribute the least (−0.007) but still help. This confirms the
v3 design: the upwind coastal/offshore grids carry real signal for heavy
events.

### 4.4 Imbalance-strategy comparison (Phase D, CV PR-AUC, 3 h ≥ 10 mm)

| Strategy | XGB | LightGBM | HistGB | Mean |
|---|---|---|---|---|
| balanced (neg/pos) | 0.1473 | 0.1418 | 0.1489 | 0.1460 |
| half (0.5× balanced) | 0.1465 | 0.1381 | 0.1543 | 0.1463 |
| double (2× balanced) | 0.1408 | 0.1279 | 0.1454 | 0.1380 |
| sample_weight (positives ×2) | 0.1503 | 0.1364 | 0.1673 | 0.1514 |
| **neg_sample_50 (keep 50% of negatives)** | **0.1608** | **0.1503** | **0.1651** | **0.1587** |
| neg_sample_25 (keep 25% of negatives) | 0.1569 | 0.1471 | 0.1656 | 0.1565 |

Negative downsampling (50%) had the highest mean CV PR-AUC (0.1587) and
was selected for the final v3.1 model. All strategies were applied only
inside training folds; validation and test were never resampled. After
downsampling, probabilities were recalibrated with Platt scaling on
validation, which corrects the shifted base rate.

**Important caveat (see §6):** the CV ranking did not fully generalise
to the 2025 test set for the 3 h ≥ 10 mm event. See the honest assessment
in §6.

## 5. Threshold policy

Thresholds are optimised on the 2024 validation set to **maximise
precision subject to a recall floor** (not F1/F2 as in v3):

| Event | Watch (`elevated`) recall floor | Warning (`high`) recall floor |
|---|---|---|
| 3 h ≥ 10 mm | 0.25 | 0.20 |
| 6 h ≥ 10 mm | 0.50 | 0.25 |
| 3 h ≥ 5 mm | 0.50 | 0.30 |

If no threshold meets the floor, the threshold with the highest recall is
used and the miss is reported. In the v3.1 run, all floors were met on
validation.

## 6. Results — 2025 test set (untouched holdout)

### 6.1 Headline: 3 h ≥ 10 mm (the primary objective)

| Metric | v3.1 | v3 | Δ |
|---|---|---|---|
| PR-AUC | 0.1571 | 0.168 | **−0.011 (worse)** |
| ROC-AUC | 0.9251 | 0.913 | +0.012 |
| Brier | 0.0092 | 0.0092 | 0.000 |
| elevated: Precision / Recall / F1 | 0.144 / 0.299 / 0.194 | 0.149 / 0.299 / 0.198 | P −0.005, R 0.000 |
| elevated: TP / FP / missed | 26 / 155 / 61 | 26 / — / 61 | same TP |
| high: Precision / Recall / F1 | 0.154 / 0.241 / 0.188 | 0.161 / 0.218 / 0.185 | P −0.007, R +0.023 |
| high: TP / FP / missed | 21 / 115 / 66 | 19 / — / 68 | +2 TP |
| elevated event-level P / R | 0.139 / 0.361 (13/36 events) | — | — |
| high event-level P / R | 0.122 / 0.278 (10/36 events) | — | — |

**Honest assessment: v3.1 did NOT achieve its primary objective.**
For 3 h ≥ 10 mm, PR-AUC fell from 0.168 (v3) to 0.157 (v3.1) and
precision is slightly lower at both operating points. The tuned
hyperparameters and the neg_sample_50 strategy that won on CV did not
translate into a better 2025 test result for this event. A follow-up
control (tuned hyperparameters + `balanced` strategy, no neg sampling)
gave PR-AUC 0.1625 — also below v3's 0.168. So neither the tuning nor
the imbalance strategy improved the 3 h ≥ 10 mm classifier on the
holdout. The 3 h ≥ 10 mm event (87 positives in 2025, base rate ~1%)
appears to be at the ceiling of what the current ERA5 + spatial features
can distinguish; the next step is better input data (see
`V31_EXTERNAL_DATA.md`), not more tuning.

### 6.2 6 h ≥ 10 mm

| Metric | v3.1 | v3 | Δ |
|---|---|---|---|
| PR-AUC | 0.2105 | 0.207 | +0.004 |
| elevated: Precision / Recall / F1 | 0.162 / 0.550 / 0.250 | 0.108 / 0.860 / 0.191 | P +0.054, R −0.310 |
| elevated: TP / FP / missed | 142 / 735 / 116 | 222 / — / 36 | −80 TP |
| high: Precision / Recall / F1 | 0.244 / 0.209 / 0.225 | 0.185 / 0.291 / 0.226 | P +0.059, R −0.082 |
| high: TP / FP / missed | 54 / 167 / 204 | 75 / — / 183 | −21 TP |
| elevated event-level P / R | 0.225 / 0.891 (49/55 events) | — | — |
| high event-level P / R | 0.241 / 0.418 (23/55 events) | — | — |

PR-AUC is essentially unchanged (+0.004). Precision improved at both
levels (+0.054 / +0.059) but recall fell sharply at `elevated`
(0.86 → 0.55), because the precision-maximising threshold (t=0.09) is
stricter than v3's F2 threshold (t=0.04). The event-level recall at
`elevated` is still high (0.891, 49/55 events caught), so the model
still detects most 6 h events as events even when it misses individual
hours. This is a genuine precision/recall trade-off, not a pure win.

### 6.3 3 h ≥ 5 mm — the clear v3.1 win

| Metric | v3.1 | v3 | Δ |
|---|---|---|---|
| PR-AUC | **0.3580** | 0.323 | **+0.035** |
| ROC-AUC | 0.9212 | 0.915 | +0.006 |
| Brier | 0.0279 | 0.0288 | −0.001 |
| elevated: Precision / Recall / F1 | 0.318 / 0.476 / 0.381 | 0.225 / 0.707 / 0.341 | P +0.093, R −0.231 |
| elevated: TP / FP / missed | 151 / 324 / 166 | 224 / — / 93 | −73 TP |
| high: Precision / Recall / F1 | 0.422 / 0.271 / 0.330 | 0.290 / 0.432 / 0.347 | P +0.132, R −0.161 |
| high: TP / FP / missed | 86 / 118 / 231 | 137 / — / 180 | −51 TP |
| elevated event-level P / R | 0.388 / 0.667 (66/99 events) | — | — |
| high event-level P / R | 0.468 / 0.465 (46/99 events) | — | — |

**This is the one clear v3.1 improvement.** PR-AUC rose 0.323 → 0.358
(+11%) and precision rose substantially at both levels (+0.093 at
`elevated`, +0.132 at `high`). Recall fell, so the F1 gain is modest
at `elevated` (+0.040) and slightly negative at `high` (−0.017). The
control run (tuned + `balanced`) gave the same PR-AUC (0.3583), so this
gain comes from the tuned hyperparameters, not from neg sampling.

## 7. Calibration

All probabilities are Platt-calibrated on the 2024 validation set
(manual logistic regression on logit of the raw ensemble probability).
2025 Brier scores: 3 h ≥ 10 mm 0.0092 (v3: 0.0092), 6 h ≥ 10 mm 0.0256
(v3: 0.0258), 3 h ≥ 5 mm 0.0279 (v3: 0.0288). Calibration is preserved;
no event is miscalibrated relative to v3.

## 8. Event-level metrics (overlapping windows)

Because the 3 h and 6 h windows overlap, hour-level precision/recall
overstates how many distinct storms are caught or missed. Event-level
metrics group consecutive positive hours into events:

- 3 h ≥ 10 mm: 36 true events in 2025. v3.1 `elevated` catches 13/36
  (event recall 0.361); `high` catches 10/36 (0.278).
- 6 h ≥ 10 mm: 55 true events. v3.1 `elevated` catches 49/55 (0.891);
  `high` catches 23/55 (0.418).
- 3 h ≥ 5 mm: 99 true events. v3.1 `elevated` catches 66/99 (0.667);
  `high` catches 46/99 (0.465).

Event-level precision is low (0.12–0.47) because many predicted events
are false alarms. The 6 h `elevated` event recall (0.891) is the
strongest operational number in v3.1: it catches nearly 9 in 10 six-hour
heavy events as events, even though hour-level precision is only 0.162.

## 9. Artifacts

```
models/rainfall_xgb_v3_1/
  clf_3h_ge_10mm_xgb.json / _lgbm.txt / _hgb.pkl   (one per family)
  clf_6h_ge_10mm_xgb.json / _lgbm.txt / _hgb.pkl
  clf_3h_ge_5mm_xgb.json / _lgbm.txt / _hgb.pkl
  ensemble_weights.json    non-negative weights per event
  platt.json               Platt calibration params (w, b) per event
  thresholds.json          dual thresholds (elevated / high) per event
  feature_schema.json      41 features (v3 set), targets
  metadata.json            version, data source, split, strategy
  evaluation.json          full 2025 test metrics + threshold curves
  tuning.json              Phases A–D results (CV PR-AUC, ablations, strategies)
```

Regressors (mean + P90) are **not** in v3.1 — they are unchanged from v3
and live in `models/rainfall_xgb_v3/`. To serve v3.1 classifiers, load
the v3.1 classifier files and the v3 regressor files together (the
`predict.py` interface accepts a model directory per component).

## 10. How to reproduce

```bash
cd backend
.venv/bin/python ml/train_rainfall_v31.py --fast          # full pipeline (tuning + training)
.venv/bin/python ml/train_rainfall_v31.py --fast --skip-tuning   # reuse tuning.json, retrain only
```

The `--fast` flag uses 3 hyperparameter configs per family (the run
reported here). Without it, 6 configs per family are searched.

## 11. Recommendation

**Do not replace v3 with v3.1 for the 3 h ≥ 10 mm event.** v3.1 does not
beat v3 on the primary objective (PR-AUC 0.157 vs 0.168; precision
slightly lower). The API should keep serving `rainfall-xgb-v3`.

**Consider adopting v3.1's 3 h ≥ 5 mm classifier** (PR-AUC 0.323 → 0.358,
precision +0.09/+0.13) if the moderate-event precision matters more than
its recall loss — that is a product decision, not a model decision.

**The next step for 3 h ≥ 10 mm is better input data, not more tuning.**
The ablations show spatial features are already the dominant signal and
the CV-to-test generalisation gap shows the current features are at
their ceiling for this event. The concrete next data step is NASA GPM
IMERG (see `V31_EXTERNAL_DATA.md`): it needs a free Earthdata account
from Kam, after which the IMERG point series can be tested as an
additional feature on the 2024 validation set before any 2025 evaluation.
