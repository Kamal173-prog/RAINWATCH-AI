import { motion } from 'framer-motion'
import {
  BarChart3,
  Cloud,
  CloudRain,
  Download,
  Eye,
  Gauge,
  LineChart as LineIcon,
  RefreshCw,
  Thermometer,
  Wind,
  Droplets,
  Compass,
  AreaChart as AreaIcon,
} from 'lucide-react'
import { useState } from 'react'
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip as RTooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { toast } from 'sonner'
import { Badge, DemoBadge, RainBadge } from '../components/common/Badge'
import { Button } from '../components/common/Button'
import { ChartCard } from '../components/common/ChartCard'
import { DataTable, type Column } from '../components/common/DataTable'
import { PageHeader } from '../components/common/PageHeader'
import { SegmentedControl } from '../components/common/SegmentedControl'
import { Select } from '../components/common/Select'
import { SkeletonCard, StatePanel } from '../components/common/Skeleton'
import { useDemo } from '../context/DemoContext'
import { useSelectedLocation } from '../context/LocationContext'
import { useSettings } from '../context/SettingsContext'
import { useAsyncData } from '../hooks/useAsyncData'
import { demoApi } from '../services/dataService'
import type { WeatherReading } from '../types'
import { downloadCsv } from '../utils/csv'
import {
  classifyRainfall,
  formatTime,
  rainfallColor,
  temperatureLabel,
  windDirectionLabel,
  windLabel,
} from '../utils/colors'

const tooltipStyle = {
  background: 'var(--rw-card)', border: '1px solid var(--rw-border)', borderRadius: 12,
  color: 'var(--rw-ink)', fontSize: 12, boxShadow: '0 20px 50px -25px rgba(0,0,0,0.9)',
}

const RANGES = [
  { value: '12', label: 'Last 12 hours' },
  { value: '24', label: 'Last 24 hours' },
  { value: '48', label: 'Last 48 hours' },
  { value: '72', label: 'Last 72 hours' },
]

const METRICS = [
  { value: 'rainfall', label: 'Rainfall' },
  { value: 'temperature', label: 'Temperature' },
  { value: 'humidity', label: 'Humidity' },
  { value: 'wind', label: 'Wind speed' },
]

export function LiveWeather() {
  const { locationId, setLocationId } = useSelectedLocation()
  const { settings } = useSettings()
  const { version } = useDemo()
  const [range, setRange] = useState('24')
  const [metric, setMetric] = useState('rainfall')
  const [chartType, setChartType] = useState<'line' | 'bar' | 'area'>('area')

  const { data: locations } = useAsyncData(() => demoApi.listLocations(), [])
  const { data, loading, error, reload } = useAsyncData(
    () => demoApi.fetchWeather(locationId, Number(range)),
    [locationId, range, version],
  )

  const current = data?.[data.length - 1] ?? null

  const chartData = (data ?? []).map((r) => ({
    time: formatTime(r.timestamp),
    rainfall: r.rainfallMmHr,
    temperature: settings.units === 'metric' ? r.temperatureC : r.temperatureC * 9 / 5 + 32,
    humidity: r.humidityPct,
    wind: settings.units === 'metric' ? r.windSpeedKmph : r.windSpeedKmph * 0.621371,
  }))

  const conditions = current ? [
    { label: 'Temperature', value: temperatureLabel(current.temperatureC, settings.units), icon: Thermometer, color: '#F0823F', desc: 'Feels-like estimated' },
    { label: 'Humidity', value: `${current.humidityPct}%`, icon: Droplets, color: '#6FD6C2', desc: 'Relative humidity' },
    { label: 'Wind Speed', value: windLabel(current.windSpeedKmph, settings.units), icon: Wind, color: '#6FD6C2', desc: windDirectionLabel(current.windDirectionDeg) + ' direction' },
    { label: 'Pressure', value: `${current.pressureHpa}`, unit: 'hPa', icon: Gauge, color: '#B19BFA', desc: 'Atmospheric pressure' },
    { label: 'Visibility', value: `${current.visibilityKm}`, unit: 'km', icon: Eye, color: '#8B9996', desc: 'Horizontal visibility' },
    { label: 'Cloud Cover', value: `${current.cloudCoverPct}%`, icon: Cloud, color: '#8B9996', desc: 'Sky coverage' },
    { label: 'Rainfall Intensity', value: `${current.rainfallMmHr}`, unit: 'mm/hr', icon: CloudRain, color: rainfallColor(current.rainfallMmHr), desc: 'Instantaneous rate' },
    { label: 'Wind Direction', value: `${current.windDirectionDeg}°`, icon: Compass, color: '#69D2A0', desc: windDirectionLabel(current.windDirectionDeg) },
  ] : []

  const primaryKey = metric === 'rainfall' ? 'rainfall' : metric as 'temperature' | 'humidity' | 'wind'
  const primaryColor = metric === 'rainfall' ? 'var(--rw-accent)' : metric === 'temperature' ? '#F0823F' : metric === 'humidity' ? '#6FD6C2' : '#B19BFA'
  const primaryName = metric.charAt(0).toUpperCase() + metric.slice(1)

  const renderSeries = (dataKey: 'rainfall' | 'temperature' | 'humidity' | 'wind', color: string, name: string) => {
    if (chartType === 'bar') {
      return <Bar dataKey={dataKey} name={name} fill={color} radius={[3, 3, 0, 0]} animationDuration={700}>
        {(data ?? []).map((_, i) => <Cell key={i} fill={dataKey === 'rainfall' ? rainfallColor(data?.[i]?.rainfallMmHr ?? 0) : color} />)}
      </Bar>
    }
    if (chartType === 'line') {
      return <Line type="monotone" dataKey={dataKey} name={name} stroke={color} strokeWidth={2} dot={false} activeDot={{ r: 4 }} animationDuration={700} />
    }
    return <Area type="monotone" dataKey={dataKey} name={name} stroke={color} strokeWidth={2} fill={color} fillOpacity={0.18} dot={false} animationDuration={700} />
  }

  const exportCsv = () => {
    // Weather is demo-generated by the backend for every location (no
    // observation feed exists), so every row is honestly labelled demo.
    downloadCsv(`rainwatch-weather-${locationId}-${range}h`,
      ['Timestamp', 'Temperature (°C)', 'Humidity (%)', 'Wind (km/h)', 'Wind Dir (°)', 'Pressure (hPa)', 'Visibility (km)', 'Cloud (%)', 'Rainfall (mm/hr)', 'Source'],
      (data ?? []).map((r) => [r.timestamp, r.temperatureC, r.humidityPct, r.windSpeedKmph, r.windDirectionDeg, r.pressureHpa, r.visibilityKm, r.cloudCoverPct, r.rainfallMmHr, 'demo']))
    toast.success('Weather series exported as CSV')
  }

  const tableColumns: Column<WeatherReading>[] = [
    { key: 'time', header: 'Time', render: (r) => <span className="num text-ink">{formatTime(r.timestamp)}</span> },
    { key: 'temp', header: 'Temp', render: (r) => <span className="num">{temperatureLabel(r.temperatureC, settings.units)}</span> },
    { key: 'humidity', header: 'Humidity', render: (r) => <span className="num">{r.humidityPct}%</span>, secondary: true },
    { key: 'wind', header: 'Wind', render: (r) => <span className="num">{windLabel(r.windSpeedKmph, settings.units)} {windDirectionLabel(r.windDirectionDeg)}</span>, secondary: true },
    { key: 'pressure', header: 'Pressure', render: (r) => <span className="num">{r.pressureHpa} hPa</span>, secondary: true },
    { key: 'rain', header: 'Rainfall', render: (r) => <span className="num font-semibold" style={{ color: rainfallColor(r.rainfallMmHr) }}>{r.rainfallMmHr} mm/hr</span> },
  ]

  return (
    <div className="section-gap flex flex-col">
      <PageHeader
        title="Live Weather"
        subtitle="Demo surface conditions and historical trends for the selected monitoring region."
        meta={<><DemoBadge /><Badge tone="info" dot>Sample station network</Badge></>}
      >
        <Button icon={<RefreshCw size={14} />} onClick={() => { reload(); toast.success('Weather observations refreshed') }}>Refresh</Button>
      </PageHeader>

      {/* Controls */}
      <div className="flex flex-wrap items-end gap-3 rounded-2xl border border-line bg-card p-[var(--rw-card-pad)]">
        <Select label="Location" options={(locations ?? []).map((l) => ({ value: l.id, label: `${l.name} · ${l.zone}` }))} value={locationId} onValueChange={setLocationId} compact className="min-w-[200px] flex-1" />
        <Select label="Time range" options={RANGES} value={range} onValueChange={setRange} compact className="w-[160px]" />
        <Select label="Primary metric" options={METRICS} value={metric} onValueChange={setMetric} compact className="w-[160px]" />
        <div className="flex flex-col gap-1.5">
          <span className="text-[11px] font-semibold tracking-wider text-muted uppercase">Chart style</span>
          <SegmentedControl
            ariaLabel="Chart style" size="sm"
            value={chartType} onChange={setChartType}
            options={[
              { value: 'line', label: <><LineIcon size={12} /> Line</> },
              { value: 'bar', label: <><BarChart3 size={12} /> Bar</> },
              { value: 'area', label: <><AreaIcon size={12} /> Area</> },
            ]}
          />
        </div>
      </div>

      {error ? <StatePanel variant="error" title="Weather data unavailable" message={error} actionLabel="Retry" onAction={reload} /> : null}

      {/* Conditions */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {loading || !current
          ? Array.from({ length: 8 }).map((_, i) => <SkeletonCard key={i} lines={1} />)
          : conditions.map((c, i) => {
            const Icon = c.icon
            return (
              <motion.div key={c.label}
                initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
                whileHover={{ y: -3 }}
                className="rounded-2xl border border-line bg-card p-[var(--rw-card-pad)] transition-colors hover:border-accent/35">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-semibold tracking-wider text-muted uppercase">{c.label}</span>
                  <span className="flex h-7 w-7 items-center justify-center rounded-lg" style={{ background: `${c.color}18`, color: c.color }}><Icon size={14} aria-hidden /></span>
                </div>
                <p className="num mt-2 text-xl font-bold text-ink">{c.value} {c.unit ? <span className="text-xs font-normal text-muted">{c.unit}</span> : null}</p>
                <p className="mt-1 text-[10px] text-muted">{c.desc}</p>
              </motion.div>
            )
          })}
      </div>

      {current ? (
        <div className="flex flex-wrap items-center gap-2 rounded-xl border border-line bg-surface/60 px-3 py-2 text-xs">
          <span className="text-muted">Current classification:</span>
          <RainBadge label={classifyRainfall(current.rainfallMmHr)} />
          <span className="text-muted">· Sample series {locationId.toUpperCase()} · Updated {formatTime(current.timestamp)}</span>
        </div>
      ) : null}

      {/* Charts */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <ChartCard title={`${primaryName} — primary trend`} subtitle={`Last ${range} hours · ${chartType} chart`} icon={<CloudRain size={16} />} height={280} loading={loading} delay={0.02}>
          <ResponsiveContainer width="100%" height="100%">
            {chartType === 'bar' ? (
              <BarChart data={chartData} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
                <CartesianGrid stroke="var(--rw-border)" strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="time" tickLine={false} axisLine={false} interval={Math.max(1, Math.floor(chartData.length / 8))} />
                <YAxis tickLine={false} axisLine={false} width={46} />
                <RTooltip contentStyle={tooltipStyle} />
                {renderSeries(primaryKey, primaryColor, primaryName)}
              </BarChart>
            ) : (
              <AreaChart data={chartData} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
                <defs><linearGradient id="primaryFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={primaryColor} stopOpacity={0.4} /><stop offset="100%" stopColor={primaryColor} stopOpacity={0.02} /></linearGradient></defs>
                <CartesianGrid stroke="var(--rw-border)" strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="time" tickLine={false} axisLine={false} interval={Math.max(1, Math.floor(chartData.length / 8))} />
                <YAxis tickLine={false} axisLine={false} width={46} />
                <RTooltip contentStyle={tooltipStyle} />
                {chartType === 'line' ? (
                  <Line type="monotone" dataKey={primaryKey} name={primaryName} stroke={primaryColor} strokeWidth={2} dot={false} animationDuration={700} />
                ) : (
                  <Area type="monotone" dataKey={primaryKey} name={primaryName} stroke={primaryColor} strokeWidth={2} fill="url(#primaryFill)" dot={false} animationDuration={700} />
                )}
              </AreaChart>
            )}
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Hourly Rainfall" subtitle="Rainfall intensity (mm/hr) — demo series" icon={<CloudRain size={16} />} height={280} loading={loading} delay={0.06}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
              <CartesianGrid stroke="var(--rw-border)" strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="time" tickLine={false} axisLine={false} interval={Math.max(1, Math.floor(chartData.length / 8))} />
              <YAxis tickLine={false} axisLine={false} width={46} />
              <RTooltip contentStyle={tooltipStyle} />
              <Bar dataKey="rainfall" name="Rainfall mm/hr" radius={[3, 3, 0, 0]} animationDuration={700}>
                {chartData.map((d, i) => <Cell key={i} fill={rainfallColor(d.rainfall)} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Temperature Trend" subtitle={settings.units === 'metric' ? 'Degrees Celsius' : 'Degrees Fahrenheit'} icon={<Thermometer size={16} />} height={280} loading={loading} delay={0.1}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
              <CartesianGrid stroke="var(--rw-border)" strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="time" tickLine={false} axisLine={false} interval={Math.max(1, Math.floor(chartData.length / 8))} />
              <YAxis tickLine={false} axisLine={false} width={46} domain={['dataMin - 2', 'dataMax + 2']} />
              <RTooltip contentStyle={tooltipStyle} />
              <Line type="monotone" dataKey="temperature" name="Temperature" stroke="#F0823F" strokeWidth={2} dot={false} animationDuration={700} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Humidity & Wind" subtitle="Relative humidity (%) and wind speed" icon={<Droplets size={16} />} height={280} loading={loading} delay={0.14}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
              <CartesianGrid stroke="var(--rw-border)" strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="time" tickLine={false} axisLine={false} interval={Math.max(1, Math.floor(chartData.length / 8))} />
              <YAxis tickLine={false} axisLine={false} width={46} />
              <RTooltip contentStyle={tooltipStyle} />
              <Line type="monotone" dataKey="humidity" name="Humidity %" stroke="#6FD6C2" strokeWidth={2} dot={false} animationDuration={700} />
              <Line type="monotone" dataKey="wind" name={settings.units === 'metric' ? 'Wind km/h' : 'Wind mph'} stroke="#B19BFA" strokeWidth={2} dot={false} animationDuration={700} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Observation log */}
      <ChartCard title="Observation Log" subtitle={`Last ${Math.min(8, data?.length ?? 0)} hourly records`} icon={<Gauge size={16} />}
        actions={<Button size="sm" icon={<Download size={13} />} onClick={exportCsv}>Export CSV</Button>}
        loading={loading} empty={(data?.length ?? 0) === 0}>
        <DataTable columns={tableColumns} rows={(data ?? []).slice(-8).reverse()} rowKey={(r) => r.timestamp} caption="Hourly weather observations" />
      </ChartCard>
    </div>
  )
}
