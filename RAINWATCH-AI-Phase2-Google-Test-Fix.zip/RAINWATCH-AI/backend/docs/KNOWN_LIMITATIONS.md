# RAINWATCH AI — Known Limitations

Things that are wrong, missing, or fragile, stated plainly. Nothing
here is a secret to keep from judges — the honest version of each
item is the one to say out loud if asked.

## Scientific limits (say these, do not work around them)

1. **Heavy-rain precision is low.** The "high" tier is an
   early-warning signal, not a confirmed forecast. 2025 test, 3h ≥
   10 mm: v3.3 Watch P 0.128 / R 0.270 (matched-recall); the mean
   regressor never forecasts a daily total ≥ 50 mm (max 30.8 mm) and
   missed both observed ≥ 50 mm days in 2025. Monsoon totals run ~22%
   high. Never present the system as a reliable heavy-rainfall warning
   system.
2. **One grid cell, not a state.** The model predicts for a single
   Bhubaneswar ERA5 cell. All 14 non-Ganjam locations share it
   (Cuttack, Puri included) and are badged MODEL; that is the API
   contract, not per-city modelling. No statewide performance is
   claimed or established. Since the 2026-11-24 integrity check the UI
   states this wherever MODEL values appear — a note strip on
   Forecast, Flood Intelligence and Overview, the Map subtitle, every
   MODEL badge tooltip ("ML model rainfall-xgb-v3.3 · Bhubaneswar grid
   cell"), and the `/api/health` scope field — so the shared-cell fact
   remains, but it is no longer silent. A regression test pins it:
   the six MODEL points are identical across Old Town, Patia, Cuttack
   and Puri (`test_provenance.py`), while the DEMO points differ.
   Flood "susceptibility index" is not inundation — no water depths
   or flood boundaries are validated.
3. **Daily validation is not hourly validation.** The IMD comparison
   validates daily totals at Bhubaneswar only (r = 0.58, P90 coverage
   0.94). It does not establish 3 h/6 h accuracy, and IMD gridded
   data is not station ground truth. Two distinct F1s exist in the
   report — regression daily-total F1 and classifier any-fire F1 —
   and they must not be mixed (see `IMD_DAILY_VALIDATION.md` §3.3).
   At ≥ 50 mm in 2025, precision is undefined (0/0) and F1 is 0 only
   because recall is 0; at ≥ 100 mm F1 is undefined — never quote the
   `metrics.json` by-construction 0.0 for it.
4. **v3.3 is not production.** It does not clear the production bar
   (validated improvement on 3h ≥ 10 mm). v3.2 beats it on 3h ≥
   10 mm. The next step is better input data (GPM IMERG), not more
   tuning.
5. **2026 is reserved and untouched.** Never tune, threshold, or
   select against it. 2025 is a benchmark for v3.3, not an untouched
   holdout (v3.3 was selected using 2025); 2024 is non-independent
   (weights/Platt/thresholds fitted on it).
6. **CAPE is not used.** Open-Meteo ERA5 returns it all nulls for all
   three cells; surface instability proxies are used instead.

## Data gaps

7. **Ganjam/Brahmapur archive still not fetched** (Open-Meteo HTTP
   429, twice 2026-11-23). Ganjam history and forecasts stay demo.
   Retry `backend/fetch_brahmapur.py`, then restart the backend.
8. **The reported Odisha hourly telemetry dataset 2021–2025 does not
   exist on AIKosh.** The only live lead for hourly station data is
   the IMD API AWS/ARG endpoint (free key needed, historical depth
   unverified). GPM IMERG needs a free Earthdata account.
9. **IMD file ends 2025-12-31** — it cannot validate 2026, and it is
   daily-only (cannot validate 3 h/6 h labels).

## External dependencies (Google Weather, added 2026-11-25)

- **Google Weather API is opt-in and key-gated.** Without
  `GOOGLE_WEATHER_API_KEY` the Forecast page shows "Google Weather
  unavailable — key not configured" and the Data Sources card reads
  "Not Connected". Nothing else depends on it: `/api/forecast`,
  `/api/health` and every other route work with no key, and a Google
  outage can never break them (lazy import; the endpoint returns 502
  on Google errors). The Maps Demo Key in use is prototyping-only
  (no billing); its daily limits are unpublished by Google.
- **QPF is not the model rate.** Google `precipitation.qpf.quantity`
  is millimetres falling in that hour; the RAINWATCH series is a
  rainfall rate. The two series are different quantities shown
  together on the Rainfall Intensity Timeline only for visual
  comparison (dashed Google series + caption). Agreement or
  disagreement between them proves nothing about model accuracy.
- **Google values never enter the model** and are never labelled
  MODEL. On the Forecast page they are merged into the main table
  (`GET /api/forecast/merged`, priority MODEL > GOOGLE WEATHER >
  UNAVAILABLE) with per-row `valueKind` labels; peak/total KPIs
  count valued hours only and mean confidence is MODEL-only, and the
  Forecast Comparison chart uses the merged series. They keep their
  own separate table and CSV export too. The 30-minute cache is
  keyed by `(locationId, hours)` only — demo refreshes do not burn
  quota — and the monthly cap defaults to 5,000 calls
  (process-local).
- **Not yet verified live.** The integration is tested against
  mocked fixtures only (21 backend tests + Playwright probe); no live
  Google call has been made. Unconfirmed until a key exists: the
  numeric default QPM quota, the Maps Demo Key daily limits, the
  exact live error `status` strings, whether `qpf` is omitted for
  dry hours, Google's forecast refresh cadence, and the Weather API
  ToS caching rules for the 30-min TTL.

## Product gaps (unfinished, not broken)

10. **No git repo, no CI.** The 190-test suite runs only by hand.
11. **`/api/simulations/run` and `/api/simulations/compare` do not
    exist.** Scenario comparison is client-side only. Adding the
    endpoints is a decision for Kam.
12. **Alerts page is local-only.** `/api/alerts` exists and is tested,
    but the page renders local seed alerts and never displays backend
    alerts.
13. **No frontend unit tests.** Verification is Playwright probes
    against a running dev server (see `TESTING.md`).
14. **Charts and KPI strips mix MODEL+DEMO without distinction**
    (Flood Intelligence, Overview). The Forecast page was fixed
    2026-11-25: it shows no DEMO at all, its Timeline splits the
    model rate and Google QPF into separate series, and mean
    confidence is MODEL-only. Per-row badges and CSV Source columns
    are authoritative everywhere; the Flood/Overview charts are not
    labelled.
15. **No `response_model=` on any route** — response shapes are
    enforced by tests, not by FastAPI.
16. **Backend health is only a Topbar dot** (green/amber + tooltip).
    There is no dedicated status page and no alerting.

## Operational fragilities

17. **Demo must run on :5173.** The backend CORS allow-list covers
    only `:5173`; any other frontend origin silently falls back to
    labelled DEMO (correct labelling, wrong demo).
18. **Map page needs internet** for OpenStreetMap base tiles. Overlays
    render without them; the base map does not.
19. **First request loads the model lazily (~10 s).** Warm the server
    and check `/api/health` before presenting; a 5 s client timeout
    will fail the first call.
20. **Per-tick caches grow unboundedly** across demo ticks; a long
    session with many refreshes grows memory. Demo tick is
    in-memory/process-global and resets to 0 on restart.
21. **`history.py` caches "CSV missing" forever** — if the archive
    file appears later, restart the process. `.env` is read once at
    startup.
22. **`get_model_status()` loaded:false block hardcodes the v3 label**
    alongside `loaded: false` and an error. Predictions then fall back
    to DEMO, so nothing is mislabelled — but the label is a
    placeholder, not the attempted version.
23. **Stale docstrings:** `risk.py` header says "rainfall-xgb-v1";
    `main.py` description names v3 (true for the default only).
    `MODEL_HORIZON_MAE` is v3-only but feeds indicative confidence
    for all versions.
24. **Frontend toolchain quirks:** `node_modules` ships Windows
    native binaries — run `npm install --no-save --no-package-lock`
    once on Linux (does not change package.json/lockfile); launch
    vite via `node node_modules/vite/bin/vite.js` (the `.bin/vite`
    shim is not executable); compile standalone TS files with `node
    node_modules/typescript/bin/tsc --ignoreConfig`.
25. **Non-failing warnings:** pandas `dayofyear` deprecation
    (`ml/features.py:298`); sklearn "fitted without feature names".

## Fixed in the 2026-11-24 integrity check (no features added)

- **Grid-cell origin is now visible.** Forecast, Flood Intelligence and
  Overview show a "Single grid cell" note whenever MODEL values are on
  screen; the Map subtitle names the cell; every MODEL badge tooltip
  reads "ML model &lt;version&gt; · Bhubaneswar grid cell (20.28°N,
  85.84°E)". One shared string (`MODEL_CELL_NOTE` in
  `hackathon/src/utils/source.ts`) so the wording cannot drift.
- **Data Sources no longer calls the archive "Live".** The ERA5 row's
  status is now "Archive" (blue, not green) with cadence "Static
  archive — no live updates". Every source carries a `kind`
  (Historical dataset / Real-time observation / Forecast feed / Static
  dataset), shown as a chip on each card. Summary cards now read
  "Historical archive served: 1", "Live observation feeds: 0",
  "Awaiting integration: 2" — the old "Live: 1" card was the
  misrepresentation. The banner states the four-way distinction in
  plain words; the pipeline footnote no longer claims "no data is
  currently flowing". The frontend fallback copy
  (`dataSourcesData.ts`) was stale (old description, "Demo Data") and
  now mirrors the backend exactly. Backend regression tests pin all
  of it (`test_data_sources`); the UI is covered by
  `backend/ml/probe_integrity_labels.py` (6/6 checks).
- **Stale `dataService.ts` header comment** ("Everything returned here
  is SIMULATED DEMO DATA", "integrate a real backend later") rewritten
  to describe the backend-first `viaApi` behaviour.

## Fixed in the 2026-11-25 merged-forecast change (no features added)

- **The Forecast page no longer shows synthetic DEMO rainfall.**
  New endpoint `GET /api/forecast/merged` (source priority MODEL >
  GOOGLE WEATHER > UNAVAILABLE); the page's main table, charts,
  comparison and CSV all use it. `/api/forecast` is unchanged
  (model+demo) for the simulator, risk, overview and map.
- **Timestamp alignment is explicit.** RAINWATCH hours are UTC
  hour-aligned, Google's are local-hour aligned (:30 UTC for IST);
  the merge matches by `[startTime, endTime)` containment with a
  60-minute nearest-start fallback, and `endTime` was added to the
  mapped Google point (additive).
- **Accumulated semantics are documented and enforced.** The merged
  accumulated is the running total of displayed per-hour values and
  is null from the first unavailable hour on; the page shows "—"
  for the total when the horizon has a gap.
- **Remaining DEMO on the Forecast page is shell chrome only.** The
  Topbar still renders a (hidden below 2xl) DemoBadge and the
  sidebar/footer carry "Demo Mode" / "values labelled DEMO" prose —
  global app-shell text shared by every page, whose other pages
  still show DEMO values. Removing it is an app-wide decision, not
  part of this page-scoped change.
- **The mock Google server's fixture is now anchored to the current
  UTC hour** (it was fixed at 2026-11-25T00:00Z and would have left
  early hours unmatched once the clock moved past it).

## Fixed in Stage 6 (kept here so the history is visible)

- Historical Analysis: empty trend chart / empty CSV for
  Bhubaneswar-region locations (date range vs archive end); trend
  chart rendering at 0 px (Recharts percentage height in a flex
  column); "All locations" filter was a no-op; footer claimed real
  archive data was "generated locally".
- Flood Intelligence "Population potentially affected" summed
  population across ~25 hourly rows per location (~25× overcount);
  now the peak per location, summed.
- Data Sources page claimed no backend was connected; "Live" status
  added in Stage 6, history row now `Live`, summary cards computed —
  **superseded by the integrity check**: "Live" itself misrepresented
  the static archive as a live feed, so the row is now "Archive" (see
  above).
- Simulator claimed "entirely in the browser" while POSTing
  `/api/simulate`.
- Overview showed MODEL values with no badge; "Live scan" label;
  "Last updated" was page-open time.
- Response caches were keyed by demo tick only (stale labels across
  version switches); `/api/health` `model_input_as_of` was non-ISO.
- Alerts page called `fetchAlerts()` and discarded the result.
- Settings "Bell status" toggle appeared unresponsive with zero
  severities selected.
- Landing: "v2.6", "Zero backend dependencies", "Nothing external
  connected", fake telemetry presented as live readings.
