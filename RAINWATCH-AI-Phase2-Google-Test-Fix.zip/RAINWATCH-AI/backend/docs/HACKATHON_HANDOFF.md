# RAINWATCH AI — Hackathon Handoff

Everything needed to run the live demonstration on finale day
(Thu 26 Nov 2026, 10 AM–4 PM, NIST campus) and to hand the project
to a teammate. Status as of 2026-11-24 evening.

## What this is

RAINWATCH AI — Integrated Heavy Rainfall Early Warning and
Inundation Prediction for Odisha. Hackathon entry for team
Wanda_Maximoff (Kam, Ravi Ranjan, Anshuman Panda). The MVP is
susceptibility-first: an ML rainfall forecaster (hours 1–6) plus a
grid-based flood susceptibility index. ConvLSTM, U-Net, HEC-HMS and
HEC-RAS 2D are Phase 2, not the MVP. The deck is 6 slides
(`workspace/user/files/Wanda_Maximoff_RAINWATCH_AI_HackKalp.pptx`,
slide 5 is the IMD validation slide); the Drive copy still holds the
5-slide version — re-upload only with Kam's go-ahead.

## Demo configuration (the only supported one)

| Piece | Command | Notes |
|---|---|---|
| Backend (v3.3 demo) | `cd backend && MODEL_VERSION=rainfall-xgb-v3.3 .venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port 8001` | Warm up: `curl --max-time 30 http://127.0.0.1:8001/api/health` until `"loaded": true` (~10 s). Expect `rainfall-xgb-v3.3`. |
| Frontend | `cd hackathon && VITE_API_URL=http://localhost:8001 node node_modules/vite/bin/vite.js --port 5173` | **Must be :5173** (backend CORS allow-list). Any other port silently falls back to labelled DEMO. |
| Production (untouched) | port 8000, no `MODEL_VERSION` | Serves v3. The demo never touches it. Rollback = stop the :8001 server. |
| Google Weather (optional) | `GOOGLE_WEATHER_API_KEY=<key>` in `backend/.env` before starting the backend | Without a key the Forecast page's merged table shows MODEL hours + UNAVAILABLE for the rest, and the separate Google section says "Google Weather unavailable — key not configured". With a key, the merged table shows MODEL + GOOGLE WEATHER and the Data Sources card shows Live. Never required for the demo. |

Checklist before presenting:
1. `/api/health` on :8001 says `rainfall-xgb-v3.3`, `loaded: true`.
2. Topbar clock dot is green; hover it — it should read "Backend
   live · API 1.3.0 · rainfall-xgb-v3.3". Amber = backend unreachable,
   everything on screen is demo data.
3. Forecast page, Old Town: 6 MODEL rows (hours 1–6) + 18 GOOGLE
   WEATHER rows (with a key) or 18 UNAVAILABLE rows (without a key).
   Switch to Brahmapur: 0 MODEL, 24 GOOGLE WEATHER (with a key) or
   24 UNAVAILABLE (without a key). No DEMO rows anywhere on this
   page. That is correct.
4. Google Weather (only if a key is set): the Forecast page's merged
   table carries GOOGLE WEATHER rows and the separate Google Weather
   section shows 24 GOOGLE WEATHER rows with its own CSV export; the
   Data Sources card reads Live with a last-retrieval time. Without
   a key the merged rows are UNAVAILABLE and the section says
   "Google Weather unavailable — key not configured" — that is the
   correct state, not a fault.
5. Wait ~10 s after loading a page before screenshotting — charts
   animate in.
6. The map page needs internet for its OpenStreetMap base tiles.
   Overlays render without them.

## What to say (and not say)

**Say:** the model is a Bhubaneswar grid-cell forecaster; Cuttack and
Puri share that cell's forecast — the UI now says this on the Forecast,
Flood, Overview and Map pages, so you can point at it. The "high" tier is an early-warning
signal, not a confirmed forecast. Daily validation against
independent IMD gridded data: correlation r = 0.58, P90 coverage
94%. Watch alerts caught all 9 observed ≥ 50 mm days across
2024–2025, while the amount regressor severely underestimated
extremes (max predicted daily total 30.8 mm; monsoon totals ~22%
high). Flood risk is a susceptibility index, not inundation. On the
Data Sources page: the ERA5 archive is a static historical dataset,
not a live feed — live observation feeds: 0; no external NWP feed is
connected; forecasts are the ML ensemble's output. **Google
Weather (when connected):** it is an independent external forecast
that fills the Forecast page's main table wherever the model has no
coverage (hours 7–72 and Ganjam), under the priority MODEL >
GOOGLE WEATHER > UNAVAILABLE — hours neither can provide show
UNAVAILABLE, never a made-up value. It is **not** model validation,
not a RAINWATCH prediction, and its values never enter the model.
The Google series is hourly QPF (mm in that hour); the model series
is a rainfall rate — different quantities, shown as separate series
and labelled per row, never averaged.

**Do not say:** that the system accurately predicts extreme rainfall
amounts; that validation covers 3 h/6 h or the whole state; that
Cuttack/Puri have their own models; that the demo model is
production (v3 is production; v3.3 is the demo candidate); any
advance-warning lead time (none is evidenced); that Google Weather
validates the model or that agreement with Google proves accuracy
(the two series measure different quantities).

## Project state

- **Backend tests: 190 passed** (`backend/tests/`, `pytest`).
  Frontend: `tsc -b` clean, `vite build` passes. See `TESTING.md`.
- **Merged forecast (2026-11-25).** The Forecast page no longer
  shows synthetic DEMO rainfall: `GET /api/forecast/merged` serves
  MODEL hours (byte-identical to `/api/forecast`) + genuine Google
  Weather QPF where the model has no coverage, else UNAVAILABLE.
  `/api/forecast` is unchanged (model+demo) for the simulator, risk,
  overview and map. 17 new backend tests + Playwright probe
  (`backend/ml/probe_forecast_merged.py`, PASS both phases).
- **Google Weather API integration (2026-11-25).** Optional third
  source alongside MODEL and DEMO: `GET /api/weather/google`
  (hourly forecast, METRIC, hours 1–72), 30-min cache, 5,000
  calls/month cap, 503 with no key, 502 on Google errors. Verified
  against mocked fixtures only — **no live Google call has been
  made; no key exists yet.** The Maps Demo Key (no billing) goes in
  `backend/.env` as `GOOGLE_WEATHER_API_KEY`; the key is never
  committed. Probe `backend/ml/probe_google_weather.py` passed both
  phases (mocked success + no-key).
- **v3.3 frozen artifacts: 15/15 hashes match** the release
  manifest. Production is v3; v3.2 is the benchmark.
- **Integrity check 2026-11-24 (no features added).** Grid-cell origin
  is labelled wherever MODEL values appear (Forecast/Flood/Overview
  note, Map subtitle, badge tooltips); the Data Sources page now
  distinguishes historical datasets, connected APIs, real-time
  observations and forecast feeds, with the ERA5 archive as "Archive"
  (live observation feeds: 0). Regression tests: backend
  `test_data_sources` + shared-cell test in `test_provenance.py`;
  UI probe `backend/ml/probe_integrity_labels.py` — 6/6 checks passed
  (screenshots in `~/workspace/integrity-screenshots/`).
- **Docs:** `TESTING.md`, `SYSTEM_ARCHITECTURE.md`,
  `MODEL_VERSIONING.md`, `DATA_PROVENANCE.md`,
  `KNOWN_LIMITATIONS.md` (this handoff's companion), plus
  `MODEL_REPORT.md` (§§1–14), `V33_DEMO_READINESS.md`,
  `IMD_DAILY_VALIDATION.md`, `AIKOSH_DATA_AUDIT.md`,
  `ENGINEERING_AUDIT.md`.
- **Stage 6 is complete.** The six docs above are the handoff.

## Known open items (prioritised)

1. **Drive deck copy is the 5-slide version** — re-upload the 6-slide
   deck with Kam's go-ahead. Verify the submitted HackKalp link opens
   the final deck signed-out.
2. **Brahmapur/Ganjam archive not fetched** (Open-Meteo HTTP 429).
   Ganjam stays demo until `fetch_brahmapur.py` succeeds + restart.
3. **Alerts page is local-only** — `/api/alerts` exists but is not
   displayed. Wiring it is a feature, not a fix.
4. **`/api/simulations/run` + `/api/simulations/compare` do not
   exist** — scenario comparison is client-side. Adding them is
   Kam's call.
5. **No git repo, no CI.** The suite runs by hand.
6. **No frontend unit tests** — verification is Playwright probes.
7. **Charts/KPI strips mix MODEL+DEMO without labels** — per-row
   badges and CSV Source columns are authoritative.
8. **IMERG / IMD API keys** — the next data step for 3h ≥ 10 mm
   needs Kam's free registrations (Earthdata for GPM IMERG; IMD API
   key for AWS/ARG). Do not start this before the finale.
9. **Google Weather key not yet placed.** The integration is built
   and tested against mocks; the Maps Demo Key still needs to go in
   `backend/.env` as `GOOGLE_WEATHER_API_KEY` (Kam's manual step) for
   any live Google data. Without it the demo is unaffected.

## Do not do

- Do not switch production to v3.3 (the bar is not met).
- Do not retrain, modify frozen artifacts, change thresholds, or tune
  against the reserved 2026 evaluation.
- Do not deploy anything, change the Drive presentation, or work on
  pitch scripts as part of this engineering handoff.
- Do not present daily validation numbers as 3 h/6 h results, and do
  not claim statewide performance.

## Key files

- Backend: `~/workspace/backend/` (FastAPI :8000/:8001)
- Frontend: `~/workspace/hackathon/` (React :5173)
- Deck: `~/workspace/user/files/Wanda_Maximoff_RAINWATCH_AI_HackKalp.pptx`
- This doc: `~/workspace/backend/docs/HACKATHON_HANDOFF.md`
