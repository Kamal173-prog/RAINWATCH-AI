"""Freeze + hash the v3.3 release configuration.

Writes:
  * models/rainfall_xgb_v3_3/frozen/thresholds_optimized.json -- the
    operating thresholds in the same format as thresholds.json
    ({target: {elevated, high}}), so the API can load them directly.
    thresholds.json itself is NOT touched: it stays the freeze record.
  * models/rainfall_xgb_v3_3/frozen/RELEASE_MANIFEST.json -- SHA-256
    hashes of every frozen artifact, the threshold-selection record
    (data, rules, date), and the pooled 2024+2025 metrics at the
    chosen thresholds.

Frozen model weights and features are NOT modified by this script.
2026 was not used for any threshold selection or calibration here.
"""

import hashlib
import json
import logging
import os
from datetime import datetime, timezone

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger("freeze_v33_release")

BACKEND = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FROZEN = os.path.join(BACKEND, "models", "rainfall_xgb_v3_3", "frozen")
WORK = os.path.join(BACKEND, "models", "rainfall_xgb_v3_3", "threshold_work")
TARGETS = ["y_3h_ge_10mm", "y_6h_ge_10mm", "y_3h_ge_5mm"]


def _sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> None:
    opt = json.load(open(os.path.join(WORK, "thresholds_optimized.json")))
    # Operating thresholds in the thresholds.json format.
    operating = {}
    for target in TARGETS:
        operating[target] = {
            "elevated": opt["v3.3"][target]["watch"]["threshold"],
            "high": opt["v3.3"][target]["warning"]["threshold"],
        }
    with open(os.path.join(FROZEN, "thresholds_optimized.json"), "w") as f:
        json.dump(operating, f, indent=2)
    log.info("wrote thresholds_optimized.json: %s", operating)

    # Hash every frozen artifact (excluding the manifest itself).
    files = {}
    for name in sorted(os.listdir(FROZEN)):
        path = os.path.join(FROZEN, name)
        if os.path.isfile(path) and name != "RELEASE_MANIFEST.json":
            files[name] = {
                "sha256": _sha256(path),
                "bytes": os.path.getsize(path),
            }
    log.info("hashed %d frozen files", len(files))

    manifest = {
        "model_version": "rainfall-xgb-v3.3",
        "release": "v3.3-thresholds-2026-11-24",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "api_version": "1.3.0",
        "production_model": "rainfall-xgb-v3 (unchanged; v3.3 is flag-gated, not deployed)",
        "frozen_config": {
            "members": "base arm, three-family ensemble (XGBoost + LightGBM + "
                       "HistGradientBoosting), refit on 2021-2024",
            "features": "94 (pruned v33 set; see feature_schema.json)",
            "weights": "ensemble_weights.json (2024 validation)",
            "calibration": "platt.json (Platt scaling fit on 2024 validation)",
            "freeze_verification": "frozen artifacts reproduce variants.json "
                "2025 PR-AUC exactly (0.1687 / 0.2743 / 0.3915), verified 2026-11-24",
            "weights_and_features_unchanged_by_this_release": True,
        },
        "operating_thresholds": operating,
        "thresholds_source_file": "thresholds_optimized.json",
        "thresholds_freeze_record": "thresholds.json (unchanged; the freeze record)",
        "threshold_selection": {
            "data": "pooled out-of-sample 2024 (train-only models, 2021-2023) + "
                    "2025 (deployed artifacts) calibrated probabilities; "
                    "17,520 hours (2024: 8,766; 2025: 8,754)",
            "2026_use": "NONE. 2026 was not used for threshold selection, "
                        "calibration, or any validation claim in this release.",
            "rules": {
                "watch": "maximize F2 subject to recall >= floor and precision >= 0.10",
                "warning": "maximize F1 subject to recall >= floor and precision >= 0.15",
                "recall_floors": {
                    "y_3h_ge_10mm": {"watch": 0.25, "warning": 0.20},
                    "y_6h_ge_10mm": {"watch": 0.50, "warning": 0.25},
                    "y_3h_ge_5mm": {"watch": 0.50, "warning": 0.30},
                },
            },
            "pooled_2024_2025_metrics_at_operating_thresholds": {
                target: {
                    "watch": opt["v3.3"][target]["watch"]["metrics"],
                    "warning": opt["v3.3"][target]["warning"]["metrics"],
                    "per_year": opt["v3.3"][target]["per_year"],
                } for target in TARGETS
            },
        },
        "files": files,
    }
    with open(os.path.join(FROZEN, "RELEASE_MANIFEST.json"), "w") as f:
        json.dump(manifest, f, indent=2)
    log.info("wrote RELEASE_MANIFEST.json")


if __name__ == "__main__":
    main()
