# RAINWATCH AI — rainfall-v3.3 experiment log

Chronological record of every experiment run for v3.3 (23–24 Nov 2026).
The full write-up is `V33_TECHNICAL.md`; this file is the lab notebook:
what was tried, what it scored, what was kept. All numbers are 2025
benchmark PR-AUC unless stated otherwise (2025 is a benchmark, not a
clean holdout — it was used for selection in v3/v3.1; 2026 is the
fresh evaluation).

## E1. Reproduce v3.2 (Phase 1)

Re-scoring the saved v3.2 artifacts initially gave LOWER recall than
`evaluation.json`. Root cause: a weights bug introduced in v3.2 Phase 11
— `ml/predict.py` merged v3's `clf_*` ensemble weights over v3.2's, so
the v3.2 classifiers silently used v3's weights. Fix: the merge now
takes only `reg_*`/`p90_*` keys from v3. After the fix,
`ml/reproduce_v32.py` reproduces `evaluation.json` exactly on both
periods. Production v3 was never affected. Reproduced v3.2: 2025
0.2228 / 0.2371 / 0.3575; 2026 0.2983 / 0.4293 / 0.4898.

## E2. Leakage audit + variable probes (Phase 3)

Open-Meteo Historical Forecast docs + live probes: the seamless series
is stitched from successive model runs, so 0-hour-lead features at time
≤ t are leakage-free. Previous Runs API gives fixed lead offsets in
whole days; GFS `precipitation_previous_day1/2` is all-null before
2024-01-01 and populated from 2024 — multi-lead precipitation features
therefore exist only from 2024 and were excluded from the main
protocol. `precipitable_water` is an invalid variable (HTTP 400) →
replaced by the documented proxy `gfs_rh_column_mean`. Pressure-level
variables are 0.25° vs 0.11° surface (grid cell up to ~12 km away).
Single Runs API is not usable for GFS 2021–2025.

## E3. OOF + thresholds (Phase 2)

Expanding-window CV, per-fold weights + Platt. v33 features beat v32
features on OOF PR-AUC for all events: 3h ≥ 10 mm 0.1638 → 0.1932,
6h ≥ 10 mm 0.2763 → 0.3565, 3h ≥ 5 mm 0.3742 → 0.4053. The v3.2
thresholds are already on the OOF precision–recall frontier, so
threshold re-optimisation alone cannot improve v3.2.
`thresholds_oof.json`, `oof/`.

## E4. Feature pruning (Phase 4)

Permutation importance on 2024 validation; prune only if importance
≤ 0 for BOTH 3h ≥ 10 mm and 3h ≥ 5 mm. 8 of 102 pruned, 94 kept.
Top new features: `gfs_rh_850_700`, `gfs_rh_column_mean`,
`gfs_precip_12h_sum`, `gfs_rh_700`. `feature_schema.json`.

## E5. Variants (Phase 5)

8 arms, `variants.json`. 2025 PR-AUC (3h ≥ 10 mm / 6h ≥ 10 mm /
3h ≥ 5 mm): base 0.1687 / 0.2743 / 0.3915; posweight_half 0.1656 /
0.2536 / 0.3989; posweight_double 0.1762 / 0.2707 / 0.4003; cost3
0.1727 / 0.2562 / 0.4008; cost5 0.1557 / 0.2618 / 0.4083; hardneg
0.1343 / 0.2776 / 0.4189; eventaware 0.1661 / 0.2563 / 0.4084; focal
0.1824 / 0.2606 / 0.4016. No arm beats v3.2's 0.2228 on 2025 for
3h ≥ 10 mm.

**Bug found and fixed:** the event-aware arm's weights were computed
but never passed to `fit` in `_train_arm`/`_refit_arm`, so its first
run duplicated base exactly. Fixed, re-run, and verified two ways
(results differ from base on all three targets; direct HGB check:
1,382 of 26,209 training hours upweighted ×2, mean |Δp| 0.0654,
max 0.7533).

## E6. Feature-set diagnostic

Same base-arm protocol, 2025 PR-AUC: 53 feats 0.2228 / 0.2371 /
0.3575; 102 feats 0.1770 / 0.2555 / 0.4025; 94 feats 0.1687 / 0.2743
/ 0.3915. New features hurt 2025 for 3h ≥ 10 mm, help the other two.
`feature_set_diagnostic.json`.

## E7. Bootstrap of the 2025 gap

Paired bootstrap (1,000 resamples), 3h ≥ 10 mm, v32 − v33-102:
mean +0.040, 95% CI [−0.009, +0.085], P(>0) = 0.945. Leans v32,
not significant. `bootstrap_3h10.json`.

## E8. Event-level summary (Phase 6)

`event_level_summary.json`. Median lead times mostly 0.0 h; focal
3h ≥ 10 mm and hardneg 3h ≥ 5 mm reach +1.0 h. Base storm detection
rates (2025): 0.485 / 0.549 / 0.708. Log-line bug fixed: the variants
phase printed `median_lead_time_h or -1`, so a true 0.0 h appeared
as −1.0 h in run logs; the JSON values were always correct.

## E9. Location experiment (Phase 7)

`location_experiment.json`. LOLO 2025 PR-AUC means 0.163 / 0.232 /
0.314. Pooled-all-5 beats Bhubaneswar-only on all three events
(0.1920 / 0.2214 / 0.3768 vs 0.1800 / 0.2047 / 0.3487) but stays
below v3.2's 0.2228. A runtime restart killed the first run at
~42 min with nothing saved (no checkpointing); the script was made
resumable (writes after each config, skips completed ones) and
re-run to completion in ~29.5 min. Lesson: long jobs checkpoint
incrementally and log line-buffered.

## E10. Random Forest challenger

Full record: `V33_RANDOM_FOREST_EXPERIMENT.md`. Tuning: 300 trees,
depth None, leaf 5, balanced_subsample, event-aware weights; mean
OOF PR-AUC 0.1701 (3h ≥ 10 mm) vs 0.1932 three-family. 2025:
rf_alone 0.1920 / 0.2563 / 0.3792; xgb_rf 0.1916 / 0.2571 / 0.3989;
four_family 0.2011 / 0.2697 / 0.3868; stacking 0.1922 / 0.2606 /
0.4094. Verdict: NOT adopted — all block-bootstrap CIs include
zero; RF arms detect significantly fewer 3h ≥ 10 mm storms at the
F1 operating point.

## E11. Stacking (Phase 8)

- v32+v33 stacker (`test_stacking.py`): 2024-OOF gate FAILED on all
  three (0.0948 / 0.2275 / 0.3565 vs v33 fixed 0.1068 / 0.2565 /
  0.3620) — not adopted, despite 2025 0.1898 / 0.2378 / 0.4153
  (best of any approach on 3h ≥ 5 mm).
- RF 4-family stacker: passes its OOF gate on all three (0.1100 /
  0.2596 / 0.3698 vs fixed 0.1068 / 0.2565 / 0.3620), 2025 0.1922 /
  0.2606 / 0.4094, but block-bootstrap CIs include zero — not
  adopted.

## E12. Freeze

`ml/freeze_v33.py`. Frozen: base arm, 94 features, weights/Platt/
thresholds from 2024 validation, members refit on 2021–2024.
Verification: frozen artifacts reproduce variants.json 2025 PR-AUC
exactly (0.1687 / 0.2743 / 0.3915). Artifacts:
`models/rainfall_xgb_v3_3/frozen/`.

## E13. Final 2026 evaluation (Phase 9)

`ml/evaluate_2026.py` (run once) + `ml/bootstrap_2026.py`.
`final_2026_comparison.json`, `bootstrap_2026.json`. 2026 PR-AUC:
v3 0.2364 / 0.4006 / 0.4514; v3.1 0.2304 / 0.4336 / 0.4640; v3.2
0.2983 / 0.4293 / 0.4898; **v3.3 0.2998 / 0.4774 / 0.4956**.
Bootstrap: only the 6h ≥ 10 mm gap vs v3 excludes zero (+0.071,
CI [+0.002, +0.130]); vs v3.2 the gaps are a tie on 3h ≥ 10 mm
(+0.000) and 3h ≥ 5 mm (+0.003) and a +0.047 lean on 6h ≥ 10 mm
(P = 0.937). Shared regressors on 2026: 1h MAE 0.3256 / RMSE
1.4209; 3h 0.9736 / 3.7535; 6h 1.8106 / 6.6006.
