"""RAINWATCH AI multi-source data connectors (v3.2)."""

from .base_source import BaseDataSource, SourceManifest, retry_with_backoff

__all__ = ["BaseDataSource", "SourceManifest", "retry_with_backoff"]
