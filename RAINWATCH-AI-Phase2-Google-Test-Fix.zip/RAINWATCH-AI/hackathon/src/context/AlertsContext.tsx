import { createContext, useCallback, useContext, useMemo, type ReactNode } from 'react'
import { useLocalStorage } from '../hooks/useLocalStorage'
import { SAMPLE_ALERTS } from '../data/alertsData'
import type { Alert, AlertStatus } from '../types'

interface AlertsContextValue {
  alerts: Alert[]
  /** Alerts the user has not yet acknowledged (notification badge count). */
  activeCount: Alert[]
  activeCountValue: number
  dismissedCount: number
  acknowledge: (id: string) => void
  dismiss: (id: string) => void
  restore: (id: string) => void
  acknowledgeAll: () => void
  clearDismissed: () => void
  resetAlerts: () => void
}

const AlertsContext = createContext<AlertsContextValue | null>(null)

interface Persisted {
  status: Record<string, AlertStatus>
  cleared: string[]
}

const EMPTY: Persisted = { status: {}, cleared: [] }
const STORAGE_KEY = 'rainwatch.alerts'

export function AlertsProvider({ children }: { children: ReactNode }) {
  const [persisted, setPersisted] = useLocalStorage<Persisted>(STORAGE_KEY, EMPTY)

  const alerts = useMemo(
    () =>
      SAMPLE_ALERTS.filter((a) => !persisted.cleared.includes(a.id)).map((a) => ({
        ...a,
        status: persisted.status[a.id] ?? a.status,
      })),
    [persisted],
  )

  const setStatus = useCallback(
    (id: string, status: AlertStatus) =>
      setPersisted((prev) => ({ ...prev, status: { ...prev.status, [id]: status } })),
    [setPersisted],
  )

  const acknowledge = useCallback((id: string) => setStatus(id, 'acknowledged'), [setStatus])
  const dismiss = useCallback((id: string) => setStatus(id, 'dismissed'), [setStatus])

  const restore = useCallback(
    (id: string) =>
      setPersisted((prev) => {
        const status = { ...prev.status }
        delete status[id]
        return { ...prev, status }
      }),
    [setPersisted],
  )

  const acknowledgeAll = useCallback(
    () =>
      setPersisted((prev) => {
        const status = { ...prev.status }
        for (const a of SAMPLE_ALERTS) {
          if (!prev.cleared.includes(a.id) && status[a.id] !== 'dismissed') status[a.id] = 'acknowledged'
        }
        return { ...prev, status }
      }),
    [setPersisted],
  )

  const clearDismissed = useCallback(
    () =>
      setPersisted((prev) => ({
        ...prev,
        cleared: [...new Set([...prev.cleared, ...SAMPLE_ALERTS.filter((a) => prev.status[a.id] === 'dismissed').map((a) => a.id)])],
      })),
    [setPersisted],
  )

  const resetAlerts = useCallback(() => setPersisted({ ...EMPTY, status: {}, cleared: [] }), [setPersisted])

  const value = useMemo<AlertsContextValue>(() => {
    const activeList = alerts.filter((a) => a.status === 'active')
    return {
      alerts,
      activeCount: activeList,
      activeCountValue: activeList.length,
      dismissedCount: alerts.filter((a) => a.status === 'dismissed').length,
      acknowledge,
      dismiss,
      restore,
      acknowledgeAll,
      clearDismissed,
      resetAlerts,
    }
  }, [alerts, acknowledge, dismiss, restore, acknowledgeAll, clearDismissed, resetAlerts])

  return <AlertsContext.Provider value={value}>{children}</AlertsContext.Provider>
}

export function useAlerts(): AlertsContextValue {
  const ctx = useContext(AlertsContext)
  if (!ctx) throw new Error('useAlerts must be used inside <AlertsProvider>')
  return ctx
}
