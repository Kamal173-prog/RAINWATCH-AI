# v3.2 External Access — What Kam Needs to Provide

Date: 2026-11-23. This document lists, for each data source that v3.2
could not acquire, the exact step Kam needs to take and what to provide.
Nothing here requires Kam to share a password in chat — credentials go
through the Secure Vault.

## 1. INSAT-3D/3DR (MOSDAC) — highest priority

**What it unlocks:** satellite rainfall at ~4 km / 30-minute resolution
— the highest-resolution precipitation source for India. This is the
single most promising next data source for v3.3.

**Steps:**
1. Register at https://mosdac.gov.in/signup/ (free, open to researchers).
2. Provide the username and password via the Secure Vault (they become
   the `MOSDAC_USERNAME` and `MOSDAC_PASSWORD` environment variables).
3. Muse runs `python scripts/download_datasets.py --source insat --product 3RIMG_L2B_HEM --start 2021-01-01 --end 2025-12-31`.

**What is already built:** `ml/data_sources/insat_source.py` — catalog
search (tested live, returns granules), OAuth2 token flow, granule
download with retry/backoff. The HDF5 decoding step needs the first
granule to inspect its internal variable names.

**Cost:** free (research use). Download cap: 5000 files/user/day.

## 2. IMD AWS/ARG station observations

**What it unlocks:** ground-truth hourly rainfall at Bhubaneswar,
Cuttack, Puri, Paradip, Khordha and Gopalpur — the independent
verification dataset for all satellite/NWP products.

**Steps:**
1. Register at https://api.imd.gov.in/public/register.php.
2. Request IP whitelisting from IMD (see
   https://mausam.imd.gov.in/responsive/apis.php). Government
   registrants must use a gov.in / nic.in address — NIST may need to
   make this request institutionally.
3. Provide the API key via the Secure Vault (`IMD_API_KEY`).

**What is already built:** `ml/data_sources/imd_source.py` — station
registry, access check, and the fetch/process structure. The exact API
endpoint shape must be confirmed against the live IMD API reference
once access is granted.

## 3. MSWEP V3

**What it unlocks:** hourly precipitation at 0.1° from 1979–present,
merging gauges + satellites + reanalysis with machine learning.

**Steps:**
1. Submit a request at https://www.gloh2o.org/mswep (use your email).
2. GloH2O emails a shared Google Drive folder link.
3. Provide the link via the Secure Vault (`MSWEP_DRIVE_LINK`).

**What is already built:** `ml/data_sources/mswep_source.py` — variant
selection (Past / Past_nogauge), access check, and the fetch/process
structure. The rclone download must be confirmed against the actual
shared-drive layout in the reply email.

**Cost:** free (CC BY-NC 4.0, academic/research use).

## 4. JAXA GSMaP V8

**What it unlocks:** hourly satellite precipitation at 0.1°, with a
gauge-adjusted band (`hourlyPrecipRateGC`) — a second satellite product
to compare against IMERG and GFS.

**Steps (either route):**
- Route 1 (Google Earth Engine): sign up at
  https://earthengine.google.com/, run `earthengine authenticate` on
  your machine, and share the authenticated project.
- Route 2 (JAXA G-Portal): register at https://gportal.jaxa.jp/gpr/
  (free) for FTP access.

**What is already built:** `ml/data_sources/gsmap_source.py` — access
check, band selection, and the fetch/process structure.

## 5. ERA5-Land

**What it unlocks:** soil moisture (layers 1–3), soil temperature,
runoff and evaporation at 0.1° hourly — the land-surface features for
the flood-susceptibility component.

**Steps:**
1. Register at https://cds.climate.copernicus.eu/ (free).
2. Provide the CDS API token via the Secure Vault (`CDSAPI_KEY`,
   `CDSAPI_URL`).

**What is already built:** `ml/data_sources/era5_land_source.py` —
variable list, access check, and the fetch/process structure.

## 6. NASA GPM IMERG (from the v3.1 investigation — still the best satellite candidate)

**What it unlocks:** half-hourly satellite precipitation at ~10 km from
2000–present — a satellite *observation* (not a reanalysis), usable as
both a feature and an alternative precipitation target.

**Steps:**
1. Create a free NASA Earthdata account at
   https://urs.earthdata.nasa.gov/ (free).
2. Authorise the GES DISC application.
3. Provide the username/password via the Secure Vault (or download the
   point series yourself and share the file).

**Cost:** free.

## What does NOT need Kam

- GFS and ECMWF IFS (Open-Meteo Historical Forecast API): keyless,
  already acquired.
- ERA5 2021–2026 (Open-Meteo archive API): keyless, already acquired.
- The connector framework, preprocessing, alignment and QC: built.
- The v3.2-GFS model: trained and evaluated (see V32_TECHNICAL.md).
