export interface SliderProps {
  label: string
  value: number
  min: number
  max: number
  step?: number
  unit?: string
  onChange: (v: number) => void
  description?: string
  format?: (v: number) => string
}

export function Slider({
  label,
  value,
  min,
  max,
  step = 1,
  unit = '',
  onChange,
  description,
  format,
}: SliderProps) {
  const pct = ((value - min) / (max - min)) * 100
  const display = format ? format(value) : `${value}${unit}`

  return (
    <div className="group">
      <div className="mb-2 flex items-baseline justify-between gap-3">
        <label
          htmlFor={`slider-${label.replace(/\W+/g, '-').toLowerCase()}`}
          className="text-[13px] font-medium text-ink"
        >
          {label}
        </label>
        <span className="num rounded-lg border border-line bg-surface px-2 py-0.5 text-xs font-semibold text-accent">
          {display}
        </span>
      </div>
      <input
        id={`slider-${label.replace(/\W+/g, '-').toLowerCase()}`}
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        aria-valuetext={display}
        onChange={(e) => onChange(Number(e.target.value))}
        style={{
          background: `linear-gradient(to right, var(--rw-accent) 0%, var(--rw-accent) ${pct}%, color-mix(in srgb, var(--rw-muted) 22%, transparent) ${pct}%, color-mix(in srgb, var(--rw-muted) 22%, transparent) 100%)`,
        }}
      />
      <div className="mt-1.5 flex justify-between text-[10px] text-muted">
        <span>
          {min}
          {unit}
        </span>
        {description ? <span className="text-muted/80">{description}</span> : null}
        <span>
          {max}
          {unit}
        </span>
      </div>
    </div>
  )
}
