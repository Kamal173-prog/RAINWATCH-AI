"""Bootstrap the 2025 PR-AUC gap for 3h >= 10mm between the v3.2 53-feature
set and the v3.3 102-feature set (base arm, same protocol).

The diagnostic showed v32 0.2228 vs v33-unpruned 0.1770 on 2025, while
OOF (2022-2024) showed the reverse (0.1638 -> 0.1932). With only 87
positive hours in 2025, the gap may be noise. A paired bootstrap over
the 2025 rows gives a confidence interval on the difference, which
decides whether the freeze should trust OOF or 2025 for this event.
2026 is NOT touched.
"""
import json
import os
import sys

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "ml"))
from train_rainfall_v33 import (  # noqa: E402
    TARGETS,
    _refit_arm,
    _train_arm,
    load_table,
    load_v32_features,
    load_v33_features,
)

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "models",
                   "rainfall_xgb_v3_3")
TARGET = "y_3h_ge_10mm"
N_BOOT = 1000
SEED = 42


def _probs_for(feats: list[str], tr, va, tv, te) -> np.ndarray:
    _, w, platt, _ = _train_arm("base", TARGET, tr, va, feats)
    models = _refit_arm("base", TARGET, tv, feats, w, platt)
    X_te = te[feats].to_numpy(dtype=float)
    probs = {f: models[f].predict_proba(X_te)[:, 1] for f in ("xgb", "lgbm", "hgb")}
    return sum(w[f] * probs[f] for f in ("xgb", "lgbm", "hgb"))


def main() -> None:
    df = load_table("v33")
    tr = df[df["timestamp"].dt.year.isin([2021, 2022, 2023])].reset_index(drop=True)
    va = df[df["timestamp"].dt.year == 2024].reset_index(drop=True)
    tv = pd.concat([tr, va], ignore_index=True)
    te = df[df["timestamp"].dt.year == 2025].reset_index(drop=True)
    y = te[TARGET].to_numpy().astype(int)
    print(f"2025 n={len(y)} positives={int(y.sum())}", flush=True)

    p32 = _probs_for(load_v32_features(), tr, va, tv, te)
    print(f"v32_53 2025 PR-AUC {average_precision_score(y, p32):.4f}", flush=True)
    p33 = _probs_for(load_v33_features(), tr, va, tv, te)
    print(f"v33_102 2025 PR-AUC {average_precision_score(y, p33):.4f}", flush=True)
    np.save(os.path.join(OUT, "bootstrap_p32_3h10.npy"), p32)
    np.save(os.path.join(OUT, "bootstrap_p33_3h10.npy"), p33)

    rng = np.random.default_rng(SEED)
    diffs = np.empty(N_BOOT)
    n = len(y)
    for b in range(N_BOOT):
        idx = rng.integers(0, n, n)
        if y[idx].sum() == 0:
            diffs[b] = np.nan
            continue
        diffs[b] = (average_precision_score(y[idx], p32[idx])
                    - average_precision_score(y[idx], p33[idx]))
    diffs = diffs[~np.isnan(diffs)]
    lo, hi = np.percentile(diffs, [2.5, 97.5])
    print(f"paired bootstrap (n={len(diffs)}): v32 - v33 PR-AUC diff "
          f"mean {diffs.mean():.4f} 95% CI [{lo:.4f}, {hi:.4f}] "
          f"P(diff > 0) = {(diffs > 0).mean():.3f}")
    res = {"target": TARGET, "n_2025": int(n), "positives_2025": int(y.sum()),
           "pr_auc_v32_53": round(float(average_precision_score(y, p32)), 4),
           "pr_auc_v33_102": round(float(average_precision_score(y, p33)), 4),
           "diff_mean": round(float(diffs.mean()), 4),
           "diff_ci_95": [round(float(lo), 4), round(float(hi), 4)],
           "p_diff_gt_0": round(float((diffs > 0).mean()), 3),
           "n_boot": N_BOOT}
    with open(os.path.join(OUT, "bootstrap_3h10.json"), "w") as f:
        json.dump(res, f, indent=2)
    print("saved models/rainfall_xgb_v3_3/bootstrap_3h10.json")


if __name__ == "__main__":
    main()
