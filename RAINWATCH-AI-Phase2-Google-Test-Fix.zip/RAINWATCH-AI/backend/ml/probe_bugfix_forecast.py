"""Post-fix verification probe: Forecast Data Table must show 6 MODEL + 18 DEMO
for Old Town (and 24 DEMO for Brahmapur), rendered in the browser, plus the
CSV export's Source column. Exits non-zero on any failure."""
import json, sys
from pathlib import Path
from playwright.sync_api import sync_playwright

OUT = Path.home() / "workspace" / "bugfix-screenshots"
OUT.mkdir(parents=True, exist_ok=True)
results = {}

with sync_playwright() as p:
    b = p.chromium.launch()
    page = b.new_page()
    page.on("console", lambda m: results.setdefault("console_errors", []).append(m.text) if m.type == "error" else None)
    page.on("requestfailed", lambda r: results.setdefault("failed_requests", []).append(r.url) if "tile.openstreetmap" not in r.url and "fonts.g" not in r.url else None)

    # --- Forecast page, default location (Old Town) ---
    page.goto("http://localhost:5173/forecast", wait_until="networkidle")
    page.wait_for_timeout(4000)
    body = page.locator("body").inner_text()
    model_badges = page.locator("text=MODEL").count()
    demo_badges = page.locator("text=DEMO").count()
    results["forecast_old_town"] = {"MODEL_badges": model_badges, "DEMO_badges": demo_badges}
    # The table's Source column: count exact badge texts in the table body
    table = page.locator("table").first
    rows = table.locator("tbody tr").count() if table.count() else 0
    results["forecast_old_town"]["table_rows"] = rows
    page.screenshot(path=str(OUT / "forecast-fixed-old-town.png"), full_page=True)

    # --- CSV export ---
    with page.expect_download() as dl:
        page.get_by_text("CSV", exact=False).first.click()
    dl.value.save_as(str(OUT / "forecast-fixed.csv"))
    lines = (OUT / "forecast-fixed.csv").read_text().strip().splitlines()
    header = lines[0]
    sources = [l.rsplit(",", 1)[-1].strip() for l in lines[1:]]
    results["csv_export"] = {"header": header, "rows": len(lines) - 1,
                             "model_rows": sources.count("model"), "demo_rows": sources.count("demo")}

    # --- Brahmapur (custom Select: label is "Name · Zone") ---
    try:
        page.get_by_label("Location").click()
        page.wait_for_timeout(800)
        page.get_by_text("Brahmapur", exact=False).first.click()
        page.wait_for_timeout(3000)
    except Exception as e:
        results["brahmapur_switch_error"] = str(e)[:200]
    results["forecast_brahmapur_badges"] = {"MODEL": page.locator("text=MODEL").count(),
                                            "DEMO": page.locator("text=DEMO").count()}
    page.screenshot(path=str(OUT / "forecast-fixed-brahmapur.png"), full_page=True)
    b.close()

print(json.dumps(results, indent=2))
ok = (results["forecast_old_town"]["MODEL_badges"] >= 6
      and results["csv_export"]["model_rows"] == 6
      and results["csv_export"]["demo_rows"] == 18)
print("VERDICT:", "PASS" if ok else "FAIL")
sys.exit(0 if ok else 1)
