"""Tests for POST /api/simulate (the What-if simulator).

The simulator is a deterministic demo formula — explicitly NOT an AI
model — so these tests assert its contract: validation bounds, response
structure, determinism, and severity mapping.

Note: the brief names ``/api/simulations/run`` and
``/api/simulations/compare``. Neither endpoint exists in this codebase
(see docs/ENGINEERING_AUDIT.md §2): the real surface is
``POST /api/simulate`` (and ``GET /api/overview`` for the bundle). The
last two tests here assert that absence explicitly, so a future
addition is a deliberate product decision, not an accident.
"""

import pytest

VALID = {
    "locationId": "old-town",
    "rainfallMmHr": 60,
    "durationH": 12,
    "soilSaturationPct": 70,
    "drainageEfficiencyPct": 40,
    "riverLevelPct": 55,
}


def test_simulate_ok(v3_client):
    r = v3_client.post("/api/simulate", json=VALID)
    assert r.status_code == 200
    body = r.json()
    assert {"riskIndex", "riskLevel", "affectedZones",
            "inundationSeverity", "peakDepthM", "durationToImpactH",
            "breakdown", "inputs"} <= set(body)
    assert 1 <= body["riskIndex"] <= 99
    assert body["riskLevel"] in ("Low", "Moderate", "High", "Very High", "Critical")
    assert 0 <= body["affectedZones"] <= 14
    assert body["inundationSeverity"] in ("None", "Minor", "Moderate", "Severe", "Extreme")
    assert 0 <= body["peakDepthM"] <= 3.6
    assert 0.5 <= body["durationToImpactH"] <= 12
    assert body["inputs"] == VALID
    # Breakdown: five factors, contributions roughly sum to ~100.
    assert [b["factor"] for b in body["breakdown"]] == [
        "Rainfall intensity", "Storm duration", "Soil saturation",
        "River / water level", "Terrain & drainage"]
    assert 90 <= sum(b["contribution"] for b in body["breakdown"]) <= 110


def test_simulate_deterministic(v3_client):
    first = v3_client.post("/api/simulate", json=VALID).json()
    second = v3_client.post("/api/simulate", json=VALID).json()
    assert first == second


def test_simulate_dry_inputs_low_risk(v3_client):
    dry = dict(VALID, rainfallMmHr=0, durationH=1, soilSaturationPct=0,
               drainageEfficiencyPct=100, riverLevelPct=0)
    body = v3_client.post("/api/simulate", json=dry).json()
    assert body["riskIndex"] < 20
    assert body["inundationSeverity"] == "None"


def test_simulate_extreme_inputs_high_risk(v3_client):
    wet = dict(VALID, rainfallMmHr=300, durationH=72, soilSaturationPct=100,
               drainageEfficiencyPct=0, riverLevelPct=100)
    body = v3_client.post("/api/simulate", json=wet).json()
    assert body["riskIndex"] >= 80
    assert body["inundationSeverity"] == "Extreme"
    assert body["riskLevel"] == "Critical"


@pytest.mark.parametrize("field,value", [
    ("rainfallMmHr", -1), ("rainfallMmHr", 301),
    ("durationH", 0), ("durationH", 73),
    ("soilSaturationPct", -1), ("soilSaturationPct", 101),
    ("drainageEfficiencyPct", -1), ("drainageEfficiencyPct", 101),
    ("riverLevelPct", -1), ("riverLevelPct", 101),
])
def test_simulate_out_of_bounds(v3_client, field, value):
    body = dict(VALID, **{field: value})
    assert v3_client.post("/api/simulate", json=body).status_code == 422


@pytest.mark.parametrize("field", [
    "locationId", "rainfallMmHr", "durationH", "soilSaturationPct",
    "drainageEfficiencyPct", "riverLevelPct",
])
def test_simulate_missing_field(v3_client, field):
    body = {k: v for k, v in VALID.items() if k != field}
    assert v3_client.post("/api/simulate", json=body).status_code == 422


def test_simulate_wrong_types(v3_client):
    body = dict(VALID, rainfallMmHr="heavy")
    assert v3_client.post("/api/simulate", json=body).status_code == 422


def test_simulate_unknown_location(v3_client):
    body = dict(VALID, locationId="not-a-place")
    r = v3_client.post("/api/simulate", json=body)
    assert r.status_code == 404
    assert "not-a-place" in r.json()["detail"]


def test_simulate_empty_body(v3_client):
    assert v3_client.post("/api/simulate", json={}).status_code == 422


def test_simulate_malformed_json(v3_client):
    r = v3_client.post("/api/simulate", content="{not json",
                       headers={"Content-Type": "application/json"})
    assert r.status_code == 422


def test_simulate_ganjam_location_works(v3_client):
    body = dict(VALID, locationId="brahmapur")
    r = v3_client.post("/api/simulate", json=body)
    assert r.status_code == 200
    # The simulator is location-agnostic demo maths (terrain differs);
    # it must not claim any ML provenance.
    assert "source" not in r.json()
    assert "model_version" not in r.json()


def test_simulations_run_endpoint_does_not_exist(v3_client):
    """Documents the audit finding: /api/simulations/run is not a route."""
    assert v3_client.post("/api/simulations/run", json=VALID).status_code == 404


def test_simulations_compare_endpoint_does_not_exist(v3_client):
    """Documents the audit finding: /api/simulations/compare is not a route."""
    assert v3_client.post("/api/simulations/compare", json={}).status_code == 404
