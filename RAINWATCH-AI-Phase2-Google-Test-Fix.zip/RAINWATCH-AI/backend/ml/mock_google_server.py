"""Test harness ONLY — run the RAINWATCH backend with Google Weather mocked.

Starts uvicorn on a test port with an httpx MockTransport returning a
24h fixture built from Google's documented response shape. The server
code is unchanged; the mock is injected in this harness process only.
Never used by the production server. Usage:

    python ml/mock_google_server.py [port]   # default 8009
"""

import os
import sys

os.environ.setdefault("GOOGLE_WEATHER_API_KEY", "test-demo-key")
os.environ.setdefault("MODEL_VERSION", "rainfall-xgb-v3.3")

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import httpx  # noqa: E402
import uvicorn  # noqa: E402

from app.services import google_weather as gw  # noqa: E402


def _hour(i):
    from datetime import datetime, timedelta, timezone
    # Fixture anchored to the current UTC hour (like the RAINWATCH
    # base hour), so the merged forecast's interval matching covers
    # the whole requested range no matter when the probe runs. The
    # fixed 2026-11-25T00:00Z anchor it replaced would leave early
    # hours unmatched once the clock moved past it.
    now = datetime.now(timezone.utc)
    base = now.replace(minute=0, second=0, microsecond=0)
    start = base + timedelta(hours=i)
    end = start + timedelta(hours=1)
    rain = i in (5, 6)
    return {
        "interval": {
            "startTime": start.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "endTime": end.strftime("%Y-%m-%dT%H:%M:%SZ"),
        },
        "temperature": {"degrees": 28.0 - (i % 24) * 0.2, "unit": "CELSIUS"},
        "relativeHumidity": 70 + (i % 5),
        "precipitation": {
            "probability": {"percent": 65 if rain else 10, "type": "RAIN" if rain else "NONE"},
            "qpf": {"quantity": 1.4 if rain else 0.0, "unit": "MILLIMETERS"},
        },
        "wind": {
            "direction": {"degrees": 120, "cardinal": "ESE"},
            "speed": {"value": 11.0, "unit": "KILOMETERS_PER_HOUR"},
        },
        "weatherCondition": {
            "type": "LIGHT_RAIN" if rain else "PARTLY_CLOUDY",
            "description": {"text": "Light rain" if rain else "Partly cloudy"},
        },
    }


def _handler(request: httpx.Request) -> httpx.Response:
    pages = request.url.params.get("pageToken")
    idx = 0 if pages is None else int(pages)
    hours_req = int(request.url.params.get("hours", "24"))
    start = idx * 24
    hours = [_hour(start + i) for i in range(24)]
    next_token = str(idx + 1) if (idx + 1) * 24 < hours_req else None
    return httpx.Response(200, json={
        "forecastHours": hours,
        "timeZone": {"id": "Asia/Kolkata"},
        "nextPageToken": next_token,
    })


if __name__ == "__main__":
    gw.set_transport(httpx.MockTransport(_handler))
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8009
    uvicorn.run("app.main:app", host="127.0.0.1", port=port, log_level="warning")
