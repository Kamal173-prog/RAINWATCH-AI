import 'leaflet/dist/leaflet.css'

import { AnimatePresence, motion } from 'framer-motion'
import {
  AlertTriangle,
  CloudRain,
  Expand,
  Layers,
  Minimize2,
  RadioTower,
  RotateCcw,
  Search,
  Siren,
  Users,
  Waves,
  X,
} from 'lucide-react'
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import {
  Circle,
  CircleMarker,
  MapContainer,
  Marker,
  Polygon,
  Popup,
  TileLayer,
  Tooltip,
  useMap,
} from 'react-leaflet'
import type { Map as LeafletMap } from 'leaflet'
import L from 'leaflet'
import { useDemo } from '../../context/DemoContext'
import { useAsyncData } from '../../hooks/useAsyncData'
import { demoApi } from '../../services/dataService'
import { LOCATIONS, regionOf } from '../../data/locationsData'
import { classifyRainfall, RISK_COLORS, rainfallColor, relativeTime } from '../../utils/colors'
import type { MapLayerId, RegionCondition } from '../../types'
import { Badge, DemoBadge, RainBadge, RiskBadge } from '../common/Badge'
import { Button } from '../common/Button'
import { Skeleton, StatePanel } from '../common/Skeleton'

/* ------------------------------------------------------------------ */

interface LayerDef {
  id: MapLayerId
  label: string
  color: string
  icon: typeof CloudRain
}

export const LAYER_DEFS: LayerDef[] = [
  { id: 'rainfall', label: 'Rainfall Intensity', color: '#6FD6C2', icon: CloudRain },
  { id: 'riskZones', label: 'Flood Risk Zones', color: '#F05A43', icon: Waves },
  { id: 'inundation', label: 'Inundation Extent', color: '#6FD6C2', icon: Waves },
  { id: 'vulnerable', label: 'Vulnerable Locations', color: '#F2A93B', icon: Siren },
  { id: 'stations', label: 'Monitoring Stations', color: '#69D2A0', icon: RadioTower },
  { id: 'population', label: 'Population Density', color: '#B19BFA', icon: Users },
  { id: 'scenario', label: 'Simulation Overlay', color: '#F05A43', icon: AlertTriangle },
]

const RAINFALL_LEGEND = [
  { label: 'Light <2.5', color: '#69D2A0' },
  { label: 'Moderate 2.5–15.5', color: '#6FD6C2' },
  { label: 'Heavy 15.6–64.4', color: '#F2A93B' },
  { label: 'Very Heavy 64.5–115.5', color: '#F0823F' },
  { label: 'Extremely Heavy >115.5', color: '#F05A43' },
]

function populationColor(density: number): string {
  if (density >= 6000) return '#F05A43'
  if (density >= 3500) return '#F2A93B'
  if (density >= 1800) return '#6FD6C2'
  return '#69D2A0'
}

/* ------------------------- map controller -------------------------- */

interface FlyTarget {
  lat: number
  lng: number
  zoom: number
  nonce: number
}

function MapController({
  target,
  resetNonce,
  center,
  zoom,
  onReady,
}: {
  target: FlyTarget | null
  resetNonce: number
  center: [number, number]
  zoom: number
  onReady: (map: LeafletMap) => void
}) {
  const map = useMap()

  useEffect(() => {
    onReady(map)
  }, [map, onReady])

  useEffect(() => {
    if (target) map.flyTo([target.lat, target.lng], target.zoom, { duration: 0.85 })
  }, [target, map])

  useEffect(() => {
    if (resetNonce > 0) map.flyTo(center, zoom, { duration: 0.7 })
  }, [resetNonce, map])

  return null
}

/* ------------------------------ props ------------------------------ */

export interface RainMapProps {
  height?: number
  /** Reduced control set for embedded (Overview) usage. */
  compact?: boolean
  /** Controlled layer state (when supplied, onLayersChange should update it). */
  layers?: MapLayerId[]
  /** Default layers for uncontrolled usage. */
  initialLayers?: MapLayerId[]
  onLayersChange?: (layers: MapLayerId[]) => void
  selectedLocationId?: string
  onSelectLocation?: (id: string) => void
  className?: string
}

export function RainMap({
  height = 560,
  compact = false,
  layers: controlledLayers,
  initialLayers,
  onLayersChange,
  selectedLocationId,
  onSelectLocation,
  className = '',
}: RainMapProps) {
  const { version, scenario, clearScenario } = useDemo()
  const { data, loading, error, reload } = useAsyncData(
    () => Promise.all([demoApi.fetchMapLayers(), demoApi.fetchRegionConditions()]),
    [version],
  )

  const [internalLayers, setInternalLayers] = useState<Set<MapLayerId>>(
    () => new Set(initialLayers ?? ['rainfall', 'riskZones', 'inundation', 'vulnerable', 'stations']),
  )
  const activeLayers = useMemo(
    () => new Set<MapLayerId>(controlledLayers ?? [...internalLayers]),
    [controlledLayers, internalLayers],
  )
  const [panelOpen, setPanelOpen] = useState(!compact)
  const [selected, setSelected] = useState<RegionCondition | null>(null)
  const [query, setQuery] = useState('')
  const [showSearchResults, setShowSearchResults] = useState(false)
  const [target, setTarget] = useState<FlyTarget | null>(null)
  const [resetNonce, setResetNonce] = useState(0)
  const [fullscreen, setFullscreen] = useState(false)
  const [tileErrors, setTileErrors] = useState(0)
  const mapRef = useRef<LeafletMap | null>(null)

  const activeRegion = regionOf(selectedLocationId ?? 'old-town')

  const mapLayers = data?.[0] ?? null
  const conditions = data?.[1] ?? null

  const byId = useMemo(() => {
    const m = new Map<string, RegionCondition>()
    for (const c of conditions ?? []) m.set(c.locationId, c)
    return m
  }, [conditions])

  const toggleLayer = (id: MapLayerId) => {
    const current: MapLayerId[] = controlledLayers ? [...controlledLayers] : [...internalLayers]
    const next: MapLayerId[] = current.includes(id)
      ? current.filter((x) => x !== id)
      : [...current, id]
    setInternalLayers(new Set(next))
    onLayersChange?.(next)
  }

  const selectLocation = useCallback(
    (id: string) => {
      const c = byId.get(id) ?? null
      setSelected(c)
      onSelectLocation?.(id)
    },
    [byId, onSelectLocation],
  )

  // Keep the info card in sync when the global location changes elsewhere.
  useEffect(() => {
    if (selectedLocationId && byId.has(selectedLocationId)) {
      setSelected((prev) => (prev?.locationId === selectedLocationId ? prev : byId.get(selectedLocationId) ?? prev))
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedLocationId, byId.size])

  // A fresh simulation result flies the map to the affected region.
  useEffect(() => {
    if (!scenario) return
    const loc = LOCATIONS.find((l) => l.id === scenario.result.inputs.locationId)
    if (!loc) return
    setTarget({ lat: loc.lat, lng: loc.lng, zoom: 13, nonce: scenario.id })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scenario?.id])

  // Switching the global region (top-bar selector / sidebar) reframes the map.
  const mountedRegion = useRef(activeRegion.id)
  useEffect(() => {
    if (mountedRegion.current === activeRegion.id) return
    mountedRegion.current = activeRegion.id
    setTarget({
      lat: activeRegion.center[0],
      lng: activeRegion.center[1],
      zoom: activeRegion.zoom,
      nonce: Date.now(),
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeRegion.id])

  useEffect(() => {
    if (!fullscreen) return
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => {
      document.body.style.overflow = prev
    }
  }, [fullscreen])

  const onReady = useCallback((m: LeafletMap) => {
    mapRef.current = m
  }, [])

  const results = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return LOCATIONS.slice(0, 6)
    return LOCATIONS.filter(
      (l) => l.name.toLowerCase().includes(q) || l.zone.toLowerCase().includes(q),
    ).slice(0, 8)
  }, [query])

  const runSearch = (id: string, lat: number, lng: number) => {
    setTarget({ lat, lng, zoom: 14, nonce: Date.now() })
    selectLocation(id)
    setQuery('')
    setShowSearchResults(false)
  }

  const visible = (id: MapLayerId) => activeLayers.has(id)

  /* ------------------------------ render --------------------------- */

  const mapElement = (
    <MapContainer
      center={activeRegion.center}
      zoom={activeRegion.zoom}
      scrollWheelZoom
      zoomControl
      attributionControl
      className="h-full w-full"
      style={{ background: '#070d17' }}
    >
      <TileLayer
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        eventHandlers={{
          tileerror: () => setTileErrors((n) => n + 1),
        }}
      />
      <MapController target={target} resetNonce={resetNonce} center={activeRegion.center} zoom={activeRegion.zoom} onReady={onReady} />

      {/* ---- Flood risk zones ---- */}
      {visible('riskZones')
        ? mapLayers?.riskZones.map((z) => (
            <Polygon
              key={z.id}
              positions={z.polygon}
              pathOptions={{
                color: RISK_COLORS[z.level],
                weight: 1.8,
                fillColor: RISK_COLORS[z.level],
                fillOpacity: 0.16,
              }}
              eventHandlers={{ click: () => selectLocation(z.id.replace('zone-', '')) }}
            >
              <Tooltip direction="top" opacity={0.95}>
                <strong>{z.name}</strong>
                <br />
                Risk: {z.level}
              </Tooltip>
            </Polygon>
          ))
        : null}

      {/* ---- Inundation extent ---- */}
      {visible('inundation')
        ? mapLayers?.inundation.map((z) => (
            <Polygon
              key={z.id}
              positions={z.polygon}
              pathOptions={{
                color: '#6FD6C2',
                weight: 1.4,
                fillColor: '#6FD6C2',
                fillOpacity: 0.14,
                dashArray: '7 7',
              }}
            >
              <Tooltip direction="top" opacity={0.95}>
                <strong>{z.name}</strong>
                <br />
                Est. depth {z.depthM} m · confidence {z.confidencePct}%
                <br />
                <span style={{ opacity: 0.7 }}>Illustrative extent</span>
              </Tooltip>
            </Polygon>
          ))
        : null}

      {/* ---- Rainfall intensity halos ---- */}
      {visible('rainfall')
        ? conditions?.map((c) => (
            <CircleMarker
              key={`rain-${c.locationId}`}
              center={[c.lat, c.lng]}
              radius={9 + Math.min(28, c.rainfallMmHr / 3.4)}
              pathOptions={{
                color: rainfallColor(c.rainfallMmHr),
                weight: 1.6,
                fillColor: rainfallColor(c.rainfallMmHr),
                fillOpacity: 0.2,
              }}
              eventHandlers={{ click: () => selectLocation(c.locationId) }}
            >
              <Tooltip direction="top" opacity={0.95}>
                <strong>{c.name}</strong>
                <br />
                Rainfall {c.rainfallMmHr} mm/hr
              </Tooltip>
            </CircleMarker>
          ))
        : null}

      {/* ---- Population density ---- */}
      {visible('population')
        ? mapLayers?.population.map((cell) => (
            <CircleMarker
              key={cell.id}
              center={[cell.lat, cell.lng]}
              radius={5 + Math.min(12, cell.densityPerKm2 / 900)}
              pathOptions={{
                color: populationColor(cell.densityPerKm2),
                weight: 0.8,
                fillColor: populationColor(cell.densityPerKm2),
                fillOpacity: 0.3,
              }}
            >
              <Tooltip direction="top" opacity={0.95}>
                <strong>{cell.label}</strong>
                <br />
                {cell.densityPerKm2.toLocaleString('en-IN')} persons/km²
              </Tooltip>
            </CircleMarker>
          ))
        : null}

      {/* ---- Monitoring stations (radar pulse) ---- */}
      {visible('stations')
        ? mapLayers?.stations.map((st) => (
            <Marker
              key={st.id}
              position={[st.lat, st.lng]}
              icon={L.divIcon({
                className: '',
                iconSize: [13, 13],
                iconAnchor: [6, 6],
                html: `<span class="rw-station rw-station--${st.status}"></span>`,
              })}
              eventHandlers={{ click: () => selectLocation(st.id.replace('st-', '')) }}
            >
              <Popup>
                <strong>{st.name}</strong>
                <br />
                Status: {st.status}
                <br />
                Rainfall: {st.rainfallMmHr} mm/hr
                <br />
                <span style={{ opacity: 0.75 }}>Updated {relativeTime(st.lastUpdate)}</span>
              </Popup>
            </Marker>
          ))
        : null}

      {/* ---- Vulnerable locations ---- */}
      {visible('vulnerable')
        ? mapLayers?.vulnerable.map((site) => (
            <Marker
              key={site.id}
              position={[site.lat, site.lng]}
              icon={L.divIcon({
                className: '',
                iconSize: [16, 16],
                iconAnchor: [8, 8],
                html: `<span class="rw-marker" style="width:14px;height:14px;background:#F2A93B;border-radius:4px"></span>`,
              })}
            >
              <Popup>
                <strong>{site.name}</strong>
                <br />
                Type: {site.type}
                <br />
                Vulnerability: {site.vulnerability}
              </Popup>
            </Marker>
          ))
        : null}

      {/* ---- Latest what-if simulation warning overlay ---- */}
      {visible('scenario') && scenario
        ? (() => {
            const loc = LOCATIONS.find((l) => l.id === scenario.result.inputs.locationId)
            if (!loc) return null
            const r = scenario.result
            const color = RISK_COLORS[r.riskLevel]
            const outerRadius = 620 + r.riskIndex * 24
            const innerRadius = 240 + r.riskIndex * 9
            const glyph = `<span class="rw-warning-pin radar-pulse" style="border-color:${color};color:${color}"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2.4" stroke-linecap="square"><path d="M12 3 22 20H2L12 3Z"/><path d="M12 9v5"/><circle cx="12" cy="17" r="0.8" fill="${color}"/></svg></span>`
            return (
              <>
                <Circle
                  center={[loc.lat, loc.lng]}
                  radius={outerRadius}
                  pathOptions={{ color, weight: 2, fillColor: color, fillOpacity: 0.14, dashArray: '9 7' }}
                  eventHandlers={{ click: () => selectLocation(loc.id) }}
                >
                  <Tooltip direction="top" opacity={0.95} permanent={false}>
                    <strong>SIMULATION WARNING · {r.riskLevel.toUpperCase()}</strong>
                    <br />
                    Risk {r.riskIndex}/100 · {r.inundationSeverity} inundation
                  </Tooltip>
                  <Popup>
                    <strong>Simulation scenario · {loc.name}</strong>
                    <br />
                    Risk index: {r.riskIndex}/100 ({r.riskLevel})
                    <br />
                    Inundation severity: {r.inundationSeverity}
                    <br />
                    Estimated depth: {r.peakDepthM} m · zones: {r.affectedZones}
                    <br />
                    Inputs: {r.inputs.rainfallMmHr} mm/hr × {r.inputs.durationH} h · drainage {r.inputs.drainageEfficiencyPct}%
                    <br />
                    <span style={{ opacity: 0.7 }}>Educational demo simulation — illustrative only.</span>
                  </Popup>
                </Circle>
                <Circle
                  center={[loc.lat, loc.lng]}
                  radius={innerRadius}
                  pathOptions={{ color, weight: 1, fillColor: color, fillOpacity: 0.16 }}
                  eventHandlers={{ click: () => selectLocation(loc.id) }}
                />
                <Marker
                  position={[loc.lat, loc.lng]}
                  zIndexOffset={900}
                  icon={L.divIcon({ className: '', iconSize: [24, 24], iconAnchor: [12, 12], html: glyph })}
                  eventHandlers={{ click: () => selectLocation(loc.id) }}
                >
                  <Popup>
                    <strong>Simulation epicentre</strong>
                    <br />
                    {r.riskLevel} risk · {r.inundationSeverity} severity
                  </Popup>
                </Marker>
              </>
            )
          })()
        : null}

      {/* ---- Location labels / click targets ---- */}
      {conditions?.map((c) => (
        <Marker
          key={c.locationId}
          position={[c.lat, c.lng]}
          zIndexOffset={500}
          icon={L.divIcon({
            className: '',
            iconSize: [0, 0],
            html: `<span class="rw-marker-label">${c.name}</span>`,
          })}
          eventHandlers={{ click: () => selectLocation(c.locationId) }}
        >
          <Popup>
            <strong>{c.name}</strong>
            <br />
            <span style={{ opacity: 0.75 }}>{c.zone}</span>
            <br />
            Rainfall: {c.rainfallMmHr} mm/hr
            <br />
            Risk: {c.riskLevel} ({c.riskIndex}/100)
            <br />
            Est. inundation: {c.inundationDepthM} m
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  )

  const tileFallback =
    tileErrors > 12 ? (
      <div className="pointer-events-none absolute inset-0 z-[400] flex items-center justify-center bg-[linear-gradient(140deg,#0a1322_0%,#0d1a2e_55%,#0a1526_100%)] px-6">
        <div className="max-w-sm rounded-2xl border border-line bg-card px-5 py-4 text-center shadow-2xl">
          <p className="text-sm font-semibold text-ink">Basemap tiles unavailable</p>
          <p className="mt-1.5 text-xs leading-relaxed text-muted">
            The OpenStreetMap tile server could not be reached (offline demo?). All illustrative
            overlays, markers and popups remain fully interactive on the schematic background.
          </p>
          <Badge tone="accent" className="mt-3">
            Graceful fallback active
          </Badge>
        </div>
      </div>
    ) : null

  const layerPanel = (
    <div className="w-[218px] rounded-xl border border-line bg-card p-2.5 shadow-[4px_4px_0_#050708]">
      <div className="mb-1.5 flex items-center justify-between px-1">
        <span className="flex items-center gap-1.5 text-[10px] font-bold tracking-[0.14em] text-muted uppercase">
          <Layers size={12} aria-hidden /> Layers
        </span>
        {!compact ? (
          <button
            type="button"
            onClick={() => setPanelOpen(false)}
            aria-label="Collapse layer panel"
            className="text-muted hover:text-ink"
          >
            <X size={13} aria-hidden />
          </button>
        ) : null}
      </div>
      <div className="space-y-0.5">
        {LAYER_DEFS.map((def) => {
          const on = activeLayers.has(def.id)
          const Icon = def.icon
          return (
            <button
              key={def.id}
              type="button"
              role="switch"
              aria-checked={on}
              onClick={() => toggleLayer(def.id)}
              className={`flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left transition-colors ${
                on ? 'bg-surface text-ink' : 'text-muted hover:bg-surface/60 hover:text-ink'
              }`}
            >
              <span
                className="flex h-4 w-4 shrink-0 items-center justify-center rounded border"
                style={{
                  borderColor: on ? def.color : 'var(--rw-border)',
                  background: on ? `${def.color}26` : 'transparent',
                }}
                aria-hidden
              >
                {on ? <span className="h-1.5 w-1.5 rounded-sm" style={{ background: def.color }} /> : null}
              </span>
              <Icon size={12} style={{ color: on ? def.color : 'currentColor' }} aria-hidden />
              <span className="flex-1 truncate text-[11px] font-medium">{def.label}</span>
            </button>
          )
        })}
      </div>
    </div>
  )

  const legend = (
    <div className="max-w-[260px] rounded-xl border border-line bg-card px-3 py-2.5 shadow-[4px_4px_0_#050708]">
      <p className="mb-1.5 text-[10px] font-bold tracking-[0.14em] text-muted uppercase">Legend</p>
      {visible('rainfall') ? (
        <div className="mb-1.5">
          <p className="mb-1 text-[10px] font-semibold text-ink">Rainfall (mm/hr)</p>
          <div className="grid grid-cols-1 gap-0.5">
            {RAINFALL_LEGEND.map((r) => (
              <span key={r.label} className="flex items-center gap-1.5 text-[10px] text-muted">
                <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: r.color }} />
                {r.label}
              </span>
            ))}
          </div>
        </div>
      ) : null}
      {visible('riskZones') ? (
        <div className="mb-1.5">
          <p className="mb-1 text-[10px] font-semibold text-ink">Flood risk</p>
          <div className="flex flex-wrap gap-x-2.5 gap-y-1">
            {(['Low', 'Moderate', 'High', 'Very High', 'Critical'] as const).map((lvl) => (
              <span key={lvl} className="flex items-center gap-1 text-[10px] text-muted">
                <span
                  className="h-2 w-2 rounded-sm"
                  style={{ background: RISK_COLORS[lvl], opacity: 0.85 }}
                />
                {lvl}
              </span>
            ))}
          </div>
        </div>
      ) : null}
      <div className="flex flex-wrap gap-x-3 gap-y-1">
        {visible('inundation') ? (
          <span className="flex items-center gap-1 text-[10px] text-muted">
            <span className="h-0 w-3 border-t-2 border-dashed border-[#6FD6C2]" /> Inundation extent
          </span>
        ) : null}
        {visible('stations') ? (
          <span className="flex items-center gap-1 text-[10px] text-muted">
            <span className="h-2 w-2 rounded-full bg-[#6FD6C2] ring-2 ring-[#0a0d0e]" /> Station
          </span>
        ) : null}
        {visible('vulnerable') ? (
          <span className="flex items-center gap-1 text-[10px] text-muted">
            <span className="h-2.5 w-2.5 rounded-sm bg-[#F2A93B]" /> Vulnerable site
          </span>
        ) : null}
        {visible('population') ? (
          <span className="flex items-center gap-1 text-[10px] text-muted">
            <span className="h-2 w-2 rounded-full bg-[#B19BFA]" /> Population cell
          </span>
        ) : null}
        {visible('scenario') && scenario ? (
          <span className="flex items-center gap-1 text-[10px] font-semibold" style={{ color: RISK_COLORS[scenario.result.riskLevel] }}>
            <AlertTriangle size={11} aria-hidden /> Simulation warning
          </span>
        ) : null}
      </div>
      <p className="mt-1.5 border-t border-line pt-1.5 text-[9px] leading-snug text-muted/80">
        All overlays are illustrative demo geometry — not real flood boundaries.
      </p>
    </div>
  )

  const infoCard = selected ? (
    <motion.div
      key={selected.locationId}
      initial={{ opacity: 0, y: 14, scale: 0.97 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ type: 'spring', stiffness: 320, damping: 26 }}
      className="w-[248px] rounded-xl border border-line bg-card p-3 shadow-[4px_4px_0_#050708]"
      role="status"
      aria-label={`Location details for ${selected.name}`}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="truncate text-sm font-semibold text-ink">{selected.name}</p>
          <p className="truncate text-[10px] text-muted">{selected.zone}</p>
        </div>
        <button
          type="button"
          onClick={() => setSelected(null)}
          aria-label="Close location details"
          className="text-muted transition-colors hover:text-ink"
        >
          <X size={14} aria-hidden />
        </button>
      </div>

      <div className="mt-2.5 grid grid-cols-2 gap-2">
        <div className="rounded-lg border border-line bg-surface p-2">
          <p className="text-[9px] tracking-wider text-muted uppercase">Rainfall</p>
          <p className="num mt-0.5 text-sm font-bold text-ink">{selected.rainfallMmHr} mm/hr</p>
          <div className="mt-1">
            <RainBadge label={classifyRainfall(selected.rainfallMmHr)} />
          </div>
        </div>
        <div className="rounded-lg border border-line bg-surface p-2">
          <p className="text-[9px] tracking-wider text-muted uppercase">Flood risk</p>
          <p className="num mt-0.5 text-sm font-bold text-ink">{selected.riskIndex}/100</p>
          <div className="mt-1">
            <RiskBadge level={selected.riskLevel} />
          </div>
        </div>
        <div className="rounded-lg border border-line bg-surface p-2">
          <p className="text-[9px] tracking-wider text-muted uppercase">Inundation</p>
          <p className="num mt-0.5 text-sm font-bold text-accent">{selected.inundationDepthM} m</p>
          <p className="text-[9px] text-muted">illustrative depth</p>
        </div>
        <div className="rounded-lg border border-line bg-surface p-2">
          <p className="text-[9px] tracking-wider text-muted uppercase">Vulnerability</p>
          <p className="mt-1.5 text-xs font-semibold text-ink">{selected.vulnerability}</p>
          <p className="text-[9px] text-muted">{selected.lowLyingPct}% low-lying</p>
        </div>
      </div>

      <div className="mt-2 flex items-center justify-between border-t border-line pt-2 text-[10px] text-muted">
        <span>Population at risk</span>
        <span className="num font-semibold text-ink">
          {selected.populationAtRisk.toLocaleString('en-IN')}
        </span>
      </div>
      <div className="mt-1 flex items-center justify-between text-[10px] text-muted">
        <span>Drainage efficiency</span>
        <span className="num font-semibold text-ink">{selected.drainageEfficiency}%</span>
      </div>
    </motion.div>
  ) : null

  const scenarioCard = scenario ? (
    <motion.div
      key={scenario.id}
      initial={{ opacity: 0, x: 18, scale: 0.96 }}
      animate={{ opacity: 1, x: 0, scale: 1 }}
      transition={{ type: 'spring', stiffness: 340, damping: 26 }}
      className="cut-br w-[224px] border-l-2 bg-card p-3 shadow-[4px_4px_0_#050708]"
      style={{ borderLeftColor: RISK_COLORS[scenario.result.riskLevel] }}
      role="status"
      aria-label="Active simulation overlay"
    >
      <div className="flex items-start justify-between gap-2">
        <p className="mono flex items-center gap-1.5 text-[9px] text-accent">
          <AlertTriangle size={12} aria-hidden /> Simulation overlay <DemoBadge compact />
        </p>
        <button
          type="button"
          onClick={clearScenario}
          aria-label="Clear simulation overlay"
          className="text-muted transition-colors hover:text-ink"
        >
          <X size={13} aria-hidden />
        </button>
      </div>
      <p className="num mt-2 text-xl leading-none font-bold text-ink">
        {scenario.result.riskIndex}
        <span className="mono ml-1 text-[9px] font-normal text-muted">/ 100</span>
      </p>
      <p className="mono mt-1 text-[10px]" style={{ color: RISK_COLORS[scenario.result.riskLevel] }}>
        {scenario.result.riskLevel.toUpperCase()} · {scenario.result.inundationSeverity.toUpperCase()}
      </p>
      <div className="mono mt-2 flex justify-between border-t border-line pt-2 text-[9px] text-muted">
        <span>{LOCATIONS.find((l) => l.id === scenario.result.inputs.locationId)?.name}</span>
        <span>{scenario.result.peakDepthM} M DEPTH</span>
      </div>
    </motion.div>
  ) : null

  const toolbar = (
    <div className="absolute top-3 left-3 z-[500] flex items-center gap-2">
      <div className="relative">
        <div className="flex h-9 w-[210px] items-center gap-2 rounded-xl border border-line bg-card px-3 shadow-[3px_3px_0_#050708] sm:w-[250px]">
          <Search size={14} className="shrink-0 text-muted" aria-hidden />
          <input
            value={query}
            onChange={(e) => {
              setQuery(e.target.value)
              setShowSearchResults(true)
            }}
            onFocus={() => setShowSearchResults(true)}
            placeholder="Search location…"
            aria-label="Search map locations"
            className="w-full bg-transparent text-xs text-ink placeholder:text-muted focus:outline-none"
          />
          {query ? (
            <button
              type="button"
              onClick={() => setQuery('')}
              aria-label="Clear search"
              className="text-muted hover:text-ink"
            >
              <X size={13} aria-hidden />
            </button>
          ) : null}
        </div>
        <AnimatePresence>
          {showSearchResults ? (
            <motion.div
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.16 }}
              className="absolute top-11 left-0 w-full overflow-hidden rounded-xl border border-line bg-card shadow-[4px_4px_0_#050708]"
            >
              <div className="max-h-56 overflow-y-auto p-1.5">
                {results.length === 0 ? (
                  <p className="px-3 py-5 text-center text-[11px] text-muted">No matching locations.</p>
                ) : (
                  results.map((loc) => (
                    <button
                      key={loc.id}
                      type="button"
                      onMouseDown={(e) => e.preventDefault()}
                      onClick={() => runSearch(loc.id, loc.lat, loc.lng)}
                      className={`block w-full rounded-lg px-3 py-2 text-left text-xs transition-colors ${
                        selectedLocationId === loc.id
                          ? 'bg-accent/12 text-accent'
                          : 'text-ink hover:bg-surface'
                      }`}
                    >
                      <span className="block truncate font-medium">{loc.name}</span>
                      <span className="block truncate text-[10px] text-muted">{loc.zone}</span>
                    </button>
                  ))
                )}
              </div>
              <div className="border-t border-line px-3 py-1.5 text-[9px] text-muted">
                Clicking a result flies the map and selects the region.
              </div>
            </motion.div>
          ) : null}
        </AnimatePresence>
      </div>

      <button
        type="button"
        onClick={() => setResetNonce((n) => n + 1)}
        aria-label="Reset map position"
        title="Reset map position"
        className="flex h-9 w-9 items-center justify-center rounded-xl border border-line bg-card text-muted shadow-[3px_3px_0_#050708] transition-all hover:border-accent/40 hover:text-accent"
      >
        <RotateCcw size={15} aria-hidden />
      </button>

      <button
        type="button"
        onClick={() => setFullscreen((v) => !v)}
        aria-label={fullscreen ? 'Exit fullscreen map' : 'Enter fullscreen map'}
        title={fullscreen ? 'Exit fullscreen' : 'Fullscreen'}
        className="flex h-9 w-9 items-center justify-center rounded-xl border border-line bg-card text-muted shadow-[3px_3px_0_#050708] transition-all hover:border-accent/40 hover:text-accent"
      >
        {fullscreen ? <Minimize2 size={15} aria-hidden /> : <Expand size={15} aria-hidden />}
      </button>
    </div>
  )

  const loadingState = (
    <div className="flex h-full flex-col gap-3 p-5">
      <Skeleton className="h-9 w-64 rounded-xl" />
      <Skeleton className="flex-1 rounded-xl" />
      <Skeleton className="h-4 w-72" />
    </div>
  )

  const errorState = (
    <div className="flex h-full items-center justify-center p-6">
      <StatePanel
        variant="error"
        title="Map data unavailable"
        message={error ?? 'The demo map service did not respond.'}
        actionLabel="Retry"
        onAction={reload}
      />
    </div>
  )

  const body = (
    <div
      className={`corner-brackets relative overflow-hidden border border-line bg-[#070d17] ${
        fullscreen ? 'h-screen w-screen rounded-none border-0' : ''
      } ${className}`}
      style={fullscreen ? undefined : { height }}
      onMouseDown={() => setShowSearchResults(false)}
    >
      {loading ? loadingState : error ? errorState : mapElement}

      {tileFallback}

      {!loading && !error ? (
        <>
          {toolbar}

          {panelOpen ? (
            <div className="absolute top-3 right-3 z-[500] hidden sm:block">{layerPanel}</div>
          ) : (
            <button
              type="button"
              onClick={() => setPanelOpen(true)}
              className="absolute top-3 right-3 z-[500] hidden h-9 items-center gap-2 rounded-xl border border-line bg-card px-3 text-xs font-medium text-muted shadow-[3px_3px_0_#050708] transition-all hover:border-accent/40 hover:text-accent sm:flex"
            >
              <Layers size={14} aria-hidden /> Layers
            </button>
          )}

          {scenarioCard ? (
            <div className="absolute top-14 left-3 z-[500]">{scenarioCard}</div>
          ) : null}

          {compact ? (
            <div className="absolute bottom-3 left-3 z-[500] hidden sm:block">{legend}</div>
          ) : (
            <>
              <div className="absolute bottom-3 left-3 z-[500] hidden md:block">{legend}</div>
              <div className="absolute right-3 bottom-3 z-[500] hidden lg:block">{infoCard}</div>
            </>
          )}

          {/* Mobile controls */}
          <div className="absolute right-3 bottom-3 left-3 z-[500] flex gap-2 sm:hidden">
            <button
              type="button"
              onClick={() => setPanelOpen((v) => !v)}
              className="flex h-9 flex-1 items-center justify-center gap-1.5 rounded-xl border border-line bg-card text-xs font-medium text-ink shadow-[3px_3px_0_#050708]"
            >
              <Layers size={14} aria-hidden /> Layers
            </button>
          </div>
          {compact ? null : (
            <div className="absolute right-3 bottom-14 z-[500] lg:hidden sm:bottom-3">{infoCard}</div>
          )}

          <div className="absolute top-3 left-1/2 z-[490] hidden -translate-x-1/2 xl:block">
            <DemoBadge />
          </div>
        </>
      ) : null}
    </div>
  )

  if (fullscreen) {
    return createPortal(
      <div className="fixed inset-0 z-[200] bg-bg">
        <div className="flex h-14 items-center justify-between border-b border-line px-4">
          <div className="flex items-center gap-3">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent/15 text-accent">
              <Waves size={16} aria-hidden />
            </span>
            <div>
              <p className="text-sm font-semibold text-ink">Inundation Map — fullscreen</p>
              <p className="text-[10px] text-muted">Illustrative demo overlays · {activeRegion.shortName}</p>
            </div>
          </div>
          <Button
            size="sm"
            variant="secondary"
            icon={<Minimize2 size={13} />}
            onClick={() => setFullscreen(false)}
          >
            Exit fullscreen
          </Button>
        </div>
        <div className="h-[calc(100vh-3.5rem)]">{body}</div>
      </div>,
      document.body,
    )
  }

  return body
}

