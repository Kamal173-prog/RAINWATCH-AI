"""Fetch v3.3 GFS data: new pressure-level / stability variables, spatial
GFS grids, and Previous-Runs multi-lead precipitation.

What is fetched (all keyless, Open-Meteo):
1. Bhubaneswar, Historical Forecast API (gfs_global), 2021-03-23..2026-11-23:
   25 NEW variables the v3.2 fetch did not include (pressure levels 925 /
   850 / 700 / 500 hPa, vertical velocity, CIN, lifted index, dew point,
   gusts, cloud layers, geopotential heights). The v3.2 9 variables
   (precip, CAPE, RH, pressure, wind, temp, cloud, surface pressure)
   already live in data/processed/ifs/gfs_global_processed.csv.
2. Puri Coast (19.81, 85.83) + Offshore Bay (19.50, 86.30), same API,
   7 variables (precip, CAPE, RH, wind, pressure, temp) — for spatial
   GFS precipitation gradients.
3. Previous Runs API (gfs_global), 2024-01-01..2026-11-23:
   precipitation_previous_day1 / _previous_day2 — the forecast for a
   valid time issued 24 h / 48 h earlier. PROBED 2026-11-23: these are
   all-null before 2024-01-01, so multi-lead features only exist from
   2024. They are a scoped experiment, not part of the main v3.3
   training protocol (train 2021-2023 has no multi-lead data).

Leakage audit (see docs/V33_TECHNICAL.md):
- (1) and (2) use the Historical Forecast API seamless series: "built by
  stitching the first hours of each successive model run" (Open-Meteo
  docs). Each value comes from a run initialised at or before its valid
  time, so the value at valid time t was available at t. Features built
  from values at time <= t are leakage-free.
- (3) records init time = valid time - lead (24 h / 48 h); init <= t by
  construction, so also leakage-free for a prediction issued at t.
- GFS pressure-level variables are 0.25 deg resolution; surface GFS is
  0.11 deg. The API snaps the requested lat/lon to each resolution's
  grid independently, so pressure-level values may come from a grid cell
  up to ~12 km from the surface cell. Same mesoscale environment;
  recorded in the manifest, not silently mixed.

Outputs:
- data/raw/ifs/v33/*.json (raw API responses)
- data/processed/ifs/gfs_v33_bhubaneswar.csv (25 new vars)
- data/processed/ifs/gfs_v33_spatial.csv (coast/bay, 7 vars each)
- data/processed/ifs/gfs_previous_runs.csv (day1/day2 precip, 2024+)

Usage:
    cd backend && .venv/bin/python scripts/fetch_gfs_v33.py [--skip PREVIOUS]
"""

from __future__ import annotations

import json
import logging
import sys
import time
from datetime import date, timedelta
from pathlib import Path

import pandas as pd
import requests

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from ml.data_sources.base_source import retry_with_backoff  # noqa: E402
from ml.preprocessing.temporal_alignment import standardise_hourly  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("fetch_gfs_v33")

BACKEND = Path(__file__).resolve().parent.parent
RAW_DIR = BACKEND / "data" / "raw" / "ifs" / "v33"
PROC_DIR = BACKEND / "data" / "processed" / "ifs"
HIST_URL = "https://historical-forecast-api.open-meteo.com/v1/forecast"
PREV_URL = "https://previous-runs-api.open-meteo.com/v1/forecast"
SLEEP_S = 4

BHUB = (20.281195, 85.843376)
COAST = (19.81, 85.83)   # Puri Coast — same point as the ERA5 upwind grid
BAY = (19.50, 86.30)     # Offshore Bay of Bengal — same point as ERA5

# New variables for Bhubaneswar (probed live 2026-11-23: all return data).
V33_BHUB_VARS = [
    "temperature_925hPa", "relative_humidity_925hPa",
    "wind_speed_925hPa", "wind_direction_925hPa",
    "temperature_850hPa", "relative_humidity_850hPa",
    "wind_speed_850hPa", "wind_direction_850hPa",
    "temperature_700hPa", "relative_humidity_700hPa",
    "wind_speed_700hPa", "wind_direction_700hPa",
    "temperature_500hPa", "relative_humidity_500hPa",
    "vertical_velocity_850hPa", "vertical_velocity_700hPa",
    "convective_inhibition", "lifted_index",
    "dew_point_2m", "wind_gusts_10m",
    "cloud_cover_low", "cloud_cover_mid", "cloud_cover_high",
    "geopotential_height_850hPa", "geopotential_height_500hPa",
]
# Spatial points: precipitation-led subset.
V33_SPATIAL_VARS = [
    "precipitation", "cape", "relative_humidity_2m",
    "wind_speed_10m", "wind_direction_10m", "pressure_msl", "temperature_2m",
]
# Previous Runs: fixed lead offsets (day1 = issued 24 h before valid time).
PREV_VARS = ["precipitation_previous_day1", "precipitation_previous_day2"]

START = date(2021, 3, 23)   # GFS available since 2021-03-23
END = date(2026, 11, 23)
PREV_START = date(2024, 1, 1)  # multi-lead precip is all-null before this


def _chunks(start: date, end: date):
    cur = start
    while cur <= end:
        chunk_end = min(date(cur.year, 12, 31), end)
        yield cur, chunk_end
        cur = chunk_end + timedelta(days=1)


def _get(url: str, params: dict) -> dict:
    def _do() -> requests.Response:
        r = requests.get(url, params=params, timeout=120)
        r.raise_for_status()
        return r
    resp = retry_with_backoff(_do, description=f"GET {url.split('/')[2]} {params.get('start_date')}")
    return resp.json()


def _fetch_hist(lat: float, lon: float, variables: list[str], stem: str) -> list[Path]:
    out = []
    for s, e in _chunks(START, END):
        raw_path = RAW_DIR / f"{stem}_{s.isoformat()}_{e.isoformat()}.json"
        if raw_path.exists():
            try:
                json.loads(raw_path.read_text())
                log.info("exists, skipping: %s", raw_path.name)
                out.append(raw_path)
                continue
            except (json.JSONDecodeError, OSError):
                log.warning("corrupt, re-fetching: %s", raw_path.name)
        data = _get(HIST_URL, {
            "latitude": lat, "longitude": lon,
            "start_date": s.isoformat(), "end_date": e.isoformat(),
            "hourly": ",".join(variables), "models": "gfs_global", "timezone": "UTC",
        })
        n = len(data.get("hourly", {}).get("time", []))
        raw_path.write_text(json.dumps(data))
        log.info("saved %s (%d hours)", raw_path.name, n)
        out.append(raw_path)
        time.sleep(SLEEP_S)
    return out


def _fetch_prev() -> list[Path]:
    out = []
    for s, e in _chunks(PREV_START, END):
        raw_path = RAW_DIR / f"gfs_prevruns_{s.isoformat()}_{e.isoformat()}.json"
        if raw_path.exists():
            try:
                json.loads(raw_path.read_text())
                log.info("exists, skipping: %s", raw_path.name)
                out.append(raw_path)
                continue
            except (json.JSONDecodeError, OSError):
                log.warning("corrupt, re-fetching: %s", raw_path.name)
        data = _get(PREV_URL, {
            "latitude": BHUB[0], "longitude": BHUB[1],
            "start_date": s.isoformat(), "end_date": e.isoformat(),
            "hourly": ",".join(PREV_VARS), "models": "gfs_global", "timezone": "UTC",
        })
        n = len(data.get("hourly", {}).get("time", []))
        raw_path.write_text(json.dumps(data))
        log.info("saved %s (%d hours)", raw_path.name, n)
        out.append(raw_path)
        time.sleep(SLEEP_S)
    return out


def _process(files: list[Path], variables: list[str], out_csv: Path,
             prefix: str = "") -> pd.DataFrame:
    frames = []
    for p in files:
        data = json.loads(p.read_text())
        hourly = data.get("hourly", {})
        times = hourly.get("time", [])
        if not times:
            log.warning("no hourly data in %s", p.name)
            continue
        frame = pd.DataFrame({"timestamp": times})
        for var in variables:
            vals = hourly.get(var)
            if vals is not None:
                frame[f"{prefix}{var}"] = vals
        frames.append(frame)
    df = pd.concat(frames, ignore_index=True)
    df = standardise_hourly(df, "timestamp")
    df = df.drop_duplicates(subset=["timestamp"]).sort_values("timestamp").reset_index(drop=True)
    df.to_csv(out_csv, index=False)
    log.info("processed %s: %d rows, %d cols, %s..%s",
             out_csv.name, len(df), len(df.columns), df["timestamp"].min(), df["timestamp"].max())
    return df


def main() -> None:
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    PROC_DIR.mkdir(parents=True, exist_ok=True)
    only = sys.argv[1] if len(sys.argv) > 1 else "all"

    if only in ("all", "bhub"):
        files = _fetch_hist(BHUB[0], BHUB[1], V33_BHUB_VARS, "gfs_v33_bhub")
        _process(files, V33_BHUB_VARS, PROC_DIR / "gfs_v33_bhubaneswar.csv")
    if only in ("all", "spatial"):
        for (lat, lon), name in ((COAST, "coast"), (BAY, "bay")):
            files = _fetch_hist(lat, lon, V33_SPATIAL_VARS, f"gfs_v33_{name}")
            _process(files, V33_SPATIAL_VARS,
                     PROC_DIR / f"gfs_v33_{name}.csv", prefix=f"{name}_")
        # Merge coast + bay into one spatial file.
        coast = pd.read_csv(PROC_DIR / "gfs_v33_coast.csv", parse_dates=["timestamp"])
        bay = pd.read_csv(PROC_DIR / "gfs_v33_bay.csv", parse_dates=["timestamp"])
        spatial = coast.merge(bay, on="timestamp", how="outer", validate="one_to_one")
        spatial = spatial.sort_values("timestamp").reset_index(drop=True)
        spatial.to_csv(PROC_DIR / "gfs_v33_spatial.csv", index=False)
        log.info("spatial merged: %d rows", len(spatial))
    if only in ("all", "prev"):
        files = _fetch_prev()
        _process(files, PREV_VARS, PROC_DIR / "gfs_previous_runs.csv")
    log.info("fetch complete")


if __name__ == "__main__":
    main()
