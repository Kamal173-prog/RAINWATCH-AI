# RAINWATCH AI — UI Build Contract (read before writing any page)

Frontend-only React 19 + Vite + TypeScript (strict) + Tailwind v4 + Framer Motion 14 +
Lucide React + Recharts 3 + React Leaflet 5 + React Router 7 + Sonner toasts.

## Hard rules

1. **Strict TypeScript**: `strict`, `noUnusedLocals`, `noUnusedParameters`, `verbatimModuleSyntax`
   are ON. Use `import type { … }` for every type-only import. NO enums (`erasableSyntaxOnly`).
   No unused imports/variables/params. No `any` unless unavoidable (prefer `unknown` + narrowing).
2. **No dead UI**: every button, tab, filter, dropdown, slider and link must do something real
   (local state / CSV download / modal / navigation / toast). No `TODO`, no empty handlers.
3. **All data comes from `src/services/dataService.ts` (`demoApi`)** via `useAsyncData` — never
   import `src/data/*` directly from a page (the simulator's local maths is the one exception:
   `demoApi.runSimulation`).
4. **Demo honesty**: label simulated values as DEMO DATA (use `<DemoBadge />`). Never claim
   real-time operational accuracy.
5. **Do NOT edit** shared files: `src/App.tsx`, `src/index.css`, `src/components/**`,
   `src/context/**`, `src/hooks/**`, `src/services/**`, `src/data/**`, `src/types/**`,
   `vite.config.ts`, `tsconfig*`. Create page-local components inside
   `src/components/<yourarea>/` if needed.
6. **Do NOT run `npm run build` or `npm run dev`** (other agents work in parallel).
   Type-check your own files at the end with:
   `npx tsc --noEmit -p tsconfig.app.json 2>&1 | findstr /i "YourFile"` (or PowerShell filter).
   Ignore "Cannot find module './pages/…'" errors for pages you don't own.
7. Motion: use `framer-motion`. The app is already wrapped in
   `<MotionConfig reducedMotion="user">` — do not add your own reduced-motion handling unless
   you animate manually with JS. Keep animations subtle (0.3–0.5 s, ease `[0.22,1,0.36,1]`).
8. Responsive: desktop-first, but must not break at 375 px. No horizontal overflow.
   Tables → wrap in the provided `DataTable` (has responsive column collapsing) or
   `overflow-x-auto`.

## Design tokens (Tailwind classes)

| Token | Classes |
|---|---|
| Backgrounds | `bg-bg` (page), `bg-card` (cards), `bg-surface` (controls/wells), `bg-sidebar` |
| Text | `text-ink` (primary), `text-muted` (secondary) |
| Borders | `border`, `border-line` |
| Accent | `text-accent`, `bg-accent`, `bg-accent/12`, `border-accent/40` (accent-2 = secondary) |
| Status | `text-success`, `text-warning`, `text-critical`, plus `/12` background variants |
| Numbers | add class `num` (Space Grotesk + tabular-nums) |
| Card padding | automatic via `<Card>` (`p-[var(--rw-card-pad)]`), density-aware |

Fonts: body Inter (default), `font-display` = Space Grotesk, `font-body` = Manrope.
Hex palettes for charts: `RISK_COLORS`, `SEVERITY_COLORS`, `RAINFALL_BANDS` (+ helpers
`classifyRainfall`, `classifyRisk`, `rainfallColor`) from `src/utils/colors.ts`.

## Shared components — `src/components/common/`

```tsx
<Card hover delay={0.1}>…</Card>            // motion card, entrance + optional hover lift
<CardHeader title subtitle actions icon />  // optional header inside a plain div
<ChartCard title subtitle actions icon tooltip height loading empty emptyMessage delay footer>
  <Recharts…/>
</ChartCard>                                // handles loading skeleton + empty state for you
<KpiCard label value unit decimals icon={LucideIcon} tooltip trend={{value,suffix,tone,label}}
         spark={number[]} footnote delay /> // animated counter + sparkline
<AnimatedNumber value decimals prefix suffix className />
<Button variant="primary|secondary|ghost|outline|danger" size="sm|md" loading icon={jsx} />
<Badge tone="accent|info|success|warning|critical|muted">{label}</Badge>
<RiskBadge level="Low|Moderate|High|Very High|Critical" />
<SeverityBadge severity={AlertSeverity} />   // Information | Advisory | Watch | Warning | Critical
<RainBadge label="Heavy" />                 // Light | Moderate | Heavy | Very Heavy | Extremely Heavy
<DemoBadge />  <DemoBadge compact />
<InfoTip text="…" />                        // hover/focus tooltip with icon
<Tooltip text="…">{trigger}</Tooltip>
<Modal open onClose title subtitle footer size="sm|md|lg">…</Modal>   // Escape + scroll-lock built in
<Select label options={[{value,label}]} value onValueChange compact hint />   // styled native select
<Toggle checked onChange label description /> // role="switch"
<Slider label value min max step unit onChange description format />
<SegmentedControl options value onChange ariaLabel size="sm|md" />  // animated sliding indicator
<Dropdown align width label trigger={(open,toggle)=>jsx} children={(close)=>jsx} />
<DataTable columns={Column<T>[]} rows rowKey emptyMessage onRowClick maxHeight caption />
// Column<T> = { key, header, render:(row,i)=>ReactNode, align?, width?, secondary? } (secondary hides <md)
<StatePanel variant="empty|error" title message actionLabel onAction />
<Skeleton className="h-4 w-24" /> <SkeletonCard lines={3} /> <PageLoading label />
<PageHeader title subtitle meta>{actions}</PageHeader>
<SectionTitle hint action>Section</SectionTitle>
```

## Contexts & hooks

```tsx
import { useSettings } from '../context/SettingsContext'
const { settings, update, reset, clearPreferences, accent } = useSettings()
// settings: AppSettings = { theme, accent, density, defaultLocationId, defaultTimeframe,
//   defaultMapLayers, units, notificationsEnabled, severityPrefs: AlertSeverity[] }
// update({ units: 'imperial' }) persists to localStorage and re-themes instantly.

import { useSelectedLocation } from '../context/LocationContext'
const { locationId, setLocationId } = useSelectedLocation()   // global selected region

import { useAlerts } from '../context/AlertsContext'
const { alerts, activeCountValue, dismissedCount, acknowledge, dismiss, restore,
        acknowledgeAll, clearDismissed, resetAlerts } = useAlerts()
// Alert.status: 'active' | 'acknowledged' | 'dismissed' — persisted automatically.

import { useDemo } from '../context/DemoContext'
const { version, refreshing, refresh } = useDemo()  // pass `version` into useAsyncData deps

import { useAsyncData } from '../hooks/useAsyncData'
const { data, loading, error, reload } = useAsyncData(() => demoApi.fetchX(args), [arg1, version])
// ALWAYS include `version` (and location/filters) in the deps array. Render:
// loading → skeletons, error → <StatePanel variant="error" …/>, empty → <StatePanel …/>.

import { useCountUp, useLiveClock } from '../hooks/useUi'
import { useLocalStorage } from '../hooks/useLocalStorage'
```

## `demoApi` (src/services/dataService.ts) — signatures

```ts
listLocations(): Promise<GeoLocation[]>
fetchWeather(locationId, hours): Promise<WeatherReading[]>        // past `hours`, last item = now
fetchCurrentWeather(locationId): Promise<WeatherReading>
fetchForecast(locationId, hours): Promise<ForecastPoint[]>        // hours ∈ 3|6|12|24|48|72
fetchIntensityDistribution(locationId, hours): Promise<{label,hours,color}[]>
fetchRiskRecords({locationId?, level?, horizonH?}): Promise<FloodRiskRecord[]>
fetchRiskSummary(horizonH): Promise<{overallIndex, distribution:[{level,count}], worst, vulnerable}>
fetchAllRiskRecords(): Promise<FloodRiskRecord[]>                 // all locs × 3h × 72h
fetchAlerts(): Promise<Alert[]>
fetchUpcomingAlerts(limit?): Promise<Alert[]>
fetchDailyHistory(locationId, days): Promise<HistoricalDay[]>
fetchMonthlyHistory(locationId): Promise<MonthlySummary[]>
fetchAnnualHistory(): Promise<AnnualSummary[]>
fetchPeakEvents(locationId?, limit?): Promise<PeakEvent[]>
fetchLocationComparison(days): Promise<{locationId,name,rainfallMm,peakMmHr,avgRiskIndex}[]>
fetchMapLayers(): Promise<MapLayersPayload>
fetchDataSources(): Promise<{sources: DataSourceInfo[], pipeline: PipelineNode[]}>
refreshDemoData(): Promise<number>
fetchOverview(locationId, alertCount): Promise<OverviewBundle>
runSimulation(inputs: SimulatorInputs): Promise<SimulatorResult> // ~600 ms, local maths
```

Types live in `src/types/index.ts` — read it before starting.

## Utilities

- `downloadCsv(filename, headers, rows)` from `src/utils/csv.ts` — used by every Export button.
- `formatDateTime`, `formatTime`, `formatDay`, `relativeTime`, `formatNumber`, `formatCompact`,
  `windDirectionLabel`, `rainfallLabel(mm, units)`, `temperatureLabel(c, units)`,
  `windLabel(kmh, units)` from `src/utils/colors.ts`.
- Timeframes: `TIMEFRAME_OPTIONS` / `timeframeHours(id)` from `src/data/settingsData.ts`.

## Charts (Recharts 3)

```tsx
<ResponsiveContainer width="100%" height={height}>
  <BarChart data={data} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
    <CartesianGrid stroke="var(--rw-border)" strokeDasharray="3 3" vertical={false} />
    <XAxis dataKey="name" tickLine={false} axisLine={false} stroke="var(--rw-muted)" fontSize={11} />
    <YAxis tickLine={false} axisLine={false} stroke="var(--rw-muted)" fontSize={11} />
    <Tooltip contentStyle={{ background:'var(--rw-card)', border:'1px solid var(--rw-border)',
      borderRadius:12, color:'var(--rw-ink)', fontSize:12 }} labelStyle={{ color:'var(--rw-muted)' }} />
    <Bar dataKey="value" fill="var(--rw-accent)" radius={[4,4,0,0]} />
  </BarChart>
</ResponsiveContainer>
```
Wrap every chart in `<ChartCard>` (it owns loading/empty states). Use literal hex from
`RISK_COLORS`/`SEVERITY_COLORS`/`RAINFALL_BANDS` where series are categorical (donut/legend
swatches need real hex). Use `var(--rw-*)` strings for axis/grid/tooltip chrome.

## Page skeleton (every page)

```tsx
export function MyPage() {
  const { locationId } = useSelectedLocation()
  const { version } = useDemo()
  const { settings } = useSettings()
  const { data, loading, reload } = useAsyncData(() => demoApi.fetchX(locationId), [locationId, version])
  return (
    <div className="section-gap flex flex-col">
      <PageHeader title="…" subtitle="…" meta={<><DemoBadge /><Badge>Region</Badge></>}>
        <Button variant="secondary" icon={<RefreshCw size={14}/>} onClick={reload}>Refresh</Button>
      </PageHeader>
      {/* working filters, charts, tables, empty/error states */}
    </div>
  )
}
```

Named export `export function X()` (App.tsx imports `{ X }`).
