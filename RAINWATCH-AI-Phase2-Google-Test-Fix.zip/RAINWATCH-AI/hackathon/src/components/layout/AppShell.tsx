import { AnimatePresence, motion } from 'framer-motion'
import { useEffect } from 'react'
import { Outlet, useLocation } from 'react-router-dom'
import { useLocalStorage } from '../../hooks/useLocalStorage'
import { Sidebar } from './Sidebar'
import { Topbar } from './Topbar'

export function AppShell() {
  const [collapsed, setCollapsed] = useLocalStorage<boolean>('rainwatch.sidebar.collapsed', false)
  const [mobileOpen, setMobileOpen] = useLocalStorage<boolean>('rainwatch.sidebar.mobile', false)
  const { pathname } = useLocation()

  useEffect(() => {
    setMobileOpen(false)
    window.scrollTo({ top: 0, behavior: 'smooth' })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname])

  return (
    <div
      className="flex min-h-screen bg-bg"
      style={{ '--rw-sidebar-w': collapsed ? '76px' : '264px' } as React.CSSProperties}
    >
      <Sidebar
        collapsed={collapsed}
        onToggleCollapse={() => setCollapsed(!collapsed)}
        mobileOpen={mobileOpen}
        onCloseMobile={() => setMobileOpen(false)}
      />

      <div className="flex min-w-0 flex-1 flex-col transition-[padding] duration-300 ease-out lg:ps-[var(--rw-sidebar-w)]">
        <Topbar onOpenMobileNav={() => setMobileOpen(true)} />

        <main className="flex-1 px-3 py-5 sm:px-5 lg:px-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={pathname}
              initial={{ opacity: 0, y: 12, rotateX: -2.5 }}
              animate={{ opacity: 1, y: 0, rotateX: 0 }}
              exit={{ opacity: 0, y: -6, rotateX: 1.5 }}
              transition={{ duration: 0.42, ease: [0.16, 1, 0.3, 1] }}
              style={{ transformPerspective: 1200, transformOrigin: 'top center' }}
            >
              <Outlet />
            </motion.div>
          </AnimatePresence>
        </main>

        <footer className="border-t border-line px-4 py-3 text-center text-[10px] leading-relaxed tracking-wide text-muted sm:px-6">
          RAINWATCH AI · Frontend demonstration build — values labelled DEMO are simulated samples; values
          labelled MODEL come from the trained ML ensemble and are an early-warning signal, not a confirmed
          forecast. Must not be used for operational emergency decisions.
        </footer>
      </div>
    </div>
  )
}
