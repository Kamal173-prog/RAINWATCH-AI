import { motion } from 'framer-motion'
import { BarChart3, CalendarRange, Download, LineChart as LineIcon, RefreshCw, TrendingUp } from 'lucide-react'
import { useEffect, useMemo, useState } from 'react'
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip as RTooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { toast } from 'sonner'
import { Badge, DemoBadge, RiskBadge } from '../components/common/Badge'
import { Button } from '../components/common/Button'
import { ChartCard } from '../components/common/ChartCard'
import { DataTable, type Column } from '../components/common/DataTable'
import { PageHeader } from '../components/common/PageHeader'
import { SegmentedControl } from '../components/common/SegmentedControl'
import { Select } from '../components/common/Select'
import { SkeletonCard, StatePanel } from '../components/common/Skeleton'
import { useDemo } from '../context/DemoContext'
import { useSelectedLocation } from '../context/LocationContext'
import { useAsyncData } from '../hooks/useAsyncData'
import { demoApi } from '../services/dataService'
import type { PeakEvent } from '../types'
import { downloadCsv } from '../utils/csv'
import { formatDay } from '../utils/colors'

const tooltipStyle = {
  background: 'var(--rw-card)', border: '1px solid var(--rw-border)', borderRadius: 12,
  color: 'var(--rw-ink)', fontSize: 12, boxShadow: '0 20px 50px -25px rgba(0,0,0,0.9)',
}

type Aggregation = 'daily' | 'weekly' | 'monthly'
type Metric = 'rainfall' | 'risk'

function isoDaysAgo(n: number) {
  const d = new Date()
  d.setDate(d.getDate() - n)
  return d.toISOString().slice(0, 10)
}

function isoDaysBefore(isoDate: string, n: number) {
  const d = new Date(`${isoDate}T00:00:00`)
  d.setDate(d.getDate() - n)
  return d.toISOString().slice(0, 10)
}

export function HistoricalAnalysis() {
  const { locationId, setLocationId } = useSelectedLocation()
  const { version } = useDemo()
  const [from, setFrom] = useState(isoDaysAgo(90))
  const [to, setTo] = useState(isoDaysAgo(0))
  const [aggregation, setAggregation] = useState<Aggregation>('daily')
  const [metric, setMetric] = useState<Metric>('rainfall')
  const { data: locations } = useAsyncData(() => demoApi.listLocations(), [])
  const { data: daily, loading, error, reload } = useAsyncData(
    () => demoApi.fetchDailyHistory(locationId, 365),
    [locationId, version],
  )
  // Ganjam locations use the demo generator; Bhubaneswar-region locations
  // use the real ERA5 archive (2021–2025). Provenance wording below
  // follows this, and the date range follows the data (see effect).
  const isGanjam = locations?.some((l) => l.id === locationId && l.regionId === 'ganjam') ?? false
  const dataMaxDate = daily && daily.length > 0 ? daily[daily.length - 1].date : null

  // The real archive ends 2025-12-31, but the default range ends today.
  // Without this clamp the filter excludes every archive row and the
  // trend chart, summary cards and CSV export are empty for
  // Bhubaneswar-region locations (regression from the real-data switch).
  // Ganjam demo data ends today, so the clamp is a no-op there. The
  // user's own range choice is never overridden after this first clamp.
  useEffect(() => {
    if (!dataMaxDate) return
    if (to > dataMaxDate) {
      setTo(dataMaxDate)
      setFrom(isoDaysBefore(dataMaxDate, 90))
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dataMaxDate])
  const { data: monthly } = useAsyncData(() => demoApi.fetchMonthlyHistory(locationId), [locationId, version])
  const { data: annual } = useAsyncData(() => demoApi.fetchAnnualHistory(), [version])
  const { data: peaks } = useAsyncData(() => demoApi.fetchPeakEvents(locationId, 8), [locationId, version])
  const { data: comparison } = useAsyncData(() => demoApi.fetchLocationComparison(90), [version])

  const filtered = useMemo(() => {
    const rows = (daily ?? []).filter((r) => r.date >= from && r.date <= to)
    if (aggregation === 'daily') return rows.map((r) => ({ label: formatDay(r.date), date: r.date, rainfall: r.rainfallMm, risk: r.riskIndex, peak: r.peakHourMmHr }))

    const buckets = new Map<string, { rainfall: number; risk: number; n: number; date: string }>()
    for (const r of rows) {
      const d = new Date(`${r.date}T00:00:00`)
      let key: string
      if (aggregation === 'monthly') key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
      else {
        const week = Math.floor((d.getTime() - new Date(d.getFullYear(), 0, 1).getTime()) / (7 * 86400_000))
        key = `${d.getFullYear()}-W${String(week).padStart(2, '0')}`
      }
      const b = buckets.get(key) ?? { rainfall: 0, risk: 0, n: 0, date: r.date }
      b.rainfall += r.rainfallMm
      b.risk += r.riskIndex
      b.n += 1
      buckets.set(key, b)
    }
    return [...buckets.entries()].sort((a, b) => a[0].localeCompare(b[0])).map(([key, b]) => ({
      label: aggregation === 'monthly' ? key : key.replace('-W', ' w'),
      date: b.date,
      rainfall: Math.round(b.rainfall * 10) / 10,
      risk: Math.round(b.risk / b.n * 10) / 10,
      peak: 0,
    }))
  }, [daily, from, to, aggregation])

  const riskBuckets = useMemo(() => {
    const levels = ['Low (<25)', 'Moderate (25–44)', 'High (45–64)', 'Very High (65–81)', 'Critical (82+)']
    const counts = [0, 0, 0, 0, 0]
    for (const r of filtered) {
      const i = r.risk < 25 ? 0 : r.risk < 45 ? 1 : r.risk < 65 ? 2 : r.risk < 82 ? 3 : 4
      counts[i] += 1
    }
    const colors = ['#69D2A0', '#F2A93B', '#F0823F', '#F05A43', '#E11D48']
    return levels.map((name, i) => ({ name, count: counts[i], color: colors[i] }))
  }, [filtered])

  const metricKey = metric === 'rainfall' ? 'rainfall' : 'risk'
  const metricLabel = metric === 'rainfall' ? 'Rainfall (mm)' : 'Risk index (/100)'
  const metricColor = metric === 'rainfall' ? 'var(--rw-accent)' : '#F05A43'

  const exportCsv = () => {
    // Source follows the page's provenance rule: Bhubaneswar-region rows
    // are the ERA5 archive, Ganjam rows are the demo generator.
    const rowSource = isGanjam ? 'demo' : 'era5-archive'
    downloadCsv(`rainwatch-historical-${locationId}-${from}-${to}`,
      ['Date', 'Location ID', 'Daily Rainfall (mm)', 'Peak Hour (mm/hr)', 'Risk Index', 'Source'],
      (daily ?? []).filter((r) => r.date >= from && r.date <= to).map((r) => [r.date, r.locationId, r.rainfallMm, r.peakHourMmHr, r.riskIndex, rowSource]))
    toast.success('Historical data exported as CSV', { description: `${filtered.length} rows in current view.` })
  }

  const reset = () => {
    // Reset to the last 90 days of the data actually available, not of
    // today — otherwise Bhubaneswar-region locations reset to an empty
    // range (the archive ends 2025-12-31).
    const end = dataMaxDate ?? isoDaysAgo(0)
    setFrom(isoDaysBefore(end, 90)); setTo(end); setAggregation('daily'); setMetric('rainfall')
    toast.info('Historical filters reset')
  }

  const peakColumns: Column<PeakEvent>[] = [
    { key: 'date', header: 'Date', render: (p) => <span className="num text-ink">{formatDay(p.date)}</span> },
    { key: 'loc', header: 'Location', render: (p) => <button type="button" onClick={() => { setLocationId(p.locationId) }} className="font-medium hover:text-accent">{p.locationName}</button> },
    { key: 'daily', header: 'Daily total', render: (p) => <span className="num font-semibold text-accent">{p.dailyMm} mm</span> },
    { key: 'dur', header: 'Duration', render: (p) => <span className="num">{p.durationH} h</span>, secondary: true },
    { key: 'risk', header: 'Risk', render: (p) => <RiskBadge level={p.riskLevel} /> },
  ]

  return (
    <div className="section-gap flex flex-col">
      <PageHeader
        title="Historical Analysis"
        subtitle={isGanjam
          ? 'Explore locally generated rainfall climatology, peak events and historical risk patterns.'
          : 'Explore ERA5 archive rainfall climatology, peak events and historical risk patterns.'}
        meta={<>{isGanjam ? <DemoBadge /> : <Badge tone="muted">ERA5 archive · 2021–2025</Badge>}<Badge tone="muted">365-day sample archive</Badge></>}
      >
        <Button icon={<Download size={14} />} onClick={exportCsv}>Export CSV</Button>
        <Button icon={<RefreshCw size={14} />} onClick={() => { reload(); toast.success('Historical data refreshed') }}>Refresh</Button>
      </PageHeader>

      {/* Filters */}
      <div className="flex flex-wrap items-end gap-3 rounded-2xl border border-line bg-card p-[var(--rw-card-pad)]">
        <label className="flex flex-col gap-1.5">
          <span className="text-[11px] font-semibold tracking-wider text-muted uppercase">From date</span>
          <input type="date" value={from} max={to} onChange={(e) => setFrom(e.target.value)} aria-label="From date"
            className="h-9 rounded-lg border border-line bg-surface px-3 text-xs text-ink focus:border-accent/60 focus:outline-none" />
        </label>
        <label className="flex flex-col gap-1.5">
          <span className="text-[11px] font-semibold tracking-wider text-muted uppercase">To date</span>
          <input type="date" value={to} min={from} onChange={(e) => setTo(e.target.value)} aria-label="To date"
            className="h-9 rounded-lg border border-line bg-surface px-3 text-xs text-ink focus:border-accent/60 focus:outline-none" />
        </label>
        {/* No "All locations" option: the trend/monthly/annual/peaks data
            is always for one location (fetchDailyHistory takes a single
            locationId), so an "All locations" choice was a no-op that
            silently showed one location's data. The Location-wise chart
            below is genuinely all-location regardless. */}
        <Select label="Location" options={[...(locations ?? []).map((l) => ({ value: l.id, label: l.name }))]}
          value={locationId} onValueChange={(v) => setLocationId(v)} compact className="w-[180px]" />
        <Select label="Time aggregation" options={[{ value: 'daily', label: 'Daily' }, { value: 'weekly', label: 'Weekly' }, { value: 'monthly', label: 'Monthly' }]}
          value={aggregation} onValueChange={(v) => setAggregation(v as Aggregation)} compact className="w-[150px]" />
        <Select label="Metric" options={[{ value: 'rainfall', label: 'Rainfall (mm)' }, { value: 'risk', label: 'Risk index' }]}
          value={metric} onValueChange={(v) => setMetric(v as Metric)} compact className="w-[150px]" />
        <Button size="sm" variant="ghost" onClick={reset}>Reset</Button>
      </div>

      {error ? <StatePanel variant="error" title="Archive unavailable" message={error} actionLabel="Retry" onAction={reload} /> : null}

      {/* Summary */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {loading ? Array.from({ length: 4 }).map((_, i) => <SkeletonCard key={i} lines={1} />) : (
          [
            { label: 'Days in range', value: String(filtered.length), icon: CalendarRange, color: '#6FD6C2' },
            { label: 'Total rainfall', value: `${Math.round(filtered.reduce((s, r) => s + r.rainfall, 0))} mm`, icon: TrendingUp, color: '#6FD6C2' },
            { label: 'Peak daily', value: `${Math.max(0, ...filtered.map((r) => r.rainfall)).toFixed(1)} mm`, icon: BarChart3, color: '#F2A93B' },
            { label: 'Mean risk', value: `${filtered.length ? (filtered.reduce((s, r) => s + r.risk, 0) / filtered.length).toFixed(1) : '0'}/100`, icon: LineIcon, color: '#F05A43' },
          ].map((s, i) => {
            const Icon = s.icon
            return (
              <motion.div key={s.label} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                className="rounded-2xl border border-line bg-card p-[var(--rw-card-pad)]">
                <div className="flex items-center justify-between"><span className="text-[10px] font-semibold tracking-wider text-muted uppercase">{s.label}</span><Icon size={14} style={{ color: s.color }} /></div>
                <p className="num mt-2 text-lg font-bold text-ink">{s.value}</p>
              </motion.div>
            )
          })
        )}
      </div>

      {/* Main trend */}
      <ChartCard title="Rainfall & Risk Trend" subtitle={`${aggregation} aggregation · ${from} to ${to}`} icon={<LineIcon size={16} />} height={340} loading={loading}
        empty={filtered.length === 0}
        actions={<SegmentedControl ariaLabel="Trend style" size="sm" value={metric} onChange={setMetric}
          options={[{ value: 'rainfall', label: 'Rainfall' }, { value: 'risk', label: 'Risk' }]} />}>
        {/* height={340} (not "100%"): this card sits directly in the page's
            flex column, so its body has no definite height and a percentage
            height resolves to 0 — the chart rendered at 0 px and never
            recovered. The other charts sit in a grid, where grid stretching
            gives them a definite height, so they are unaffected. */}
        <ResponsiveContainer width="100%" height={340}>
          <AreaChart data={filtered} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
            <defs><linearGradient id="histFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={metricColor} stopOpacity={0.4} /><stop offset="100%" stopColor={metricColor} stopOpacity={0.02} /></linearGradient></defs>
            <CartesianGrid stroke="var(--rw-border)" strokeDasharray="3 3" vertical={false} />
            <XAxis dataKey="label" tickLine={false} axisLine={false} interval={Math.max(1, Math.floor(filtered.length / 10))} />
            <YAxis tickLine={false} axisLine={false} width={48} />
            <RTooltip contentStyle={tooltipStyle} />
            <Area type="monotone" dataKey={metricKey} name={metricLabel} stroke={metricColor} strokeWidth={2} fill="url(#histFill)" dot={false} animationDuration={850} />
          </AreaChart>
        </ResponsiveContainer>
      </ChartCard>

      {/* Chart grid */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <ChartCard title="Monthly Rainfall" subtitle="Seasonal climatology (12 months)" icon={<BarChart3 size={16} />} height={290} loading={!monthly} delay={0.02}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={monthly ?? []} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
              <CartesianGrid stroke="var(--rw-border)" strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="month" tickLine={false} axisLine={false} fontSize={10} angle={-20} textAnchor="end" height={46} />
              <YAxis tickLine={false} axisLine={false} width={48} />
              <RTooltip contentStyle={tooltipStyle} />
              <Bar dataKey="rainfallMm" name="Rainfall mm" fill="var(--rw-accent)" radius={[3, 3, 0, 0]} animationDuration={800} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Annual Comparison" subtitle="Total rainfall by year (sample archive)" icon={<BarChart3 size={16} />} height={290} loading={!annual} delay={0.06}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={annual ?? []} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
              <CartesianGrid stroke="var(--rw-border)" strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="year" tickLine={false} axisLine={false} />
              <YAxis tickLine={false} axisLine={false} width={48} />
              <RTooltip contentStyle={tooltipStyle} />
              <Bar dataKey="rainfallMm" name="Rainfall mm" radius={[4, 4, 0, 0]} animationDuration={800}>
                {(annual ?? []).map((_, i) => <Cell key={i} fill={['#64748B', '#6FD6C2', '#6FD6C2', '#F2A93B', '#6FD6C2'][i]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Historical Flood-Risk Distribution" subtitle="Days by illustrative risk bucket in the selected range" icon={<LineIcon size={16} />} height={290} loading={loading} delay={0.1}>
          <div className="flex flex-col items-center gap-3 sm:flex-row">
            <div className="h-[200px] w-full sm:w-1/2">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={riskBuckets.filter((b) => b.count > 0)} dataKey="count" nameKey="name" cx="50%" cy="50%" innerRadius={44} outerRadius={72} paddingAngle={3} stroke="none" animationDuration={800}>
                    {riskBuckets.filter((b) => b.count > 0).map((b) => <Cell key={b.name} fill={b.color} />)}
                  </Pie>
                  <RTooltip contentStyle={tooltipStyle} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex-1 space-y-1.5">
              {riskBuckets.map((b) => (
                <div key={b.name} className="flex items-center justify-between text-[11px]">
                  <span className="flex items-center gap-2 text-muted"><span className="h-2 w-2 rounded-full" style={{ background: b.color }} />{b.name}</span>
                  <span className="num font-semibold text-ink">{b.count} d</span>
                </div>
              ))}
            </div>
          </div>
        </ChartCard>

        <ChartCard title="Location-wise Rainfall" subtitle="90-day total by location — click a bar to select" icon={<BarChart3 size={16} />} height={290} loading={!comparison} delay={0.14}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={comparison ?? []} layout="vertical" margin={{ top: 4, right: 12, left: 24, bottom: 0 }}>
              <CartesianGrid stroke="var(--rw-border)" strokeDasharray="3 3" horizontal={false} />
              <XAxis type="number" tickLine={false} axisLine={false} />
              <YAxis type="category" dataKey="name" tickLine={false} axisLine={false} width={80} fontSize={10} />
              <RTooltip contentStyle={tooltipStyle} cursor={{ fill: 'var(--rw-accent)', fillOpacity: 0.06 }} />
              <Bar dataKey="rainfallMm" name="Rainfall mm" radius={[0, 4, 4, 0]} animationDuration={800}
                onClick={(d: unknown) => { const row = d as { payload?: { locationId?: string } }; if (row?.payload?.locationId) { setLocationId(row.payload.locationId); toast.info('Location selected') } }}>
                {(comparison ?? []).map((_, i) => <Cell key={i} fill={i === 0 ? '#F2A93B' : 'var(--rw-accent)'} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Peak events */}
      <ChartCard title="Peak Rainfall Events" subtitle="Highest daily totals in the sample archive" icon={<TrendingUp size={16} />}
        actions={<Button size="sm" icon={<Download size={13} />} onClick={exportCsv}>Export CSV</Button>}
        loading={!peaks} empty={(peaks?.length ?? 0) === 0}>
        <DataTable columns={peakColumns} rows={peaks ?? []} rowKey={(p) => `${p.date}-${p.locationId}`} caption="Peak rainfall events" />
      </ChartCard>

      <p className="rounded-xl border border-warning/25 bg-warning/8 px-4 py-2.5 text-[11px] text-warning">
        {isGanjam
          ? 'DEMO DATA — Historical series are generated locally with seasonal patterns for interface demonstration. They are not observations of real historical weather events.'
          : 'ERA5 REANALYSIS — Daily totals from the Open-Meteo ERA5 archive (2021–2025) for Bhubaneswar-region locations, scaled by location exposure. Reanalysis, not station measurements; Ganjam locations use the demo generator.'}
      </p>
    </div>
  )
}
