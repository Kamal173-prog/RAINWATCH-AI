"""CLI: validate a processed RAINWATCH AI dataset (v3.2).

Usage:
    python scripts/validate_datasets.py --file data/processed/ifs/ecmwf_ifs025_processed.csv

Runs the QC checks (completeness, duplicates, negative rainfall,
out-of-range values) and the schema validation. Prints the QC report
and any warnings. Exits non-zero on a hard failure.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd

from ml.preprocessing.data_validation import validate_processed_table
from ml.preprocessing.quality_control import check_completeness, check_values


def main() -> None:
    ap = argparse.ArgumentParser(description="Validate a processed dataset")
    ap.add_argument("--file", required=True, help="Path to a processed CSV")
    ap.add_argument("--required", nargs="*", default=["timestamp"],
                    help="Required columns")
    args = ap.parse_args()
    path = Path(args.file)
    if not path.exists():
        raise SystemExit(f"file not found: {path}")
    df = pd.read_csv(path)
    print(f"rows: {len(df)}, columns: {list(df.columns)}")
    df2, comp = check_completeness(df)
    print(comp.summary())
    df3, val = check_values(df2, source=path.stem)
    print(val.summary())
    warnings = validate_processed_table(df3, args.required, source=path.stem)
    if warnings:
        print("warnings:")
        for w in warnings:
            print(f"  - {w}")
    else:
        print("validation: clean")
    flagged = (df3["qc_flag"] != "").sum() if "qc_flag" in df3.columns else 0
    print(f"flagged rows: {flagged}")


if __name__ == "__main__":
    main()
