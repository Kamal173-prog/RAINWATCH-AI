"""Train rainfall-v3.3: heavy-rain recall / F1 upgrade over v3.2-GFS.

Goal: improve heavy-rain RECALL and F1 (not just precision) for
3h >= 10 mm, 6h >= 10 mm and 3h >= 5 mm, using new GFS information
(pressure levels, vertical velocity, CIN, multi-lead precipitation,
spatial GFS gradients) plus imbalance handling (class weights,
cost-sensitive learning, hard-negative mining, event-aware sampling,
focal loss) and OOF stacking.

Protocol (non-negotiable):
- Train 2021-2023, validation 2024, 2025 = historical benchmark,
  2026 = fresh evaluation, NEVER used for selection until the freeze.
- OOF: chronological expanding-window CV inside 2021-2024
  (train 2021 -> val 2022; train 2021-22 -> val 2023;
  train 2021-23 -> val 2024). No random shuffling. All reweighting /
  resampling happens INSIDE training folds only.
- The frozen v3.3 config is fixed before the single 2026 evaluation.
- Production (v3) and the API are untouched; no auto-deploy.

Phases (run in order; each is idempotent and saves its outputs):
  oof        expanding-window OOF probabilities (per family + ensemble)
  thresholds F1/F2/F3 threshold optimisation on OOF + matched
             recall/precision analysis vs the v3.2 thresholds
  prune      validation-based feature pruning for the v33 feature set
  variants   imbalance-strategy arms on the pruned set (2025 benchmark)
  stack      OOF stacking meta-learner (logistic regression on OOF probs)
  freeze     train the frozen config on 2021-2024, save artifacts
  final      evaluate the frozen artifacts on 2026 ONCE + comparison
             table vs v3 / v3.1 / v3.2

Usage:
    cd backend
    .venv/bin/python ml/train_rainfall_v33.py --phase oof [--features v32|v33]
    .venv/bin/python ml/train_rainfall_v33.py --phase thresholds
    .venv/bin/python ml/train_rainfall_v33.py --phase prune
    .venv/bin/python ml/train_rainfall_v33.py --phase variants
    .venv/bin/python ml/train_rainfall_v33.py --phase stack
    .venv/bin/python ml/train_rainfall_v33.py --phase freeze
    .venv/bin/python ml/train_rainfall_v33.py --phase final
"""

from __future__ import annotations

import argparse
import itertools
import json
import logging
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from sklearn.metrics import average_precision_score  # noqa: E402
from sklearn.linear_model import LogisticRegression  # noqa: E402
from sklearn.inspection import permutation_importance  # noqa: E402
from v33_common import (  # noqa: E402
    BEST_PARAMS, FAMILIES, SEED, TARGETS,
    event_metrics, fbeta, full_eval, hour_metrics, make_classifier,
    make_xgb_focal, platt_apply, platt_fit, precision_at_recall,
    recall_at_precision, threshold_for_fbeta,
)

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger("train_rainfall_v33")

BACKEND = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.join(BACKEND, "models", "rainfall_xgb_v3_3")
OOF_DIR = os.path.join(OUT_DIR, "oof")
os.makedirs(OOF_DIR, exist_ok=True)

V32_TABLE = os.path.join(BACKEND, "data", "model_ready", "bhubaneswar_features_v32.csv")
V33_TABLE = os.path.join(BACKEND, "data", "model_ready", "bhubaneswar_features_v33.csv")
V32_DIR = os.path.join(BACKEND, "models", "rainfall_xgb_v3_2")
V3_DIR = os.path.join(BACKEND, "models", "rainfall_xgb_v3")
V31_DIR = os.path.join(BACKEND, "models", "rainfall_xgb_v3_1")

# Chronological OOF folds: (train years, validation year).
OOF_FOLDS = [([2021], 2022), ([2021, 2022], 2023), ([2021, 2022, 2023], 2024)]


def load_table(features: str) -> pd.DataFrame:
    path = V32_TABLE if features == "v32" else V33_TABLE
    df = pd.read_csv(path, parse_dates=["timestamp"])
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True).dt.tz_localize(None)
    return df


def load_v32_features() -> list[str]:
    with open(os.path.join(V32_DIR, "feature_schema.json")) as f:
        return json.load(f)["features"]


def load_v33_features() -> list[str]:
    """v3.2 53 + the new v3.3 features, EXCLUDING the Previous-Runs
    multi-lead features (2024+ only) — those are a separate experiment."""
    base = load_v32_features()
    with open(os.path.join(BACKEND, "data", "model_ready",
                           "bhubaneswar_features_v33.csv"), "r") as f:
        header = f.readline().strip().split(",")
    prev = {"gfs_precip_day1", "gfs_precip_day2", "gfs_precip_day1_3h_sum",
            "gfs_precip_day2_3h_sum", "gfs_precip_day1_minus_day0"}
    new = [c for c in header if c.startswith("gfs_") and c not in base and c not in prev]
    return base + new


def _ensemble_weights(y_va: np.ndarray, val_probs: dict) -> dict:
    """Grid-search ensemble weights (step 0.1) on one validation year."""
    P = np.column_stack([val_probs[f] for f in FAMILIES])
    best_w, best_s = None, None
    for w in itertools.product([0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0],
                               repeat=3):
        if abs(sum(w) - 1.0) > 1e-9:
            continue
        s = average_precision_score(y_va, P @ np.array(w))
        if best_s is None or s > best_s:
            best_w, best_s = w, float(s)
    return dict(zip(FAMILIES, [float(x) for x in best_w]))


def _fit_predict_family(family: str, target: str, X_tr: np.ndarray,
                        y_tr: np.ndarray, X_va: np.ndarray,
                        sample_weight: np.ndarray | None = None):
    """Fit one family member on a training fold; return its val probs."""
    pos = max(1, int(y_tr.sum()))
    neg = max(1, int((1 - y_tr).sum()))
    model = make_classifier(family, BEST_PARAMS[target][family], neg / pos)
    if sample_weight is not None:
        model.fit(X_tr, y_tr, sample_weight=sample_weight)
    else:
        model.fit(X_tr, y_tr)
    return model.predict_proba(X_va)[:, 1], model


# ----------------------------------------------------------------------
# Phase: oof
# ----------------------------------------------------------------------
def phase_oof(features: str) -> None:
    df = load_table(features)
    feats = load_v32_features() if features == "v32" else load_v33_features()
    # Drop features with no training data in the first fold (2021).
    tr2021 = df[df["timestamp"].dt.year == 2021]
    dropped = [c for c in feats if tr2021[c].isna().all()]
    if dropped:
        log.warning("dropping %d features with no 2021 data: %s", len(dropped), dropped)
        feats = [c for c in feats if c not in dropped]
    log.info("oof features=%s n=%d (dropped %d)", features, len(feats), len(dropped))

    for target in TARGETS:
        oof_rows = []
        for train_years, val_year in OOF_FOLDS:
            tr = df[df["timestamp"].dt.year.isin(train_years)].reset_index(drop=True)
            va = df[df["timestamp"].dt.year == val_year].reset_index(drop=True)
            X_tr = tr[feats].to_numpy(dtype=float)
            y_tr = tr[target].to_numpy().astype(int)
            X_va = va[feats].to_numpy(dtype=float)
            y_va = va[target].to_numpy().astype(int)
            val_probs: dict[str, np.ndarray] = {}
            for fam in FAMILIES:
                p, _ = _fit_predict_family(fam, target, X_tr, y_tr, X_va)
                val_probs[fam] = p
            w = _ensemble_weights(y_va, val_probs)
            ens = sum(w[f] * val_probs[f] for f in FAMILIES)
            wp, bp = platt_fit(ens, y_va)
            cal = platt_apply(ens, wp, bp)
            oof_rows.append(pd.DataFrame({
                "timestamp": va["timestamp"],
                "y": y_va,
                **{f"p_{fam}": val_probs[fam] for fam in FAMILIES},
                "p_ens_raw": ens,
                "p_ens_cal": cal,
                "fold_val_year": val_year,
            }))
            log.info("%s fold val=%d: PR-AUC raw %.4f | weights %s | platt w=%.3f b=%.3f",
                     target, val_year, average_precision_score(y_va, ens), w, wp, bp)
        oof = pd.concat(oof_rows, ignore_index=True)
        out = os.path.join(OOF_DIR, f"oof_{features}_{target}.csv")
        oof.to_csv(out, index=False)
        log.info("saved %s (%d rows, val years 2022-2024)", out, len(oof))


# ----------------------------------------------------------------------
# Phase: thresholds
# ----------------------------------------------------------------------
def phase_thresholds(features: str = "v32") -> None:
    """Optimise F1/F2/F3 thresholds on pooled OOF calibrated probs and
    compare against the v3.2 operating thresholds at matched recall /
    precision. Uses the v32-feature OOF by default (the v3.2 baseline
    thresholds live on that feature set)."""
    with open(os.path.join(V32_DIR, "thresholds.json")) as f:
        v32_thresholds = json.load(f)
    report: dict = {"features": features, "targets": {}}
    for target in TARGETS:
        oof = pd.read_csv(os.path.join(OOF_DIR, f"oof_{features}_{target}.csv"),
                          parse_dates=["timestamp"])
        y = oof["y"].to_numpy().astype(int)
        p = oof["p_ens_cal"].to_numpy()
        entry: dict = {
            "n_oof": len(y), "positives": int(y.sum()),
            "pr_auc": round(float(average_precision_score(y, p)), 4),
            "f_thresholds": {},
            "v32_thresholds_on_oof": {},
            "matched": {},
        }
        for beta, name in ((1.0, "f1"), (2.0, "f2"), (3.0, "f3")):
            t, prec, rec = threshold_for_fbeta(y, p, beta)
            entry["f_thresholds"][name] = {
                "threshold": round(t, 2), "precision": round(prec, 4),
                "recall": round(rec, 4), "fbeta": round(fbeta(prec, rec, beta), 4),
            }
        for level, t32 in v32_thresholds[target].items():
            hm = hour_metrics(y, p, t32)
            entry["v32_thresholds_on_oof"][level] = hm
            # Matched analysis: at the recall the v3.2 threshold achieves,
            # what precision is possible? And at its precision, what recall?
            entry["matched"][level] = {
                "v32_recall": hm["recall"], "v32_precision": hm["precision"],
                "best_precision_at_same_recall": round(
                    precision_at_recall(y, p, hm["recall"]), 4),
                "best_recall_at_same_precision": round(
                    recall_at_precision(y, p, hm["precision"]), 4),
            }
        report["targets"][target] = entry
        log.info("%s OOF PR-AUC %.4f | F1 t=%.2f (P %.3f R %.3f) | "
                 "F2 t=%.2f (P %.3f R %.3f) | F3 t=%.2f (P %.3f R %.3f)",
                 target, entry["pr_auc"],
                 entry["f_thresholds"]["f1"]["threshold"],
                 entry["f_thresholds"]["f1"]["precision"],
                 entry["f_thresholds"]["f1"]["recall"],
                 entry["f_thresholds"]["f2"]["threshold"],
                 entry["f_thresholds"]["f2"]["precision"],
                 entry["f_thresholds"]["f2"]["recall"],
                 entry["f_thresholds"]["f3"]["threshold"],
                 entry["f_thresholds"]["f3"]["precision"],
                 entry["f_thresholds"]["f3"]["recall"])
    out = os.path.join(OUT_DIR, "thresholds_oof.json")
    with open(out, "w") as f:
        json.dump(report, f, indent=2)
    log.info("saved %s", out)


def main() -> None:
    ap = argparse.ArgumentParser(description="Train rainfall-v3.3")
    ap.add_argument("--phase", required=True,
                    choices=["oof", "thresholds", "prune", "variants",
                             "stack", "freeze", "final"])
    ap.add_argument("--features", default="v33", choices=["v32", "v33"],
                    help="Feature set for the oof phase")
    ap.add_argument("--arms", default=None,
                    help="Comma-separated subset of arms to (re)run in the "
                         "variants phase; results merge into variants.json")
    args = ap.parse_args()
    if args.phase == "oof":
        phase_oof(args.features)
    elif args.phase == "thresholds":
        phase_thresholds(args.features)
    elif args.phase == "prune":
        phase_prune()
    elif args.phase == "variants":
        phase_variants(args.arms.split(",") if args.arms else None)
    else:
        raise SystemExit(f"phase {args.phase} not implemented yet")


# ----------------------------------------------------------------------
# Phase: prune
# ----------------------------------------------------------------------
def phase_prune() -> None:
    """Validation-based feature pruning for the v33 classifier set.

    Protocol (same as v3): fit a single XGBoost classifier per target on
    train (2021-2023), compute permutation importance on validation
    (2024) for the 3h>=10mm and 3h>=5mm classifier PR-AUC. A feature is
    pruned only when its importance is <= 0 for BOTH targets (it helps
    neither). Saves the kept feature list to
    models/rainfall_xgb_v3_3/feature_schema.json.
    """
    df = load_table("v33")
    feats = load_v33_features()
    tr = df[df["timestamp"].dt.year.isin([2021, 2022, 2023])].reset_index(drop=True)
    va = df[df["timestamp"].dt.year == 2024].reset_index(drop=True)
    X_tr = tr[feats].to_numpy(dtype=float)
    X_va = va[feats].to_numpy(dtype=float)
    importances: dict[str, dict[str, float]] = {}
    for target in ("y_3h_ge_10mm", "y_3h_ge_5mm"):
        y_tr = tr[target].to_numpy().astype(int)
        y_va = va[target].to_numpy().astype(int)
        pos = max(1, int(y_tr.sum()))
        neg = max(1, int((1 - y_tr).sum()))
        model = make_classifier("xgb", BEST_PARAMS[target]["xgb"], neg / pos)
        model.fit(X_tr, y_tr)
        base = average_precision_score(y_va, model.predict_proba(X_va)[:, 1])
        res = permutation_importance(
            model, X_va, y_va, n_repeats=1, random_state=SEED,
            scoring="average_precision", n_jobs=-1)
        importances[target] = {
            f: float(res.importances_mean[i]) for i, f in enumerate(feats)
        }
        log.info("%s: base val PR-AUC %.4f", target, base)
    pruned, kept = [], []
    for f in feats:
        i10 = importances["y_3h_ge_10mm"].get(f, 0.0)
        i5 = importances["y_3h_ge_5mm"].get(f, 0.0)
        if i10 <= 0 and i5 <= 0:
            pruned.append(f)
        else:
            kept.append(f)
    log.info("pruned %d / %d features: %s", len(pruned), len(feats), pruned)
    for f in sorted(feats, key=lambda c: importances["y_3h_ge_10mm"].get(c, 0),
                    reverse=True)[:15]:
        log.info("  top %s: PR-AUC drop 3h>=10mm %.4f | 3h>=5mm %.4f",
                 f, importances["y_3h_ge_10mm"].get(f, 0),
                 importances["y_3h_ge_5mm"].get(f, 0))
    with open(os.path.join(OUT_DIR, "feature_schema.json"), "w") as fh:
        json.dump({"features": kept, "pruned": pruned,
                   "importances": importances}, fh, indent=2)
    log.info("saved %s (%d kept)", os.path.join(OUT_DIR, "feature_schema.json"),
             len(kept))


def _train_arm(arm: str, target: str, tr: pd.DataFrame, va: pd.DataFrame,
               feats: list[str]) -> tuple[dict, dict, dict, dict]:
    """Train one imbalance arm on train (2021-2023); learn ensemble
    weights + Platt + F1/F2 thresholds on validation (2024).

    Returns (models, weights, platt, thresholds). Arms:
      base          v3.2 config (pos_weight = neg/pos)
      posweight_half / posweight_double: scale_pos_weight x0.5 / x2
      cost3 / cost5: sample weights {neg: 1, pos: C}, scale_pos_weight=1
      hardneg:   two-round; round-2 upweights training negatives with
                 round-1 p >= 0.5 by x3
      eventaware: hours within +/-6 h of a heavy-event hour upweighted x2
      focal:     XGB member replaced by the focal-loss objective
                 (alpha=0.25, gamma=2.0); LGBM/HGB unchanged
    All reweighting is inside the training fold only.
    """
    X_tr = tr[feats].to_numpy(dtype=float)
    y_tr = tr[target].to_numpy().astype(int)
    X_va = va[feats].to_numpy(dtype=float)
    y_va = va[target].to_numpy().astype(int)
    pos = max(1, int(y_tr.sum()))
    neg = max(1, int((1 - y_tr).sum()))
    base_pw = neg / pos

    # Per-arm sample weights for the training fold.
    sw = np.ones(len(y_tr))
    if arm in ("cost3", "cost5"):
        sw = np.where(y_tr == 1, float(arm[4:]), 1.0)
    if arm == "eventaware":
        idx = np.where(y_tr == 1)[0]
        near = np.zeros(len(y_tr), dtype=bool)
        for i in idx:
            near[max(0, i - 6):min(len(y_tr), i + 7)] = True
        sw = np.where(near, 2.0, 1.0)
        log.info("  %s event-aware: %d/%d training hours upweighted",
                 target, int(near.sum()), len(y_tr))

    models: dict[str, object] = {}
    val_probs: dict[str, np.ndarray] = {}
    for fam in FAMILIES:
        if arm == "focal" and fam == "xgb":
            model = make_xgb_focal(BEST_PARAMS[target]["xgb"], alpha=0.25, gamma=2.0)
            model.fit(X_tr, y_tr)
        elif arm in ("cost3", "cost5", "eventaware"):
            # Sample-weight arms: neutral scale_pos_weight; the weights
            # carry the cost. (eventaware was silently dropped before
            # this fix: its weights were computed but never passed to
            # fit, so it returned base-identical results.)
            model = make_classifier(fam, BEST_PARAMS[target][fam], 1.0)
            model.fit(X_tr, y_tr, sample_weight=sw)
        elif arm in ("posweight_half", "posweight_double"):
            pw = base_pw * (0.5 if arm == "posweight_half" else 2.0)
            model = make_classifier(fam, BEST_PARAMS[target][fam], pw)
            model.fit(X_tr, y_tr)
        else:
            model = make_classifier(fam, BEST_PARAMS[target][fam], base_pw)
            model.fit(X_tr, y_tr)
        models[fam] = model
        val_probs[fam] = model.predict_proba(X_va)[:, 1]

    if arm == "hardneg":
        # Round 2: upweight training negatives the round-1 model scores >= 0.5.
        tr_probs = np.zeros(len(y_tr))
        w0 = _ensemble_weights(y_va, val_probs)
        for fam in FAMILIES:
            tr_probs += w0[fam] * models[fam].predict_proba(X_tr)[:, 1]
        hard = (y_tr == 0) & (tr_probs >= 0.5)
        log.info("  %s hardneg: %d/%d training negatives are hard (p>=0.5)",
                 target, int(hard.sum()), int((y_tr == 0).sum()))
        sw2 = np.where(hard, 3.0, 1.0)
        models, val_probs = {}, {}
        for fam in FAMILIES:
            if fam == "xgb":
                m = make_classifier(fam, BEST_PARAMS[target][fam], base_pw)
            else:
                m = make_classifier(fam, BEST_PARAMS[target][fam], base_pw)
            m.fit(X_tr, y_tr, sample_weight=sw2)
            models[fam] = m
            val_probs[fam] = m.predict_proba(X_va)[:, 1]

    w = _ensemble_weights(y_va, val_probs)
    ens = sum(w[f] * val_probs[f] for f in FAMILIES)
    wp, bp = platt_fit(ens, y_va)
    cal = platt_apply(ens, wp, bp)
    thresholds = {}
    for beta, name in ((1.0, "f1"), (2.0, "f2")):
        t, prec, rec = threshold_for_fbeta(y_va, cal, beta)
        thresholds[name] = {"threshold": round(t, 2), "precision": round(prec, 4),
                            "recall": round(rec, 4)}
    return models, w, {"w": wp, "b": bp}, thresholds


def _refit_arm(arm: str, target: str, tv: pd.DataFrame, feats: list[str],
               weights: dict, platt: dict) -> dict:
    """Refit one arm on train+val (2021-2024) with the same settings;
    return the saved member models (for the 2025 benchmark eval)."""
    X_tv = tv[feats].to_numpy(dtype=float)
    y_tv = tv[target].to_numpy().astype(int)
    pos = max(1, int(y_tv.sum()))
    neg = max(1, int((1 - y_tv).sum()))
    base_pw = neg / pos
    sw = np.ones(len(y_tv))
    if arm in ("cost3", "cost5"):
        sw = np.where(y_tv == 1, float(arm[4:]), 1.0)
    if arm == "eventaware":
        idx = np.where(y_tv == 1)[0]
        near = np.zeros(len(y_tv), dtype=bool)
        for i in idx:
            near[max(0, i - 6):min(len(y_tv), i + 7)] = True
        sw = np.where(near, 2.0, 1.0)
    models: dict[str, object] = {}
    for fam in FAMILIES:
        if arm == "focal" and fam == "xgb":
            model = make_xgb_focal(BEST_PARAMS[target]["xgb"], alpha=0.25, gamma=2.0)
            model.fit(X_tv, y_tv)
        elif arm in ("cost3", "cost5", "eventaware"):
            # Sample-weight arms: neutral scale_pos_weight; weights carry
            # the cost. (eventaware weights were silently dropped here
            # too before the fix.)
            model = make_classifier(fam, BEST_PARAMS[target][fam], 1.0)
            model.fit(X_tv, y_tv, sample_weight=sw)
        elif arm in ("posweight_half", "posweight_double"):
            pw = base_pw * (0.5 if arm == "posweight_half" else 2.0)
            model = make_classifier(fam, BEST_PARAMS[target][fam], pw)
            model.fit(X_tv, y_tv)
        else:
            model = make_classifier(fam, BEST_PARAMS[target][fam], base_pw)
            model.fit(X_tv, y_tv)
        models[fam] = model
    if arm == "hardneg":
        tv_probs = np.zeros(len(y_tv))
        for fam in FAMILIES:
            tv_probs += weights[fam] * models[fam].predict_proba(X_tv)[:, 1]
        hard = (y_tv == 0) & (tv_probs >= 0.5)
        sw2 = np.where(hard, 3.0, 1.0)
        for fam in FAMILIES:
            model = make_classifier(fam, BEST_PARAMS[target][fam], base_pw)
            model.fit(X_tv, y_tv, sample_weight=sw2)
            models[fam] = model
    return models


# ----------------------------------------------------------------------
# Phase: variants
# ----------------------------------------------------------------------
ARMS = ["base", "posweight_half", "posweight_double", "cost3", "cost5",
        "hardneg", "eventaware", "focal"]


def phase_variants(arms: list[str] | None = None) -> None:
    """Imbalance-strategy arms on the pruned v33 feature set.

    Per arm and target: learn weights/Platt/F1-F2 thresholds on 2024
    validation (train 2021-2023), refit on 2021-2024, evaluate ONCE on
    the 2025 benchmark. 2026 is untouched. Saves variants.json. When
    ``arms`` is given, only those arms run and their results merge
    into the existing variants.json.
    """
    df = load_table("v33")
    with open(os.path.join(OUT_DIR, "feature_schema.json")) as f:
        feats = json.load(f)["features"]
    tr = df[df["timestamp"].dt.year.isin([2021, 2022, 2023])].reset_index(drop=True)
    va = df[df["timestamp"].dt.year == 2024].reset_index(drop=True)
    tv = pd.concat([tr, va], ignore_index=True)
    te = df[df["timestamp"].dt.year == 2025].reset_index(drop=True)
    n_days = len(te) / 24.0
    out_path = os.path.join(OUT_DIR, "variants.json")
    if arms and os.path.exists(out_path):
        with open(out_path) as f:
            results = json.load(f)
    else:
        results = {"arms": {}, "feature_set": feats, "n_features": len(feats)}
    for arm in (arms or ARMS):
        if arm not in ARMS:
            raise SystemExit(f"unknown arm {arm!r}; choices {ARMS}")
        log.info("=== arm %s ===", arm)
        arm_res: dict = {}
        for target in TARGETS:
            _, w, platt, thresholds = _train_arm(arm, target, tr, va, feats)
            models = _refit_arm(arm, target, tv, feats, w, platt)
            X_te = te[feats].to_numpy(dtype=float)
            y_te = te[target].to_numpy().astype(int)
            probs = {f: models[f].predict_proba(X_te)[:, 1] for f in FAMILIES}
            ens = sum(w[f] * probs[f] for f in FAMILIES)
            cal = platt_apply(ens, platt["w"], platt["b"])
            ev = full_eval(y_te, cal,
                           {k: v["threshold"] for k, v in thresholds.items()},
                           n_days=n_days)
            arm_res[target] = {
                "weights": w, "platt": platt, "thresholds": thresholds, "eval": ev,
            }
            log.info("  %s: 2025 PR-AUC %.4f | F1 t=%.2f P %.3f R %.3f | "
                     "F2 t=%.2f P %.3f R %.3f | storm det %.3f lead %.1fh",
                     target, ev["pr_auc"],
                     thresholds["f1"]["threshold"],
                     ev["levels"]["f1"]["precision"], ev["levels"]["f1"]["recall"],
                     thresholds["f2"]["threshold"],
                     ev["levels"]["f2"]["precision"], ev["levels"]["f2"]["recall"],
                     ev["levels"]["f1"]["storm_detection_rate"],
                     ev["levels"]["f1"]["median_lead_time_h"]
                     if ev["levels"]["f1"]["median_lead_time_h"] is not None
                     else float("nan"))
        results["arms"][arm] = arm_res
    with open(os.path.join(OUT_DIR, "variants.json"), "w") as f:
        json.dump(results, f, indent=2)
    log.info("saved %s", os.path.join(OUT_DIR, "variants.json"))


if __name__ == "__main__":
    main()
