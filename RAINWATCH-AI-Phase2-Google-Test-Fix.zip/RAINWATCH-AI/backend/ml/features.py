"""Feature engineering for the RAINWATCH AI rainfall forecaster (v3).

Builds a model-ready table from the hourly Open-Meteo ERA5 archive.
All features use data at time ``t`` or earlier — no leakage: the targets
are rainfall accumulations strictly in the future (t+1 onwards).

Feature groups
--------------
Base (always, from the 6 core columns):
- Lagged precipitation: 1/3/6/12/24 h ago.
- Rolling precipitation sums: last 3/6/12/24/72 h (ending at t, inclusive).
- Rolling precipitation max: last 6/24 h.
- Current meteorology at t: temperature, humidity, wind, pressure, cloud.
- Lagged meteorology (6 h and 24 h ago) and tendencies (pressure and
  temperature change over 6 h and 24 h).
- Dew point (Magnus formula) at t.
- Time: hour-of-day and day-of-year as sin/cos pairs, month, monsoon flag.

Instability (v2, always, engineered from the core columns):
- Dew point depression (temp - dew point): column saturation indicator.
- Onshore moisture flux proxy: wind_speed * saturation vapour pressure *
  (humidity / 100) — captures Bay of Bengal moisture surges.
- Short-term pressure tendency: 1 h and 3 h pressure drops.
- Pressure acceleration: change in the 3 h pressure drop.

Convective (v2, only when the merged convective columns exist):
- Direct: wind gusts, low / mid / high cloud cover, vapour pressure deficit.
- Derived: gust factor (gusts - wind speed) and a deep-convection flag
  (low cloud > 60% AND high cloud > 60%).
- NOT used: ``showers`` (all zeros at this grid cell) and ``tcwv``
  (6-month gap 2024-01-01 → 2024-07-01 in the source; see data/README.md).

Spatial-thermodynamic (v3, only when the upwind spatial CSV exists):
- Vector wind: zonal (u) and meridional (v) components from wind speed
  and direction. Onshore SE flux: wind projected onto the SE-to-NW
  onshore vector (-0.707, +0.707) times specific humidity q.
- Saturation-weighted moisture convergence: onshore flux weighted by
  saturation (1 - dew-point depression / 40), a CAPE-free instability
  proxy (CAPE is not populated by Open-Meteo for this region).
- Thermodynamic: dew point (2 m, direct), surface pressure (direct),
  equivalent potential temperature proxy (theta_e).
- Spatial look-ahead: upwind Puri Coast and Offshore Bay precipitation
  (current and 3 h sums) and the spatial rain lead
  (coast 3 h sum - Bhubaneswar 3 h sum).
- Sea-to-land pressure gradients: bay - Bhubaneswar and coast -
  Bhubaneswar pressure.
- Upwind humidity excess: bay and coast humidity minus Bhubaneswar humidity.
- NOT used: CAPE (all nulls from Open-Meteo for this region; see
  data/README.md). Do not claim CAPE features exist.

Targets (mm)
--------
- ``y_1h``: precipitation in the next 1 hour  (precip at t+1).
- ``y_3h``: precipitation summed over the next 3 hours (t+1 .. t+3).
- ``y_6h``: precipitation summed over the next 6 hours (t+1 .. t+6).

Binary heavy-event targets (for the classifiers)
------------------------------------------------
- ``y_3h_ge_10mm``: 1 when y_3h >= 10 mm.
- ``y_6h_ge_10mm``: 1 when y_6h >= 10 mm.
- ``y_3h_ge_5mm``: 1 when y_3h >= 5 mm.

The module is shared by training (``train_rainfall.py``) and inference
(``predict.py``) so the feature definitions cannot drift apart.
"""

import os

import numpy as np
import pandas as pd

HORIZONS = (1, 3, 6)

# Core columns the processed CSV must have (convective columns optional).
CORE_COLUMNS = [
    "timestamp", "temperature_c", "humidity_pct", "precipitation_mm",
    "wind_speed_kmh", "pressure_hpa", "cloud_cover_pct",
]

# Convective source columns (merged 2026-11-23). Only used when present.
CONVECTIVE_SOURCE = {
    "wind_gusts_kmh": "wind_gusts_kmh",
    "cloud_cover_low_pct": "cloud_cover_low_pct",
    "cloud_cover_mid_pct": "cloud_cover_mid_pct",
    "cloud_cover_high_pct": "cloud_cover_high_pct",
    "vapour_pressure_deficit_hpa": "vapour_pressure_deficit_hpa",
}

BASE_FEATURE_COLUMNS = [
    # lagged precipitation (mm/hr)
    "precip_lag1", "precip_lag3", "precip_lag6", "precip_lag12", "precip_lag24",
    # rolling precipitation sums / max (mm)
    "precip_sum3h", "precip_sum6h", "precip_sum12h", "precip_sum24h", "precip_sum72h",
    "precip_max6h", "precip_max24h", "precip_mean24h",
    # current meteorology
    "temperature_c", "humidity_pct", "wind_speed_kmh", "pressure_hpa", "cloud_cover_pct",
    "dewpoint_c",
    # lagged meteorology + tendencies
    "temp_lag6", "temp_lag24", "humidity_lag6", "humidity_lag24",
    "pressure_lag6", "pressure_lag24",
    "pressure_tendency_6h", "pressure_tendency_24h", "temp_tendency_6h",
    # time
    "hour_sin", "hour_cos", "doy_sin", "doy_cos", "month", "is_monsoon",
    # --- v2 instability features (engineered from core columns) ---
    "dewpoint_depression",
    "moisture_flux_proxy",
    "pressure_drop_1h",
    "pressure_drop_3h",
    "pressure_accel",
]

# v2 convective features (only when the source columns exist in the input).
CONVECTIVE_FEATURE_COLUMNS = [
    "wind_gusts_kmh",
    "cloud_cover_low_pct", "cloud_cover_mid_pct", "cloud_cover_high_pct",
    "vapour_pressure_deficit_hpa",
    "gust_factor",
    "deep_convection",
]

# v3 spatial-thermodynamic source columns (upwind_spatial.csv, merged by
# load_hourly). Only used when present.
SPATIAL_SOURCE = {
    "coast_precip_mm": "coast_precip_mm",
    "coast_pressure_hpa": "coast_pressure_hpa",
    "coast_wind_speed_kmh": "coast_wind_speed_kmh",
    "coast_wind_direction_deg": "coast_wind_direction_deg",
    "coast_humidity_pct": "coast_humidity_pct",
    "bay_precip_mm": "bay_precip_mm",
    "bay_pressure_hpa": "bay_pressure_hpa",
    "bay_wind_speed_kmh": "bay_wind_speed_kmh",
    "bay_wind_direction_deg": "bay_wind_direction_deg",
    "bay_humidity_pct": "bay_humidity_pct",
}

# v3 thermodynamic source columns (merged into bhubaneswar_weather.csv).
THERMO_SOURCE = {
    "wind_direction_deg": "wind_direction_deg",
    "dew_point_2m_c": "dew_point_2m_c",
    "surface_pressure_hpa": "surface_pressure_hpa",
}

# v3 spatial-thermodynamic features (only when the source columns exist).
V3_FEATURE_COLUMNS = [
    # vector wind (from wind speed + direction)
    "wind_u", "wind_v",
    # onshore moisture flux (SE-to-NW onshore vector x specific humidity)
    "onshore_flux",
    "moisture_convergence_proxy",
    # thermodynamic (direct + derived)
    "dew_point_2m_c", "surface_pressure_hpa", "theta_e_proxy",
    # spatial look-ahead (upwind Puri Coast + Offshore Bay)
    "coast_precip", "coast_precip_3h_sum", "bay_precip", "bay_precip_3h_sum",
    "spatial_rain_lead",
    # sea-to-land pressure gradients
    "bay_pressure_grad", "coast_pressure_grad",
    # upwind humidity excess
    "bay_humidity_excess", "coast_humidity_excess",
]

TARGET_COLUMNS = ["y_1h", "y_3h", "y_6h"]
BINARY_TARGETS = {
    "y_3h_ge_10mm": ("y_3h", 10.0),
    "y_6h_ge_10mm": ("y_6h", 10.0),
    "y_3h_ge_5mm": ("y_3h", 5.0),
}

# Backwards-compatible alias (v1 code used FEATURE_COLUMNS).
FEATURE_COLUMNS = BASE_FEATURE_COLUMNS


def _dewpoint_c(temp_c: pd.Series, humidity_pct: pd.Series) -> pd.Series:
    """Dew point via the Magnus formula (a=17.27, b=237.7)."""
    rh = humidity_pct.clip(lower=1, upper=100) / 100.0
    a, b = 17.27, 237.7
    alpha = (a * temp_c / (b + temp_c)) + np.log(rh)
    return (b * alpha) / (a - alpha)


def _saturation_vapour_pressure_hpa(temp_c: pd.Series) -> pd.Series:
    """Saturation vapour pressure (Magnus, hPa)."""
    return 6.112 * np.exp((17.67 * temp_c) / (temp_c + 243.5))


def _specific_humidity(temp_c: pd.Series, humidity_pct: pd.Series,
                       pressure_hpa: pd.Series) -> pd.Series:
    """Specific humidity q (kg/kg) from T, RH and pressure."""
    es = _saturation_vapour_pressure_hpa(temp_c)
    e = es * (humidity_pct.clip(lower=0, upper=100) / 100.0)
    return (0.622 * e) / (pressure_hpa - 0.378 * e)


def _theta_e_proxy(temp_c: pd.Series, humidity_pct: pd.Series,
                   pressure_hpa: pd.Series) -> pd.Series:
    """Equivalent potential temperature proxy (K).

    theta_e ~= T_K * exp(Lv * q / (cp * T_K)), with Lv = 2.5e6 J/kg and
    cp = 1004 J/(kg K). A surface-based instability indicator; higher
    theta_e means a warmer, moister (more buoyant) air mass.
    """
    q = _specific_humidity(temp_c, humidity_pct, pressure_hpa)
    t_k = temp_c + 273.15
    return t_k * np.exp((2.5e6 * q) / (1004.0 * t_k))


def load_hourly(csv_path: str) -> pd.DataFrame:
    """Load the processed hourly archive, tz-naive local (Asia/Kolkata) time.

    Also merges the upwind spatial CSV (``data/processed/upwind_spatial.csv``)
    when it exists, so the v3 spatial features are available.
    """
    df = pd.read_csv(csv_path, parse_dates=["timestamp"])
    df = df.sort_values("timestamp").reset_index(drop=True)
    # Merge upwind spatial grids if available (same directory as the input CSV).
    spatial_path = os.path.join(
        os.path.dirname(os.path.abspath(csv_path)), "upwind_spatial.csv"
    )
    if os.path.exists(spatial_path):
        spatial = pd.read_csv(spatial_path, parse_dates=["timestamp"])
        df = df.merge(spatial, on="timestamp", how="left", validate="one_to_one")
    return df


def available_convective_columns(df: pd.DataFrame) -> list:
    """Convective source columns actually present in this DataFrame.

    Also returns a non-empty list when the convective FEATURE columns are
    already present (a model-ready table, which has no source columns).
    """
    src = [c for c in CONVECTIVE_SOURCE if c in df.columns]
    if src:
        return src
    if any(c in df.columns for c in CONVECTIVE_FEATURE_COLUMNS):
        return ["wind_gusts_kmh"]  # non-empty sentinel; feature list is fixed
    return []


def available_v3_columns(df: pd.DataFrame) -> bool:
    """True when the v3 source columns are present (input) OR the v3
    features are present (a model-ready table, which has no source columns)."""
    has_wind_dir = "wind_direction_deg" in df.columns
    has_spatial = any(c in df.columns for c in SPATIAL_SOURCE)
    has_v3_features = any(c in df.columns for c in V3_FEATURE_COLUMNS)
    return (has_wind_dir and has_spatial) or has_v3_features


def feature_columns_for(df: pd.DataFrame) -> list:
    """Full feature list for this DataFrame (base + convective + v3 if present)."""
    cols = list(BASE_FEATURE_COLUMNS)
    if available_convective_columns(df):
        cols = cols + CONVECTIVE_FEATURE_COLUMNS
    if available_v3_columns(df):
        cols = cols + V3_FEATURE_COLUMNS
    return cols


def build_features(df: pd.DataFrame, targets: bool = True) -> pd.DataFrame:
    """Return the model-ready table: timestamp + features + (optionally) targets.

    Rows whose features or targets need data outside the archive are
    dropped (the first 72 h for features, the last 6 h for targets).
    When ``targets=False`` (inference), targets are not computed and rows
    are dropped only for missing features, so the last row is the most
    recent timestamp — the model then predicts from current data, not
    data 6 h old.
    """
    out = pd.DataFrame({"timestamp": df["timestamp"]})
    p = df["precipitation_mm"]

    # --- lagged precipitation ---
    for lag in (1, 3, 6, 12, 24):
        out[f"precip_lag{lag}"] = p.shift(lag)

    # --- rolling precipitation (windows ending at t, inclusive) ---
    for w in (3, 6, 12, 24, 72):
        out[f"precip_sum{w}h"] = p.rolling(w, min_periods=w).sum()
    for w in (6, 24):
        out[f"precip_max{w}h"] = p.rolling(w, min_periods=w).max()
    out["precip_mean24h"] = p.rolling(24, min_periods=24).mean()

    # --- current meteorology ---
    for col in ("temperature_c", "humidity_pct", "wind_speed_kmh", "pressure_hpa", "cloud_cover_pct"):
        out[col] = df[col]
    dewpoint = _dewpoint_c(df["temperature_c"], df["humidity_pct"])
    out["dewpoint_c"] = dewpoint

    # --- lagged meteorology + tendencies ---
    for col, short in (("temperature_c", "temp"), ("humidity_pct", "humidity"), ("pressure_hpa", "pressure")):
        for lag in (6, 24):
            out[f"{short}_lag{lag}"] = df[col].shift(lag)
    out["pressure_tendency_6h"] = df["pressure_hpa"] - df["pressure_hpa"].shift(6)
    out["pressure_tendency_24h"] = df["pressure_hpa"] - df["pressure_hpa"].shift(24)
    out["temp_tendency_6h"] = df["temperature_c"] - df["temperature_c"].shift(6)

    # --- time features ---
    ts = df["timestamp"]
    hour = ts.dt.hour
    doy = ts.dt.dayofyear
    out["hour_sin"] = np.sin(2 * np.pi * hour / 24)
    out["hour_cos"] = np.cos(2 * np.pi * hour / 24)
    out["doy_sin"] = np.sin(2 * np.pi * doy / 365.25)
    out["doy_cos"] = np.cos(2 * np.pi * doy / 365.25)
    out["month"] = ts.dt.month
    out["is_monsoon"] = ts.dt.month.isin([6, 7, 8, 9]).astype(int)

    # --- v2 instability features (engineered from core columns) ---
    out["dewpoint_depression"] = df["temperature_c"] - dewpoint
    es = _saturation_vapour_pressure_hpa(df["temperature_c"])
    out["moisture_flux_proxy"] = df["wind_speed_kmh"] * es * (df["humidity_pct"] / 100.0)
    out["pressure_drop_1h"] = df["pressure_hpa"] - df["pressure_hpa"].shift(1)
    out["pressure_drop_3h"] = df["pressure_hpa"] - df["pressure_hpa"].shift(3)
    out["pressure_accel"] = (
        (df["pressure_hpa"] - df["pressure_hpa"].shift(3))
        - (df["pressure_hpa"].shift(3) - df["pressure_hpa"].shift(6))
    )

    # --- v2 convective features (only when the source columns exist) ---
    conv = available_convective_columns(df)
    if conv:
        for c in ("wind_gusts_kmh", "cloud_cover_low_pct", "cloud_cover_mid_pct",
                  "cloud_cover_high_pct", "vapour_pressure_deficit_hpa"):
            if c in df.columns:
                out[c] = df[c]
        if "wind_gusts_kmh" in df.columns:
            out["gust_factor"] = df["wind_gusts_kmh"] - df["wind_speed_kmh"]
        else:
            out["gust_factor"] = 0.0
        if "cloud_cover_low_pct" in df.columns and "cloud_cover_high_pct" in df.columns:
            out["deep_convection"] = (
                (df["cloud_cover_low_pct"] > 60) & (df["cloud_cover_high_pct"] > 60)
            ).astype(int)
        else:
            out["deep_convection"] = 0

    # --- v3 spatial-thermodynamic features (only when source columns exist) ---
    if available_v3_columns(df):
        # Vector wind: meteorological convention — direction is where the
        # wind comes FROM. u = -speed*sin(dir), v = -speed*cos(dir).
        dir_rad = np.radians(df["wind_direction_deg"])
        speed = df["wind_speed_kmh"]
        out["wind_u"] = -speed * np.sin(dir_rad)
        out["wind_v"] = -speed * np.cos(dir_rad)
        # Onshore SE flux: project the wind onto the SE-to-NW onshore
        # vector (-0.707, +0.707) — the direction from the Bay of Bengal
        # toward Bhubaneswar — and multiply by specific humidity q.
        # Positive = onshore (from the sea); negative = offshore.
        q = _specific_humidity(df["temperature_c"], df["humidity_pct"], df["pressure_hpa"])
        onshore_wind = -0.707 * out["wind_u"] + 0.707 * out["wind_v"]
        out["onshore_flux"] = onshore_wind * q
        # Saturation-weighted moisture convergence (CAPE-free proxy):
        # onshore flux weighted by how close the air is to saturation.
        # saturation = 1 - (dew-point depression / 40), clipped to [0, 1].
        sat = (1.0 - out["dewpoint_depression"] / 40.0).clip(lower=0, upper=1)
        out["moisture_convergence_proxy"] = np.maximum(out["onshore_flux"], 0) * sat
        # Thermodynamic (direct + derived).
        if "dew_point_2m_c" in df.columns:
            out["dew_point_2m_c"] = df["dew_point_2m_c"]
        if "surface_pressure_hpa" in df.columns:
            out["surface_pressure_hpa"] = df["surface_pressure_hpa"]
        out["theta_e_proxy"] = _theta_e_proxy(
            df["temperature_c"], df["humidity_pct"], df["pressure_hpa"])
        # Spatial look-ahead (upwind Puri Coast + Offshore Bay).
        coast_p = df["coast_precip_mm"]
        bay_p = df["bay_precip_mm"]
        out["coast_precip"] = coast_p
        out["coast_precip_3h_sum"] = coast_p.rolling(3, min_periods=3).sum()
        out["bay_precip"] = bay_p
        out["bay_precip_3h_sum"] = bay_p.rolling(3, min_periods=3).sum()
        out["spatial_rain_lead"] = out["coast_precip_3h_sum"] - out["precip_sum3h"]
        # Sea-to-land pressure gradients (positive = higher pressure
        # offshore, forcing onshore convergence).
        out["bay_pressure_grad"] = df["bay_pressure_hpa"] - df["pressure_hpa"]
        out["coast_pressure_grad"] = df["coast_pressure_hpa"] - df["pressure_hpa"]
        # Upwind humidity excess.
        out["bay_humidity_excess"] = df["bay_humidity_pct"] - df["humidity_pct"]
        out["coast_humidity_excess"] = df["coast_humidity_pct"] - df["humidity_pct"]

    # --- targets: future accumulation (strictly t+1 onwards) ---
    # y_1h = precip at t+1; y_3h = sum t+1..t+3; y_6h = sum t+1..t+6.
    # Skipped when targets=False (inference): the model predicts from
    # the most recent timestamp, whose future is unknown by definition.
    if targets:
        out["y_1h"] = p.shift(-1)
        out["y_3h"] = p.shift(-1) + p.shift(-2) + p.shift(-3)
        out["y_6h"] = (
            p.shift(-1) + p.shift(-2) + p.shift(-3)
            + p.shift(-4) + p.shift(-5) + p.shift(-6)
        )

        # --- binary heavy-event targets ---
        for name, (target, thr) in BINARY_TARGETS.items():
            out[name] = (out[target] >= thr).astype(int)

        # Drop rows with any missing feature or target (edges of the archive).
        feat_cols = feature_columns_for(out)
        cols = feat_cols + TARGET_COLUMNS + list(BINARY_TARGETS)
    else:
        # Inference: drop only rows with missing features.
        cols = feature_columns_for(out)
    out = out.dropna(subset=cols).reset_index(drop=True)
    return out


def chronological_split(df: pd.DataFrame):
    """Chronological train / validation / test split.

    Train 2021–2023, validation 2024, test 2025. No shuffling, so no
    temporal leakage: the model is always evaluated on data after
    everything it was trained and tuned on.
    """
    ts = df["timestamp"]
    train = df[ts < "2024-01-01"].reset_index(drop=True)
    val = df[(ts >= "2024-01-01") & (ts < "2025-01-01")].reset_index(drop=True)
    test = df[ts >= "2025-01-01"].reset_index(drop=True)
    return train, val, test
