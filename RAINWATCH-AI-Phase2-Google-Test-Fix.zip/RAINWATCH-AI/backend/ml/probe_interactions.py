"""Interaction probe: run the simulator in the UI, and download CSVs
from the forecast and historical pages, verifying the exports carry
provenance. Against the live demo API (v3.3 on :8001, vite :5173).
"""

import json
import os
import re

from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:5173"
OUT = os.path.expanduser("~/workspace/integration-screenshots")
CHROME = "/home/hatch/.cache/ms-playwright/chromium-1255/chrome-linux64/chrome"


def main():
    results = {}
    with sync_playwright() as pw:
        browser = pw.chromium.launch(executable_path=CHROME)
        ctx = browser.new_context(viewport={"width": 1440, "height": 900},
                                  accept_downloads=True)
        page = ctx.new_page()
        api_calls = []
        page.on("request", lambda req: api_calls.append(
            f"{req.method} {req.url}") if "/api/" in req.url else None)

        # --- Simulator: run a scenario end to end ---
        page.goto(f"{BASE}/simulator", wait_until="networkidle")
        page.wait_for_timeout(4000)
        api_calls.clear()
        page.locator("button:has-text('Run Simulation')").first.click()
        page.wait_for_timeout(4000)
        body = page.locator("body").inner_text()
        sim_posts = [c for c in api_calls if c.startswith("POST") and "/api/simulate" in c]
        results["simulator_run"] = {
            "simulate_posts": len(sim_posts),
            "shows_risk_index": bool(re.search(r"Risk Index|risk index", body)),
            "shows_severity": bool(re.search(
                r"Minor|Moderate|Severe|Extreme", body)),
            "shows_demo_note": "demo" in body.lower(),
            "body_chars": len(body),
        }
        page.screenshot(path=f"{OUT}/simulator-run.png", full_page=True)

        # --- Forecast CSV export ---
        page.goto(f"{BASE}/forecast", wait_until="networkidle")
        page.wait_for_timeout(6000)
        with page.expect_download(timeout=15000) as dl:
            page.locator("button:has-text('CSV')").first.click()
        dl = dl.value
        path = os.path.join(OUT, "forecast-export.csv")
        dl.save_as(path)
        text = open(path).read()
        lines = text.strip().splitlines()
        results["forecast_csv"] = {
            "filename": dl.suggested_filename,
            "rows": len(lines) - 1,
            "header": lines[0] if lines else "",
            "has_source_column": "Source" in (lines[0] if lines else ""),
            "model_rows": sum(1 for ln in lines[1:] if "MODEL" in ln),
            "demo_rows": sum(1 for ln in lines[1:] if "DEMO" in ln),
        }

        # --- Historical CSV export ---
        page.goto(f"{BASE}/historical", wait_until="networkidle")
        page.wait_for_timeout(6000)
        with page.expect_download(timeout=15000) as dl2:
            page.locator("button:has-text('CSV')").first.click()
        dl2 = dl2.value
        path2 = os.path.join(OUT, "historical-export.csv")
        dl2.save_as(path2)
        text2 = open(path2).read()
        lines2 = text2.strip().splitlines()
        results["historical_csv"] = {
            "filename": dl2.suggested_filename,
            "rows": len(lines2) - 1,
            "header": lines2[0] if lines2 else "",
            "has_source_column": "Source" in (lines2[0] if lines2 else ""),
        }
        browser.close()
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
