"""Location-aware feature tables for the v3.3 Phase 7 investigation.

Builds a POINT-ONLY feature table per Odisha location (no spatial
features — each location gets the same feature set so a pooled model can
be trained and evaluated with geographic holdouts):
- v2 point features from ml/features.py build_features() (lags, rolling
  sums, meteorology, tendencies, instability, convective columns)
- v3.2 GFS features from ml/feature_groups/ifs_features.py
  build_ifs_features() (renamed ifs_* -> gfs_*)
- targets y_1h/y_3h/y_6h accumulations + binary heavy-event targets
- a ``location`` column (slug) for pooled training / holdout splits

Locations: bhubaneswar (from the existing ERA5 + GFS files), cuttack,
paradip, brahmapur, sambalpur (from data/processed/locations/).

All features use values at time <= t (same leakage discipline as the
main pipeline). The pooled experiment trains on N-1 locations and tests
on the held-out location (leave-one-location-out), plus a pooled model
evaluated on Bhubaneswar's 2025/2026 vs the Bhubaneswar-only v3.2.
"""

from __future__ import annotations

import os
import sys

import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import features as feat  # noqa: E402
from feature_groups.ifs_features import build_ifs_features  # noqa: E402

BACKEND = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOC_DIR = os.path.join(BACKEND, "data", "processed", "locations")

LOCATIONS = {
    "bhubaneswar": None,  # uses the main processed files
    "cuttack": "cuttack",
    "paradip": "paradip",
    "brahmapur": "brahmapur",
    "sambalpur": "sambalpur",
}

TARGETS = ("y_1h", "y_3h", "y_6h", "y_3h_ge_10mm", "y_6h_ge_10mm", "y_3h_ge_5mm")


def build_location_table(slug: str) -> pd.DataFrame:
    if slug == "bhubaneswar":
        era5 = pd.read_csv(
            os.path.join(BACKEND, "data", "processed", "bhubaneswar_weather.csv"),
            parse_dates=["timestamp"])
        # 2026 lives in a separate file (core 6 vars only — convective
        # columns are NaN for 2026 rows; boosters handle NaN natively).
        era5_2026 = pd.read_csv(
            os.path.join(BACKEND, "data", "processed", "bhubaneswar_weather_2026.csv"),
            parse_dates=["timestamp"])
        era5 = pd.concat([era5, era5_2026], ignore_index=True)
        gfs = pd.read_csv(
            os.path.join(BACKEND, "data", "processed", "ifs", "gfs_global_processed.csv"),
            parse_dates=["timestamp"])
    else:
        era5 = pd.read_csv(os.path.join(LOC_DIR, f"{slug}.csv"), parse_dates=["timestamp"])
        gfs = pd.read_csv(os.path.join(LOC_DIR, f"{slug}_gfs.csv"), parse_dates=["timestamp"])
    era5["timestamp"] = pd.to_datetime(era5["timestamp"], utc=True).dt.tz_localize(None)
    gfs["timestamp"] = pd.to_datetime(gfs["timestamp"], utc=True).dt.tz_localize(None)
    # Point-only features: keep just the core + convective columns so
    # build_features() does NOT add the Bhubaneswar spatial features
    # (the processed Bhubaneswar CSV carries merged thermo/upwind
    # columns under different names, which build_features cannot use).
    point_cols = ["timestamp", "temperature_c", "humidity_pct", "precipitation_mm",
                  "wind_speed_kmh", "pressure_hpa", "cloud_cover_pct",
                  "wind_gusts_kmh", "cloud_cover_low_pct", "cloud_cover_mid_pct",
                  "cloud_cover_high_pct", "vapour_pressure_deficit_hpa", "tcwv_kg_m2"]
    era5_point = era5[[c for c in point_cols if c in era5.columns]].copy()
    # build_features drops the first 72 h (features) and the last 6 h (targets).
    table = feat.build_features(era5_point, targets=True)
    gfs_feats = build_ifs_features(gfs, era5_precip=era5["precipitation_mm"])
    gfs_feats = gfs_feats.rename(columns=lambda c: c.replace("ifs_", "gfs_")
                                  if c != "timestamp" else c)
    table = table.merge(gfs_feats, on="timestamp", how="left", validate="one_to_one")
    table["location"] = slug
    return table


def build_all() -> pd.DataFrame:
    frames = []
    for slug in LOCATIONS:
        t = build_location_table(slug)
        log = f"{slug}: {len(t)} rows, {len(t.columns)} cols"
        print(log)
        frames.append(t)
    all_df = pd.concat(frames, ignore_index=True).sort_values(
        ["location", "timestamp"]).reset_index(drop=True)
    out = os.path.join(BACKEND, "data", "model_ready", "odisha_locations.csv")
    all_df.to_csv(out, index=False)
    print(f"saved {out} ({len(all_df)} rows)")
    return all_df


if __name__ == "__main__":
    build_all()
