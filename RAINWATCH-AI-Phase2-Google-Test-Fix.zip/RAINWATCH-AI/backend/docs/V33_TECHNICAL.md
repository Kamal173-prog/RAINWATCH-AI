# RAINWATCH AI — rainfall-xgb-v3.3: heavy-rain recall and F1

Experimental upgrade of the rainfall classifier, ordered 2026-11-23.
**Status: evaluated, NOT deployed. Production stays on `rainfall-xgb-v3`
(API v1.3.0).** The frozen v3.3 artifacts exist for the record and for a
future deployment decision; no API or frontend change was made.

## 1. Summary verdict

On the reserved 2026 evaluation (Jan–Nov 2026, 7,771 hours, never used
for any selection, weight, threshold or feature decision), the frozen
v3.3 has the best ranking (PR-AUC) of all four versions on all three
events, and the best calibration (Brier, ECE) on all three:

| event | v3 | v3.1 | v3.2 | **v3.3 frozen** |
|---|---|---|---|---|
| 3h ≥ 10 mm PR-AUC | 0.2364 | 0.2304 | 0.2983 | **0.2998** |
| 6h ≥ 10 mm PR-AUC | 0.4006 | 0.4336 | 0.4293 | **0.4774** |
| 3h ≥ 5 mm PR-AUC | 0.4514 | 0.4640 | 0.4898 | **0.4956** |

The honest version of that sentence: v3.3 is clearly better than
production v3, but against v3.2 it is a tie on two events and a lean on
one. Paired 7-day block bootstrap of the 2026 PR-AUC gaps (1,000
resamples, `bootstrap_2026.json`):

| gap | mean | 95% CI | P(>0) |
|---|---|---|---|
| 3h ≥ 10 mm, v3.3 − v3 | +0.058 | [−0.004, +0.123] | 0.965 |
| 3h ≥ 10 mm, v3.3 − v3.2 | +0.000 | [−0.057, +0.056] | 0.496 |
| 6h ≥ 10 mm, v3.3 − v3 | +0.071 | [+0.002, +0.130] | 0.978 |
| 6h ≥ 10 mm, v3.3 − v3.2 | +0.047 | [−0.015, +0.103] | 0.937 |
| 3h ≥ 5 mm, v3.3 − v3 | +0.042 | [−0.002, +0.084] | 0.972 |
| 3h ≥ 5 mm, v3.3 − v3.2 | +0.003 | [−0.024, +0.028] | 0.609 |

Only the 6h ≥ 10 mm gap vs v3 excludes zero. The 6h ≥ 10 mm gap vs
v3.2 (+0.047, P = 0.937) leans strongly positive but is not
established. At the saved operating thresholds v3.3 does **not** lead
on F1 for 3h ≥ 10 mm (v3.2: 0.318/0.331 vs v3.3: 0.305/0.308) or on
storm detection for that event. Precision is still low in absolute
terms (3h ≥ 10 mm elevated precision 0.21 on 2026) — a "high" tier
remains an early-warning signal, not a confirmed forecast.

## 2. Protocol

- **Data:** ERA5 reanalysis (Bhubaneswar + Puri Coast + Offshore Bay
  upwind grids) + Open-Meteo Historical Forecast API (GFS, 0.11°
  surface / 0.25° pressure-level) for 2021-03-23 → 2026-11-23.
  2025 was already used repeatedly in v3/v3.1 model selection, so it
  is a historical benchmark here, NOT a clean holdout. **2026
  (Jan–Nov, 7,771 rows) is the fresh evaluation, reserved until the
  freeze.**
- **Splits:** train 2021–2023, validation 2024, benchmark 2025,
  fresh evaluation 2026. Expanding-window CV for OOF: train 2021 →
  val 2022, train 2021–22 → val 2023, train 2021–23 → val 2024.
- **No leakage:** no random temporal shuffling; no resampling outside
  training folds; no SMOTE on time-series data. GFS values are
  seamless-forecast values from model runs initialised at or before
  the valid time (verified against Open-Meteo docs and live probes);
  multi-lead "previous run" precipitation exists only from 2024-01-01
  and was excluded from the main training protocol.
- **Freeze rule:** the frozen config was chosen on OOF + 2025 only,
  before any 2026 evaluation. 2026 was scored exactly once per
  version with identical metric code
  (`ml/evaluate_2026.py`). Never re-freeze on 2026 results.
- **Regressors:** carried over from v3 unchanged in every version.
  Shared 2026 regressor scores: 1h MAE 0.3256 / RMSE 1.4209, 3h
  0.9736 / 3.7535, 6h 1.8106 / 6.6006 — much worse than 2025
  (0.209/0.631/1.211) because 2026 is a heavier year (185 3h ≥ 10 mm
  hours vs 87 in 2025) with larger extremes; RMSE blows up on the
  big misses.

## 3. Features

54 new GFS features engineered in `ml/features_v33.py` (multi-lead
precipitation sums, CAPE/CIN, lifted index, RH profile 925/850/700/
500 hPa and column mean, precipitable-water proxy `gfs_rh_column_mean`
— `precipitable_water` is not a valid Open-Meteo variable — 850/700
hPa wind and vertical velocity, pressure tendencies, spatial
precipitation gradients, dew-point depressions). Previous-Runs
day1/day2 precipitation fetched but excluded from the main set (only
exists from 2024).

Pruning (permutation importance on 2024 validation, single XGBoost;
prune only if importance ≤ 0 for BOTH 3h ≥ 10 mm and 3h ≥ 5 mm):
**8 of 102 pruned, 94 kept** (`models/rainfall_xgb_v3_3/
feature_schema.json`). Top new features by importance: `gfs_rh_850_700`
(top overall), `gfs_rh_column_mean`, `gfs_precip_12h_sum`,
`gfs_rh_700` — the moisture-profile features carry real signal.

## 4. Out-of-fold results

Expanding-window OOF PR-AUC (per-fold weights + Platt):

| event | v32 features | v33 features |
|---|---|---|
| 3h ≥ 10 mm | 0.1638 | **0.1932** (+18%) |
| 6h ≥ 10 mm | 0.2763 | **0.3565** (+29%) |
| 3h ≥ 5 mm | 0.3742 | **0.4053** (+8%) |

The new features improved every fold and every event on OOF; 2024
was the hard year (3h ≥ 10 mm fold PR-AUC 0.0883 v32 / 0.1068 v33).
Matched analysis: the v3.2 operating thresholds are already on the
OOF precision–recall frontier — threshold re-optimisation alone
cannot improve v3.2; only a better ranking can.

OOF F-thresholds (v33 features): 3h ≥ 10 mm F1 t=0.13 (P 0.215 /
R 0.264), F2 t=0.05 (P 0.114 / R 0.495), F3 t=0.03 (P 0.082 /
R 0.632); 6h ≥ 10 mm F1 t=0.18 (P 0.337 / R 0.455); 3h ≥ 5 mm F1
t=0.25 (P 0.438 / R 0.477).

## 5. Variants (2025 benchmark)

8 arms × 3 targets (`models/rainfall_xgb_v3_3/variants.json`).
2025 PR-AUC (3h ≥ 10 mm / 6h ≥ 10 mm / 3h ≥ 5 mm):

| arm | 3h ≥ 10 mm | 6h ≥ 10 mm | 3h ≥ 5 mm |
|---|---|---|---|
| base | 0.1687 | 0.2743 | 0.3915 |
| posweight_half | 0.1656 | 0.2536 | 0.3989 |
| posweight_double | 0.1762 | 0.2707 | 0.4003 |
| cost3 | 0.1727 | 0.2562 | 0.4008 |
| cost5 | 0.1557 | 0.2618 | 0.4083 |
| hardneg | 0.1343 | 0.2776 | **0.4189** |
| eventaware | 0.1661 | 0.2563 | 0.4084 |
| focal | **0.1824** | 0.2606 | 0.4016 |

Focal loss is the best arm for 3h ≥ 10 mm (gradients/Hessians
verified against numerical differentiation; γ=0 reduces to weighted
logistic). **No arm beats the deployed v3.2's 0.2228 on 2025 for
3h ≥ 10 mm** despite the v33 features winning on OOF — an honest
negative result. Event-aware sampling was initially broken (weights
computed but never passed to `fit`, so its first run duplicated base
exactly); the fix was verified two ways (results now differ from
base on all three targets; a direct weight-application check shows
mean |Δp| 0.0654 on 2024). Median detection lead times are mostly
0.0 h (storms detected as they start); focal 3h ≥ 10 mm and hardneg
3h ≥ 5 mm reach +1.0 h.

Feature-set diagnostic (`feature_set_diagnostic.json`), 2025 PR-AUC:
53 feats (v3.2) 0.2228 / 0.2371 / 0.3575; 102 feats (v33 unpruned)
0.1770 / 0.2555 / 0.4025; 94 feats (v33 pruned) 0.1687 / 0.2743 /
0.3915. The new features hurt 2025 for 3h ≥ 10 mm but help 6h ≥
10 mm and 3h ≥ 5 mm. Paired bootstrap of the 2025 3h ≥ 10 mm gap
(v32 − v33-102): mean +0.040, 95% CI [−0.009, +0.085], P(>0) = 0.945
— leans v32, CI crosses zero, not significant; 2026 was the arbiter.

## 6. Location-aware investigation (Phase 7)

5 Odisha locations (Bhubaneswar, Cuttack, Paradip, Brahmapur,
Sambalpur), point-only features, train 2021–23 / weights+thresholds
on 2024 / evaluated on 2025 (`location_experiment.json`).
Leave-one-location-out 2025 PR-AUC means: 0.163 / 0.232 / 0.314.
Pooled-all-5 vs Bhubaneswar-only on Bhubaneswar 2025: 0.1920 /
0.2214 / 0.3768 vs 0.1800 / 0.2047 / 0.3487 — pooling wins on all
three events but stays below v3.2's same-location 0.2228, because
the location models lack the spatial/upwind features. Geographic
transfer works with a cost; spatial features matter more than
pooling. Pooling does not change the freeze decision.

## 7. Random Forest challenger

Full record: `docs/V33_RANDOM_FOREST_EXPERIMENT.md`. Tuned
RandomForestClassifier (300 trees, unlimited depth, leaf 5,
balanced_subsample, event-aware weights; mean OOF PR-AUC 0.1701
for 3h ≥ 10 mm vs 0.1932 for the three-family ensemble). 2025:
four-family 0.2011 / 0.2697 / 0.3868 vs baseline 0.1687 / 0.2743 /
0.3915; stacking 0.1922 / 0.2606 / 0.4094. **Verdict: NOT adopted**
— every block-bootstrap CI includes zero, and at the F1 operating
point the RF arms detect significantly fewer 3h ≥ 10 mm storms
than the baseline. RF alone catches 14 storms the ensemble misses
for 3h ≥ 5 mm, but the ensemble inherits only 3 of them.

## 8. Stacking

- **v32+v33 feature-set stacker** (`ml/test_stacking.py`,
  `stacking.json`): logistic meta-learner over per-family
  probabilities. 2024-OOF gate FAILED on all three targets (stack
  0.0948 / 0.2275 / 0.3565 vs v33 fixed 0.1068 / 0.2565 / 0.3620),
  so it is not adopted despite its 2025 numbers (0.1898 / 0.2378 /
  **0.4153** — best of any approach on 3h ≥ 5 mm).
- **RF 4-family stacker** (in `rf_experiment.json`): passes its
  2024-OOF gate on all three targets (0.1100 / 0.2596 / 0.3698 vs
  fixed 0.1068 / 0.2565 / 0.3620) and scores 0.1922 / 0.2606 /
  0.4094 on 2025, but its block-bootstrap CIs also include zero —
  not adopted.

## 9. Freeze

Frozen config: the **base arm** — three-family ensemble
(XGBoost + LightGBM + HistGradientBoosting) on the pruned
94-feature v33 set, per-target weights/Platt/F1–F2 thresholds
learned on 2024 validation, members refit on 2021–2024
(`ml/freeze_v33.py`, artifacts in `models/rainfall_xgb_v3_3/frozen/`).
It is the only config passing every gate: best OOF on two of three
events, best 2025 on 6h ≥ 10 mm, and the alternatives that beat it
on 2025 all fail a gate (RF: bootstrap CI includes zero; v32+v33
stacking: OOF gate; focal: no OOF record). The freeze was verified:
frozen artifacts reproduce the variants.json 2025 PR-AUC exactly
(0.1687 / 0.2743 / 0.3915, diffs ≤ 0.0000).

## 10. Final 2026 evaluation — four-way comparison

Single evaluation on reserved 2026 data (7,771 hours),
`models/rainfall_xgb_v3_3/final_2026_comparison.json`,
`ml/evaluate_2026.py`. Each version scored at its OWN saved
operating thresholds; v3.2's numbers reproduce
`reproduce_v32.py` exactly (0.2983 / 0.4293 / 0.4898), validating
the evaluation code.

PR-AUC / Brier / ECE:

| version | 3h ≥ 10 mm | 6h ≥ 10 mm | 3h ≥ 5 mm |
|---|---|---|---|
| v3 | 0.2364 / 0.0212 / 0.0080 | 0.4006 / 0.0491 / 0.0231 | 0.4514 / 0.0463 / 0.0099 |
| v3.1 | 0.2304 / 0.0212 / 0.0102 | 0.4336 / 0.0489 / 0.0250 | 0.4640 / 0.0457 / 0.0132 |
| v3.2 | 0.2983 / 0.0204 / 0.0070 | 0.4293 / 0.0475 / 0.0258 | 0.4898 / 0.0446 / 0.0100 |
| **v3.3** | **0.2998 / 0.0201 / 0.0068** | **0.4774 / 0.0452 / 0.0192** | **0.4956 / 0.0444 / 0.0089** |

F1 at elevated / high thresholds, 2026:

| version | 3h ≥ 10 mm | 6h ≥ 10 mm | 3h ≥ 5 mm |
|---|---|---|---|
| v3 | 0.286 / 0.307 | 0.324 / 0.446 | 0.444 / 0.473 |
| v3.1 | 0.337 / 0.322 | 0.459 / 0.405 | 0.485 / 0.443 |
| v3.2 | 0.318 / 0.331 | 0.411 / 0.460 | 0.476 / 0.461 |
| **v3.3** | 0.305 / 0.308 | 0.406 / **0.466** | 0.451 / **0.495** |

Storm detection rate (elevated), 2026: 3h ≥ 10 mm — v3 0.761,
v3.1 0.761, v3.2 0.696, v3.3 0.565 (26/46). 6h ≥ 10 mm — v3 0.359,
v3.1 0.830, v3.2 0.566, v3.3 0.415. 3h ≥ 5 mm — v3 0.659, v3.1
0.716, v3.2 0.648, v3.3 0.705. Median lead times are mostly
−1.0 to 0.0 h — alerts still typically arrive as rain starts, not
before; only v3.1's 6h elevated median (+0.5 h) is positive.

Caveat on the storm-detection metric: it counts a storm detected
only when a predicted event block STARTS within [s−2, e+2] of the
true storm. A constantly-firing arm merges its alerts into few
long blocks with early starts, so it can show high hour recall
with low storm detection (v3's 6h ≥ 10 mm elevated arm: hour
recall 0.915, false alarms 5.67/day, storm detection 0.359).
Treat storm detection as a secondary signal; PR-AUC and F-scores
are the primary comparison.

## 11. Limitations

1. The 2026 wins over v3.2 are point-estimate wins, not established
   ones (only the 6h ≥ 10 mm gap vs v3 excludes zero). One more
   monsoon season of prospective data is the real test.
2. Precision is still low in absolute terms; 3h ≥ 10 mm elevated
   precision is 0.21 on 2026. Do not present this as a reliable
   heavy-rainfall warning system.
3. Operating thresholds were learned on 2024 validation, never
   re-optimised on 2026. v3.3's F1 at its saved thresholds trails
   v3.2 on 3h ≥ 10 mm despite the better ranking — a threshold
   re-optimisation on validation including 2025 is the next step
   before any production switch (never optimise on 2026).
4. Median detection lead time is ~0 h. This is a nowcast aid, not
   an advance warning.
5. Bhubaneswar-only forecaster (single ERA5 grid cell + upwind
   grids). The location experiment shows geographic transfer works
   with a cost, but no multi-location model was frozen.
6. GFS pressure-level variables are 0.25° vs 0.11° surface — their
   grid cell can sit up to ~12 km away. GFS has a ~15-day archive
   gap 2022-11-29 → 2022-12-14.
7. The v33 features won on OOF but lost to v3.2 on the 2025
   benchmark for 3h ≥ 10 mm — the 2026 result reverses that, which
   is consistent with 2025 being a hard/small sample for this event
   (87 positives) rather than with either year being the truth.

## 12. Artifacts

- `ml/freeze_v33.py`, `ml/evaluate_2026.py`,
  `ml/bootstrap_2026.py`, `ml/train_rainfall_v33.py`,
  `ml/features_v33.py`, `ml/rf_challenger.py`,
  `ml/test_stacking.py`, `ml/diagnose_feature_sets.py`,
  `ml/bootstrap_3h10.py`, `ml/location_experiment.py`,
  `ml/v33_common.py` (metrics, focal loss, best params)
- `models/rainfall_xgb_v3_3/frozen/` (frozen members, weights,
  Platt, thresholds, feature schema, metadata)
- `models/rainfall_xgb_v3_3/` — `variants.json`,
  `feature_schema.json`, `thresholds_oof.json`, `oof/`,
  `stacking.json`, `stacking_oof2024.json`,
  `feature_set_diagnostic.json`, `bootstrap_3h10.json`,
  `event_level_summary.json`, `location_experiment.json`,
  `rf_tuning.json`, `rf_experiment.json`, `rf_arm_probs_*.npz`,
  `final_2026_comparison.json`, `bootstrap_2026.json`
- `data/model_ready/bhubaneswar_features_v33.csv` (51,518 rows,
  2021–2026, 147 cols), `data/model_ready/odisha_locations.csv`
  (5 locations, point-only features)

## 13. How to reproduce

```bash
# Rebuild the v33 feature table (2021-2026)
.venv/bin/python ml/features_v33.py
# OOF + thresholds + prune + variants
.venv/bin/python ml/train_rainfall_v33.py --phase oof
.venv/bin/python ml/train_rainfall_v33.py --phase thresholds
.venv/bin/python ml/train_rainfall_v33.py --phase prune
.venv/bin/python ml/train_rainfall_v33.py --phase variants
# Freeze (retrains base arm on 2021-2024, verifies 2025 reproduction)
.venv/bin/python ml/freeze_v33.py
# Final 2026 evaluation, four-way (run once; do not re-freeze on it)
.venv/bin/python ml/evaluate_2026.py
.venv/bin/python ml/bootstrap_2026.py
```
