"""Probe the v3.3 demo frontend: count MODEL/DEMO/UNKNOWN badges and screenshot.

Demo config: vite on :5173 with VITE_API_URL=http://localhost:8001 (v3.3 API).
Default location is old-town (Bhubaneswar). Brahmapur must show all DEMO.
Run: .venv-audit/bin/python backend/ml/probe_v33_demo.py
"""
import json
import os
from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:5173"
OUT = "/home/hatch/workspace/v33-demo-screenshots"
CHROME = "/home/hatch/.cache/ms-playwright/chromium-1255/chrome-linux64/chrome"
os.makedirs(OUT, exist_ok=True)


def count_badges(page):
    model = page.locator('span[title^="ML model"]')
    demo = page.locator('span:text-is("DEMO")')
    unknown = page.locator('span:text-is("UNKNOWN")')
    titles = sorted(set(model.evaluate_all(
        "els => els.map(e => e.getAttribute('title'))")))
    return {
        "MODEL": model.count(),
        "DEMO": demo.count(),
        "UNKNOWN": unknown.count(),
        "model_titles": titles,
    }


def set_location(page, name):
    # The location picker is a <select> (components/common/Select) or a
    # button list; try select first, then a button with the city name.
    sel = page.locator("select").first
    if sel.count():
        opts = sel.locator("option").all_inner_texts()
        match = [o for o in opts if name.lower() in o.lower()]
        if match:
            sel.select_option(label=match[0])
            page.wait_for_timeout(2500)
            return True
    btn = page.locator(f"button:text-is('{name}')")
    if btn.count():
        btn.first.click()
        page.wait_for_timeout(2500)
        return True
    return False


def probe(page, url, label, switch_to=None):
    page.goto(url, wait_until="networkidle")
    page.wait_for_timeout(3000)
    result = {"page": label, "url": url, "before": count_badges(page)}
    page.screenshot(path=f"{OUT}/{label}.png", full_page=True)
    if switch_to:
        ok = set_location(page, switch_to)
        result["switched_to_" + switch_to] = ok
        result["after"] = count_badges(page)
        page.screenshot(path=f"{OUT}/{label}-{switch_to.lower()}.png",
                        full_page=True)
    return result


def main():
    results = []
    with sync_playwright() as pw:
        browser = pw.chromium.launch(executable_path=CHROME)
        page = browser.new_page(viewport={"width": 1440, "height": 900})
        results.append(probe(page, f"{BASE}/forecast", "forecast", "Brahmapur"))
        results.append(probe(page, f"{BASE}/flood-intelligence",
                             "flood-intelligence", "Brahmapur"))
        browser.close()
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
