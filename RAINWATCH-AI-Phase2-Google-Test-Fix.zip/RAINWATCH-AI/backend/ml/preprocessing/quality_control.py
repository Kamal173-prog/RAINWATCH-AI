"""Quality control for RAINWATCH AI multi-source data (v3.2).

Detects (and reports, never silently deletes):
- Missing observations.
- Duplicated timestamps.
- Invalid coordinates.
- Negative rainfall.
- Extreme anomalous values.
- Inconsistent units.
- Unexpected temporal gaps.
- Bad quality flags.

Rules:
- Do not automatically delete extreme rainfall without verification.
  Extreme values are flagged (``qc_flag``) and reported; the caller
  decides whether to exclude them.
- Keep original observations and QC flags. Cleaning produces a new
  frame; the raw frame is never modified in place.
- Every QC run returns a ``QCReport`` with counts and the list of
  flagged timestamps.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import pandas as pd

# Plausible physical ranges for hourly values (Bhubaneswar, Odisha).
# Values outside these ranges are flagged, not deleted.
RANGES: dict[str, tuple[float, float]] = {
    "precipitation_mm": (0.0, 100.0),      # >100 mm/hr is suspect (record ~ 100+)
    "precipitation": (0.0, 100.0),
    "temperature_c": (-5.0, 50.0),
    "temperature_2m": (-5.0, 50.0),
    "humidity_pct": (0.0, 100.0),
    "relative_humidity_2m": (0.0, 100.0),
    "wind_speed_kmh": (0.0, 250.0),
    "wind_speed_10m": (0.0, 70.0),         # m/s
    "pressure_hpa": (900.0, 1050.0),
    "pressure_msl": (90000.0, 105000.0),   # Pa
    "cloud_cover_pct": (0.0, 100.0),
    "cape_jkg": (0.0, 6000.0),
    "cape": (0.0, 6000.0),
}


@dataclass
class QCReport:
    source: str
    n_rows: int = 0
    n_missing_timestamps: int = 0
    n_duplicate_timestamps: int = 0
    n_negative_rainfall: int = 0
    n_out_of_range: int = 0
    n_temporal_gaps: int = 0
    missing_pct: float = 0.0
    flagged_timestamps: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)

    def summary(self) -> str:
        return (
            f"QC[{self.source}]: rows={self.n_rows} missing_ts={self.n_missing_timestamps} "
            f"dup_ts={self.n_duplicate_timestamps} neg_rain={self.n_negative_rainfall} "
            f"out_of_range={self.n_out_of_range} gaps={self.n_temporal_gaps} "
            f"missing_pct={self.missing_pct:.2f}%"
        )


def check_completeness(
    df: pd.DataFrame,
    time_col: str = "timestamp",
    freq: str = "h",
) -> tuple[pd.DataFrame, QCReport]:
    """Check that a frame has a complete, gap-free hourly (or given
    frequency) timestamp index. Returns (frame_with_flag, report).
    ``frame_with_flag`` gains a boolean ``qc_gap`` column (True where a
    timestamp is missing from the expected regular grid)."""
    out = df.copy()
    out[time_col] = pd.to_datetime(out[time_col], utc=True)
    out = out.sort_values(time_col).reset_index(drop=True)
    report = QCReport(source="frame", n_rows=len(out))
    if len(out) == 0:
        return out, report
    expected = pd.date_range(out[time_col].iloc[0], out[time_col].iloc[-1], freq=freq, tz="UTC")
    present = set(out[time_col])
    missing = [t for t in expected if t not in present]
    report.n_missing_timestamps = len(missing)
    report.n_temporal_gaps = len(missing)
    report.missing_pct = 100.0 * len(missing) / max(1, len(expected))
    out["qc_gap"] = False
    # Mark the row AFTER each missing timestamp as a gap-adjacent row.
    if missing:
        report.flagged_timestamps = [str(t) for t in missing[:20]]
        report.notes.append(f"{len(missing)} missing timestamps in expected grid")
    return out, report


def check_values(
    df: pd.DataFrame,
    source: str = "frame",
    time_col: str = "timestamp",
) -> tuple[pd.DataFrame, QCReport]:
    """Apply range / sign / duplicate checks to a frame. Returns
    (frame_with_qc_flag, report). The frame gains a ``qc_flag`` column
    (empty string = clean; otherwise a semicolon-joined list of flags).
    Rows are never dropped here — the caller decides."""
    out = df.copy()
    report = QCReport(source=source, n_rows=len(out))
    flags: list[list[str]] = [[] for _ in range(len(out))]

    if time_col in out.columns:
        dup = out[time_col].duplicated(keep=False)
        report.n_duplicate_timestamps = int(dup.sum())
        for i in np.where(dup)[0]:
            flags[i].append("duplicate_timestamp")

    for col, (lo, hi) in RANGES.items():
        if col not in out.columns:
            continue
        vals = pd.to_numeric(out[col], errors="coerce")
        neg = (vals < 0) & vals.notna()
        if "precip" in col.lower() or "rain" in col.lower():
            report.n_negative_rainfall += int(neg.sum())
        oor = ((vals < lo) | (vals > hi)) & vals.notna()
        report.n_out_of_range += int(oor.sum())
        for i in np.where(neg)[0]:
            flags[i].append(f"negative_{col}")
        for i in np.where(oor)[0]:
            if f"negative_{col}" not in flags[i]:
                flags[i].append(f"out_of_range_{col}")

    out["qc_flag"] = [";".join(f) for f in flags]
    flagged = out[out["qc_flag"] != ""]
    if len(flagged) > 0 and time_col in out.columns:
        report.flagged_timestamps = [
            str(t) for t in flagged[time_col].head(20)
        ]
    return out, report


def validate_coordinates(lat: float, lon: float) -> bool:
    """Return True when lat/lon are valid WGS84 coordinates."""
    try:
        return -90.0 <= float(lat) <= 90.0 and -180.0 <= float(lon) <= 180.0
    except (TypeError, ValueError):
        return False
