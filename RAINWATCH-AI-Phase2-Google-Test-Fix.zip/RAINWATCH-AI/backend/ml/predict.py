"""Inference for the RAINWATCH AI rainfall forecaster, v3 (rainfall-xgb-v3).

Spatial-Thermodynamic Ensemble:
- Mean regressors (``reg_1h/3h/6h``): XGBoost + LightGBM + HistGradientBoosting,
  blended with non-negative weights learned on the 2024 validation set.
- Heavy-event classifiers (``clf_3h_ge_10mm`` etc.): the same three families,
  blended, Platt-calibrated on validation, with TWO operating thresholds
  per event: ``elevated`` (Watch, F2-optimal, high recall) and ``high``
  (Warning, F1-optimal, high precision).
- P90 quantile regressors (``p90_3h/6h``): XGBoost + LightGBM + HistGB
  quantile, blended the same way.

The forecaster is a point model for the Bhubaneswar ERA5 grid cell
(lat 20.281195, lng 85.843376), with spatial look-ahead from the Puri Coast
and Offshore Bay of Bengal grids. It takes the last 72 hours of hourly
observations, builds the same pruned v3 features as training, and returns
predictions for the next 1 / 3 / 6 hours.

Heavy-risk tier (from the validation-tuned dual thresholds)
----------------------------------------------------------
- "high":     P(3h >= 10 mm) >= its ``high`` threshold OR P(6h >= 10 mm) >= its ``high`` threshold.
- "elevated": P(3h >= 10 mm) >= its ``elevated`` threshold OR P(6h >= 10 mm) >= its ``elevated`` threshold OR P(3h >= 5 mm) >= its ``elevated`` threshold.
- "moderate": P(3h >= 10 mm) >= 0.5 * its ``elevated`` threshold OR P(3h >= 5 mm) >= 0.5 * its ``elevated`` threshold.
- "low":      otherwise.

Usage
-----
    from ml.predict import RainfallForecaster
    fc = RainfallForecaster()
    fc.predict(hourly_df)                  # {"1h": mm, "3h": mm, "6h": mm}
    fc.predict_with_provenance(hourly_df)  # full dict (see below)
    fc.heavy_rain_probability(hourly_df)   # {"3h_ge_5mm": p, "3h_ge_10mm": p, "6h_ge_10mm": p}
    fc.upper_bound_p90(hourly_df)          # {"3h": mm, "6h": mm}
    fc.heavy_risk_tier(hourly_df)          # "low" | "moderate" | "elevated" | "high"
"""

import json
import os
import sys

import joblib
import lightgbm as lgbm
import numpy as np
import pandas as pd
import xgboost as xgb

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import features as feat  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
BACKEND = os.path.dirname(HERE)
MODEL_DIR = os.path.join(BACKEND, "models", "rainfall_xgb_v3")
MODEL_VERSION = "rainfall-xgb-v3"

# v3.2: the classifier ensemble is trained on v3 41 features + 12 GFS
# features. The regressors (mean + P90) are unchanged from v3. When the
# MODEL_VERSION env var is "rainfall-xgb-v3.2", the classifiers are loaded
# from models/rainfall_xgb_v3_2/ and the GFS features are built at
# inference time from data/processed/ifs/gfs_global_processed.csv.
# The default is v3 (production). Set MODEL_VERSION=rainfall-xgb-v3.2 in
# .env to enable v3.2 behind the feature flag.
V32_MODEL_DIR = os.path.join(BACKEND, "models", "rainfall_xgb_v3_2")
V32_MODEL_VERSION = "rainfall-xgb-v3.2"
GFS_PROCESSED_CSV = os.path.join(BACKEND, "data", "processed", "ifs", "gfs_global_processed.csv")

# v3.3: the frozen classifier ensemble (94 features = 39 v3 features +
# 55 GFS features, incl. the moisture-profile features from the v3.3
# GFS files). Same v3 regressors/P90. When MODEL_VERSION is
# "rainfall-xgb-v3.3", classifiers load from models/rainfall_xgb_v3_3/frozen/
# and the extra v3.3 GFS features are built at inference time from
# data/processed/ifs/gfs_v33_*.csv (see ml/features_v33.py:
# build_v33_features_at). The frozen thresholds.json is the freeze record;
# the operating thresholds are thresholds_optimized.json (2024+2025
# evidence, 2026 never used for selection). Production default stays v3.
V33_MODEL_DIR = os.path.join(BACKEND, "models", "rainfall_xgb_v3_3", "frozen")
V33_MODEL_VERSION = "rainfall-xgb-v3.3"

# Classifier targets: (artifact suffix, probability key).
CLASSIFIERS = [
    ("y_3h_ge_10mm", "3h_ge_10mm"),
    ("y_6h_ge_10mm", "6h_ge_10mm"),
    ("y_3h_ge_5mm", "3h_ge_5mm"),
]

FAMILIES = ("xgb", "lgbm", "hgb")


def _logit(p: float, eps: float = 1e-6) -> float:
    p = min(max(p, eps), 1 - eps)
    return float(np.log(p / (1 - p)))


def _sigmoid(z: float) -> float:
    return float(1.0 / (1.0 + np.exp(-z)))


def _load_member(kind: str, family: str, model_dir: str | None = None):
    """Load one ensemble member.

    XGBoost -> native booster (JSON), LightGBM -> Booster (txt),
    HistGB -> joblib. LightGBM is loaded as a raw Booster (not the sklearn
    wrapper) because the wrapper cannot be rehydrated from a saved file.
    ``model_dir`` defaults to the v3 directory; pass the v3.2 directory
    to load v3.2 classifiers.

    v3.2 artifacts use a shorter classifier naming (``clf_3h_ge_10mm_*``)
    than v3 (``clf_y_3h_ge_10mm_*``); both are tried.
    """
    base = model_dir if model_dir else MODEL_DIR
    ext = {"xgb": "json", "lgbm": "txt", "hgb": "pkl"}[family]
    path = os.path.join(base, f"{kind}_{family}.{ext}")
    if not os.path.exists(path) and kind.startswith("clf_y_"):
        alt = os.path.join(base, f"clf_{kind[6:]}_{family}.{ext}")
        if os.path.exists(alt):
            path = alt
    if family == "xgb":
        m = xgb.XGBRegressor() if kind.startswith(("reg_", "p90_")) else xgb.XGBClassifier()
        m.load_model(path)
        return m
    if family == "lgbm":
        return lgbm.Booster(model_file=path)
    return joblib.load(path)


def _lookup(d: dict, key: str):
    """Look up ``key`` in ``d``, also trying the v3.2 short form.

    v3 uses ``clf_y_3h_ge_10mm`` keys; v3.2 uses ``y_3h_ge_10mm``.
    """
    if key in d:
        return d[key]
    short = key[4:] if key.startswith("clf_") else key
    if short in d:
        return d[short]
    raise KeyError(key)


def _model_predict(model, X) -> float:
    """Single prediction from any member (XGB / LightGBM Booster / HistGB)."""
    if isinstance(model, lgbm.Booster):
        arr = X.to_numpy() if hasattr(X, "to_numpy") else np.asarray(X)
        return float(model.predict(arr)[0])
    return float(model.predict(X)[0])


def _model_proba(model, X) -> float:
    """Probability of class 1 from any classifier member."""
    if isinstance(model, lgbm.Booster):
        arr = X.to_numpy() if hasattr(X, "to_numpy") else np.asarray(X)
        return float(model.predict(arr)[0])
    return float(model.predict_proba(X)[0, 1])


class RainfallForecaster:
    """Loads the v3 (or v3.2 / v3.3) ensemble once and predicts from hourly observations.

    ``model_dir`` selects the classifier directory. When it is the v3.2
    directory, the classifiers are the v3.2-GFS ensemble (53 features)
    and the GFS features are built at inference time; when it is the
    v3.3 frozen directory, the classifiers are the v3.3 ensemble
    (94 features) and the extra v3.3 GFS features are built at inference
    time. The regressors and P90 quantiles are always loaded from v3
    (unchanged in v3.2/v3.3). ``model_version`` is reported in the API
    status/metadata.
    """

    def __init__(self, model_dir: str = MODEL_DIR, model_version: str | None = None):
        self.model_dir = model_dir
        if model_version is None:
            norm = os.path.normpath(model_dir)
            if os.path.basename(norm) == "rainfall_xgb_v3_2":
                model_version = V32_MODEL_VERSION
            elif (os.path.basename(norm) == "frozen"
                    and os.path.basename(os.path.dirname(norm)) == "rainfall_xgb_v3_3"):
                model_version = V33_MODEL_VERSION
            else:
                model_version = MODEL_VERSION
        self.model_version = model_version
        self.is_v33 = self.model_version == V33_MODEL_VERSION
        # The v3.2/v3.3 directories have no regressors/quantiles — those
        # live in v3. Their ensemble_weights.json holds only the three
        # classifier weights (keyed by the short target name), so merge
        # v3's weights in for the regressor/quantile lookups.
        reg_dir = MODEL_DIR if self.model_version in (V32_MODEL_VERSION, V33_MODEL_VERSION) else model_dir
        with open(os.path.join(model_dir, "ensemble_weights.json")) as f:
            self.weights = json.load(f)
        if reg_dir != model_dir:
            with open(os.path.join(reg_dir, "ensemble_weights.json")) as f:
                v3_weights = json.load(f)
            # Only the regressor/quantile weights come from v3. The v3.2/
            # v3.3 classifier weights MUST win: v3's file also has clf_*
            # keys (with different values), and merging them would silently
            # give the classifiers v3's weights. (Found by the v3.3
            # reproduction: v3.2 2025 recall was 0.345 instead of the
            # recorded 0.448 until this was fixed.)
            for k, v in v3_weights.items():
                if k.startswith(("reg_", "p90_")):
                    self.weights.setdefault(k, v)
        with open(os.path.join(model_dir, "platt.json")) as f:
            self.platt = json.load(f)
        # Operating thresholds: v3.3 uses thresholds_optimized.json when
        # present (the 2024+2025-optimised operating thresholds); the
        # frozen thresholds.json stays as the freeze record.
        self.thresholds_source = "thresholds.json"
        thr_path = os.path.join(model_dir, "thresholds.json")
        if self.is_v33 and os.path.exists(
                os.path.join(model_dir, "thresholds_optimized.json")):
            thr_path = os.path.join(model_dir, "thresholds_optimized.json")
            self.thresholds_source = "thresholds_optimized.json"
        with open(thr_path) as f:
            self.thresholds = json.load(f)
        with open(os.path.join(model_dir, "feature_schema.json")) as f:
            self.feature_schema = json.load(f)
        self.features = self.feature_schema["features"]
        self.use_gfs = any(c.startswith("gfs_") for c in self.features)
        # Regressors/quantiles were trained on the 41 v3 features only;
        # classifiers (v3.2) use the full 53. Keep the v3 list for them.
        if self.use_gfs:
            with open(os.path.join(MODEL_DIR, "feature_schema.json")) as f:
                self.reg_features = json.load(f)["features"]
        else:
            self.reg_features = self.features

        # Mean regressors: one ensemble per horizon (from v3).
        self.regressors = {}
        for h in feat.HORIZONS:
            kind = f"reg_{h}h"
            self.regressors[h] = {
                fam: _load_member(kind, fam, reg_dir) for fam in FAMILIES
            }
        # P90 quantile regressors (3h, 6h) (from v3).
        self.quantiles = {}
        for h in (3, 6):
            kind = f"p90_{h}h"
            self.quantiles[h] = {
                fam: _load_member(kind, fam, reg_dir) for fam in FAMILIES
            }
        # Classifiers: one ensemble per binary target (from model_dir).
        self.classifiers = {}
        for suffix, key in CLASSIFIERS:
            kind = f"clf_{suffix}"
            self.classifiers[key] = {
                fam: _load_member(kind, fam, model_dir) for fam in FAMILIES
            }

    # -- internals ---------------------------------------------------

    def _features_at(self, hourly_df: pd.DataFrame) -> pd.DataFrame:
        """Single-row feature DataFrame for the last timestamp.

        Returns a DataFrame (not a Series) so column dtypes stay numeric —
        XGBoost rejects the object dtype a transposed Series produces.
        Uses targets=False so the last row is the most recent timestamp
        (not 6 h old, which is what the training table's last row is).

        When the model uses GFS features (v3.2), the GFS processed CSV is
        loaded and the GFS features are built for the same last timestamp
        and merged. If the GFS file is missing or has no data at that
        timestamp, the GFS features are NaN (the models handle NaN
        natively) and a warning is logged — the API never crashes on a
        missing optional dataset. v3.3 additionally builds the 43 new
        moisture-profile GFS features from the v3.3 GFS files
        (ml/features_v33.py: build_v33_features_at), same NaN fallback.
        """
        if len(hourly_df) < 73:
            raise ValueError(
                f"need at least 73 hourly rows (72 h of history + current hour), got {len(hourly_df)}"
            )
        table = feat.build_features(hourly_df, targets=False)
        if len(table) == 0:
            raise ValueError("could not build features from the supplied data")
        row = table.iloc[[-1]].copy()
        if self.use_gfs:
            try:
                sys.path.insert(0, os.path.join(BACKEND, "ml"))
                from feature_groups.ifs_features import build_ifs_features
            except ImportError:
                import logging as _logging
                _logging.getLogger("rainwatch.model").warning(
                    "ifs_features module unavailable; GFS features will be NaN"
                )
                build_ifs_features = None
            if build_ifs_features is not None:
                try:
                    gfs_df = pd.read_csv(GFS_PROCESSED_CSV, parse_dates=["timestamp"])
                    gfs_df["timestamp"] = pd.to_datetime(gfs_df["timestamp"], utc=True).dt.tz_localize(None)
                    gfs_feats = build_ifs_features(gfs_df, era5_precip=None)
                    last_ts = pd.to_datetime(row["timestamp"].iloc[0])
                    match = gfs_feats[gfs_feats["timestamp"] == last_ts]
                    if len(match) == 0:
                        raise ValueError(f"no GFS data at {last_ts}")
                    # build_ifs_features prefixes columns with ifs_; the
                    # v3.2 schema uses gfs_ for GFS data.
                    for c in gfs_feats.columns:
                        if c == "timestamp":
                            continue
                        gfs_col = "gfs_" + c[4:] if c.startswith("ifs_") else c
                        row[gfs_col] = match[c].iloc[0]
                    # Disagreement feature: GFS precip minus ERA5 precip.
                    era5_at = hourly_df[
                        pd.to_datetime(hourly_df["timestamp"], utc=True).dt.tz_localize(None) == last_ts
                    ]["precipitation_mm"]
                    if len(era5_at) > 0 and "gfs_precip" in row.columns:
                        row["gfs_precip_minus_era5"] = row["gfs_precip"].iloc[0] - era5_at.iloc[0]
                except Exception as exc:  # noqa: BLE001 — GFS is optional; never break inference
                    import logging as _logging
                    _logging.getLogger("rainwatch.model").warning(
                        "GFS features unavailable at inference (%s); using NaN", exc
                    )
            if build_ifs_features is None:
                for c in self.features:
                    if c.startswith("gfs_") and c not in row.columns:
                        row[c] = np.nan
            else:
                for c in self.features:
                    if c.startswith("gfs_") and c not in row.columns:
                        row[c] = np.nan
            # v3.3: the extra moisture-profile GFS features (43 of the 55
            # gfs_ features in the frozen schema; the other 12 come from
            # the v3.2 block above). Built from the v3.3 GFS files for the
            # same last timestamp; any failure leaves them NaN.
            if self.is_v33:
                try:
                    sys.path.insert(0, os.path.join(BACKEND, "ml"))
                    from features_v33 import build_v33_features_at
                    last_ts = pd.to_datetime(row["timestamp"].iloc[0])
                    v33_feats = build_v33_features_at(last_ts)
                    for c, val in v33_feats.items():
                        row[c] = val
                except Exception as exc:  # noqa: BLE001 — GFS is optional; never break inference
                    import logging as _logging
                    _logging.getLogger("rainwatch.model").warning(
                        "v3.3 GFS features unavailable at inference (%s); using NaN", exc
                    )
                for c in self.features:
                    if c.startswith("gfs_") and c not in row.columns:
                        row[c] = np.nan
        return row

    def _ensemble_predict(self, members: dict, weights: dict, X) -> float:
        """Weighted ensemble prediction from one member per family."""
        total = 0.0
        for fam, model in members.items():
            w = weights.get(fam, 0.0)
            if w > 0:
                total += w * _model_predict(model, X)
        return total

    def _ensemble_proba(self, members: dict, weights: dict, X) -> float:
        """Weighted ensemble probability (class 1) from one member per family."""
        total = 0.0
        for fam, model in members.items():
            w = weights.get(fam, 0.0)
            if w > 0:
                total += w * _model_proba(model, X)
        return total

    # -- predictions -------------------------------------------------

    def predict(self, hourly_df: pd.DataFrame) -> dict:
        """Expected rainfall accumulation (mm) over the next 1 / 3 / 6 h.

        Regressors use the 41 v3 features (``reg_features``); v3.2
        classifiers use the full 53-feature set.
        """
        row = self._features_at(hourly_df)
        X = row[self.reg_features]
        out = {}
        for h, members in self.regressors.items():
            w = self.weights[f"reg_{h}h"]
            out[f"{h}h"] = round(max(self._ensemble_predict(members, w, X), 0.0), 2)
        return out

    def upper_bound_p90(self, hourly_df: pd.DataFrame) -> dict:
        """90th-percentile upper-bound accumulation (mm) for 3 h and 6 h."""
        row = self._features_at(hourly_df)
        X = row[self.reg_features]
        out = {}
        for h, members in self.quantiles.items():
            w = self.weights[f"p90_{h}h"]
            out[f"{h}h"] = round(max(self._ensemble_predict(members, w, X), 0.0), 2)
        return out

    def heavy_rain_probability(self, hourly_df: pd.DataFrame) -> dict:
        """Calibrated probability (0-1) of reaching each heavy/moderate threshold."""
        row = self._features_at(hourly_df)
        X = row[self.features]
        out = {}
        for key, members in self.classifiers.items():
            suffix = f"y_{key}"
            w = _lookup(self.weights, f"clf_{suffix}")
            raw = self._ensemble_proba(members, w, X)
            platt = _lookup(self.platt, suffix)
            out[key] = round(_sigmoid(platt["w"] * _logit(raw) + platt["b"]), 4)
        return out

    def heavy_risk_tier(self, hourly_df: pd.DataFrame) -> str:
        """Risk tier from the validation-tuned dual thresholds."""
        probs = self.heavy_rain_probability(hourly_df)
        t = self.thresholds
        t10_3 = _lookup(t, "y_3h_ge_10mm")
        t10_6 = _lookup(t, "y_6h_ge_10mm")
        t5_3 = _lookup(t, "y_3h_ge_5mm")
        # "high" (Warning): either heavy-event probability clears its high threshold.
        if (probs["3h_ge_10mm"] >= t10_3["high"]
                or probs["6h_ge_10mm"] >= t10_6["high"]):
            return "high"
        # "elevated" (Watch): any event clears its elevated threshold.
        if (probs["3h_ge_10mm"] >= t10_3["elevated"]
                or probs["6h_ge_10mm"] >= t10_6["elevated"]
                or probs["3h_ge_5mm"] >= t5_3["elevated"]):
            return "elevated"
        if (probs["3h_ge_10mm"] >= 0.5 * t10_3["elevated"]
                or probs["3h_ge_5mm"] >= 0.5 * t5_3["elevated"]):
            return "moderate"
        return "low"

    def predict_with_provenance(self, hourly_df: pd.DataFrame) -> dict:
        """Full v3 prediction with provenance metadata."""
        row = self._features_at(hourly_df)
        expected = self.predict(hourly_df)
        p90 = self.upper_bound_p90(hourly_df)
        probs = self.heavy_rain_probability(hourly_df)
        tier = self.heavy_risk_tier(hourly_df)
        gfs_suffix = ""
        if self.use_gfs:
            gfs_suffix = (" + GFS forecast + moisture-profile features"
                          if self.is_v33 else " + GFS forecast features")
        if self.is_v33:
            note = ("expected_mm is the ensemble mean-regressor forecast. "
                    "upper_bound_p90_mm is the 90th-percentile envelope. "
                    "heavy_rain_probability is the ensemble probability, "
                    "Platt-calibrated on 2024 validation. "
                    "Thresholds are the 2024+2025-optimised operating "
                    "thresholds (thresholds_optimized.json); on that pooled "
                    "evidence the 3 h heavy-event Watch has Precision 0.12 "
                    "at Recall 0.39 and the Warning has Precision 0.20 at "
                    "Recall 0.22 — treat 'high' tiers as an early-warning "
                    "signal, not a confirmed forecast. "
                    "CAPE is not used (all nulls from Open-Meteo for this region).")
        else:
            note = ("expected_mm is the ensemble mean-regressor forecast. "
                    "upper_bound_p90_mm is the 90th-percentile envelope. "
                    "heavy_rain_probability is the ensemble probability, "
                    "Platt-calibrated on 2024 validation. "
                    "The 3 h heavy-event detector has test Precision 0.15 at "
                    "Recall 0.30 (elevated) — treat 'high' tiers as an "
                    "early-warning signal, not a confirmed forecast. "
                    "CAPE is not used (all nulls from Open-Meteo for this region).")
        return {
            "source": "model",
            "model": "xgboost+lightgbm+histgradientboosting",
            "model_version": self.model_version,
            "data_source": "Open-Meteo ERA5 archive, Bhubaneswar grid cell "
                           "(lat 20.281195, lng 85.843376) + Puri Coast + Offshore Bay"
                           + gfs_suffix,
            "scope": "Bhubaneswar grid cell only (lat 20.281195, lng 85.843376); "
                     "not state-wide",
            "issued_for": "next 6 h from the last available observation",
            "model_input_as_of": pd.Timestamp(row["timestamp"].iloc[0]).isoformat(),
            "expected_mm": expected,
            # Backwards-compatible alias (v1 key name).
            "predictions_mm": expected,
            "upper_bound_p90_mm": p90,
            "heavy_rain_probability": probs,
            "heavy_risk_tier": tier,
            "decision_thresholds": self.thresholds,
            "thresholds_source": self.thresholds_source,
            "horizons_h": list(feat.HORIZONS),
            "note": note,
        }


if __name__ == "__main__":
    # Smoke test: predict from the tail of the real archive.
    hourly = feat.load_hourly(os.path.join(BACKEND, "data", "processed", "bhubaneswar_weather.csv"))
    fc = RainfallForecaster()
    result = fc.predict_with_provenance(hourly)
    print(json.dumps(result, indent=2))
