"""Train rainfall-v3.1 — precision-focused classifier upgrade over v3.

Primary objective: increase heavy-rain classification precision without
destroying recall, for the 3h >= 10mm event (and the other two events).

What v3.1 does differently from v3
------------------------------------
1. **Chronological cross-validation tuning.** Each classifier family
   (XGBoost, LightGBM, HistGradientBoosting) is tuned independently with
   an expanding-window CV inside 2021-2024 (folds: train 2021/val 2022,
   train 2021-22/val 2023, train 2021-23/val 2024), maximising mean CV
   PR-AUC. v3 used fixed hyperparameters for the ensemble members.
2. **Feature-set comparison.** The v3 pruned 41 features vs all 62
   features, plus model-family-specific feature selection (permutation
   importance per family on validation), compared on CV PR-AUC.
3. **Feature-group ablations.** Spatial and thermodynamic input groups
   are removed one at a time and the CV PR-AUC change is measured.
4. **Class-imbalance strategies compared.** Class weights (scale_pos_weight
   / class_weight at 0.5x, 1x, 2x the balanced ratio), positive sample
   weighting, and negative downsampling (50% / 25% of negatives kept in
   training, with recalibration afterwards). No SMOTE — it is not valid
   for time-series data — and no resampling is ever applied outside the
   training folds.
5. **Threshold policy.** Thresholds are optimised on the 2024 validation
   set to maximise precision subject to recall floors:
   3h >= 10mm: Watch recall >= 0.25, Warning recall >= 0.20.
   6h >= 10mm: Watch recall >= 0.50, Warning recall >= 0.25.
   3h >= 5mm:  Watch recall >= 0.50, Warning recall >= 0.30.
6. **Event-level metrics.** Overlapping forecast windows are evaluated
   at the event level (consecutive positive hours grouped into events):
   event-level precision/recall, plus alerts per 100 forecast hours,
   false positives, true positives and missed events.

Protocol (same as v3, so the comparison is honest)
---------------------------------------------------
- Chronological split: train 2021-2023 / validation 2024 / test 2025.
  2025 is never touched until the final evaluation.
- All tuning, feature selection, ablations and threshold optimisation
  use only train + validation. The final model is refit on train+val
  and evaluated ONCE on the untouched 2025 test set.
- Regressors (mean + P90) are carried over from v3 unchanged — v3.1 is
  a classifier upgrade. The v3 artifacts in models/rainfall_xgb_v3/
  are never modified; v3.1 saves to models/rainfall_xgb_v3_1/.
- API v1.3.0 compatibility is preserved: the v3.1 artifacts use the
  same file layout and the same predict.py interface (a model_version
  flag selects v3 or v3.1). The API is NOT switched to v3.1 here — that
  is a separate decision for Kam after the results are reviewed.

External-data investigation (done before training, see
docs/V31_EXTERNAL_DATA.md): IMD radar is not publicly available;
NASA GPM IMERG needs a free Earthdata account (Kam would have to
provide credentials); IMDAA ends in 2020 and does not cover the
2021-2025 training period; the Open-Meteo Historical Forecast API
(GFS, 13 km, CAPE populated from Mar 2021) was test-fetched for 2024
— GFS precipitation correlates only 0.11 with ERA5 hourly (0.19 for
3h sums) and CAPE shows only a weak heavy-event signal (mean 710 vs
642 J/kg), so GFS was NOT integrated into v3.1. No weather data or
metrics are fabricated anywhere in this pipeline.

Usage:  python ml/train_rainfall_v31.py [--fast] [--skip-tuning]
  --fast: smaller hyperparameter grids (quicker run).
  --skip-tuning: reuse the tuning results in models/rainfall_xgb_v3_1/tuning.json
    (useful to re-run only the final training).
"""

import argparse
import itertools
import json
import os
import sys
import time

import joblib
import lightgbm as lgbm
import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)

HERE = os.path.dirname(os.path.abspath(__file__))
BACKEND = os.path.dirname(HERE)
sys.path.insert(0, HERE)

import features as feat  # noqa: E402

FEATURES_CSV = os.path.join(BACKEND, "data", "model_ready", "bhubaneswar_features.csv")
OUT_DIR = os.path.join(BACKEND, "models", "rainfall_xgb_v3_1")
V3_DIR = os.path.join(BACKEND, "models", "rainfall_xgb_v3")
SEED = 42

BINARY = {
    "y_3h_ge_10mm": ("y_3h", 10.0),
    "y_6h_ge_10mm": ("y_6h", 10.0),
    "y_3h_ge_5mm": ("y_3h", 5.0),
}
# Recall floors for threshold optimisation (validation set).
RECALL_FLOORS = {
    "y_3h_ge_10mm": {"elevated": 0.25, "high": 0.20},
    "y_6h_ge_10mm": {"elevated": 0.50, "high": 0.25},
    "y_3h_ge_5mm": {"elevated": 0.50, "high": 0.30},
}
FAMILIES = ("xgb", "lgbm", "hgb")

# Feature groups for ablation (names from features.py).
SPATIAL_FEATURES = [
    "coast_precip", "coast_precip_3h_sum", "bay_precip", "bay_precip_3h_sum",
    "spatial_rain_lead", "bay_pressure_grad", "coast_pressure_grad",
    "bay_humidity_excess", "coast_humidity_excess",
]
THERMO_FEATURES = [
    "dew_point_2m_c", "surface_pressure_hpa", "theta_e_proxy",
    "dewpoint_depression", "moisture_flux_proxy", "onshore_flux",
    "moisture_convergence_proxy", "pressure_drop_1h", "pressure_drop_3h",
    "pressure_accel",
]
CONVECTIVE_FEATURES = [
    "wind_gusts_kmh", "cloud_cover_low_pct", "cloud_cover_mid_pct",
    "cloud_cover_high_pct", "vapour_pressure_deficit_hpa", "gust_factor",
    "deep_convection",
]
# Everything else (lags, rolling sums, current meteorology, time) is the base group.
GROUPS = {
    "spatial": SPATIAL_FEATURES,
    "thermodynamic": THERMO_FEATURES,
    "convective": CONVECTIVE_FEATURES,
}


# --------------------------------------------------------------------------
# Chronological expanding-window CV folds (train/val only, never test)
# --------------------------------------------------------------------------

def cv_folds(feats: pd.DataFrame):
    """Expanding-window folds inside 2021-2024.

    Returns a list of (train_mask, val_mask) boolean arrays.
    Fold 1: train 2021, val 2022. Fold 2: train 2021-22, val 2023.
    Fold 3: train 2021-23, val 2024.
    """
    years = feats["timestamp"].dt.year.to_numpy()
    folds = []
    for train_end, val_year in ((2021, 2022), (2022, 2023), (2023, 2024)):
        tr = years <= train_end
        va = years == val_year
        folds.append((tr, va))
    return folds


# --------------------------------------------------------------------------
# Classifier factories
# --------------------------------------------------------------------------

def make_classifier(family: str, params: dict, pos_weight: float = 1.0,
                    sample_weight_mode: str = "none"):
    """Build a classifier. pos_weight is applied via scale_pos_weight /
    class_weight. sample_weight_mode is handled by the caller (it needs
    the sample weights at fit time, not construction time)."""
    if family == "xgb":
        p = dict(params)
        p["scale_pos_weight"] = pos_weight
        return xgb.XGBClassifier(**p)
    if family == "lgbm":
        p = dict(params)
        p["scale_pos_weight"] = pos_weight
        return lgbm.LGBMClassifier(**p)
    p = dict(params)
    if pos_weight != 1.0:
        # HistGB has no scale_pos_weight; use class_weight dict.
        p["class_weight"] = {0: 1.0, 1: pos_weight}
    return HistGradientBoostingClassifier(**p)


def _fit_with_strategy(model, X, y, strategy: str, pos_weight: float,
                       rng: np.random.RandomState):
    """Fit a classifier under one imbalance strategy.

    Strategies:
      'balanced'    — class weight = neg/pos (pos_weight passed in).
      'half' / 'double' — class weight = 0.5x / 2x the balanced ratio.
      'sample_weight' — sample weights: positives x2, class weight 1.
      'neg_sample_50' / 'neg_sample_25' — keep 50% / 25% of negatives
          (random subsample, training rows only), class weight 1.
          Probabilities are recalibrated afterwards (Platt on validation),
          so the shifted base rate is corrected.
    Returns (fitted_model, train_row_mask).
    """
    n = len(y)
    mask = np.ones(n, dtype=bool)
    sample_weight = None
    if strategy in ("balanced", "half", "double"):
        # Class weight is already in the model; fit on all rows.
        model.fit(X, y)
        return model, mask
    if strategy == "sample_weight":
        sample_weight = np.where(y == 1, 2.0, 1.0)
        model.fit(X, y, sample_weight=sample_weight)
        return model, mask
    if strategy in ("neg_sample_50", "neg_sample_25"):
        frac = 0.5 if strategy == "neg_sample_50" else 0.25
        neg_idx = np.where(y == 0)[0]
        keep_neg = rng.choice(neg_idx, size=int(len(neg_idx) * frac), replace=False)
        pos_idx = np.where(y == 1)[0]
        keep = np.sort(np.concatenate([keep_neg, pos_idx]))
        model.fit(X[keep], y[keep])
        mask = np.zeros(n, dtype=bool)
        mask[keep] = True
        return model, mask
    raise ValueError(strategy)


# --------------------------------------------------------------------------
# Hyperparameter grids (modest, tuned for PR-AUC)
# --------------------------------------------------------------------------

def clf_grids(fast: bool):
    """Per-family hyperparameter grids for the classifiers."""
    xgb_grid = [
        {"max_depth": 3, "learning_rate": 0.1, "n_estimators": 200,
         "subsample": 0.8, "colsample_bytree": 0.9, "min_child_weight": 1,
         "reg_lambda": 10.0},
        {"max_depth": 4, "learning_rate": 0.05, "n_estimators": 300,
         "subsample": 0.8, "colsample_bytree": 0.8, "min_child_weight": 3,
         "reg_lambda": 10.0},
        {"max_depth": 2, "learning_rate": 0.1, "n_estimators": 300,
         "subsample": 0.9, "colsample_bytree": 0.9, "min_child_weight": 5,
         "reg_lambda": 20.0},
        {"max_depth": 3, "learning_rate": 0.03, "n_estimators": 500,
         "subsample": 0.8, "colsample_bytree": 0.9, "min_child_weight": 1,
         "reg_lambda": 5.0},
        {"max_depth": 5, "learning_rate": 0.05, "n_estimators": 200,
         "subsample": 0.7, "colsample_bytree": 0.7, "min_child_weight": 5,
         "reg_lambda": 10.0},
        {"max_depth": 3, "learning_rate": 0.1, "n_estimators": 150,
         "subsample": 0.8, "colsample_bytree": 1.0, "min_child_weight": 1,
         "reg_lambda": 30.0},
    ]
    lgbm_grid = [
        {"max_depth": 3, "learning_rate": 0.1, "n_estimators": 200,
         "subsample": 0.8, "colsample_bytree": 0.9, "min_child_samples": 20,
         "reg_lambda": 10.0},
        {"max_depth": 4, "learning_rate": 0.05, "n_estimators": 300,
         "subsample": 0.8, "colsample_bytree": 0.8, "min_child_samples": 30,
         "reg_lambda": 10.0},
        {"max_depth": 2, "learning_rate": 0.1, "n_estimators": 300,
         "subsample": 0.9, "colsample_bytree": 0.9, "min_child_samples": 40,
         "reg_lambda": 20.0},
        {"max_depth": 3, "learning_rate": 0.03, "n_estimators": 500,
         "subsample": 0.8, "colsample_bytree": 0.9, "min_child_samples": 20,
         "reg_lambda": 5.0},
        {"max_depth": -1, "learning_rate": 0.05, "n_estimators": 200,
         "num_leaves": 15, "subsample": 0.8, "colsample_bytree": 0.8,
         "min_child_samples": 30, "reg_lambda": 10.0},
        {"max_depth": 3, "learning_rate": 0.1, "n_estimators": 150,
         "subsample": 0.8, "colsample_bytree": 1.0, "min_child_samples": 20,
         "reg_lambda": 30.0},
    ]
    hgb_grid = [
        {"max_depth": 3, "learning_rate": 0.1, "max_iter": 200,
         "min_samples_leaf": 20, "l2_regularization": 10.0},
        {"max_depth": 4, "learning_rate": 0.05, "max_iter": 300,
         "min_samples_leaf": 30, "l2_regularization": 10.0},
        {"max_depth": 2, "learning_rate": 0.1, "max_iter": 300,
         "min_samples_leaf": 40, "l2_regularization": 20.0},
        {"max_depth": 3, "learning_rate": 0.03, "max_iter": 500,
         "min_samples_leaf": 20, "l2_regularization": 5.0},
        {"max_depth": None, "learning_rate": 0.05, "max_iter": 200,
         "min_samples_leaf": 30, "l2_regularization": 10.0},
        {"max_depth": 3, "learning_rate": 0.1, "max_iter": 150,
         "min_samples_leaf": 20, "l2_regularization": 30.0},
    ]
    if fast:
        xgb_grid, lgbm_grid, hgb_grid = xgb_grid[:3], lgbm_grid[:3], hgb_grid[:3]
    base = {
        "xgb": {"objective": "binary:logistic", "random_state": SEED,
                "n_jobs": 4, "tree_method": "hist", "eval_metric": "logloss"},
        "lgbm": {"objective": "binary", "random_state": SEED,
                 "n_jobs": 4, "verbose": -1},
        "hgb": {"random_state": SEED},
    }
    grids = {}
    for fam, grid in (("xgb", xgb_grid), ("lgbm", lgbm_grid), ("hgb", hgb_grid)):
        grids[fam] = [{**base[fam], **g} for g in grid]
    return grids


# --------------------------------------------------------------------------
# Helpers: Platt, thresholds, event-level metrics
# --------------------------------------------------------------------------

def _logit(p):
    p = np.clip(p, 1e-6, 1 - 1e-6)
    return np.log(p / (1 - p))


def _sigmoid(z):
    return 1.0 / (1.0 + np.exp(-z))


def platt_fit(raw, y):
    lr = LogisticRegression(C=1.0, solver="lbfgs", random_state=SEED)
    lr.fit(_logit(raw).reshape(-1, 1), y)
    return float(lr.coef_[0][0]), float(lr.intercept_[0])


def platt_apply(raw, w, b):
    return np.clip(_sigmoid(w * _logit(raw) + b), 0.0, 1.0)


def threshold_max_precision(y, probs, min_recall):
    """Highest threshold whose recall >= min_recall, maximising precision.

    Scans thresholds; among those meeting the recall floor, picks the one
    with the highest precision (ties -> higher threshold). Returns
    (threshold, precision, recall, f1) or (None, ...) if no threshold
    meets the floor.
    """
    best = None
    for t in np.arange(0.01, 0.99, 0.01):
        pred = (probs >= t).astype(int)
        r = recall_score(y, pred, zero_division=0)
        if r < min_recall:
            continue
        p = precision_score(y, pred, zero_division=0)
        f = f1_score(y, pred, zero_division=0)
        if best is None or p > best[1] or (p == best[1] and t > best[0]):
            best = (float(t), float(p), float(r), float(f))
    return best


def event_metrics(y, probs, threshold):
    """Event-level metrics for overlapping forecast windows.

    A true event is a maximal run of consecutive hours with y == 1.
    A predicted event is a maximal run of consecutive hours with
    probs >= threshold. Event-level recall = fraction of true events
    overlapping at least one predicted event; event-level precision =
    fraction of predicted events overlapping at least one true event.
    Also returns the counts: n_true_events, n_pred_events, TP events,
    missed events, FP events, and alerts per 100 forecast hours.
    """
    pred = (probs >= threshold).astype(int)

    def _runs(arr):
        runs = []
        start = None
        for i, v in enumerate(arr):
            if v == 1 and start is None:
                start = i
            elif v == 0 and start is not None:
                runs.append((start, i - 1))
                start = None
        if start is not None:
            runs.append((start, len(arr) - 1))
        return runs

    true_runs = _runs(y)
    pred_runs = _runs(pred)

    def _overlaps(a, b):
        return a[0] <= b[1] and b[0] <= a[1]

    tp_events = sum(1 for tr in true_runs if any(_overlaps(tr, pr) for pr in pred_runs))
    fp_events = sum(1 for pr in pred_runs if not any(_overlaps(pr, tr) for tr in true_runs))
    missed = len(true_runs) - tp_events
    ev_recall = tp_events / len(true_runs) if true_runs else 0.0
    ev_precision = (len(pred_runs) - fp_events) / len(pred_runs) if pred_runs else 0.0
    alerts_per_100h = 100.0 * len(pred_runs) / len(y) if len(y) else 0.0
    return {
        "n_true_events": len(true_runs),
        "n_pred_events": len(pred_runs),
        "tp_events": tp_events,
        "missed_events": missed,
        "fp_events": fp_events,
        "event_recall": float(ev_recall),
        "event_precision": float(ev_precision),
        "alerts_per_100h": float(alerts_per_100h),
    }


def hour_metrics(y, probs, threshold):
    """Hour-level metrics at one threshold."""
    pred = (probs >= threshold).astype(int)
    tp = int(((pred == 1) & (y == 1)).sum())
    fp = int(((pred == 1) & (y == 0)).sum())
    fn = int(((pred == 0) & (y == 1)).sum())
    tn = int(((pred == 0) & (y == 0)).sum())
    return {
        "threshold": float(threshold),
        "precision": float(precision_score(y, pred, zero_division=0)),
        "recall": float(recall_score(y, pred, zero_division=0)),
        "f1": float(f1_score(y, pred, zero_division=0)),
        "tp": tp, "fp": fp, "fn": fn, "tn": tn,
        "n_actual": int(y.sum()),
        "n_pred": int(pred.sum()),
        "alerts_per_100h": float(100.0 * pred.sum() / len(y)),
    }


def threshold_curve(y, probs):
    """Precision/recall/F1 at every threshold (0.01 steps) for plotting."""
    rows = []
    for t in np.arange(0.01, 0.99, 0.01):
        pred = (probs >= t).astype(int)
        rows.append({
            "threshold": round(float(t), 2),
            "precision": float(precision_score(y, pred, zero_division=0)),
            "recall": float(recall_score(y, pred, zero_division=0)),
            "f1": float(f1_score(y, pred, zero_division=0)),
            "n_pred": int(pred.sum()),
        })
    return rows


# --------------------------------------------------------------------------
# Phase A: chronological CV hyperparameter tuning
# --------------------------------------------------------------------------

def tune_family(family, target, feats, feature_cols, folds, grid, strategy="balanced"):
    """Tune one family on one event via expanding-window CV.

    Returns (best_params, best_cv_pr_auc, all_results).
    """
    y_all = feats[target].to_numpy()
    results = []
    for gi, params in enumerate(grid):
        prs = []
        for tr_mask, va_mask in folds:
            X_tr = feats.loc[tr_mask, feature_cols].to_numpy()
            y_tr = y_all[tr_mask]
            X_va = feats.loc[va_mask, feature_cols].to_numpy()
            y_va = y_all[va_mask]
            pos = max(1, int(y_tr.sum()))
            neg = max(1, int((1 - y_tr).sum()))
            pw = neg / pos if strategy == "balanced" else 1.0
            model = make_classifier(family, params, pos_weight=pw)
            rng = np.random.RandomState(SEED)
            model, _ = _fit_with_strategy(model, X_tr, y_tr, strategy, pw, rng)
            probs = model.predict_proba(X_va)[:, 1]
            prs.append(average_precision_score(y_va, probs))
        mean_pr = float(np.mean(prs))
        results.append({"grid_idx": gi, "params": {k: v for k, v in params.items()
                                                   if k not in ("random_state", "n_jobs",
                                                                "tree_method", "eval_metric",
                                                                "objective", "verbose")},
                        "cv_pr_auc": mean_pr, "fold_pr_aucs": [float(x) for x in prs]})
    results.sort(key=lambda r: -r["cv_pr_auc"])
    return results[0], results


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fast", action="store_true", help="Smaller hyperparameter grids.")
    ap.add_argument("--skip-tuning", action="store_true",
                    help="Reuse tuning.json and skip Phase A-D.")
    args = ap.parse_args()

    t0 = time.time()
    os.makedirs(OUT_DIR, exist_ok=True)
    rng = np.random.RandomState(SEED)

    m = pd.read_csv(FEATURES_CSV, parse_dates=["timestamp"])
    all_feature_cols = feat.feature_columns_for(m)
    print(f"loaded {len(m)} rows; {len(all_feature_cols)} features")
    train, val, test = feat.chronological_split(m)
    print(f"train {len(train)} | val {len(val)} | test {len(test)} (test untouched)")
    folds = cv_folds(pd.concat([train, val]))
    print(f"CV folds: {[(int(f[0].sum()), int(f[1].sum())) for f in folds]}")

    # v3 pruned feature list (for the 41 vs 62 comparison).
    with open(os.path.join(V3_DIR, "feature_schema.json")) as f:
        v3_schema = json.load(f)
    v3_features = v3_schema["features"]
    print(f"v3 kept features: {len(v3_features)} | all features: {len(all_feature_cols)}")

    tuning_path = os.path.join(OUT_DIR, "tuning.json")
    tuning = {}

    if not args.skip_tuning:
        # --------------------------------------------------------------
        # Phase A: per-family CV tuning (primary event 3h>=10mm first).
        # --------------------------------------------------------------
        print("\n=== Phase A: chronological CV tuning (3h >= 10mm) ===")
        grids = clf_grids(args.fast)
        tuning["phase_a"] = {}
        best_params = {}
        for family in FAMILIES:
            best, all_res = tune_family(family, "y_3h_ge_10mm",
                                        pd.concat([train, val]), v3_features,
                                        folds, grids[family])
            tuning["phase_a"][family] = {
                "best_cv_pr_auc": best["cv_pr_auc"],
                "best_params": best["params"],
                "all": all_res,
            }
            best_params[family] = best["params"]
            print(f"  {family}: best CV PR-AUC {best['cv_pr_auc']:.4f} "
                  f"(params: {best['params']})")
        tuning["best_params_3h10"] = best_params

        # Tune the other two events with the same grids (reuse Phase A code).
        for target in ("y_6h_ge_10mm", "y_3h_ge_5mm"):
            print(f"\n=== Phase A: chronological CV tuning ({target}) ===")
            tuning["phase_a"][target] = {}
            for family in FAMILIES:
                best, all_res = tune_family(family, target,
                                            pd.concat([train, val]), v3_features,
                                            folds, grids[family])
                tuning["phase_a"][target][family] = {
                    "best_cv_pr_auc": best["cv_pr_auc"],
                    "best_params": best["params"],
                }
                print(f"  {family}: best CV PR-AUC {best['cv_pr_auc']:.4f}")

        # --------------------------------------------------------------
        # Phase B: feature-set comparison (41 vs 62) on CV PR-AUC.
        # --------------------------------------------------------------
        print("\n=== Phase B: feature-set comparison (CV PR-AUC, 3h >= 10mm) ===")
        tuning["phase_b"] = {}
        tv = pd.concat([train, val])
        for family in FAMILIES:
            for label, cols in (("v3_41", v3_features), ("all_62", all_feature_cols)):
                prs = []
                for tr_mask, va_mask in folds:
                    X_tr = tv.loc[tr_mask, cols].to_numpy()
                    y_tr = tv.loc[tr_mask, "y_3h_ge_10mm"].to_numpy()
                    X_va = tv.loc[va_mask, cols].to_numpy()
                    y_va = tv.loc[va_mask, "y_3h_ge_10mm"].to_numpy()
                    pos = max(1, int(y_tr.sum())); neg = max(1, int((1 - y_tr).sum()))
                    model = make_classifier(family, {**grids[family][0],
                        **best_params[family]}, pos_weight=neg / pos)
                    model.fit(X_tr, y_tr)
                    prs.append(average_precision_score(y_va, model.predict_proba(X_va)[:, 1]))
                tuning["phase_b"][f"{family}_{label}"] = float(np.mean(prs))
                print(f"  {family} {label}: CV PR-AUC {np.mean(prs):.4f}")

        # --------------------------------------------------------------
        # Phase C: feature-group ablations (CV PR-AUC, 3h >= 10mm).
        # --------------------------------------------------------------
        print("\n=== Phase C: feature-group ablations (CV PR-AUC, 3h >= 10mm) ===")
        tuning["phase_c"] = {}
        for group, members in GROUPS.items():
            cols = [c for c in v3_features if c not in members]
            per_family = {}
            for family in FAMILIES:
                fprs = []
                for tr_mask, va_mask in folds:
                    X_tr = tv.loc[tr_mask, cols].to_numpy()
                    y_tr = tv.loc[tr_mask, "y_3h_ge_10mm"].to_numpy()
                    X_va = tv.loc[va_mask, cols].to_numpy()
                    y_va = tv.loc[va_mask, "y_3h_ge_10mm"].to_numpy()
                    pos = max(1, int(y_tr.sum())); neg = max(1, int((1 - y_tr).sum()))
                    model = make_classifier(family, {**grids[family][0],
                        **best_params[family]}, pos_weight=neg / pos)
                    model.fit(X_tr, y_tr)
                    fprs.append(average_precision_score(y_va, model.predict_proba(X_va)[:, 1]))
                per_family[family] = float(np.mean(fprs))
            tuning["phase_c"][f"drop_{group}"] = {
                "cv_pr_auc_mean": float(np.mean(list(per_family.values()))),
                "per_family": per_family,
                "n_features_removed": len([c for c in v3_features if c in members]),
            }
            print(f"  drop {group}: CV PR-AUC {np.mean(list(per_family.values())):.4f} "
                  f"(removed {tuning['phase_c'][f'drop_{group}']['n_features_removed']} features) "
                  f"| per-family: " + " ".join(f"{f} {v:.4f}" for f, v in per_family.items()))

        # --------------------------------------------------------------
        # Phase D: imbalance-strategy comparison (CV PR-AUC, 3h >= 10mm).
        # --------------------------------------------------------------
        print("\n=== Phase D: imbalance strategies (CV PR-AUC, 3h >= 10mm) ===")
        tuning["phase_d"] = {}
        strategies = ["balanced", "half", "double", "sample_weight",
                      "neg_sample_50", "neg_sample_25"]
        for strategy in strategies:
            fam_prs = {}
            for family in FAMILIES:
                prs = []
                for tr_mask, va_mask in folds:
                    X_tr = tv.loc[tr_mask, v3_features].to_numpy()
                    y_tr = tv.loc[tr_mask, "y_3h_ge_10mm"].to_numpy()
                    X_va = tv.loc[va_mask, v3_features].to_numpy()
                    y_va = tv.loc[va_mask, "y_3h_ge_10mm"].to_numpy()
                    pos = max(1, int(y_tr.sum())); neg = max(1, int((1 - y_tr).sum()))
                    if strategy == "half":
                        pw = 0.5 * neg / pos
                    elif strategy == "double":
                        pw = 2.0 * neg / pos
                    elif strategy == "balanced":
                        pw = neg / pos
                    else:
                        pw = 1.0
                    model = make_classifier(family, {**grids[family][0],
                        **best_params[family]}, pos_weight=pw)
                    model, _ = _fit_with_strategy(model, X_tr, y_tr, strategy, pw, rng)
                    prs.append(average_precision_score(y_va, model.predict_proba(X_va)[:, 1]))
                fam_prs[family] = float(np.mean(prs))
            tuning["phase_d"][strategy] = fam_prs
            print(f"  {strategy}: " + " | ".join(f"{f} {v:.4f}" for f, v in fam_prs.items())
                  + f" | mean {np.mean(list(fam_prs.values())):.4f}")

        with open(tuning_path, "w") as f:
            json.dump(tuning, f, indent=2, default=str)
        print(f"\ntuning results saved to {tuning_path}")
    else:
        with open(tuning_path) as f:
            tuning = json.load(f)
        best_params = tuning["best_params_3h10"]
        print(f"loaded tuning results from {tuning_path}")

    # --------------------------------------------------------------
    # Phase E: final training with the best configuration.
    # --------------------------------------------------------------
    print("\n=== Phase E: final training (best config) ===")
    # Choose the best feature set and strategy from tuning.
    # (Defaults: v3 41 features, 'balanced' strategy, unless tuning says otherwise.)
    b = tuning.get("phase_b", {})
    use_all = False
    if b:
        m41 = np.mean([b.get(f"{fam}_v3_41", 0) for fam in FAMILIES])
        m62 = np.mean([b.get(f"{fam}_all_62", 0) for fam in FAMILIES])
        use_all = m62 > m41
        print(f"  feature set: v3_41 CV PR-AUC {m41:.4f} vs all_62 {m62:.4f} -> "
              f"{'all_62' if use_all else 'v3_41'}")
    feature_cols = all_feature_cols if use_all else v3_features
    d = tuning.get("phase_d", {})
    best_strategy = "balanced"
    if d:
        means = {s: float(np.mean(list(v.values()))) for s, v in d.items()}
        best_strategy = max(means, key=means.get)
        print(f"  imbalance strategy: {best_strategy} "
              f"(mean CV PR-AUC {means[best_strategy]:.4f})")

    grids = clf_grids(args.fast)
    # Per-event best params (fall back to the 3h>=10mm params).
    per_event_params = {}
    for target in BINARY:
        if target == "y_3h_ge_10mm":
            per_event_params[target] = best_params
        else:
            ev = tuning.get("phase_a", {}).get(target, {})
            if ev:
                per_event_params[target] = {fam: ev[fam]["best_params"] for fam in FAMILIES}
            else:
                per_event_params[target] = best_params

    # Train on train, learn ensemble weights + Platt + thresholds on val.
    X_tr = train[feature_cols].to_numpy()
    X_va = val[feature_cols].to_numpy()
    X_te = test[feature_cols].to_numpy()

    ensemble = {}   # target -> {family: model, weights, platt, thresholds}
    for target in BINARY:
        y_tr = train[target].to_numpy()
        y_va = val[target].to_numpy()
        pos = max(1, int(y_tr.sum())); neg = max(1, int((1 - y_tr).sum()))
        print(f"\n--- {target}: train positives {pos}, val positives {int(y_va.sum())} ---")
        # Train each family on train.
        val_probs = {}
        for family in FAMILIES:
            params = {**grids[family][0], **per_event_params[target][family]}
            if best_strategy == "half":
                pw = 0.5 * neg / pos
            elif best_strategy == "double":
                pw = 2.0 * neg / pos
            elif best_strategy == "balanced":
                pw = neg / pos
            else:
                pw = 1.0
            model = make_classifier(family, params, pos_weight=pw)
            model, _ = _fit_with_strategy(model, X_tr, y_tr, best_strategy, pw, rng)
            val_probs[family] = model.predict_proba(X_va)[:, 1]
            ensemble.setdefault(target, {})[family] = model
        # Ensemble weights on validation (PR-AUC).
        P = np.column_stack([val_probs[f] for f in FAMILIES])
        for fam in FAMILIES:
            print(f"  {fam} val PR-AUC (raw): "
                  f"{average_precision_score(y_va, val_probs[fam]):.4f}")
        best_w, best_s = None, None
        for w in itertools.product([0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0],
                                   repeat=3):
            if abs(sum(w) - 1.0) > 1e-9:
                continue
            ens = P @ np.array(w)
            s = average_precision_score(y_va, ens)
            if best_s is None or s > best_s:
                best_w, best_s = w, float(s)
        ensemble[target]["weights"] = {fam: float(best_w[i]) for i, fam in enumerate(FAMILIES)}
        ensemble[target]["val_pr_auc"] = best_s
        ens_va = P @ np.array(best_w)
        # Platt calibration on validation.
        w_platt, b_platt = platt_fit(ens_va, y_va)
        ensemble[target]["platt"] = {"w": w_platt, "b": b_platt}
        cal_va = platt_apply(ens_va, w_platt, b_platt)
        print(f"  ensemble weights: {ensemble[target]['weights']} (val PR-AUC {best_s:.4f})")
        print(f"  Platt: w={w_platt:.3f} b={b_platt:.3f} | val Brier {brier_score_loss(y_va, cal_va):.4f}")
        # Thresholds: maximise precision subject to recall floors.
        thresholds = {}
        for level, floor in RECALL_FLOORS[target].items():
            res = threshold_max_precision(y_va, cal_va, floor)
            if res is None:
                # No threshold meets the floor: fall back to the threshold
                # with the highest recall (report it honestly).
                best_r, best_t = -1.0, 0.5
                for t in np.arange(0.01, 0.99, 0.01):
                    r = recall_score(y_va, (cal_va >= t).astype(int), zero_division=0)
                    if r > best_r:
                        best_r, best_t = r, float(t)
                thresholds[level] = {"threshold": best_t, "precision": float(
                    precision_score(y_va, (cal_va >= best_t).astype(int), zero_division=0)),
                    "recall": float(best_r), "floor_met": False}
                print(f"  {level}: NO threshold meets recall floor {floor} "
                      f"(best recall {best_r:.3f} at t={best_t:.2f})")
            else:
                t, p, r, f1 = res
                thresholds[level] = {"threshold": t, "precision": p, "recall": r,
                                     "f1": f1, "floor_met": True}
                print(f"  {level}: t={t:.2f} P={p:.3f} R={r:.3f} F1={f1:.3f} (floor {floor})")
        ensemble[target]["thresholds"] = thresholds
        ensemble[target]["threshold_curve_val"] = threshold_curve(y_va, cal_va)

    # --------------------------------------------------------------
    # Phase F: refit on train+val, evaluate ONCE on untouched 2025 test.
    # --------------------------------------------------------------
    print("\n=== Phase F: refit on train+val, evaluate on 2025 (once) ===")
    tv = pd.concat([train, val])
    X_tv = tv[feature_cols].to_numpy()
    results = {"model": "rainfall-xgb-v3.1", "feature_set": "all_62" if use_all else "v3_41",
               "n_features": len(feature_cols), "imbalance_strategy": best_strategy,
               "classifiers": {}, "regression": "v3 (unchanged)"}
    for target in BINARY:
        y_tv = tv[target].to_numpy()
        y_te = test[target].to_numpy()
        pos = max(1, int(y_tv.sum())); neg = max(1, int((1 - y_tv).sum()))
        # Refit each family on train+val with the same config.
        test_probs = {}
        refit = {}
        for family in FAMILIES:
            params = {**grids[family][0], **per_event_params[target][family]}
            if best_strategy == "half":
                pw = 0.5 * neg / pos
            elif best_strategy == "double":
                pw = 2.0 * neg / pos
            elif best_strategy == "balanced":
                pw = neg / pos
            else:
                pw = 1.0
            model = make_classifier(family, params, pos_weight=pw)
            model, _ = _fit_with_strategy(model, X_tv, y_tv, best_strategy, pw, rng)
            refit[family] = model
            test_probs[family] = model.predict_proba(X_te)[:, 1]
        w = np.array([ensemble[target]["weights"][fam] for fam in FAMILIES])
        ens_te = np.column_stack([test_probs[f] for f in FAMILIES]) @ w
        pl = ensemble[target]["platt"]
        cal_te = platt_apply(ens_te, pl["w"], pl["b"])
        pr = average_precision_score(y_te, cal_te)
        roc = roc_auc_score(y_te, cal_te)
        brier = float(brier_score_loss(y_te, cal_te))
        res = {"pr_auc": float(pr), "roc_auc": float(roc), "brier": brier,
               "weights": ensemble[target]["weights"],
               "platt": pl, "levels": {}}
        for level in ("elevated", "high"):
            t = ensemble[target]["thresholds"][level]["threshold"]
            hm = hour_metrics(y_te, cal_te, t)
            em = event_metrics(y_te, cal_te, t)
            res["levels"][level] = {**hm, **em}
            print(f"  {target} {level} (t={t:.2f}): P {hm['precision']:.3f} "
                  f"R {hm['recall']:.3f} F1 {hm['f1']:.3f} | TP {hm['tp']} FP {hm['fp']} "
                  f"missed {hm['fn']} | events: evP {em['event_precision']:.3f} "
                  f"evR {em['event_recall']:.3f} ({em['tp_events']}/{em['n_true_events']}) "
                  f"alerts/100h {hm['alerts_per_100h']:.2f}")
        print(f"  {target}: PR-AUC {pr:.4f} ROC-AUC {roc:.4f} Brier {brier:.4f}")
        res["threshold_curve_test"] = threshold_curve(y_te, cal_te)
        results["classifiers"][target] = res
        # Save the refit models.
        for family, model in refit.items():
            kind = f"clf_{target.replace('y_', '')}_{family}"
            if family == "xgb":
                model.save_model(os.path.join(OUT_DIR, f"{kind}_xgb.json"))
            elif family == "lgbm":
                model.booster_.save_model(os.path.join(OUT_DIR, f"{kind}_lgbm.txt"))
            else:
                joblib.dump(model, os.path.join(OUT_DIR, f"{kind}_hgb.pkl"))

    # Save metadata / thresholds / evaluation.
    with open(os.path.join(OUT_DIR, "evaluation.json"), "w") as f:
        json.dump(results, f, indent=2, default=str)
    with open(os.path.join(OUT_DIR, "thresholds.json"), "w") as f:
        json.dump({t: ensemble[t]["thresholds"] for t in BINARY}, f, indent=2)
    with open(os.path.join(OUT_DIR, "ensemble_weights.json"), "w") as f:
        json.dump({t: ensemble[t]["weights"] for t in BINARY}, f, indent=2)
    with open(os.path.join(OUT_DIR, "platt.json"), "w") as f:
        json.dump({t: ensemble[t]["platt"] for t in BINARY}, f, indent=2)
    with open(os.path.join(OUT_DIR, "feature_schema.json"), "w") as f:
        json.dump({"model": "rainfall-xgb-v3.1", "features": feature_cols,
                   "n_features": len(feature_cols),
                   "binary_targets": list(BINARY)}, f, indent=2)
    with open(os.path.join(OUT_DIR, "metadata.json"), "w") as f:
        json.dump({"model": "rainfall-xgb-v3.1", "version": "3.1",
                   "data_source": "Open-Meteo ERA5 archive (Bhubaneswar) + upwind grids",
                   "split": {"train": "2021-2023", "validation": "2024", "test": "2025"},
                   "seed": SEED, "imbalance_strategy": best_strategy,
                   "feature_set": results["feature_set"],
                   "regression": "v3 (unchanged)",
                   "api_compatibility": "v1.3.0 (additive fields only; v3 artifacts untouched)"},
                  f, indent=2)
    print(f"\nartifacts saved to {OUT_DIR}")
    print(f"total time: {(time.time() - t0) / 60:.1f} min")


if __name__ == "__main__":
    main()
