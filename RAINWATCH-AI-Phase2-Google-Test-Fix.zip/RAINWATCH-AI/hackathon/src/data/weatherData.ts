import { classifyRainfall, rainfallColor } from '../utils/colors'
import { clamp, createRng, hashSeed, round } from '../utils/rng'
import { getDemoTick } from '../services/demoState'
import type { WeatherReading } from '../types'
import { getRainfallSeries, hourAlignedNow, offsetIndex, PAST_HOURS } from './rainfallData'

/* ------------------------------------------------------------------
   Sample surface-weather observations (DEMO DATA).
   Derived from the shared rainfall series so the live weather page
   always agrees with the forecast and flood-risk pages.
------------------------------------------------------------------ */

const cache = new Map<string, { tick: number; readings: WeatherReading[] }>()

export function getWeatherHistory(locationId: string, hours: number): WeatherReading[] {
  const tick = getDemoTick()
  const key = `${locationId}:${tick}:${hours}`
  const cached = cache.get(key)
  if (cached && cached.tick === tick) return cached.readings

  const series = getRainfallSeries(locationId)
  const rng = createRng(hashSeed(locationId) ^ Math.imul(tick + 7, 0x85ebca6b) ^ hours)
  const base = hourAlignedNow()
  const from = Math.max(-PAST_HOURS, -hours)

  const readings: WeatherReading[] = []
  for (let h = from; h <= -1; h++) {
    const mm = series.mmHr[offsetIndex(h)] ?? 0
    const ts = new Date(base.getTime() + h * 3600_000)
    const hourOfDay = ts.getHours()

    // Diurnal temperature curve peaking mid-afternoon, suppressed by rain.
    const diurnal = 4.4 * Math.sin(((hourOfDay - 9) / 24) * Math.PI * 2)
    const temperatureC = round(clamp(29.4 + diurnal - mm * 0.075 + (rng() - 0.5) * 1.6, 21, 41), 1)
    const humidityPct = round(
      clamp(64 + mm * 1.15 - diurnal * 2.6 + (rng() - 0.5) * 8, 42, 99),
      0,
    )
    const windSpeedKmph = round(clamp(9 + mm * 0.42 + rng() * 9, 4, 68), 1)
    const windDirectionDeg = round((118 + mm * 1.4 + rng() * 55) % 360, 0)
    const pressureHpa = round(clamp(1009.5 - mm * 0.11 + (rng() - 0.5) * 2.4, 994, 1014), 1)
    const visibilityKm = round(clamp(14.5 - mm * 0.36 + (rng() - 0.5) * 2, 0.7, 16), 1)
    const cloudCoverPct = round(clamp(38 + mm * 1.7 + (rng() - 0.5) * 24, 4, 100), 0)

    readings.push({
      locationId,
      timestamp: ts.toISOString(),
      temperatureC,
      humidityPct,
      windSpeedKmph,
      windDirectionDeg,
      pressureHpa,
      visibilityKm,
      cloudCoverPct,
      rainfallMmHr: mm,
    })
  }

  // Attach the current hour as the latest observation.
  const nowMm = series.mmHr[offsetIndex(0)] ?? 0
  readings.push(buildCurrent(locationId, nowMm, base, rng))

  cache.set(key, { tick, readings })
  return readings
}

function buildCurrent(
  locationId: string,
  mm: number,
  base: Date,
  rng: () => number,
): WeatherReading {
  const hourOfDay = base.getHours()
  const diurnal = 4.4 * Math.sin(((hourOfDay - 9) / 24) * Math.PI * 2)
  return {
    locationId,
    timestamp: base.toISOString(),
    temperatureC: round(clamp(29.4 + diurnal - mm * 0.075 + (rng() - 0.5) * 1.6, 21, 41), 1),
    humidityPct: round(clamp(64 + mm * 1.15 - diurnal * 2.6 + (rng() - 0.5) * 8, 42, 99), 0),
    windSpeedKmph: round(clamp(9 + mm * 0.42 + rng() * 9, 4, 68), 1),
    windDirectionDeg: round((118 + mm * 1.4 + rng() * 55) % 360, 0),
    pressureHpa: round(clamp(1009.5 - mm * 0.11 + (rng() - 0.5) * 2.4, 994, 1014), 1),
    visibilityKm: round(clamp(14.5 - mm * 0.36 + (rng() - 0.5) * 2, 0.7, 16), 1),
    cloudCoverPct: round(clamp(38 + mm * 1.7 + (rng() - 0.5) * 24, 4, 100), 0),
    rainfallMmHr: mm,
  }
}

export function getCurrentWeather(locationId: string): WeatherReading {
  const history = getWeatherHistory(locationId, 6)
  return history[history.length - 1]
}

/** KPI helper: rainfall summed over the trailing `hours`. */
export function getAccumulatedRainfall(locationId: string, hours = 24): number {
  const series = getRainfallSeries(locationId)
  let total = 0
  for (let h = -hours; h <= 0; h++) total += series.mmHr[offsetIndex(h)] ?? 0
  return round(total, 1)
}

export function getCurrentRainfall(locationId: string): number {
  const series = getRainfallSeries(locationId)
  return series.mmHr[offsetIndex(0)] ?? 0
}

/** Change vs the previous hour (mm/hr). */
export function getRainfallDelta(locationId: string): number {
  const series = getRainfallSeries(locationId)
  const now = series.mmHr[offsetIndex(0)] ?? 0
  const prev = series.mmHr[offsetIndex(-1)] ?? 0
  return round(now - prev, 1)
}

export interface PeakForecast {
  rainfallMmHr: number
  timestamp: string
}

export function getMaxForecast(locationId: string): PeakForecast {
  const series = getRainfallSeries(locationId)
  let best = 0
  let bestOffset = 0
  for (let h = 1; h <= 72; h++) {
    const v = series.mmHr[offsetIndex(h)] ?? 0
    if (v > best) {
      best = v
      bestOffset = h
    }
  }
  const base = hourAlignedNow()
  return {
    rainfallMmHr: best,
    timestamp: new Date(base.getTime() + bestOffset * 3600_000).toISOString(),
  }
}

/** Sparkline series for KPI cards (last `n` hours of rainfall). */
export function getRainfallSparkline(locationId: string, n = 12): number[] {
  const series = getRainfallSeries(locationId)
  const out: number[] = []
  for (let h = -n + 1; h <= 0; h++) out.push(series.mmHr[offsetIndex(h)] ?? 0)
  return out
}

export function intensityOf(mm: number): string {
  return classifyRainfall(mm)
}

export function intensityColor(mm: number): string {
  return rainfallColor(mm)
}
