import { Info } from 'lucide-react'
import type { ReactNode } from 'react'

/**
 * Small accessible help tooltip.  Visible on hover and keyboard focus,
 * announced via aria-describedby.
 */
export function InfoTip({ text, label }: { text: string; label?: string }) {
  const id = `tip-${text.replace(/\W+/g, '-').slice(0, 32)}`
  return (
    <span className="group/tip relative inline-flex align-middle">
      <button
        type="button"
        aria-label={label ?? 'More information'}
        aria-describedby={id}
        className="flex h-5 w-5 items-center justify-center rounded-full text-muted transition-colors hover:text-accent focus-visible:text-accent"
      >
        <Info size={13} aria-hidden />
      </button>
      <span
        id={id}
        role="tooltip"
        className="pointer-events-none absolute top-1/2 left-7 z-40 w-56 -translate-y-1/2 rounded-xl border border-line bg-surface px-3 py-2 text-[11px] leading-relaxed text-ink opacity-0 shadow-[3px_3px_0_#050708] transition-all duration-200 group-hover/tip:opacity-100 group-focus-within/tip:opacity-100"
      >
        {text}
      </span>
    </span>
  )
}

export function Tooltip({ children, text }: { children: ReactNode; text: string }) {
  return (
    <span className="group/tt relative inline-flex">
      {children}
      <span className="pointer-events-none absolute bottom-full left-1/2 z-40 mb-2 w-max max-w-56 -translate-x-1/2 rounded-lg border border-line bg-surface px-2.5 py-1.5 text-[11px] text-ink opacity-0 shadow-[3px_3px_0_#050708] transition-opacity duration-200 group-hover/tt:opacity-100">
        {text}
      </span>
    </span>
  )
}
