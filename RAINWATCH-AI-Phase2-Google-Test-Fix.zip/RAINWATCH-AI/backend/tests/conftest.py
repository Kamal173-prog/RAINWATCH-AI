"""pytest fixtures for the RAINWATCH AI backend test suite.

Design notes (see docs/ENGINEERING_AUDIT.md and docs/TESTING.md):

- The app is imported once per test session. ``model_service`` reads
  ``MODEL_VERSION`` at import time and caches the loaded forecaster, the
  model detail, the hourly rates and the status block in module globals.
  Switching versions in-process therefore needs an explicit reset — see
  ``set_model_version``. Each version is loaded at most once per session
  and then reused from ``_LOADED`` (a full forecaster load takes ~10 s).
- Forecast/risk/weather/map caches are keyed by demo tick (and, after
  the version-key fix, by model version). Tests that bump the demo tick
  or switch versions clear them; the historical CSV cache is left alone
  (re-parsing 43,824 rows per test would be slow, and history does not
  depend on the model version).
- The demo tick is process-global and only moves forward via the API.
  Tests that bump it restore the saved value afterwards.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.engine import demo_state  # noqa: E402
from app.engine import maps as maps_engine  # noqa: E402
from app.engine import rainfall as rainfall_engine  # noqa: E402
from app.engine import risk as risk_engine  # noqa: E402
from app.engine import weather as weather_engine  # noqa: E402
from app import model_service as ms  # noqa: E402
from app.core import config as app_config  # noqa: E402
from app.main import app  # noqa: E402
from app.services import google_weather as gw  # noqa: E402

VERSION_V3 = "rainfall-xgb-v3"
VERSION_V32 = "rainfall-xgb-v3.2"
VERSION_V33 = "rainfall-xgb-v3.3"

_LOADED = {}  # model version string -> loaded RainfallForecaster


def reset_model_caches():
    ms._forecaster = None
    ms._forecaster_error = None
    ms._hourly_rates_cache = None
    ms._model_status_cache = None
    ms._model_detail_cache = None


def clear_response_caches():
    rainfall_engine._cache.clear()
    rainfall_engine._forecast_cache.clear()
    risk_engine._cache = None
    weather_engine._cache.clear()
    maps_engine._cache = None


def set_model_version(monkeypatch, version):
    """Switch the served model version in-process (test-only helper).

    Returns the loaded forecaster for ``version``. An unknown version
    falls back to v3, exactly as the production code does. Each version
    is loaded at most once per session.
    """
    monkeypatch.setattr(ms, "MODEL_VERSION_ENV", version)
    reset_model_caches()
    clear_response_caches()
    if version in _LOADED:
        ms._forecaster = _LOADED[version]
    else:
        fc = ms.get_forecaster()
        # Cache under the requested version only when the loaded
        # forecaster really is that version (or the flag is unknown and
        # legitimately resolves to v3). A known version that fell back
        # to v3 must NOT be cached under its own name, or later tests
        # would serve v3 labelled as v3.2/v3.3.
        if fc is not None and (fc.model_version == version
                               or version not in (VERSION_V3, VERSION_V32, VERSION_V33)):
            _LOADED[version] = fc
    return ms.get_forecaster()


@pytest.fixture(autouse=True)
def _restore_default_model():
    """After every test, restore the import-time model state (v3).

    Version fixtures monkeypatch ``MODEL_VERSION_ENV`` and swap the
    cached forecaster; without this teardown the next test would keep
    serving the previous version under the restored v3 env value.
    Teardown of this autouse fixture runs after the monkeypatch
    teardown, so the env value is already back to the default here.
    """
    yield
    reset_model_caches()
    clear_response_caches()
    if VERSION_V3 in _LOADED:
        ms._forecaster = _LOADED[VERSION_V3]


@pytest.fixture(autouse=True)
def _no_google_key_by_default(monkeypatch):
    """Google Weather is unconfigured by default in every test.

    ``app.core.config`` snapshots ``GOOGLE_WEATHER_API_KEY`` at import
    time (``load_dotenv`` from ``backend/.env``), and the service's
    ``_api_key()`` falls back to that snapshot when the env var is
    absent — so deleting the env var alone does NOT unconfigure the
    service when ``.env`` holds a real key. The no-key tests then saw
    a configured key and made real Google calls (or failed the mock
    transport's key assertion). Clear both places, and reset the
    service state, so every test behaves the same whether or not
    ``.env`` contains a key. Tests that need a key use the ``keyed``
    fixture in the Google test files, which sets both places to the
    mock key. ``monkeypatch`` restores everything after each test, so
    production behaviour (env first, config fallback) is untouched.
    """
    monkeypatch.delenv("GOOGLE_WEATHER_API_KEY", raising=False)
    monkeypatch.delenv("GOOGLE_WEATHER_MONTHLY_CAP", raising=False)
    monkeypatch.setattr(app_config, "GOOGLE_WEATHER_API_KEY", "")
    gw.reset_state()
    gw.set_transport(None)
    yield
    gw.reset_state()
    gw.set_transport(None)


@pytest.fixture(scope="session")
def client():
    return TestClient(app)


@pytest.fixture
def tick_guard():
    """Restore the demo tick (and response caches) after the test."""
    saved = demo_state.get_demo_tick()
    yield
    demo_state._tick = saved
    clear_response_caches()


@pytest.fixture
def v3_client(client, monkeypatch):
    """TestClient serving the production default (v3)."""
    set_model_version(monkeypatch, VERSION_V3)
    return client


@pytest.fixture
def v33_client(client, monkeypatch):
    """TestClient serving the frozen v3.3 demo model."""
    set_model_version(monkeypatch, VERSION_V33)
    return client


@pytest.fixture
def v32_client(client, monkeypatch):
    """TestClient serving the v3.2 benchmark model."""
    set_model_version(monkeypatch, VERSION_V32)
    return client
