"""Matched comparison (v3.2 vs v3.3) + calibration, on pooled 2024+2025.

Selection/validation data: the out-of-sample 2024+2025 probabilities
only. 2026 is not used.

1. Matched recall: v3.3's threshold that reproduces v3.2's optimized
   Watch/Warning recall -> compare precision.
2. Matched precision: v3.3's threshold that reproduces v3.2's optimized
   Watch/Warning precision -> compare recall.
3. Optimized operating points: both versions at their own optimized
   thresholds (from thresholds_optimized.json).
4. Calibration: Brier score, ECE and 10-bin reliability tables for
   v3 / v3.2 / v3.3 per target (calibrated probabilities).
5. Paired storm-event bootstrap (1,000 resamples) of the storm
   detection-rate difference, v3.3 - v3.2 and v3.3 - v3, at the old and
   new Watch thresholds.

Outputs:
  threshold_work/matched_comparison.json
  threshold_work/calibration.json
"""

import json
import logging
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v33_common import event_metrics, hour_metrics  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger("matched_comparison")

BACKEND = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORK = os.path.join(BACKEND, "models", "rainfall_xgb_v3_3", "threshold_work")
TARGETS = ["y_3h_ge_10mm", "y_6h_ge_10mm", "y_3h_ge_5mm"]
VERSIONS = ("v3", "v3.2", "v3.3")
MODEL_DIRS = {
    "v3": os.path.join(BACKEND, "models", "rainfall_xgb_v3"),
    "v3.2": os.path.join(BACKEND, "models", "rainfall_xgb_v3_2"),
    "v3.3": os.path.join(BACKEND, "models", "rainfall_xgb_v3_3", "frozen"),
}
RNG = np.random.default_rng(42)


def _load(version: str, target: str) -> pd.DataFrame:
    return pd.read_csv(os.path.join(WORK, f"probs_{version}_{target}.csv"),
                       parse_dates=["timestamp"])


def _metrics(y: np.ndarray, p: np.ndarray, t: float) -> dict:
    hm = hour_metrics(y, p, t)
    em = event_metrics(y, p, t, n_days=len(y) / 24.0)
    return {**hm, **em,
            "missed_storms": int(em["n_true_storms"] - em["detected_storms"])}


def _curve(y: np.ndarray, p: np.ndarray) -> pd.DataFrame:
    rows = []
    for t in np.arange(0.01, 0.601, 0.005):
        rows.append({"threshold": round(float(t), 3), **_metrics(y, p, round(float(t), 3))})
    return pd.DataFrame(rows)


def _closest(curve: pd.DataFrame, col: str, value: float) -> dict:
    i = (curve[col] - value).abs().idxmin()
    return curve.loc[i].to_dict()


def _old_thresholds(version: str, target: str) -> dict:
    d = json.load(open(os.path.join(MODEL_DIRS[version], "thresholds.json")))[target]
    out = {}
    for level in ("elevated", "high"):
        v = d[level]
        out[level] = float(v["threshold"]) if isinstance(v, dict) else float(v)
    return out


def _brier_ece(y: np.ndarray, p: np.ndarray, n_bins: int = 10) -> dict:
    brier = float(np.mean((p - y) ** 2))
    edges = np.linspace(0, 1, n_bins + 1)
    bins, ece = [], 0.0
    for i in range(n_bins):
        m = (p > edges[i]) & (p <= edges[i + 1]) if i > 0 else (p >= edges[i]) & (p <= edges[i + 1])
        n = int(m.sum())
        if n == 0:
            bins.append({"bin": [float(edges[i]), float(edges[i + 1])], "n": 0,
                         "mean_predicted": None, "observed_rate": None})
            continue
        mp = float(p[m].mean())
        obs = float(y[m].mean())
        ece += abs(mp - obs) * n / len(y)
        bins.append({"bin": [float(edges[i]), float(edges[i + 1])], "n": n,
                     "mean_predicted": mp, "observed_rate": obs})
    return {"brier": brier, "ece": float(ece), "bins": bins}


def _storms(y: np.ndarray) -> list[tuple[int, int]]:
    storms, start = [], None
    for i, v in enumerate(y):
        if v == 1 and start is None:
            start = i
        elif v == 0 and start is not None:
            storms.append((start, i - 1))
            start = None
    if start is not None:
        storms.append((start, len(y) - 1))
    merged: list[list[int]] = []
    for s, e in storms:
        if merged and s - merged[-1][1] - 1 <= 6:
            merged[-1][1] = e
        else:
            merged.append([s, e])
    return [(s, e) for s, e in merged]


def _storm_detected_flags(y: np.ndarray, p: np.ndarray, t: float,
                          storms: list[tuple[int, int]]) -> np.ndarray:
    """Per-storm detection flags, using the SAME definition as
    v33_common.event_metrics: a storm counts as detected when any
    STRICT contiguous predicted event STARTS within [s-2, e+2].
    Predicted events must NOT be gap-merged first: merging moves the
    block start earlier, which undercounts detection and makes the
    rates incomparable with every storm-detection number reported
    before (2025, 2026, variants, freeze).
    """
    pred = (p >= t).astype(int)
    events, start = [], None
    for i, v in enumerate(pred):
        if v == 1 and start is None:
            start = i
        elif v == 0 and start is not None:
            events.append((start, i - 1))
            start = None
    if start is not None:
        events.append((start, len(pred) - 1))
    flags = []
    for s, e in storms:
        flags.append(any(s - 2 <= a <= e + 2 for a, _ in events))
    return np.array(flags, dtype=bool)


def _storm_bootstrap(flags_a: np.ndarray, flags_b: np.ndarray,
                     n_boot: int = 1000) -> dict:
    n = len(flags_a)
    diffs = []
    for _ in range(n_boot):
        idx = RNG.integers(0, n, n)
        diffs.append(float(flags_a[idx].mean() - flags_b[idx].mean()))
    diffs = np.array(diffs)
    return {"mean_diff": float(diffs.mean()),
            "ci95": [float(np.percentile(diffs, 2.5)), float(np.percentile(diffs, 97.5))],
            "p_gt_0": float((diffs > 0).mean()),
            "n_storms": int(n)}


def main() -> None:
    opt = json.load(open(os.path.join(WORK, "thresholds_optimized.json")))
    matched, calib = {}, {}
    for target in TARGETS:
        data = {v: _load(v, target) for v in VERSIONS}
        y = data["v3"]["y"].to_numpy().astype(int)
        p = {v: data[v]["p_cal"].to_numpy(dtype=float) for v in VERSIONS}
        curves = {v: _curve(y, p[v]) for v in VERSIONS}
        storms = _storms(y)

        m = {"optimized_points": {}, "matched_recall": {}, "matched_precision": {}}
        for level, key in (("watch", "watch"), ("warning", "warning")):
            ref = opt["v3.2"][target][key]
            ref_t = ref["threshold"]
            ref_m = ref["metrics"]
            # v3.3 at its own optimized threshold for this level.
            own = opt["v3.3"][target][key]
            m["optimized_points"][level] = {
                "v3.2": {"threshold": ref_t, "metrics": ref_m},
                "v3.3": {"threshold": own["threshold"], "metrics": own["metrics"]},
            }
            # Matched recall: v3.3 threshold reproducing v3.2's recall.
            c33 = _closest(curves["v3.3"], "recall", ref_m["recall"])
            m["matched_recall"][level] = {
                "v3.2_recall": ref_m["recall"], "v3.2_precision": ref_m["precision"],
                "v3.2_threshold": ref_t,
                "v3.3_threshold": c33["threshold"],
                "v3.3_recall": c33["recall"], "v3.3_precision": c33["precision"],
                "delta_precision": float(c33["precision"] - ref_m["precision"]),
                "v3.3_f1": c33["f1"], "v3.3_f2": c33["f2"],
                "v3.3_alerts_per_100h": c33["alerts_per_100h"],
                "v3.3_storm_detection_rate": c33["storm_detection_rate"],
            }
            # Matched precision: v3.3 threshold reproducing v3.2's precision.
            c33p = _closest(curves["v3.3"], "precision", ref_m["precision"])
            m["matched_precision"][level] = {
                "v3.2_precision": ref_m["precision"], "v3.2_recall": ref_m["recall"],
                "v3.2_threshold": ref_t,
                "v3.3_threshold": c33p["threshold"],
                "v3.3_precision": c33p["precision"], "v3.3_recall": c33p["recall"],
                "delta_recall": float(c33p["recall"] - ref_m["recall"]),
                "v3.3_f1": c33p["f1"], "v3.3_f2": c33p["f2"],
                "v3.3_alerts_per_100h": c33p["alerts_per_100h"],
                "v3.3_storm_detection_rate": c33p["storm_detection_rate"],
            }
        matched[target] = m

        # Calibration.
        calib[target] = {v: _brier_ece(y, p[v]) for v in VERSIONS}

        # Paired storm-event bootstrap at old and new Watch thresholds.
        boot = {}
        for label, thr_fn in (
                ("old_watch", lambda v: _old_thresholds(v, target)["elevated"]),
                ("new_watch", lambda v: opt[v][target]["watch"]["threshold"]),
        ):
            f33 = _storm_detected_flags(y, p["v3.3"], thr_fn("v3.3"), storms)
            f32 = _storm_detected_flags(y, p["v3.2"], thr_fn("v3.2"), storms)
            f3 = _storm_detected_flags(y, p["v3"], thr_fn("v3"), storms)
            boot[label] = {
                "v3.3_vs_v3.2": _storm_bootstrap(f33, f32),
                "v3.3_vs_v3": _storm_bootstrap(f33, f3),
                "detection_rates": {"v3": float(f3.mean()), "v3.2": float(f32.mean()),
                                    "v3.3": float(f33.mean())},
            }
        matched[target]["storm_bootstrap"] = boot
        log.info("%s: matched Watch recall %.3f -> v3.3 P %.3f (v3.2 %.3f, dP %+.3f); "
                 "matched precision %.3f -> v3.3 R %.3f (v3.2 %.3f, dR %+.3f); "
                 "Brier v3 %.4f v3.2 %.4f v3.3 %.4f; ECE v3 %.4f v3.2 %.4f v3.3 %.4f",
                 target, ref_m["recall"] if False else
                 opt["v3.2"][target]["watch"]["metrics"]["recall"],
                 m["matched_recall"]["watch"]["v3.3_precision"],
                 m["matched_recall"]["watch"]["v3.2_precision"],
                 m["matched_recall"]["watch"]["delta_precision"],
                 opt["v3.2"][target]["watch"]["metrics"]["precision"],
                 m["matched_precision"]["watch"]["v3.3_recall"],
                 m["matched_precision"]["watch"]["v3.2_recall"],
                 m["matched_precision"]["watch"]["delta_recall"],
                 calib[target]["v3"]["brier"], calib[target]["v3.2"]["brier"],
                 calib[target]["v3.3"]["brier"], calib[target]["v3"]["ece"],
                 calib[target]["v3.2"]["ece"], calib[target]["v3.3"]["ece"])

    json.dump(matched, open(os.path.join(WORK, "matched_comparison.json"), "w"), indent=2)
    json.dump(calib, open(os.path.join(WORK, "calibration.json"), "w"), indent=2)
    log.info("saved matched_comparison.json + calibration.json")


if __name__ == "__main__":
    main()
