# NASA GPM IMERG — Phase 2 API endpoints (2026-11-26)

Status: **implemented and live-verified 2026-11-26** —
`backend/verify_satellite_live.py` passed on Kam's Windows machine
(exit 0): real V07C granule downloaded, extraction VALID_ZERO 0.0 mm/hr
at 2026-11-25T19:30:00Z, grid cell 20.25/85.849998, sanitized cache
filename, second request reused the same granule with an identical
retrieval timestamp. (The check can be re-run any time with Earthdata
credentials in `backend/.env`.)

Phase 1 (`backend/app/services/satellite_rainfall.py`, 28 tests) is the
service. Phase 2 exposes it through three FastAPI endpoints. No
frontend work, no Data Sources wiring, no risk/forecast use.

## Contracts

### GET /api/satellite/status
No parameters. Always 200 — "Not Configured" is a state to report,
not a failure of the endpoint. Service import failure → 502.
```json
{"configured": true, "status": "Ready", "lastRetrievedAt": "2026-11-25T03:30:00Z",
 "recordsRetrieved": 1, "error": null, "cachedGranules": 1,
 "latestGranule": "3B-HHR-E.MS.MRG.3IMERG.20261125-S030000-E032959.0180.V07C.HDF5"}
```
`status` is "Not Configured" | "Ready" | "Error". "Ready" means
credentials are present with no known failure; it does not claim a
granule was ever retrieved.

### GET /api/satellite/rainfall?latitude=&longitude=&observationTime=
`latitude` required, −90..90; `longitude` required, −180..180
(FastAPI `Query(ge/le)` — out of range → 422). `observationTime`
optional ISO 8601; when given, only the granule whose interval
contains it is used — the newest granule is never silently
substituted. Unparseable `observationTime` → 400.
```json
{"source": "NASA GPM IMERG", "product": "IMERG Early Run", "version": "V07C",
 "location": {"latitude": 20.2662, "longitude": 85.8418},
 "gridCell": {"latitude": 20.25, "longitude": 85.85,
              "latIndex": 697, "lonIndex": 2658, "distanceKm": 1.99},
 "precipitationRateMmHr": 2.5, "accumulationMm": 1.25,
 "observationTimeUtc": "2026-11-25T03:00:00Z",
 "observationTimeIst": "2026-11-25T08:30:00+05:30",
 "observationIntervalMinutes": 30, "status": "VALID_RAINFALL",
 "granule": {"filename": "…V07C.HDF5", "nativeId": "…",
             "conceptId": "C2723758340-GES_DISC", "version": "V07C"},
 "retrievedAtUtc": "2026-11-25T03:30:00Z"}
```
`status` is VALID_ZERO | VALID_RAINFALL | MISSING | INVALID.
MISSING/INVALID are 200 with null numerics — the observation
succeeded, the cell simply has no usable value (same reasoning as the
merged forecast's UNAVAILABLE rows). These are observations, never
forecasts; nothing is fabricated.

### GET /api/satellite/rainfall/region?region=
`region` required, a region id only ("bhubaneswar" / "ganjam"). The
bbox-dict form stays service-level. One granule download is shared
across the region's locations; each location gets its own nearest
grid cell and distance, in LOCATIONS order.
```json
{"region": {"id": "bhubaneswar", "name": "Bhubaneswar Metropolitan Region, Odisha",
            "shortName": "Bhubaneswar, Odisha", "bbox": [20.23, 85.77, 20.37, 85.87]},
 "granule": {"filename": "…V07C.HDF5", "version": "V07C", "cached": true, "...": "..."},
 "coverageNote": "Bhubaneswar region returns 12 of 14 locations; Cuttack and Puri lie outside the region bounding box.",
 "locations": ["<one SatelliteRainfallResponse per location>"]}
```

## Error mapping

| Condition | Status |
|---|---|
| Service module cannot be imported | 502 |
| No Earthdata credentials (`SatelliteNotConfigured`) | 503 |
| NASA / search / download / extraction failure (`SatelliteError`) | 502 |
| Unknown region id, bad bbox, unparseable `observationTime` (`ValueError`) | 400 |
| Latitude/longitude out of range (FastAPI `Query` validation) | 422 |
| Success, including MISSING / INVALID cell status | 200 |

## Bhubaneswar bounding-box limitation (exact numbers)

The Bhubaneswar region bbox `[20.23, 85.77, 20.37, 85.87]` excludes
**Cuttack** (20.462, 85.883) and **Puri** (19.8135, 85.831), so
`region=bhubaneswar` returns **12 of 14** locations even though both
places belong to the Bhubaneswar region by `regionId`. Ganjam is
complete at **7/7**. The bbox was NOT changed (it is a shared
location definition — out of scope). The endpoint computes the
`coverageNote` from the data — returned locations vs every location
whose region is the requested id — and states the exclusion plainly:
"Bhubaneswar region returns 12 of 14 locations; Cuttack and Puri lie
outside the region bounding box." Do not claim complete regional
coverage.

## What Phase 2 does NOT do

- No frontend changes. The Forecast, map, and Data Sources pages do
  not call these endpoints.
- No Data Sources wiring: the satellite entry still reads "Awaiting
  Integration". Wiring its status to the live service is a separate
  follow-up.
- No satellite values in any forecast, merged forecast, or risk
  calculation.
- No new dependencies (earthaccess + h5py were added in Phase 1).
- No changes to the v3/v3.3 models, thresholds, datasets, Google
  Weather, or merged forecast.

## Files changed (four only)

- `backend/app/main.py` — three routes + lazy-import helper + coverage-note helper.
- `backend/app/schemas.py` — SatelliteLocation, SatelliteGridCell,
  SatelliteGranuleRef, SatelliteRainfallResponse, SatelliteRegionInfo,
  SatelliteRegionResponse, SatelliteStatusResponse (appended; existing
  models untouched).
- `backend/tests/test_satellite_endpoints.py` — new, 17 endpoint tests.
- `backend/docs/SATELLITE_IMERG_PHASE2.md` — this file.

## Verification

```bash
cd backend
TMPDIR=~/workspace/.tmp-misc .venv/bin/python -m pytest tests/ -q
```
(`TMPDIR` on the workspace disk — `/tmp` is a 512 MB tmpfs and the
satellite fixtures fill it.) New endpoint tests: 17. Full suite:
218 pre-change + 17 new = 235 passed, 0 failed. Google Weather (21)
and merged-forecast (17) tests pass. Frozen v3.3 hashes: 15/15 match.
No live NASA request in any automated test; the service is mocked at
the module level in the endpoint tests. (That is test design only —
live verification of the service itself passed separately on
2026-11-26; see the Status line at the top.)
