"""Service modules for the RAINWATCH AI backend."""
