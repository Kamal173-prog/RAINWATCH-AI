import { AnimatePresence, motion } from 'framer-motion'
import {
  Bell,
  CheckCheck,
  ChevronDown,
  LogOut,
  MapPin,
  Menu,
  Moon,
  RefreshCw,
  Search,
  Settings as SettingsIcon,
  Sun,
} from 'lucide-react'
import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { toast } from 'sonner'
import { useAlerts } from '../../context/AlertsContext'
import { useDemo } from '../../context/DemoContext'
import { useSelectedLocation } from '../../context/LocationContext'
import { useSettings } from '../../context/SettingsContext'
import { LOCATIONS } from '../../data/locationsData'
import { useLiveClock } from '../../hooks/useUi'
import { useAsyncData } from '../../hooks/useAsyncData'
import { demoApi } from '../../services/dataService'
import { DemoBadge, SeverityBadge } from '../common/Badge'
import { BrandLogo } from '../common/BrandLogo'
import { Dropdown } from '../common/Dropdown'
import { Tooltip } from '../common/InfoTip'
import { relativeTime } from '../../utils/colors'

function IconButton({
  label,
  onClick,
  children,
  active = false,
  badge,
}: {
  label: string
  onClick?: () => void
  children: React.ReactNode
  active?: boolean
  badge?: number
}) {
  return (
    <Tooltip text={label}>
      <button
        type="button"
        onClick={onClick}
        aria-label={label}
        className={`relative flex h-9 w-9 items-center justify-center rounded-xl border transition-all duration-200 ${
          active
            ? 'border-accent/45 bg-accent/12 text-accent'
            : 'border-line bg-surface text-muted hover:border-accent/40 hover:text-ink'
        }`}
      >
        {children}
        {badge !== undefined && badge > 0 ? (
          <motion.span
            key={badge}
            initial={{ scale: 0.4, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="absolute -top-1.5 -right-1.5 flex h-4.5 min-w-4.5 items-center justify-center rounded-full border-2 border-sidebar bg-critical px-1 text-[9px] font-bold text-white"
          >
            {badge > 9 ? '9+' : badge}
          </motion.span>
        ) : null}
      </button>
    </Tooltip>
  )
}

function LocationPicker() {
  const { locationId, setLocationId } = useSelectedLocation()
  const [query, setQuery] = useState('')
  const active = LOCATIONS.find((l) => l.id === locationId) ?? LOCATIONS[0]

  const results = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return LOCATIONS
    return LOCATIONS.filter(
      (l) => l.name.toLowerCase().includes(q) || l.zone.toLowerCase().includes(q),
    )
  }, [query])

  return (
    <Dropdown
      label="Select location"
      width="w-[300px]"
      align="left"
      trigger={(open, toggle) => (
        <button
          type="button"
          onClick={toggle}
          aria-expanded={open}
          aria-label={`Selected location: ${active.name}. Change location`}
          className="flex h-9 max-w-[220px] items-center gap-2 rounded-xl border border-line bg-surface px-3 text-xs font-medium text-ink transition-all hover:border-accent/40 sm:max-w-[260px]"
        >
          <MapPin size={14} className="shrink-0 text-accent" aria-hidden />
          <span className="truncate">
            <span className="text-muted">Region:</span> {active.name}
          </span>
          <ChevronDown
            size={13}
            className={`shrink-0 text-muted transition-transform ${open ? 'rotate-180' : ''}`}
            aria-hidden
          />
        </button>
      )}
    >
      {(close) => (
        <div className="max-h-[380px] overflow-hidden">
          <div className="border-b border-line p-2.5">
            <div className="flex items-center gap-2 rounded-lg border border-line bg-surface px-2.5 py-2">
              <Search size={13} className="text-muted" aria-hidden />
              <input
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search locations…"
                aria-label="Search locations"
                className="w-full bg-transparent text-xs text-ink placeholder:text-muted focus:outline-none"
              />
            </div>
          </div>
          <div className="max-h-72 overflow-y-auto p-1.5">
            {results.length === 0 ? (
              <p className="px-3 py-6 text-center text-xs text-muted">No locations match “{query}”.</p>
            ) : (
              results.map((loc) => {
                const isActive = loc.id === locationId
                return (
                  <button
                    key={loc.id}
                    type="button"
                    onClick={() => {
                      setLocationId(loc.id)
                      setQuery('')
                      close()
                    }}
                    className={`flex w-full items-center justify-between gap-2 rounded-lg px-3 py-2 text-left text-xs transition-colors ${
                      isActive ? 'bg-accent/12 text-accent' : 'text-ink hover:bg-surface'
                    }`}
                  >
                    <span className="min-w-0">
                      <span className="block truncate font-medium">{loc.name}</span>
                      <span className="block truncate text-[10px] text-muted">{loc.zone}</span>
                    </span>
                    {isActive ? <CheckCheck size={13} className="shrink-0" aria-hidden /> : null}
                  </button>
                )
              })
            )}
          </div>
        </div>
      )}
    </Dropdown>
  )
}

function NotificationBell() {
  const navigate = useNavigate()
  const { alerts, acknowledgeAll } = useAlerts()
  const { settings } = useSettings()

  // The bell only surfaces severities the user has enabled in Settings.
  const relevant = alerts.filter(
    (a) => a.status !== 'dismissed' && settings.severityPrefs.includes(a.severity),
  )
  const count = relevant.filter((a) => a.status === 'active').length

  const preview = relevant
    .slice()
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    .slice(0, 5)

  return (
    <Dropdown
      label="Notifications"
      width="w-[340px] max-w-[92vw]"
      trigger={(open, toggle) => (
        <button
          type="button"
          onClick={toggle}
          aria-expanded={open}
          aria-label={`Notifications, ${count} active`}
          className={`relative flex h-9 w-9 items-center justify-center rounded-xl border transition-all duration-200 ${
            open
              ? 'border-accent/45 bg-accent/12 text-accent'
              : 'border-line bg-surface text-muted hover:border-accent/40 hover:text-ink'
          }`}
        >
          <motion.span
            animate={
              count > 0 && settings.notificationsEnabled
                ? { rotate: [0, 14, -10, 6, 0] }
                : { rotate: 0 }
            }
            transition={{ repeat: Infinity, repeatDelay: 6, duration: 0.7 }}
          >
            <Bell size={16} aria-hidden />
          </motion.span>
          {count > 0 && settings.notificationsEnabled ? (
            <motion.span
              key={count}
              initial={{ scale: 0.4, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="absolute -top-1.5 -right-1.5 flex h-4.5 min-w-4.5 items-center justify-center rounded-full border-2 border-sidebar bg-critical px-1 text-[9px] font-bold text-white"
            >
              {count > 9 ? '9+' : count}
            </motion.span>
          ) : null}
        </button>
      )}
    >
      {(close) => (
        <div>
          <div className="flex items-center justify-between border-b border-line px-4 py-3">
            <div>
              <p className="text-xs font-semibold text-ink">Notifications</p>
              <p className="text-[10px] text-muted">
                {settings.notificationsEnabled
                  ? `${count} active demo alert${count === 1 ? '' : 's'}`
                  : 'Demo notifications disabled in Settings'}
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                acknowledgeAll()
                toast.success('All alerts acknowledged', { duration: 2200 })
              }}
              className="text-[10px] font-semibold text-accent hover:underline"
            >
              Acknowledge all
            </button>
          </div>
          <div className="max-h-80 overflow-y-auto p-2">
            {!settings.notificationsEnabled ? (
              <p className="px-3 py-8 text-center text-xs text-muted">
                Notifications are turned off. Enable them in Settings → Notifications.
              </p>
            ) : preview.length === 0 ? (
              <p className="px-3 py-8 text-center text-xs text-muted">You're all caught up.</p>
            ) : (
              preview.map((a) => (
                <button
                  key={a.id}
                  type="button"
                  onClick={() => {
                    close()
                    navigate('/alerts')
                  }}
                  className="mb-1 block w-full rounded-xl border border-transparent p-2.5 text-left transition-all hover:border-line hover:bg-surface"
                >
                  <div className="mb-1 flex items-center justify-between gap-2">
                    <SeverityBadge severity={a.severity} />
                    <span className="text-[10px] text-muted">{relativeTime(a.timestamp)}</span>
                  </div>
                  <p className="line-clamp-2 text-xs font-medium text-ink">{a.title}</p>
                  <p className="mt-0.5 truncate text-[10px] text-muted">{a.locationName}</p>
                </button>
              ))
            )}
          </div>
          <div className="border-t border-line p-2">
            <button
              type="button"
              onClick={() => {
                close()
                navigate('/alerts')
              }}
              className="w-full rounded-lg bg-accent/12 py-2 text-xs font-semibold text-accent transition-colors hover:bg-accent/20"
            >
              Open alert center
            </button>
          </div>
        </div>
      )}
    </Dropdown>
  )
}

function ProfileMenu() {
  const navigate = useNavigate()
  const { settings, update } = useSettings()
  const { refresh, refreshing } = useDemo()
  const now = useLiveClock()

  return (
    <Dropdown
      label="Profile menu"
      width="w-60"
      trigger={(open, toggle) => (
        <button
          type="button"
          onClick={toggle}
          aria-expanded={open}
          aria-label="Open profile menu"
          className={`flex h-9 items-center gap-2 rounded-xl border px-2 transition-all ${
            open ? 'border-accent/45 bg-accent/10' : 'border-line bg-surface hover:border-accent/40'
          }`}
        >
          <BrandLogo size={24} />
          <span className="hidden text-xs font-medium text-ink md:block">Demo Analyst</span>
          <ChevronDown size={13} className="text-muted" aria-hidden />
        </button>
      )}
    >
      {(close) => (
        <div className="p-2">
          <div className="mb-2 rounded-xl border border-line bg-surface p-3">
            <p className="text-xs font-semibold text-ink">Demo Analyst</p>
            <p className="text-[10px] text-muted">Emergency Operations Cell · demo@rainwatch.ai</p>
            <p className="num mt-1.5 text-[10px] text-accent">
              {now.toLocaleTimeString('en-IN', { hour12: true })} IST
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              close()
              navigate('/')
            }}
            className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs text-ink transition-colors hover:bg-surface"
          >
            <MapPin size={14} className="text-muted" aria-hidden /> Landing page
          </button>
          <button
            type="button"
            onClick={() => {
              close()
              navigate('/settings')
            }}
            className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs text-ink transition-colors hover:bg-surface"
          >
            <SettingsIcon size={14} className="text-muted" aria-hidden /> Settings
          </button>
          <button
            type="button"
            onClick={async () => {
              close()
              await refresh()
              toast.success('Demo data regenerated', { description: 'All charts and metrics refreshed.' })
            }}
            disabled={refreshing}
            className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs text-ink transition-colors hover:bg-surface disabled:opacity-50"
          >
            <RefreshCw size={14} className={`text-muted ${refreshing ? 'animate-spin' : ''}`} aria-hidden />
            {refreshing ? 'Refreshing…' : 'Refresh demo data'}
          </button>
          <button
            type="button"
            onClick={() => {
              close()
              update({ theme: settings.theme === 'dark' ? 'light' : 'dark' })
              toast.info(`Switched to ${settings.theme === 'dark' ? 'light' : 'dark'} theme`)
            }}
            className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs text-ink transition-colors hover:bg-surface"
          >
            {settings.theme === 'dark' ? (
              <Sun size={14} className="text-muted" aria-hidden />
            ) : (
              <Moon size={14} className="text-muted" aria-hidden />
            )}
            Switch to {settings.theme === 'dark' ? 'light' : 'dark'} theme
          </button>
          <div className="my-1.5 border-t border-line" />
          <button
            type="button"
            onClick={() => {
              close()
              toast.info('Demo mode', {
                description: 'Authentication is disabled in this frontend-only build.',
              })
            }}
            className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs text-muted transition-colors hover:bg-surface hover:text-ink"
          >
            <LogOut size={14} aria-hidden /> Sign out (demo)
          </button>
        </div>
      )}
    </Dropdown>
  )
}

export function Topbar({ onOpenMobileNav }: { onOpenMobileNav: () => void }) {
  const now = useLiveClock()
  const { settings, update } = useSettings()
  const { activeCountValue } = useAlerts()
  const { refresh, refreshing } = useDemo()
  // Backend health, checked once on mount: the clock dot is green only
  // while the backend answers /api/health with the model loaded. Amber
  // means the backend is unreachable and every page is showing demo data.
  const { data: health, loading: healthLoading } = useAsyncData(() => demoApi.fetchHealth(), [])
  const healthTitle = healthLoading
    ? 'Checking backend…'
    : health?.loaded
      ? `Backend live · API ${health.apiVersion} · ${health.modelVersion}`
      : 'Backend unreachable — showing demo data'

  const dateStr = now.toLocaleDateString('en-IN', {
    weekday: 'short',
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  })
  const timeStr = now.toLocaleTimeString('en-IN', { hour12: true })

  return (
    <header className="sticky top-0 z-30 border-b border-line bg-[color-mix(in_srgb,var(--rw-bg)_86%,transparent)]">
      <div className="flex h-16 items-center gap-2 px-3 sm:gap-3 sm:px-5">
        <button
          type="button"
          onClick={onOpenMobileNav}
          aria-label="Open navigation menu"
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-line bg-surface text-muted lg:hidden"
        >
          <Menu size={17} aria-hidden />
        </button>

        <LocationPicker />

        <div className="ms-auto flex items-center gap-2 sm:gap-2.5">
          <div className="hidden items-center gap-3 rounded-xl border border-line bg-surface px-3 py-1.5 xl:flex">
            <div className="text-right">
              <p className="mono text-[11px] leading-none font-semibold text-ink">{timeStr}</p>
              <p className="mt-0.5 text-[10px] leading-none text-muted">{dateStr}</p>
            </div>
            <span
              className={`h-1.5 w-1.5 rounded-full ${healthLoading ? 'bg-muted' : health?.loaded ? 'dot-live bg-success' : 'bg-warning'}`}
              title={healthTitle}
              aria-label={healthTitle}
            />
          </div>

          <span className="hidden 2xl:block">
            <DemoBadge />
          </span>

          <IconButton
            label={refreshing ? 'Refreshing demo data…' : 'Refresh demo data'}
            onClick={async () => {
              await refresh()
              toast.success('Demo data regenerated', {
                description: 'Every metric, chart and map layer has been re-seeded.',
              })
            }}
          >
            <RefreshCw size={15} className={refreshing ? 'animate-spin' : ''} aria-hidden />
          </IconButton>

          <IconButton
            label={settings.theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme'}
            active={settings.theme === 'light'}
            onClick={() => update({ theme: settings.theme === 'dark' ? 'light' : 'dark' })}
          >
            <AnimatePresence mode="wait" initial={false}>
              <motion.span
                key={settings.theme}
                initial={{ rotate: -70, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                exit={{ rotate: 70, opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                {settings.theme === 'dark' ? <Sun size={15} /> : <Moon size={15} />}
              </motion.span>
            </AnimatePresence>
          </IconButton>

          {settings.notificationsEnabled ? <NotificationBell /> : null}

          <ProfileMenu />
        </div>
      </div>

      {/* Compact clock strip for small screens */}
      <div className="flex items-center justify-between border-t border-line/60 px-4 py-1 text-[10px] text-muted xl:hidden">
        <span className="mono">
          {dateStr} · {timeStr}
        </span>
        <span className="flex items-center gap-2">
          <DemoBadge compact />
          <span>{activeCountValue} active alert{activeCountValue === 1 ? '' : 's'}</span>
        </span>
      </div>
    </header>
  )
}
