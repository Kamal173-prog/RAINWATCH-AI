"""Diagnostic: why does the v33 base arm score lower than v3.2 on 2025
for 3h >= 10mm (PR-AUC 0.1687 vs 0.2228) despite better OOF?

Compares the identical base-arm protocol (train 2021-23, weights/Platt
on 2024, refit 2021-24, evaluate once on 2025) across three feature sets:
  v32_53  : the 53 features v3.2 was trained on (should reproduce ~0.2228)
  v33_102 : the full unpruned v33 set (53 + 49 new GFS features)
  v33_94  : the pruned v33 set used by the variants phase (already known)

If v32_53 reproduces v3.2 but v33_102 does not, the new features hurt
2025 (overfit to 2022-2024). If v33_102 is fine but v33_94 is low, the
pruning step (fit on hard 2024) removed features that matter for 2025.
2026 is NOT touched.
"""
import json
import os
import sys

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "ml"))
from train_rainfall_v33 import (  # noqa: E402
    TARGETS,
    _refit_arm,
    _train_arm,
    load_table,
    load_v32_features,
    load_v33_features,
)

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "models",
                   "rainfall_xgb_v3_3")


def main() -> None:
    df = load_table("v33")
    tr = df[df["timestamp"].dt.year.isin([2021, 2022, 2023])].reset_index(drop=True)
    va = df[df["timestamp"].dt.year == 2024].reset_index(drop=True)
    tv = pd.concat([tr, va], ignore_index=True)
    te = df[df["timestamp"].dt.year == 2025].reset_index(drop=True)

    feats53 = load_v32_features()
    feats102 = load_v33_features()
    with open(os.path.join(OUT, "feature_schema.json")) as f:
        feats94 = json.load(f)["features"]
    print(f"feature sets: v32={len(feats53)} v33-unpruned={len(feats102)} "
          f"v33-pruned={len(feats94)}", flush=True)
    missing53 = [c for c in feats53 if c not in df.columns]
    missing102 = [c for c in feats102 if c not in df.columns]
    print(f"missing in v33 table: v32 {missing53} | v33 {missing102}", flush=True)

    results = {}
    for name, feats in [("v32_53", feats53), ("v33_102", feats102)]:
        print(f"=== feature set {name} ({len(feats)} features) ===", flush=True)
        res = {}
        for target in TARGETS:
            _, w, platt, _thr = _train_arm("base", target, tr, va, feats)
            models = _refit_arm("base", target, tv, feats, w, platt)
            X_te = te[feats].to_numpy(dtype=float)
            y_te = te[target].to_numpy().astype(int)
            probs = {f: models[f].predict_proba(X_te)[:, 1]
                     for f in ("xgb", "lgbm", "hgb")}
            ens = sum(w[f] * probs[f] for f in ("xgb", "lgbm", "hgb"))
            pr = average_precision_score(y_te, ens)
            res[target] = round(float(pr), 4)
            print(f"  {target}: 2025 PR-AUC {pr:.4f} | weights {w}",
                  flush=True)
        results[name] = res
    # pruned numbers are already in variants.json; restate for comparison.
    var = json.load(open(os.path.join(OUT, "variants.json")))
    results["v33_94"] = {t: var["arms"]["base"][t]["eval"]["pr_auc"]
                         for t in TARGETS}
    print(json.dumps(results, indent=2))
    with open(os.path.join(OUT, "feature_set_diagnostic.json"), "w") as f:
        json.dump(results, f, indent=2)
    print("saved models/rainfall_xgb_v3_3/feature_set_diagnostic.json")


if __name__ == "__main__":
    main()
