import { motion } from 'framer-motion'
import {
  Archive,
  Cloud,
  Cpu,
  Database,
  GitBranch,
  Mountain,
  Radio,
  Satellite,
  Radar,
  ShieldCheck,
  Workflow,
} from 'lucide-react'
import { useState } from 'react'
import { Badge, DemoBadge } from '../components/common/Badge'
import { BrandLogo } from '../components/common/BrandLogo'
import { Button } from '../components/common/Button'
import { Card, CardHeader } from '../components/common/Card'
import { PageHeader } from '../components/common/PageHeader'
import { SkeletonCard, StatePanel } from '../components/common/Skeleton'
import { useAsyncData } from '../hooks/useAsyncData'
import { demoApi } from '../services/dataService'
import type { DataSourceInfo } from '../types'
import { PIPELINE_NODES } from '../data/dataSourcesData'

const iconMap: Record<DataSourceInfo['icon'], typeof Satellite> = {
  satellite: Satellite,
  radar: Radar,
  station: Radio,
  model: Cpu,
  terrain: Mountain,
  drainage: GitBranch,
  archive: Archive,
  cloud: Cloud,
}

const nodeIcons = [Satellite, Radar, Radio, Cpu, ShieldCheck, Database]

const statusStyle: Record<DataSourceInfo['status'], { color: string; tone: 'accent' | 'success' | 'warning' | 'muted' | 'info' | 'critical' }> = {
  'Live': { color: '#69D2A0', tone: 'success' },
  'Demo Data': { color: '#6FD6C2', tone: 'accent' },
  'Not Connected': { color: '#8B9996', tone: 'muted' },
  'Awaiting Integration': { color: '#F2A93B', tone: 'warning' },
  // Archive is served from a static historical file — deliberately not
  // green "Live", so it is never read as a live external feed.
  'Archive': { color: '#7FB3D5', tone: 'info' },
  // Google Weather failed its last call (key, quota, or API error).
  'Error': { color: '#F05A43', tone: 'critical' },
}

export function DataSources() {
  const { data, loading, error, reload } = useAsyncData(() => demoApi.fetchDataSources(), [])
  const [selectedNode, setSelectedNode] = useState<string | null>(null)
  const sources = data?.sources ?? []
  const pipeline = data?.pipeline ?? PIPELINE_NODES

  // Four-way distinction, computed from the API payload — no invented counts.
  const archiveServed = sources.filter((s) => s.kind === 'Historical dataset' && s.status === 'Archive').length
  const liveObservations = sources.filter((s) => s.kind === 'Real-time observation' && s.status === 'Live').length
  const awaitingCount = sources.filter((s) => s.status === 'Awaiting Integration').length
  // Google Weather is a Forecast feed, never a Real-time observation,
  // so it can never inflate the "Live observation feeds" count.
  const googleEntry = sources.find((s) => s.id === 'google-weather')
  const googleLive = googleEntry?.status === 'Live'

  return (
    <div className="section-gap flex flex-col">
      <PageHeader
        title="Data Sources"
        subtitle={googleLive
          ? 'What feeds this demo — and what does not. The ERA5 archive is a static historical dataset served by the backend; no live satellite, radar or station feed is connected, and the Google Weather API is connected as an external forecast feed.'
          : 'What feeds this demo — and what does not. The ERA5 archive is a static historical dataset served by the backend; no live satellite, radar or station feed is connected, and no external NWP forecast feed is used.'}
        meta={<><DemoBadge /><Badge tone="warning">Integration-ready UI</Badge></>}
      >
        <Button icon={<Workflow size={14} />} onClick={() => document.getElementById('pipeline')?.scrollIntoView({ behavior: 'smooth' })}>
          View pipeline
        </Button>
      </PageHeader>

      <div className="flex items-start gap-3 rounded-xl border border-warning/30 bg-warning/8 px-4 py-3">
        <ShieldCheck size={16} className="mt-0.5 shrink-0 text-warning" aria-hidden />
        <p className="text-[11px] leading-relaxed text-warning">
          <strong>Honest status:</strong> Four different things, kept apart.
          <strong> Historical datasets:</strong> the ERA5 archive (hourly, 2021–2025) is served from this backend
          as a static archive — it is not a live feed and contains no real-time observations.
          <strong> Connected APIs:</strong> only this backend's own API, which serves the ML forecast and the
          archive; {googleLive ? 'plus the Google Weather API, an external forecast feed (see its card below).' : 'no external weather API is connected.'}
          <strong> Real-time observations:</strong> none — no live satellite, radar or station feed is connected;
          the weather shown elsewhere in this app is demo-generated.
          <strong> Forecast feeds:</strong> {googleLive ? 'the Google Weather API is connected as an external forecast feed — the forecasts shown alongside it are the ML ensemble\u2019s output, kept separate.' : 'no external NWP feed is connected — the forecasts shown are the ML ensemble\u2019s output.'} The ML model itself is not listed here; it is a consumer of these sources, not a source.
        </p>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[
          { label: 'Source types', value: String(sources.length), color: '#6FD6C2' },
          { label: 'Historical archive served', value: String(archiveServed), color: '#7FB3D5' },
          { label: 'Live observation feeds', value: String(liveObservations), color: '#F2A93B' },
          { label: 'Awaiting integration', value: String(awaitingCount), color: '#F2A93B' },
        ].map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
            className="rounded-2xl border border-line bg-card p-[var(--rw-card-pad)]">
            <p className="text-[10px] font-semibold tracking-wider text-muted uppercase">{s.label}</p>
            <p className="num mt-2 text-xl font-bold" style={{ color: s.color }}>{s.value}</p>
          </motion.div>
        ))}
      </div>

      {/* Pipeline */}
      <Card id="pipeline" className="scroll-mt-20 overflow-hidden">
        <CardHeader title="Data Pipeline" subtitle="Planned flow from observation to early-warning delivery" icon={<Workflow size={16} />} />
        {error ? <StatePanel variant="error" title="Pipeline unavailable" message={error} actionLabel="Retry" onAction={reload} /> : null}
        <div className="relative overflow-x-auto pb-2">
          <div className="flex min-w-[900px] items-stretch gap-0">
            {pipeline.map((node, i) => {
              const Icon = nodeIcons[i] ?? Database
              const isLast = i === pipeline.length - 1
              const active = selectedNode === node.id
              return (
                <div key={node.id} className="flex flex-1 items-center">
                  <motion.button
                    type="button"
                    onClick={() => setSelectedNode(active ? null : node.id)}
                    initial={{ opacity: 0, y: 16 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.06 }}
                    whileHover={{ y: -4, rotateY: -9 }}
                    style={{ transformPerspective: 620, transformStyle: 'preserve-3d' }}
                    className={`instrument-stage flex min-w-0 flex-1 flex-col items-center border p-3 text-center transition-all ${
                      active || isLast ? 'border-accent bg-accent/10' : 'border-line bg-surface/50 hover:border-accent/60'
                    }`}
                  >
                    <span className={`tilt-lift relative flex h-11 w-11 items-center justify-center border ${
                      isLast ? 'border-accent/50 bg-accent/20 text-accent animate-node-glow' : 'border-line bg-card text-accent'
                    }`}>
                      {isLast ? <BrandLogo size={30} /> : <Icon size={19} aria-hidden />}
                    </span>
                    <p className="mt-2.5 text-[11px] font-semibold leading-tight text-ink">{node.label}</p>
                    <p className="mt-1 text-[10px] leading-tight text-muted">{node.detail}</p>
                    <span className="num mt-2 text-[9px] text-muted">STAGE {String(i + 1).padStart(2, '0')}</span>
                  </motion.button>
                  {!isLast ? (
                    <div className="relative flex w-10 shrink-0 items-center justify-center">
                      <svg width="40" height="12" viewBox="0 0 40 12" aria-hidden className="overflow-visible">
                        <line x1="0" y1="6" x2="40" y2="6" stroke="var(--rw-accent)" strokeOpacity="0.22" strokeWidth="2" />
                        <line x1="0" y1="6" x2="40" y2="6" stroke="var(--rw-accent)" strokeWidth="2" className="animate-data-flow" />
                      </svg>
                      <motion.span
                        className="absolute h-1.5 w-1.5 rounded-full bg-accent"
                        animate={{ x: [0, 34, 0], opacity: [0, 1, 0] }}
                        transition={{ duration: 2.2, repeat: Infinity, delay: i * 0.25, ease: 'easeInOut' }}
                        aria-hidden
                      />
                    </div>
                  ) : null}
                </div>
              )
            })}
          </div>
        </div>
        <p className="mt-2 text-[11px] text-muted">
          {selectedNode
            ? pipeline.find((p) => p.id === selectedNode)?.detail
            : 'Click any stage to highlight it. Animated connectors show the intended data flow — today only the archive and ML-model paths carry real data; the observation stages are planned or demo.'}
        </p>
      </Card>

      {/* Source cards */}
      <div>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-sm font-semibold tracking-wide text-ink uppercase">Supported Source Categories</h2>
          <Badge tone="muted">{sources.length || 7} categories</Badge>
        </div>
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
          {loading
            ? Array.from({ length: 6 }).map((_, i) => <SkeletonCard key={i} lines={3} />)
            : sources.map((s, i) => {
              const Icon = iconMap[s.icon] ?? Database
              const style = statusStyle[s.status]
              return (
                <motion.div key={s.id} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }} whileHover={{ y: -4 }}
                  className="flex flex-col rounded-2xl border border-line bg-card p-[var(--rw-card-pad)] transition-colors hover:border-accent/35">
                  <div className="flex items-start justify-between gap-3">
                    <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-line bg-surface text-accent"><Icon size={18} aria-hidden /></span>
                    <Badge tone={style.tone} dot>{s.status}</Badge>
                  </div>
                  <h3 className="mt-3 text-sm font-semibold text-ink">{s.name}</h3>
                  <div className="mt-1.5 flex flex-wrap items-center gap-2">
                    <Badge tone="muted">{s.kind}</Badge>
                    <span className="text-[10px] font-semibold tracking-wider text-accent uppercase">{s.category}</span>
                  </div>
                  <p className="mt-2 text-xs leading-relaxed text-muted">{s.description}</p>
                  <div className="mt-3 space-y-2 border-t border-line pt-3">
                    <div>
                      <p className="text-[10px] font-semibold tracking-wider text-muted uppercase">Intended use</p>
                      <p className="mt-0.5 text-[11px] leading-relaxed text-ink">{s.intendedUse}</p>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] text-muted">Cadence</span>
                      <span className="num text-[10px] font-semibold text-ink">{s.cadence}</span>
                    </div>
                    {/* Google Weather live fields — only on its card, only
                        when the backend reports them. */}
                    {s.id === 'google-weather' ? (
                      <>
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] text-muted">Last retrieved</span>
                          <span className="num text-[10px] font-semibold text-ink">{s.lastRetrievedAt ?? '—'}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] text-muted">Records retrieved</span>
                          <span className="num text-[10px] font-semibold text-ink">{s.recordsRetrieved ?? '—'}</span>
                        </div>
                        {s.error ? (
                          <p className="text-[11px] leading-relaxed text-critical">Error: {s.error}</p>
                        ) : null}
                      </>
                    ) : null}
                  </div>
                </motion.div>
              )
            })}
        </div>
      </div>

      {/* Roadmap */}
      <Card>
        <CardHeader title="Integration Roadmap" subtitle="Planned phases — nothing here is connected today" icon={<GitBranch size={16} />} />
        <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
          {[
            { phase: 'Phase 1', title: 'Observation layer', items: ['Ground station ingestion', 'Satellite QPE adapter', 'Radar mosaic connector'], color: '#6FD6C2' },
            { phase: 'Phase 2', title: 'Forecast & terrain', items: ['NWP forecast adapter', 'DEM / flow routing', 'Drainage network import'], color: '#F2A93B' },
            { phase: 'Phase 3', title: 'Intelligence & alerts', items: ['Calibrated risk model', 'Inundation simulation', 'Operational warning delivery'], color: '#69D2A0' },
          ].map((p, i) => (
            <motion.div key={p.phase} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
              className="rounded-xl border border-line bg-surface/50 p-3.5">
              <span className="text-[10px] font-bold tracking-[0.16em] uppercase" style={{ color: p.color }}>{p.phase}</span>
              <p className="mt-1 text-sm font-semibold text-ink">{p.title}</p>
              <ul className="mt-2 space-y-1.5">
                {p.items.map((item) => (
                  <li key={item} className="flex items-start gap-2 text-[11px] text-muted">
                    <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: p.color }} />
                    {item}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </Card>
    </div>
  )
}
