"""CLI: build the multi-source model-ready dataset (v3.2).

Merges the existing v3 feature table with the new source features
(IFS first; other sources as they become available) into a single
model-ready CSV, aligned on UTC hourly timestamps.

Usage:
    python scripts/build_multisource_dataset.py --sources ifs --ifs-model ecmwf_ifs025

The output is written to data/model_ready/bhubaneswar_features_v32.csv
with a manifest recording which sources were included, their versions,
and the merge provenance. Sources that are unavailable are skipped with
a warning — they never produce fabricated rows.
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger("build_multisource_dataset")

BACKEND_DIR = Path(__file__).resolve().parent.parent


def main() -> None:
    ap = argparse.ArgumentParser(description="Build the multi-source model-ready dataset")
    ap.add_argument("--sources", nargs="*", default=["ifs"],
                    choices=["ifs", "insat", "imd_stations", "mswep", "gsmap", "era5_land"])
    ap.add_argument("--ifs-model", default="ecmwf_ifs025",
                    choices=["ecmwf_ifs025", "gfs_global"])
    ap.add_argument("--output", default="bhubaneswar_features_v32.csv")
    args = ap.parse_args()

    base_path = BACKEND_DIR / "data" / "model_ready" / "bhubaneswar_features.csv"
    if not base_path.exists():
        raise SystemExit(f"base feature table not found: {base_path}")
    df = pd.read_csv(base_path, parse_dates=["timestamp"])
    log.info("base features: %d rows, %d cols", len(df), len(df.columns))
    included: list[str] = ["v3_41 (ERA5 + spatial)"]
    skipped: list[str] = []

    if "ifs" in args.sources:
        ifs_path = BACKEND_DIR / "data" / "processed" / "ifs" / f"{args.ifs_model}_processed.csv"
        if not ifs_path.exists():
            log.warning("IFS processed file not found: %s — skipping", ifs_path)
            skipped.append(f"ifs ({args.ifs_model}): file not found")
        else:
            from ml.feature_groups.ifs_features import build_ifs_features
            ifs_df = pd.read_csv(ifs_path, parse_dates=["timestamp"])
            # ERA5 precip for the disagreement feature (same index as base).
            era5_precip = None
            if "precipitation_mm" in df.columns:
                era5_precip = df.set_index("timestamp")["precipitation_mm"]
            ifs_feats = build_ifs_features(ifs_df, era5_precip=era5_precip)
            before = len(df)
            df = df.merge(ifs_feats, on="timestamp", how="left")
            log.info("merged IFS (%s): %d rows (was %d), +%d cols",
                     args.ifs_model, len(df), before, len(ifs_feats.columns) - 1)
            included.append(f"ifs ({args.ifs_model})")

    out_path = BACKEND_DIR / "data" / "model_ready" / args.output
    df.to_csv(out_path, index=False)
    manifest = {
        "output": str(out_path),
        "n_rows": len(df),
        "n_cols": len(df.columns),
        "sources_included": included,
        "sources_skipped": skipped,
        "base": "bhubaneswar_features.csv (v3 41-feature table)",
        "timestamp_range": [str(df["timestamp"].min()), str(df["timestamp"].max())],
    }
    manifest_path = out_path.with_suffix(".manifest.json")
    with open(manifest_path, "w") as f:
        json.dump(manifest, f, indent=2)
    log.info("wrote %s (%d rows, %d cols)", out_path, len(df), len(df.columns))
    log.info("manifest: %s", manifest_path)
    if skipped:
        log.warning("skipped sources: %s", skipped)


if __name__ == "__main__":
    main()
