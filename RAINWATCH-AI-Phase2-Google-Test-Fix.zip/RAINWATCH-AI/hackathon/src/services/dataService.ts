/* ------------------------------------------------------------------
   DATA-ACCESS LAYER

   Every page in RAINWATCH AI talks to `demoApi` instead of importing
   data modules directly. When VITE_API_URL is set, `viaApi` calls the
   FastAPI backend first and falls back to the local demo computation
   on any failure. API responses carry their own per-value `source`
   ("model" | "demo"); local fallback values are stamped "demo" where
   the call site opts in (see stampDemoSource). Nothing returned here
   is assumed to be model output.
------------------------------------------------------------------ */

import {
  getAnnualHistory,
  getDailyHistory,
  getMonthlyHistory,
  getPeakEvents,
  getLocationComparison,
} from '../data/historicalData'
import {
  getAllRiskRecords,
  getFilteredRiskRecords,
  getOverallRiskIndex,
  getRiskDistribution,
  getVulnerableZones,
  type RiskFilter,
} from '../data/floodRiskData'
import {
  getAccumulatedRainfall,
  getCurrentRainfall,
  getCurrentWeather,
  getMaxForecast,
  getRainfallDelta,
  getRainfallSparkline,
  getWeatherHistory,
} from '../data/weatherData'
import { getForecast, getIntensityDistribution } from '../data/rainfallData'
import { getMapLayers } from '../data/mapLayersData'
import { computeRiskRecord } from '../data/floodRiskData'
import { SAMPLE_ALERTS, getUpcomingAlerts } from '../data/alertsData'
import { LOCATIONS } from '../data/locationsData'
import { bumpDemoTick } from './demoState'
import type {
  Alert,
  AnnualSummary,
  DataSourceInfo,
  FloodRiskRecord,
  ForecastPoint,
  GeoLocation,
  HistoricalDay,
  MapLayersPayload,
  MergedForecastResponse,
  MonthlySummary,
  PeakEvent,
  RegionCondition,
  SimulatorInputs,
  SimulatorResult,
  WeatherReading,
} from '../types'
import { classifyRisk } from '../utils/colors'
import { clamp, createRng, hashSeed, round } from '../utils/rng'
import { DATA_SOURCES, PIPELINE_NODES } from '../data/dataSourcesData'

const LATENCY_MS = 320

/* ------------------------- Backend API ---------------------------- */
// When VITE_API_URL is set (see hackathon/.env), demoApi calls the
// FastAPI backend first and falls back to the local demo computation
// on any failure, so the dashboard works with or without the server.
const API_BASE = (import.meta.env.VITE_API_URL as string | undefined)?.replace(/\/$/, '')

async function viaApi<T>(
  path: string,
  fallback: () => Promise<T>,
  opts?: { stampDemoSource?: boolean },
): Promise<T> {
  if (!API_BASE) return stampDemoSource(await fallback(), opts?.stampDemoSource)
  try {
    const res = await fetch(`${API_BASE}${path}`)
    if (!res.ok) throw new Error(`API ${res.status}`)
    // API responses carry their own per-item `source` ("model" | "demo")
    // from the backend — never overwritten here.
    return (await res.json()) as T
  } catch {
    return stampDemoSource(await fallback(), opts?.stampDemoSource)
  }
}

/**
 * Stage 5 — provenance for the local demo fallback. Values the
 * frontend generates itself (API unreachable or VITE_API_URL unset)
 * are DEMO by construction: the frontend computed them, no model was
 * involved. Stamps `source: "demo"` onto records (and, one level deep,
 * onto record arrays inside summary-style payloads) that do not
 * already carry a source. Never called on API responses.
 */
function stampDemoSource<T>(value: T, enabled?: boolean): T {
  if (!enabled) return value
  if (Array.isArray(value)) return value.map((item) => stampDemoSource(item, true)) as T
  if (value && typeof value === 'object') {
    const out: Record<string, unknown> = { ...(value as Record<string, unknown>) }
    if (!('source' in out)) out.source = 'demo'
    for (const key of Object.keys(out)) {
      const v = out[key]
      if (Array.isArray(v)) out[key] = v.map((item) => stampDemoSource(item, true))
    }
    return out as T
  }
  return value
}

function demo<T>(value: T, jitter = 220): Promise<T> {
  return new Promise((resolve) => {
    window.setTimeout(() => resolve(value), LATENCY_MS + Math.random() * jitter)
  })
}

/* ------------------------- Overview bundle ------------------------ */

export interface OverviewKpis {
  currentRainfall: number
  rainfallDelta: number
  accumulated24h: number
  accumulatedTrend: number
  maxForecast: { rainfallMmHr: number; timestamp: string }
  floodRiskIndex: number
  riskLevel: string
  vulnerableZones: number
  activeAlerts: number
}

export interface OverviewBundle {
  kpis: OverviewKpis
  sparkline: number[]
  weather: WeatherReading
  forecast: ForecastPoint[]
  intensity: Array<{ label: string; hours: number; color: string }>
  riskDistribution: Array<{ level: string; count: number }>
  vulnerable: Array<{ name: string; riskIndex: number; level: string; populationAtRisk: number }>
  upcomingAlerts: Alert[]
  activity: Array<{ id: string; time: string; text: string; tone: 'info' | 'warn' | 'crit' | 'ok' }>
}

/* ------------------------- Google Weather ------------------------- */

/** One hour of Google's hourly forecast, as returned by /api/weather/google. */
export interface GoogleForecastPoint {
  timestamp: string
  /** Google interval end — needed to match RAINWATCH hours against
      Google's [startTime, endTime) intervals. */
  endTime?: string | null
  precipitationMm: number | null
  precipitationProbabilityPct: number | null
  precipitationType: string | null
  temperatureC: number
  relativeHumidityPct: number | null
  windSpeedKmh: number | null
  windDirectionDeg: number | null
  condition: string | null
  conditionText: string | null
  source: 'google_weather'
}

export interface GoogleForecastPayload {
  locationId: string
  location: { name: string; lat: number; lng: number }
  timeZone: string | null
  retrievedAt: string
  source: 'google_weather'
  hours: GoogleForecastPoint[]
  meta: { cached: boolean; callsMade: number; lastSuccessAt: string | null; lastError: string | null }
}

/**
 * Google fetch result. `available: false` carries the reason the
 * Google section must show as unavailable — never demo values.
 */
export type GoogleForecastResult =
  | { available: true; payload: GoogleForecastPayload }
  | { available: false; reason: string }

export const demoApi = {
  async listLocations(): Promise<GeoLocation[]> {
    return viaApi('/api/locations', () => demo(LOCATIONS))
  },

  async fetchWeather(locationId: string, hours: number): Promise<WeatherReading[]> {
    return viaApi(`/api/weather?locationId=${locationId}&hours=${hours}`, () => demo(getWeatherHistory(locationId, hours)))
  },

  async fetchCurrentWeather(locationId: string): Promise<WeatherReading> {
    return viaApi(`/api/weather/current?locationId=${locationId}`, () => demo(getCurrentWeather(locationId)))
  },

  async fetchForecast(locationId: string, hours: number): Promise<ForecastPoint[]> {
    return viaApi(
      `/api/forecast?locationId=${locationId}&hours=${hours}`,
      () => demo(getForecast(locationId, hours)),
      { stampDemoSource: true },
    )
  },

  /**
   * Merged forecast (GET /api/forecast/merged) — source priority
   * MODEL > GOOGLE WEATHER > UNAVAILABLE. Deliberately NOT routed
   * through `viaApi`: there is no demo fallback for this series.
   * On any failure (no VITE_API_URL, non-200, network) it THROWS, so
   * the page shows its error panel — the backend being down must
   * show an error, never demo values. A 200 with UNAVAILABLE rows is
   * a normal successful response (Google down is inside the payload).
   */
  async fetchMergedForecast(locationId: string, hours: number): Promise<MergedForecastResponse> {
    if (!API_BASE) throw new Error('Backend not configured (VITE_API_URL unset)')
    const res = await fetch(`${API_BASE}/api/forecast/merged?locationId=${locationId}&hours=${hours}`)
    if (!res.ok) {
      let detail = `API error ${res.status}`
      try {
        const body = (await res.json()) as { detail?: string }
        if (body.detail) detail = body.detail
      } catch { /* keep the status-based message */ }
      throw new Error(detail)
    }
    return (await res.json()) as MergedForecastResponse
  },

  async fetchIntensityDistribution(
    locationId: string,
    hours: number,
  ): Promise<Array<{ label: string; hours: number; color: string }>> {
    return viaApi(`/api/forecast/intensity?locationId=${locationId}&hours=${hours}`, () => demo(getIntensityDistribution(locationId, hours)))
  },

  async fetchRiskRecords(filter: RiskFilter): Promise<FloodRiskRecord[]> {
    const q = new URLSearchParams()
    if (filter.locationId) q.set('locationId', filter.locationId)
    if (filter.level) q.set('level', filter.level)
    if (filter.horizonH) q.set('horizonH', String(filter.horizonH))
    return viaApi(
      `/api/risk/records?${q.toString()}`,
      () => demo(getFilteredRiskRecords(filter)),
      { stampDemoSource: true },
    )
  },

  async fetchRiskSummary(horizonH: number): Promise<{
    overallIndex: number
    distribution: Array<{ level: string; count: number }>
    worst: FloodRiskRecord[]
    vulnerable: FloodRiskRecord[]
  }> {
    return viaApi(
      `/api/risk/summary?horizonH=${horizonH}`,
      () =>
        demo({
          overallIndex: getOverallRiskIndex(horizonH),
          distribution: getRiskDistribution(horizonH).map((d) => ({ ...d })),
          worst: getVulnerableZones(55),
          vulnerable: getVulnerableZones(60),
        }),
      { stampDemoSource: true },
    )
  },

  async fetchAllRiskRecords(): Promise<FloodRiskRecord[]> {
    return viaApi('/api/risk/all', () => demo(getAllRiskRecords()), { stampDemoSource: true })
  },

  async fetchAlerts(): Promise<Alert[]> {
    return viaApi('/api/alerts', () => demo(SAMPLE_ALERTS))
  },

  async fetchUpcomingAlerts(limit = 5): Promise<Alert[]> {
    return viaApi(`/api/alerts/upcoming?limit=${limit}`, () => demo(getUpcomingAlerts(limit)))
  },

  async fetchDailyHistory(locationId: string, days: number): Promise<HistoricalDay[]> {
    return viaApi(`/api/history/daily?locationId=${locationId}&days=${days}`, () => demo(getDailyHistory(locationId, days), 260))
  },

  async fetchMonthlyHistory(locationId: string): Promise<MonthlySummary[]> {
    return viaApi(`/api/history/monthly?locationId=${locationId}`, () => demo(getMonthlyHistory(locationId)))
  },

  async fetchAnnualHistory(): Promise<AnnualSummary[]> {
    return viaApi('/api/history/annual', () => demo(getAnnualHistory()))
  },

  async fetchPeakEvents(locationId?: string, limit = 8): Promise<PeakEvent[]> {
    return viaApi(`/api/history/peaks?${locationId ? `locationId=${locationId}&` : ''}limit=${limit}`, () => demo(getPeakEvents(locationId, limit)))
  },

  async fetchLocationComparison(days = 90): Promise<
    Array<{ locationId: string; name: string; rainfallMm: number; peakMmHr: number; avgRiskIndex: number }>
  > {
    return viaApi(`/api/history/comparison?days=${days}`, () => demo(getLocationComparison(days)))
  },

  async fetchMapLayers(): Promise<MapLayersPayload> {
    return viaApi('/api/map/layers', () => demo(getMapLayers(), 300))
  },

  /** Per-location snapshot used by both maps (rainfall, risk, inundation). */
  async fetchRegionConditions(): Promise<RegionCondition[]> {
    return viaApi('/api/map/regions', () =>
      demo(
        LOCATIONS.map((loc) => {
          const risk = computeRiskRecord(loc.id, 6)
          return {
            locationId: loc.id,
            name: loc.name,
            zone: loc.zone,
            lat: loc.lat,
            lng: loc.lng,
            rainfallMmHr: getCurrentRainfall(loc.id),
            riskIndex: risk.riskIndex,
            riskLevel: risk.riskLevel,
            inundationDepthM: risk.inundationDepthM,
            populationAtRisk: risk.populationAtRisk,
            vulnerability: loc.vulnerability,
            lowLyingPct: loc.lowLyingPct,
            drainageEfficiency: loc.drainageEfficiency,
          }
        }),
        260,
      ),
    )
  },

  async fetchDataSources(): Promise<{ sources: DataSourceInfo[]; pipeline: typeof PIPELINE_NODES }> {
    return viaApi('/api/data-sources', () => demo({ sources: DATA_SOURCES, pipeline: PIPELINE_NODES }))
  },

  /**
   * Google Weather hourly forecast — deliberately NOT routed through
   * `viaApi`: there is no demo fallback for Google. On any failure it
   * returns `{ available: false, reason }` so the page renders the
   * Google section as unavailable. Demo values are never stamped
   * `google_weather`.
   */
  async fetchGoogleForecast(locationId: string, hours: number): Promise<GoogleForecastResult> {
    if (!API_BASE) return { available: false, reason: 'key not configured' }
    try {
      const res = await fetch(`${API_BASE}/api/weather/google?locationId=${locationId}&hours=${hours}`)
      if (res.status === 503) return { available: false, reason: 'key not configured' }
      if (!res.ok) {
        let reason = `API error ${res.status}`
        try {
          const body = (await res.json()) as { detail?: string }
          if (body.detail) reason = body.detail
        } catch { /* keep the status-based reason */ }
        return { available: false, reason }
      }
      const body = (await res.json()) as GoogleForecastPayload
      return { available: true, payload: body }
    } catch {
      return { available: false, reason: 'backend unreachable' }
    }
  },

  /**
   * Backend health, with NO demo fallback: returns null when the backend is
   * unreachable or unhealthy, so the UI can tell the presenter the backend
   * is down instead of silently showing demo data. Stage 6.
   */
  async fetchHealth(): Promise<{ apiVersion: string; modelVersion: string; loaded: boolean } | null> {
    if (!API_BASE) return null
    try {
      const res = await fetch(`${API_BASE}/api/health`)
      if (!res.ok) return null
      const body = (await res.json()) as { version?: string; api_version?: string; model?: { model_version?: string; loaded?: boolean } }
      return {
        apiVersion: body.version ?? body.api_version ?? 'unknown',
        modelVersion: body.model?.model_version ?? 'unknown',
        loaded: !!body.model?.loaded,
      }
    } catch {
      return null
    }
  },

  /** Bumps the demo seed so every series regenerates with new values. */
  async refreshDemoData(): Promise<number> {
    if (API_BASE) {
      try {
        const res = await fetch(`${API_BASE}/api/demo/refresh`, { method: 'POST' })
        if (res.ok) {
          const data = (await res.json()) as { tick: number }
          return data.tick
        }
      } catch {
        // fall through to the demo tick below
      }
    }
    return demo(bumpDemoTick(), 140)
  },

  async fetchOverview(locationId: string, alertCount: number): Promise<OverviewBundle> {
    const worst = getVulnerableZones(55)
    const activityTones: Array<'info' | 'warn' | 'crit' | 'ok'> = ['info', 'warn', 'crit', 'ok']
    const rng = createRng(hashSeed(`activity-${locationId}`))

    const activity = [
      { text: `Radar mosaic ingested for ${locationId} sector`, tone: 'info' as const },
      { text: 'Drainage model re-ran for 12 sample zones', tone: 'ok' as const },
      { text: 'Risk index recalculated — composite factors updated', tone: 'warn' as const },
      { text: 'Sample station telemetry validated', tone: 'ok' as const },
      { text: 'Inundation extent regenerated from demo terrain', tone: 'crit' as const },
      { text: 'Forecast confidence band narrowed for next 6 h', tone: 'info' as const },
      { text: 'Vulnerability registry refreshed (demo records)', tone: 'warn' as const },
    ]
      .slice(0, 6)
      .map((a, i) => ({
        id: `act-${i}`,
        time: new Date(Date.now() - (i * 17 + rng() * 12) * 60_000).toISOString(),
        text: a.text,
        tone: activityTones[activityTones.indexOf(a.tone)] ?? 'info',
      }))

    const bundle: OverviewBundle = {
      kpis: {
        currentRainfall: getCurrentRainfall(locationId),
        rainfallDelta: getRainfallDelta(locationId),
        accumulated24h: getAccumulatedRainfall(locationId, 24),
        // Percentage change vs the prior 24 hours — bounded and readable.
        accumulatedTrend: round(
          ((getAccumulatedRainfall(locationId, 24) -
            (getAccumulatedRainfall(locationId, 48) - getAccumulatedRainfall(locationId, 24))) /
            Math.max(1, getAccumulatedRainfall(locationId, 48) - getAccumulatedRainfall(locationId, 24))) *
            100,
          1,
        ),
        maxForecast: getMaxForecast(locationId),
        floodRiskIndex: getOverallRiskIndex(24),
        riskLevel: classifyRisk(getOverallRiskIndex(24)),
        vulnerableZones: worst.length,
        activeAlerts: alertCount,
      },
      sparkline: getRainfallSparkline(locationId, 24),
      weather: getCurrentWeather(locationId),
      forecast: getForecast(locationId, 24),
      intensity: getIntensityDistribution(locationId, 24),
      riskDistribution: getRiskDistribution(24).map((d) => ({ ...d })),
      vulnerable: worst.slice(0, 6).map((r) => ({
        name: LOCATIONS.find((l) => l.id === r.locationId)?.name ?? r.locationId,
        riskIndex: r.riskIndex,
        level: r.riskLevel,
        populationAtRisk: r.populationAtRisk,
      })),
      upcomingAlerts: getUpcomingAlerts(4),
      activity,
    }
    return viaApi(`/api/overview?locationId=${locationId}&alertCount=${alertCount}`, () => demo(bundle, 280))
  },

  /* ------------------- What-if simulator (local) ------------------ */

  /**
   * Deterministic, fully client-side scenario calculation.
   * Educational demo formula — explicitly NOT an AI model.
   */
  async runSimulation(inputs: SimulatorInputs): Promise<SimulatorResult> {
    if (API_BASE) {
      try {
        const res = await fetch(`${API_BASE}/api/simulate`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(inputs),
        })
        if (res.ok) return (await res.json()) as SimulatorResult
      } catch {
        // fall through to the local maths below
      }
    }

    const rng = createRng(
      hashSeed(
        `${inputs.locationId}|${inputs.rainfallMmHr}|${inputs.durationH}|${inputs.soilSaturationPct}|${inputs.drainageEfficiencyPct}|${inputs.riverLevelPct}`,
      ),
    )
    const loc = LOCATIONS.find((l) => l.id === inputs.locationId) ?? LOCATIONS[0]

    const rainLoad = clamp((inputs.rainfallMmHr / 120) * 42, 0, 44)
    const durationLoad = clamp((inputs.durationH / 48) * 16, 0, 16)
    const soilLoad = clamp((inputs.soilSaturationPct / 100) * 18, 0, 18)
    const riverLoad = clamp((inputs.riverLevelPct / 100) * 16, 0, 16)
    const terrainLoad = clamp((loc.lowLyingPct / 100) * 14, 0, 14)
    const drainageRelief = clamp((inputs.drainageEfficiencyPct / 100) * 26, 0, 26)

    const riskIndex = round(
      clamp(
        rainLoad + durationLoad + soilLoad + riverLoad + terrainLoad - drainageRelief + rng() * 3,
        1,
        99,
      ),
      1,
    )

    const breakdown = [
      { factor: 'Rainfall intensity', contribution: round((rainLoad / (riskIndex + drainageRelief)) * 100, 1) },
      { factor: 'Storm duration', contribution: round((durationLoad / (riskIndex + drainageRelief)) * 100, 1) },
      { factor: 'Soil saturation', contribution: round((soilLoad / (riskIndex + drainageRelief)) * 100, 1) },
      { factor: 'River / water level', contribution: round((riverLoad / (riskIndex + drainageRelief)) * 100, 1) },
      { factor: 'Terrain & drainage', contribution: round(((terrainLoad + 4) / (riskIndex + drainageRelief)) * 100, 1) },
    ]

    const affectedZones = Math.round(clamp((riskIndex / 100) * 14 * (loc.lowLyingPct / 60), 0, 14))
    const peakDepthM = round(clamp((riskIndex / 100) ** 1.6 * 2.4, 0, 3.6), 2)
    const severity: SimulatorResult['inundationSeverity'] =
      riskIndex < 20 ? 'None'
      : riskIndex < 40 ? 'Minor'
      : riskIndex < 60 ? 'Moderate'
      : riskIndex < 80 ? 'Severe'
      : 'Extreme'

    const durationToImpactH = round(
      clamp(
        (inputs.soilSaturationPct > 70 ? 1.2 : 2.6) +
          (100 - inputs.drainageEfficiencyPct) / 45 +
          60 / Math.max(8, inputs.rainfallMmHr),
        0.5,
        12,
      ),
      1,
    )

    await demo(null, 160)

    return {
      riskIndex,
      riskLevel: classifyRisk(riskIndex),
      affectedZones,
      inundationSeverity: severity,
      peakDepthM,
      durationToImpactH,
      breakdown,
      inputs,
    }
  },
}

export type DemoApi = typeof demoApi
