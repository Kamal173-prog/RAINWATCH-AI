# RAINWATCH AI v3.3 — Storm Detection Investigation

Date: 2026-11-24. Evidence: pooled out-of-sample 2024+2025 probabilities
only. 2026 was not used. Scripts: `ml/storm_investigation.py`,
`ml/matched_comparison.py` (paired storm-event bootstrap).
Outputs: `models/rainfall_xgb_v3_3/threshold_work/storm_investigation.json`,
`matched_comparison.json`.

Definition: a true storm is a gap-merged (gap <= 6 h) run of positive
hours. A storm counts as detected when any strict contiguous predicted
alert event STARTS within [storm start − 2 h, storm end + 2 h]. This is
exactly the `v33_common.event_metrics` definition used for every
storm-detection number reported before (2025, 2026, variants, freeze),
so the rates here are comparable with all of them.

## 1. The symptom that started this

On the reserved 2026 evaluation, at the old (frozen) thresholds, v3.3
caught 26/46 storms for 3 h >= 10 mm while v3 caught 35/46. The
question: is v3.3 systematically worse at catching storms, and can
threshold changes recover the misses without excessive false alarms?

## 2. The symptom does NOT reproduce on the development data

Pooled 2024+2025, old Watch thresholds — storm detection rate:

| Event | Storms | v3 | v3.2 | v3.3 |
|---|---|---|---|---|
| 3 h >= 10 mm | 69 | 0.319 (22) | 0.667 (46) | 0.536 (37) |
| 6 h >= 10 mm | 104 | 0.433 (45) | 0.663 (69) | 0.519 (54) |
| 3 h >= 5 mm | 176 | 0.568 (100) | 0.778 (137) | 0.710 (125) |

On 2024+2025 v3.3 catches MORE storms than v3 on all three events
(37 vs 22, 54 vs 45, 125 vs 100). The 2026 gap (26/46 vs 35/46) is a
year-specific observation, not a systematic v3.3-vs-v3 weakness. 2026
is storm-dense (46 storms in 11 months vs 69 in 24 months here) and
v3's 2026 firing pattern differs; the development data does not support
the conclusion "v3.3 is worse than v3 at storm detection".

The systematic gap on the development data is v3.3 vs **v3.2**, and it
is significant for 3 h >= 10 mm and 6 h >= 10 mm (paired storm-event
bootstrap, 1,000 resamples, old Watch): 3 h >= 10 mm v3.3−v3.2
−0.132, 95% CI [−0.232, −0.043], P(>0) = 0.002; 6 h >= 10 mm −0.142,
CI [−0.240, −0.038], P = 0.003; 3 h >= 5 mm −0.069, CI [−0.148,
+0.011], P = 0.032 (leans v3.2, CI just crosses zero).

## 3. What the new thresholds recover — and at what cost

| Event | v3.3 old Watch | v3.3 new Watch | Old misses recovered | False alarms (new Watch) |
|---|---|---|---|---|
| 3 h >= 10 mm | 0.536 (37/69) | 0.536 (37/69) | 0 / 32 | 3.39 / 100 h, 0.26 events/day |
| 6 h >= 10 mm | 0.519 (54/104) | 0.567 (59/104) | 7 / 50 | 14.56 / 100 h, 0.49 events/day |
| 3 h >= 5 mm | 0.710 (125/176) | 0.722 (127/176) | 2 / 51 | 10.21 / 100 h, 0.37 events/day |

- 3 h >= 10 mm: nothing to recover — the optimized Watch threshold
  is 0.070, identical to the frozen one, so the operating point is
  unchanged. Threshold changes cannot fix this event's storm
  detection because the F2 optimum is already where the frozen
  threshold was.
- 6 h >= 10 mm: 7 of 50 old misses recovered; false alarms fall
  slightly (15.59 → 14.56 / 100 h) because the new Watch threshold
  (0.085) is higher than the old one (0.08) while recall still rises.
- 3 h >= 5 mm: 2 of 51 recovered; false alarms fall (10.60 → 10.21).

The new thresholds do not buy storm detection with false alarms —
they are roughly neutral on false alarms and slightly positive on
detection for two events.

## 4. Mechanism: why storms are missed (per-storm evidence)

Two distinct mechanisms, visible in the per-storm max-probability data
(`storm_investigation.json`, `v3_only_storms` and `missed_by_all_storms`):

### (a) Genuinely lower probabilities — 3 h >= 10 mm

For the 10 storms v3 catches at old Watch that v3.3 misses, v3.3's
maximum calibrated probability inside the detection window is mostly
far below v3's:

| Storm | Duration | v3 max p | v3.2 max p | v3.3 max p |
|---|---|---|---|---|
| 2025-09-05 | 1 h | 0.110 | 0.073 | 0.016 |
| 2025-07-16 | 1 h | 0.127 | 0.106 | 0.034 |
| 2025-03-23 | 5 h | 0.097 | 0.083 | 0.032 |
| 2025-08-27 | 3 h | 0.136 | 0.122 | 0.063 |
| 2025-09-16 | 3 h | 0.143 | 0.100 | 0.055 |

These are mostly short (1–3 h), marginal storms. v3.3 ranks them
lower than v3/v3.2 do — a real ranking difference on marginal short
events, consistent with v3.3's lower 2025 PR-AUC for this event
(0.1687 vs v3.2's 0.2228). Lowering v3.3's Watch threshold to catch
them would cost precision across the board: at P >= 0.15 the best
achievable recall is only 0.270 (see V33_THRESHOLDS.md §5).

### (b) The block-start artifact — 6 h >= 10 mm and 3 h >= 5 mm

Many "missed" storms have v3.3 probabilities far ABOVE threshold.
Examples (3 h >= 5 mm, v3-only storms, old Watch t = 0.12):

| Storm | v3.3 max p | Detected? |
|---|---|---|
| 2024-09-23 | 0.831 | No |
| 2024-06-30 | 0.656 | No |
| 2024-07-29 | 0.536 | No |
| 2024-08-18 | 0.529 | No |

And 6 h >= 10 mm storms missed by ALL versions have v3.3 max p up
to 0.733. These storms were alerted — the model fired — but the alert
event STARTED before the detection window (s−2). The model fires early
and stays on through a long wet period, so its alert block's start
falls outside [s−2, e+2] and the metric does not credit it. The same
artifact explains the odd result that v3.3's 6 h >= 10 mm old HIGH
threshold detects slightly MORE storms (0.529) than its old WATCH
(0.519): a higher threshold splits a long alert block into separate
events whose starts land inside the windows.

Consequences:
- The storm-detection metric rewards models that fire late or
  intermittently, and penalizes models that fire early and stay on.
  It is a useful operational proxy (an alert that starts on time
  matters), but it is NOT a pure measure of "did the model see the
  storm". Hour-level recall and precision are the cleaner ranking
  measures; storm detection adds the timing dimension.
- v3's high storm detection at its new thresholds (0.696 / 0.702 /
  0.631) comes with much lower thresholds (0.040 / 0.075 / 0.045) and
  far more alert hours — it fires more often, so more of its alert
  starts land inside windows. That is a firing-frequency effect, not
  evidence that v3 ranks storms better: its PR-AUC is worse than
  v3.3's on every event in both years.

## 5. Paired storm-event bootstrap at the NEW Watch thresholds

| Event | v3.3 − v3.2 (mean, 95% CI, P(>0)) | v3.3 − v3 (mean, 95% CI, P(>0)) |
|---|---|---|
| 3 h >= 10 mm | −0.160, [−0.261, −0.072], 0.000 | −0.161, [−0.304, −0.029], 0.008 |
| 6 h >= 10 mm | −0.020, [−0.125, +0.096], 0.304 | −0.135, [−0.240, −0.038], 0.002 |
| 3 h >= 5 mm | −0.028, [−0.091, +0.040], 0.163 | +0.090, [+0.006, +0.176], 0.980 |

At the new thresholds v3.3 is statistically tied with v3.2 on storm
detection for 6 h >= 10 mm and 3 h >= 5 mm, and still significantly
behind on 3 h >= 10 mm. v3 beats v3.3 on 3 h >= 10 mm and
6 h >= 10 mm detection at its new (very low) thresholds — again the
firing-frequency effect.

## 6. Storms missed by all versions

19 / 22 / 14 storms (3 h >= 10 mm / 6 h >= 10 mm / 3 h >= 5 mm) are
missed by every version at old Watch. For 3 h >= 10 mm their v3.3
max probabilities are mostly 0.01–0.06 (genuinely unseen events);
for 6 h >= 10 mm many are 0.24–0.73 (the block-start artifact). The
first group is a data/model limit; the second is a metric-timing
limit. Neither is fixed by threshold changes.

## 7. Conclusion

- The 2026 v3.3-vs-v3 storm gap does not generalize: on 2024+2025
  v3.3 beats v3 on storm detection at old thresholds.
- The real gap is v3.3 vs v3.2 on 3 h >= 10 mm, driven by genuinely
  lower probabilities on short marginal storms — a ranking gap, not a
  threshold gap.
- The new thresholds recover 7/50 and 2/51 old misses on the other
  two events without increasing false alarms, and recover nothing on
  3 h >= 10 mm (threshold unchanged).
- Do not present storm detection as the headline metric: it conflates
  ranking with alert timing. Report it alongside hour-level
  precision/recall and PR-AUC.
