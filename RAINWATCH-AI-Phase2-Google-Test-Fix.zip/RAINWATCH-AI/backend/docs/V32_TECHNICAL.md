# rainfall-xgb-v3.2 — Technical Documentation

**Model:** `rainfall-xgb-v3.2` (v3 ensemble + GFS NWP features).
**Date:** 2026-11-23. **API compatibility:** v1.3.0 (additive fields only).
**Status: TRAINED AND EVALUATED. Deployment decision: see §9.**

v3.2 is the first RAINWATCH AI model version that integrates a second,
independent precipitation data source (GFS numerical weather prediction)
alongside the ERA5 reanalysis. It does not add a new model family — the
ensemble is still XGBoost + LightGBM + HistGradientBoosting — and it
does not change the regressors (mean + P90), which are carried over from
v3 unchanged.

## 1. What changed vs v3

| Aspect | v3 | v3.2 |
|---|---|---|
| Features | 41 (ERA5 + spatial) | 41 + 12 GFS features = 53 |
| New data source | — | GFS via Open-Meteo Historical Forecast API (keyless) |
| CAPE | Not available (ERA5 returns all nulls) | GFS CAPE (populated), plus CAPE-derived features |
| NWP precipitation | Not used | GFS precipitation, 3 h / 6 h sums, acceleration, minus-ERA5 disagreement |
| Evaluation period | 2025 test set | 2025 (benchmark) + **2026 (fresh, never used for selection)** |
| Regressors | XGBoost + LightGBM + HistGB | **Unchanged — carried over from v3** |

## 2. Data sources actually acquired

| Source | Status | Coverage | Notes |
|---|---|---|---|
| GFS (Open-Meteo Historical Forecast API) | **Acquired** | 2021-03-23 → 2026-11-23 (49,728 h) | Keyless. One ~15-day gap (2022-11-29 → 2022-12-14). |
| ECMWF IFS (Open-Meteo Historical Forecast API) | **Acquired, but unusable for training** | 2024-02-02 → 2026-11-23 (23,838 h) | Keyless, but only from Feb 2024. All 12 IFS features were dropped (no training data in 2021–2023). |
| ERA5 2026 (fresh evaluation period) | **Acquired** | 2026-01-01 → 2026-11-23 (7,848 h) | Keyless. All precipitation non-null. |
| 2026 upwind spatial grids (Puri + Bay) | **Acquired** | 2026-01-01 → 2026-11-23 (7,848 h) | Keyless. |

Sources investigated but NOT acquired (credentials/registration required):
INSAT-3D/3DR (MOSDAC), IMD AWS/ARG stations, MSWEP V3, JAXA GSMaP V8,
ERA5-Land. See `docs/V32_EXTERNAL_ACCESS.md` for the exact blocker for
each. The connector framework for all of them is implemented in
`ml/data_sources/` and reports its blocker honestly.

## 3. GFS features (12)

All computed from values at time `t` or earlier — zero future leakage.
They are 0-hour-lead (analysis) forecast values, available at the valid
time.

| Feature | Physical interpretation |
|---|---|
| `gfs_precip` | GFS precipitation estimate for the hour — a second, independent precipitation estimate alongside ERA5. |
| `gfs_precip_3h_sum`, `gfs_precip_6h_sum` | GFS precipitation accumulated over the past 3 h / 6 h. |
| `gfs_precip_accel` | Change in the 3 h GFS precipitation sum — rainfall accelerating or decelerating. |
| `gfs_cape` | Convective Available Potential Energy from GFS. ERA5 CAPE is all nulls, so GFS is the only CAPE source. |
| `gfs_cape_3h_max` | Maximum CAPE over the past 3 h — convective instability building up. |
| `gfs_cape_3h_change` | 3 h change in CAPE. |
| `gfs_cape_x_humidity` | CAPE weighted by humidity — instability only matters when moisture is present. |
| `gfs_rh_tendency_3h` | 3 h change in relative humidity — moistening ahead of rain. |
| `gfs_wind_u`, `gfs_wind_v` | GFS vector wind components. |
| `gfs_precip_minus_era5` | GFS precip minus ERA5 precip (same hour) — a disagreement signal. |

## 4. Protocol

- Chronological split: train 2021–2023 (26,209 h) / validation 2024
  (8,784 h) / test 2025 (8,754 h, **historical benchmark** — 2025 was
  used for model selection in v3/v3.1, so it is NOT an untouched
  holdout) / **fresh evaluation 2026** (7,771 h, Jan–Nov, never used
  for any model selection). Seed 42.
- Classifiers: XGBoost + LightGBM + HistGradientBoosting ensemble with
  the v3.1 tuned hyperparameters (fixed; no re-tuning in this run),
  Platt calibration on validation, dual thresholds (elevated / high)
  optimised on validation for max precision subject to the v3.1 recall
  floors (3h≥10mm Watch ≥0.25 / Warning ≥0.20; 6h≥10mm 0.50/0.25;
  3h≥5mm 0.50/0.30).
- The 2026 numbers are the primary evidence for whether v3.2 improves
  on v3.

## 5. Results

### 5.1 PR-AUC (threshold-independent) — the headline

| Event | 2025 (benchmark) | 2026 (fresh) |
|---|---|---|
| | v3 base | v3.2-GFS | Δ | v3 base | v3.2-GFS | Δ |
| 3h ≥ 10 mm | 0.1625 | **0.2228** | **+0.060** | 0.2556 | **0.2983** | **+0.043** |
| 6h ≥ 10 mm | 0.2002 | **0.2371** | **+0.037** | 0.3957 | **0.4293** | **+0.034** |
| 3h ≥ 5 mm | 0.3385 | **0.3575** | **+0.019** | 0.4396 | **0.4898** | **+0.050** |

**PR-AUC improves on all three events, on both the 2025 benchmark and
the 2026 fresh evaluation.** The improvement is consistent across two
independent evaluation periods, which strengthens the evidence that the
GFS features add real signal.

### 5.2 Operating points (2026 fresh evaluation)

| Event | Level | v3 base P / R | v3.2-GFS P / R |
|---|---|---|---|
| 3h ≥ 10 mm | elevated | 0.280 / 0.373 | 0.226 / 0.535 |
| 3h ≥ 10 mm | high | 0.290 / 0.324 | 0.254 / 0.476 |
| 6h ≥ 10 mm | elevated | 0.287 / 0.766 | 0.276 / 0.801 |
| 6h ≥ 10 mm | high | 0.404 / 0.409 | **0.442 / 0.480** |
| 3h ≥ 5 mm | elevated | 0.358 / 0.641 | **0.393 / 0.603** |
| 3h ≥ 5 mm | high | 0.476 / 0.378 | **0.522 / 0.413** |

**Honest nuance for 3h ≥ 10 mm on 2026:** at the operating thresholds
(optimised on 2024 validation), precision drops (0.280 → 0.226 at
elevated) while recall rises substantially (0.373 → 0.535). This is a
threshold-calibration effect, not a model deficiency: at matched
thresholds, the GFS model achieves the same precision with higher
recall (e.g. at t=0.10: both P≈0.32, but GFS recall 0.373 vs base
0.286; at t=0.15: both P≈0.475, but GFS recall 0.222 vs base 0.146).
The GFS model's PR curve is better; the operating thresholds chosen on
2024 validation do not transfer perfectly to 2026. For 3h ≥ 5 mm and
6h ≥ 10 mm (high), both precision AND recall improve on 2026 — those
are clean wins.

On the 2025 benchmark, precision AND recall both improve for 3h ≥ 10mm
(elevated P 0.135 → 0.163, R 0.241 → 0.448) and 6h ≥ 10mm (elevated
P 0.132 → 0.137, R 0.698 → 0.752).

### 5.3 Event-level metrics (2026)

- 3h ≥ 10 mm: 57 true events. GFS elevated catches 31/57 (evR 0.544);
  high catches 26/57 (evR 0.456).
- 6h ≥ 10 mm: 70 true events. GFS elevated catches 59/70 (evR 0.843);
  high catches 41/70 (evR 0.586).
- 3h ≥ 5 mm: 125 true events. GFS elevated catches 82/125 (evR 0.656);
  high catches 59/125 (evR 0.472).

### 5.4 Calibration

Brier scores on 2026: 3h ≥ 10 mm 0.0204 (v3: 0.0210), 6h ≥ 10 mm
0.0475 (v3: 0.0503), 3h ≥ 5 mm 0.0446 (v3: 0.0468). Calibration is
slightly better than v3 on all events.

## 6. Feature importance (permutation, 2024 validation, 3h ≥ 10 mm)

The GFS features are genuinely important, not noise:
- `gfs_precip_6h_sum` is the **#2 most important feature** overall
  (+0.175 PR-AUC drop when permuted), after `precip_max24h` (+0.234).
- `gfs_wind_v` is #8 (+0.093).
- 2 GFS features in the top 15.

## 7. What did NOT work

- **ECMWF IFS features:** only available from 2024-02-02 in the
  Open-Meteo Historical Forecast API, so they have no training data in
  2021–2023. All 12 IFS features were dropped from the IFS variant,
  which then reduces exactly to the base model. IFS cannot be used with
  the current chronological split. (Note: IFS correlates better with
  ERA5 than GFS does — Pearson 0.60 vs 0.15 — but that correlation is
  partly because ERA5 is itself produced by the IFS model, so it is not
  independent evidence of predictive value.)
- **CAPE as a concurrent feature:** GFS CAPE is actually *lower* on
  heavy-rain hours than on non-heavy hours (mean 600 vs 688 J/kg).
  CAPE is consumed by convection, so instantaneous CAPE at the time of
  heavy rain is low. The useful CAPE features are the 3 h maximum and
  the change, not the concurrent value.

## 8. Artifacts

```
models/rainfall_xgb_v3_2/
  clf_3h_ge_10mm_xgb.json / _lgbm.txt / _hgb.pkl   (GFS variant, canonical)
  clf_6h_ge_10mm_xgb.json / _lgbm.txt / _hgb.pkl
  clf_3h_ge_5mm_xgb.json / _lgbm.txt / _hgb.pkl
  ensemble_weights.json, platt.json, thresholds.json
  feature_schema.json (53 features), metadata.json, evaluation.json
  base/    — v3 41-feature baseline (same protocol, for comparison)
  gfs/     — the GFS variant (identical to the canonical model)
  ifs/     — IFS variant (reduces to base; IFS features dropped)
  gfs_ifs/ — GFS+IFS variant (identical to GFS; IFS features dropped)
```

Regressors (mean + P90) are **not** in v3.2 — they are unchanged from v3
and live in `models/rainfall_xgb_v3/`. To serve v3.2 classifiers, load
the v3.2 classifier files and the v3 regressor files together.

## 9. Deployment decision

**v3.2-GFS is a genuine improvement over v3** by the PR-AUC criterion
on both evaluation periods, and it improves precision AND recall on
2025 for the heavy events and on 2026 for 3h ≥ 5 mm and 6h ≥ 10 mm
(high). The one caveat is the 3h ≥ 10 mm operating-point precision on
2026, which drops at the 2024-optimised thresholds (a threshold
calibration effect, not a model deficiency — at matched thresholds the
GFS model achieves higher recall at the same precision).

**Recommendation:** deploy v3.2-GFS behind the feature flag
(`MODEL_VERSION=rainfall-xgb-v3.2` in `.env`), with the existing v3 as
the fallback. The API contract is unchanged (additive fields only).
Before switching production traffic, re-optimise the operating
thresholds on a validation set that includes 2025 data (now that 2025
is a benchmark, not a holdout) — this would address the threshold
calibration issue for 3h ≥ 10 mm. Do NOT optimise thresholds on 2026
(the fresh evaluation set).

### Phase 11 — feature-flag integration (23 Nov 2026, DONE, production still on v3)

Implemented in `ml/predict.py` + `app/model_service.py`:

- `MODEL_VERSION` env var (documented in `.env.example`) selects the
  served model: `rainfall-xgb-v3` (default) or `rainfall-xgb-v3.2`.
  Any other value, or a v3.2 load failure, falls back to v3 — the API
  never breaks on a bad flag.
- `RainfallForecaster(model_dir=...)` loads the v3.2 classifiers from
  `models/rainfall_xgb_v3_2/`; the mean regressors and P90 quantiles are
  always loaded from v3 (unchanged in v3.2). At inference, the 12 GFS
  features are built from `data/processed/ifs/gfs_global_processed.csv`
  for the same last timestamp; if the GFS file is missing or has no data
  at that timestamp, the GFS features are NaN (the boosters handle NaN
  natively) and a warning is logged — a missing optional dataset never
  crashes the API.
- `/api/health`, `/api/forecast` and `/api/risk/*` report the actual
  loaded version (`rainfall-xgb-v3.2` when the flag is set) and the
  `model` detail object carries it too.
- Verified live: with `MODEL_VERSION=rainfall-xgb-v3.2` the API reports
  v3.2, all 22 endpoints return 200 (simulate 200 with a valid payload),
  forecast hours 1–6 and 3 risk records carry the v3.2 model detail,
  404/400 error handling intact, zero server errors. **Production was
  then reverted to v3** (`.env` has no `MODEL_VERSION`, so it defaults
  to v3) pending the threshold re-optimisation recommended above.

**Implementation notes (do not regress):**

- `ml/features/` (the v3.2 feature-module package) was renamed to
  `ml/feature_groups/` during Phase 11: the package name collided with
  `ml/features.py` (the v3 feature builder), and Python resolves the
  package first, so `import features` returned the package and
  `features.HORIZONS` raised `AttributeError`. The running server had
  masked this (it loaded `features.py` before the package existed).
  Never create a `ml/features/` package again; feature modules live in
  `ml/feature_groups/`.
- v3.2 artifacts use a shorter classifier naming than v3
  (`clf_3h_ge_10mm_*` vs `clf_y_3h_ge_10mm_*`) and its
  `ensemble_weights.json` / `platt.json` / `thresholds.json` are keyed
  by the short target name (`y_3h_ge_10mm`) and hold only classifier
  entries. `ml/predict.py` handles both naming schemes (`_load_member`
  tries the short name; `_lookup` tries both key forms) and merges v3's
  weights in for the regressor/quantile lookups. Do not "fix" the v3.2
  artifact names without updating the loader.
- The v3.2 classifiers take 53 features; the v3 regressors/quantiles
  take 41. `predict()` / `upper_bound_p90()` use `reg_features` (41);
  `heavy_rain_probability()` uses the full 53. Passing 53 features to
  a v3 regressor raises a `ValueError` from sklearn.

## 10. How to reproduce

```bash
cd backend
# Fetch GFS + 2026 ERA5 (keyless, Open-Meteo).
.venv/bin/python scripts/download_datasets.py --source ifs --model gfs_global --start 2021-03-23 --end 2026-11-23 --process
# Build the 2026 feature table (see scripts/build_multisource_dataset.py).
# Train the variants.
.venv/bin/python ml/train_rainfall_v32.py --variant base
.venv/bin/python ml/train_rainfall_v32.py --variant gfs
.venv/bin/python ml/train_rainfall_v32.py --variant ifs
.venv/bin/python ml/train_rainfall_v32.py --variant gfs_ifs
# Compare PR curves at matched thresholds.
.venv/bin/python scripts/compare_pr_curves.py
```
