# RAINWATCH AI — v3.3 Hackathon Demo Readiness (2026-11-24)

**Decision (Kam, 2026-11-24): v3.3 is the primary model for the hackathon
demonstration. v3.2 stays the benchmark. v3 stays production and rollback.
No v3.4, no retraining, no frontend redesign, no deployment.**

## 1. How the demo selects v3.3

The existing selection mechanism is the `MODEL_VERSION` environment flag
(`backend/app/model_service.py`). No `.env` change, no config change.

- **Demo server:** `MODEL_VERSION=rainfall-xgb-v3.3 uvicorn app.main:app --port 8001`
- **Frontend:** `VITE_API_URL=http://localhost:8001 npm run dev -- --port 5173`
  (the backend CORS allow-list covers `http://localhost:5173` only — the
  demo frontend MUST run on port 5173, or it silently falls back to labelled
  DEMO; see Stage 5 notes).
- **Production:** port 8000, no `MODEL_VERSION` in `.env` — serves v3.
- **Rollback:** stop the demo server (8001). Production on 8000 is untouched
  and was re-verified serving v3 after the demo servers stopped (§5).

Frozen v3.3 artifacts were **not** modified, retrained or regenerated.
Operating thresholds are the frozen `thresholds_optimized.json`
(3 h ≥ 10 mm 0.070/0.125; 6 h ≥ 10 mm 0.085/0.185; 3 h ≥ 5 mm 0.125/0.225),
selected on pooled out-of-sample 2024+2025 only. **2026 was not touched.**

## 2. Manifest hash verification

`models/rainfall_xgb_v3_3/frozen/RELEASE_MANIFEST.json`, checked twice
(before and after all work in this task):

- **15/15 frozen files match manifest SHA-256 + size. Zero mismatches.**

## 3. v3.3 loading and the no-silent-fallback rule

Live health checks (API v1.3.0 on all three):

| Server | Flag | `/api/health` model_version | loaded |
|---|---|---|---|
| 8000 (production) | none | `rainfall-xgb-v3` | True |
| 8001 (demo) | `rainfall-xgb-v3.3` | **`rainfall-xgb-v3.3`** | True |
| 8002 (bad-flag test) | `rainfall-xgb-v9.9` | `rainfall-xgb-v3` | True |

Fallback behaviour (code, `app/model_service.py::get_forecaster`): a v3.3
load failure logs a warning and loads v3. The reported version always comes
from the **actually loaded** forecaster (`fc.model_version`), so a fallback
is reported as v3 — never as v3.3. The invalid-flag test (8002) confirms
this end to end: bad flag → v3 served **and** reported as v3.

Not empirically triggered: the true v3.3 load-failure branch (it would
require corrupting a frozen artifact, which is forbidden). Verified by code
reading + the invalid-flag test instead. One code note: when NO model loads
at all, the health block reports `loaded: false` with an `error` field and
`model_version: rainfall-xgb-v3`; predictions then fall back to the demo
engine and carry DEMO badges, so nothing is ever labelled MODEL under a
wrong version.

## 4. Provenance checks (demo server, port 8001)

Forecast (`/api/forecast`, 24 h):

| Location | MODEL | DEMO | model_version on MODEL points |
|---|---|---|---|
| patia (Bhubaneswar East) | 6 (hours 1–6) | 18 (hours 7+) | `rainfall-xgb-v3.3` (all 6) |
| brahmapur (Ganjam) | 0 | 24 | — (no `model_version` anywhere) |

Risk (`/api/risk/records`, 25 records per location):

| Location | MODEL | DEMO |
|---|---|---|
| old-town / patia (Bhubaneswar region) | 3 (offsets 0/3/6) | 22 |
| brahmapur (Ganjam) | 0 | 25 |

`/api/risk/all`: 42 MODEL (14 Bhubaneswar-region locations × 3) + 483 DEMO.
Ganjam locations are always DEMO — never labelled v3.3.

### Frontend badges (Playwright, vite :5173 → API :8001)

| Page | Location | MODEL | DEMO | UNKNOWN | MODEL badge titles |
|---|---|---|---|---|---|
| Rainfall Forecast | Old Town | 7 | 20 | 0 | `ML model`, `ML model rainfall-xgb-v3.3` |
| Rainfall Forecast | Brahmapur | 0 | 26 | 0 | — |
| Flood Intelligence | Old Town | 5 | 8 | 0 | `ML model`, `ML model rainfall-xgb-v3.3` |
| Flood Intelligence | Brahmapur | 0 | 12 | 0 | — |

Counts are page-wide (header mix badge + per-row/detail badges). The header
shows one badge per kind present; the footer names the actual serving model
(`rainfall-xgb-v3.3`) for the Bhubaneswar grid cell. Zero UNKNOWN badges in
all four states — provenance metadata was present throughout.
Screenshots: `~/workspace/v33-demo-screenshots/` (`forecast.png`,
`forecast-brahmapur.png`, `flood-intelligence-bhubaneswar.png`,
`flood-intelligence-brahmapur.png`).

## 5. Production and rollback (verified after demo servers stopped)

- Only port 8000 listening afterwards; 8001/8002/vite stopped.
- `/api/health` on 8000: API 1.3.0, `rainfall-xgb-v3`, loaded: True.
- `backend/.env` contains no `MODEL_VERSION` (production default v3).

## 6. Validation slide (added to the deck)

Deck: `workspace/user/files/Wanda_Maximoff_RAINWATCH_AI_HackKalp.pptx` —
now **6 slides** (max 7). The validation slide is new slide 5, numbered 04;
References renumbered 04 → 05. Fresh 6-page PDF saved alongside the deck
(the Drive copy still holds the 5-slide version — re-upload needs Kam's go).
Backup of the 5-slide deck:
`workspace/goals/hack-kalp-2026-entry/hidden_files/Wanda_Maximoff_RAINWATCH_AI_HackKalp.backup-20261124.pptx`.
Render-checked with LibreOffice (no overlaps, no clipping).

Slide content (all numbers from `docs/IMD_DAILY_VALIDATION.md`):

1. **It tracks real rain** — daily totals vs independent IMD daily gridded
   rainfall, Bhubaneswar 2025 (n = 365): r = 0.58, MAE 4.09 mm, beats
   persistence (r = 0.37), matches raw ERA5 (r = 0.54); P90 envelope covered
   94% of days. Includes the report's metrics table (MAE / r / wet-day F1 /
   Watch) and the wide scatter chart.
2. **Alerts fire, amounts don't** — Watch flagged all 9 observed days
   ≥ 50 mm across 2024–2025, including 3 Jun 2024 (101.5 mm), which the
   amount forecast scored at 5.5 mm. Early-warning signal, not an amount
   forecast; **no lead-time claim** (stated on the slide).
3. **Limits, measured** — amount forecast never exceeded 30.8 mm/day;
   monsoon totals ~22% high; validation is Bhubaneswar-only; every other
   location in the demo is labelled DEMO / synthetic, never v3.3 predictions.

Small print on the slide: source is **IMD 0.25° daily gridded rainfall
(Pai et al. 2014)** — independent of ERA5. Bhubaneswar only; daily totals,
not 3 h / 6 h accuracy. Amount forecasts compress extremes.

**Source-labelling correction (Kam, 2026-11-24):** the validation report
previously called the source "gauge data" in several places. It now says
**IMD daily gridded rainfall data** throughout (7 edits in
`docs/IMD_DAILY_VALIDATION.md`); the gauge-interpolated construction
(6,955 gauges, Pai et al. 2014) is stated as how the product is built, not
as the source identity.

## 7. Failed tests and limitations

- **References slide title wraps in the LibreOffice render** (pre-existing
  66 pt nit, same class as slide 4's known nit; font-metrics dependent).
  Not changed — it was already like this before the new slide was added.
- **True v3.3 load-failure branch not empirically triggered** (see §3).
- **Charts animate in:** a screenshot taken immediately after load shows
  empty chart areas; they render fully after ~10 s. Wait for a settled view
  before screenshotting during the demo.
- One console error in the headless run: an external resource failed to load
  (`ERR_TUNNEL_CONNECTION_FAILED`, a font fetch on this VM). Cosmetic; not
  API-related.
- The demo runs from this machine (local processes, not a deployment) —
  per the no-deploy instruction. For the finale, start the two commands in
  §1 on the demo machine; if the demo server ever fails to start, the
  production server on 8000 (v3) is the fallback, and the badges will say so.

## 8. Recommendation

**The demo is ready to run with v3.3 as the primary model**, v3.2 as the
benchmark (available via `MODEL_VERSION=rainfall-xgb-v3.2`), and v3 as
production/rollback. Present v3.3 as an early-warning signal with the
precision numbers on the slide; do not present daily metrics as 3 h/6 h
validation, do not claim statewide performance, and do not switch
production to v3.3 (the production bar — a validated improvement on
3 h ≥ 10 mm — is still not met).
