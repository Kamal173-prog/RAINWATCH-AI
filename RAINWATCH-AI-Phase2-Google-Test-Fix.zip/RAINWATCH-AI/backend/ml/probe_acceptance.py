"""FINAL ACCEPTANCE probe — fresh browser session, all routes, interactions.

Reads the demo config (API :8001 v3.3, vite :5173). Records per-page:
render, h1, console errors, failed requests, badge counts, zero-height
charts, plus interactions (location switch, CSV export, simulator run,
sidebar navigation). Writes JSON + screenshots to OUT.
"""
import json
import os
import re
import time

from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:5173"
OUT = "/home/hatch/workspace/acceptance-screenshots"
CHROME = "/home/hatch/.cache/ms-playwright/chromium-1255/chrome-linux64/chrome"

os.makedirs(OUT, exist_ok=True)

ROUTES = [
    ("/", "Landing"),
    ("/overview", "Overview"),
    ("/live-weather", "Live Weather"),
    ("/forecast", "Rainfall Forecast"),
    ("/flood-intelligence", "Flood Intelligence"),
    ("/map", "Inundation Map"),
    ("/simulator", "What-If Simulator"),
    ("/alerts", "Early Warning Alerts"),
    ("/historical", "Historical Analysis"),
    ("/data-sources", "Data Sources"),
    ("/settings", "Settings"),
]

results = {}


def badge_counts(page):
    """Exact-text badge elements (the Badge component renders its label)."""
    out = {}
    for label in ("MODEL", "DEMO", "UNKNOWN"):
        out[label] = page.get_by_text(label, exact=True).count()
    return out


def zero_height_charts(page):
    """Recharts ResponsiveContainers rendered at 0 px height (the old
    Historical-trend bug class). Returns their count and titles."""
    return page.evaluate(
        """() => {
          const bad = [];
          document.querySelectorAll('.recharts-responsive-container').forEach(el => {
            const r = el.getBoundingClientRect();
            if (r.height === 0) {
              const card = el.closest('[class*=\"card\"], section, div');
              bad.push((card && card.querySelector('h3, h2') || {}).textContent || 'unknown chart');
            }
          });
          return bad;
        }"""
    )


def check_route(page, path, name):
    errors, failed = [], []
    page.on("pageerror", lambda e: errors.append(str(e)[:200]))
    page.on("console", lambda m: errors.append(f"console.{m.type}: {m.text[:200]}") if m.type == "error" else None)
    page.on("response", lambda r: failed.append(f"{r.status} {r.url[:120]}") if r.status >= 400 else None)
    page.on("requestfailed", lambda r: failed.append(f"FAILED {r.url[:120]}: {r.failure}"))
    t0 = time.time()
    page.goto(f"{BASE}{path}", wait_until="networkidle")
    page.wait_for_timeout(10000)  # charts animate in
    load_ms = int((time.time() - t0) * 1000)
    h1 = page.locator("h1").first.inner_text() if page.locator("h1").count() else "(no h1)"
    body_len = len(page.locator("body").inner_text())
    detail = {
        "h1": h1,
        "body_chars": body_len,
        "load_ms": load_ms,
        "badges": badge_counts(page),
        "zero_height_charts": zero_height_charts(page),
        "console_errors": errors,
        "failed_requests": failed,
    }
    # Filter out the known sandbox-only noise: OSM tile loads fail here
    # (no external internet for tiles) and the font fetch tunnel error.
    detail["failed_requests"] = [
        f for f in failed
        if "tile.openstreetmap.org" not in f and "ERR_TUNNEL_CONNECTION_FAILED" not in f
    ]
    detail["console_errors"] = [
        e for e in errors if "ERR_TUNNEL_CONNECTION_FAILED" not in e and "tile.openstreetmap" not in e
    ]
    page.screenshot(path=f"{OUT}/{name.lower().replace(' ', '-')}.png", full_page=True)
    results[name] = detail
    ok = body_len > 500 and not detail["zero_height_charts"] and not detail["console_errors"] and not detail["failed_requests"]
    print(f"{'PASS' if ok else 'CHECK'} {name}: h1={h1!r} load={load_ms}ms badges={detail['badges']} zero-charts={detail['zero_height_charts']} console={len(detail['console_errors'])} failed={len(detail['failed_requests'])}")
    return detail


def set_location(page, name):
    sel = page.locator("select").first
    options = sel.locator("option").all_inner_texts()
    match = [o for o in options if o == name or o.startswith(name + " ")]
    assert match, f"no location option for {name}: {options}"
    sel.select_option(label=match[0])
    page.wait_for_timeout(8000)


def main():
    with sync_playwright() as pw:
        browser = pw.chromium.launch(executable_path=CHROME)
        ctx = browser.new_context(viewport={"width": 1440, "height": 900})
        page = ctx.new_page()

        # --- All routes, fresh session ---
        for path, name in ROUTES:
            check_route(page, path, name)

        # --- Forecast interactions (back on /forecast, Old Town) ---
        page.goto(f"{BASE}/forecast", wait_until="networkidle")
        page.wait_for_timeout(8000)
        body = page.locator("body").inner_text()
        assert "Single grid cell" in body, "forecast grid-cell note missing"
        assert "including Cuttack and Puri" in body, "forecast note must name Cuttack and Puri"
        # CSV export
        with page.expect_download() as dl:
            page.get_by_text("Export CSV", exact=True).first.click()
        dl.value.save_as("/tmp/acc-forecast.csv")
        lines = open("/tmp/acc-forecast.csv").read().strip().split("\n")
        src_idx = lines[0].split(",").index("Source") if "Source" in lines[0] else -1
        srcs = [l.split(",")[src_idx] for l in lines[1:] if src_idx >= 0]
        print(f"INTERACTION forecast CSV: {len(lines)-1} rows, header has Source={src_idx>=0}, model={srcs.count('model')} demo={srcs.count('demo')}")
        results["interaction-forecast-csv"] = {"rows": len(lines) - 1, "model": srcs.count("model"), "demo": srcs.count("demo")}
        # Switch to Cuttack: MODEL badges stay, note stays
        set_location(page, "Cuttack")
        body = page.locator("body").inner_text()
        assert "Single grid cell" in body
        print(f"INTERACTION forecast Cuttack badges: {badge_counts(page)}")
        results["interaction-forecast-cuttack"] = {"badges": badge_counts(page)}
        # Switch to Brahmapur: MODEL 0
        set_location(page, "Brahmapur")
        print(f"INTERACTION forecast Brahmapur badges: {badge_counts(page)}")
        results["interaction-forecast-brahmapur"] = {"badges": badge_counts(page)}

        # --- Flood interactions ---
        page.goto(f"{BASE}/flood-intelligence", wait_until="networkidle")
        page.wait_for_timeout(8000)
        set_location(page, "Cuttack")
        body = page.locator("body").inner_text()
        assert "single Bhubaneswar grid cell" in body, "flood disclaimer must name the grid cell"
        print(f"INTERACTION flood Cuttack badges: {badge_counts(page)}")
        results["interaction-flood-cuttack"] = {"badges": badge_counts(page)}

        # --- Historical interactions ---
        page.goto(f"{BASE}/historical", wait_until="networkidle")
        page.wait_for_timeout(8000)
        body = page.locator("body").inner_text()
        m = re.search(r"(\d+) days in range", body)
        print(f"INTERACTION historical Old Town days in range: {m.group(1) if m else 'NOT FOUND'}")
        results["interaction-historical"] = {"days_in_range": int(m.group(1)) if m else 0}
        with page.expect_download() as dl:
            page.get_by_text("Export CSV", exact=True).first.click()
        dl.value.save_as("/tmp/acc-historical.csv")
        hlines = open("/tmp/acc-historical.csv").read().strip().split("\n")
        print(f"INTERACTION historical CSV: {len(hlines)-1} rows, header: {hlines[0][:120]}")
        results["interaction-historical-csv"] = {"rows": len(hlines) - 1, "header": hlines[0]}

        # --- Simulator interaction ---
        page.goto(f"{BASE}/simulator", wait_until="networkidle")
        page.wait_for_timeout(8000)
        api_calls = []
        page.on("response", lambda r: api_calls.append(r.url) if "/api/simulate" in r.url else None)
        page.get_by_text("Run Simulation", exact=True).first.click()
        page.wait_for_timeout(5000)
        body = page.locator("body").inner_text()
        print(f"INTERACTION simulator: /api/simulate called={any('/api/simulate' in u for u in api_calls)}, result visible={'Scenario prism' in body or 'risk index' in body.lower()}")
        results["interaction-simulator"] = {"api_called": any("/api/simulate" in u for u in api_calls)}

        # --- Sidebar navigation: click through 4 links ---
        page.goto(f"{BASE}/overview", wait_until="networkidle")
        page.wait_for_timeout(6000)
        nav_ok = []
        for label, expect in [("Rainfall Forecast", "/forecast"), ("Flood Intelligence", "/flood-intelligence"),
                              ("Data Sources", "/data-sources"), ("Settings", "/settings")]:
            page.get_by_text(label, exact=True).first.click()
            page.wait_for_timeout(4000)
            nav_ok.append((label, page.url.endswith(expect)))
        print(f"INTERACTION sidebar nav: {nav_ok}")
        results["interaction-sidebar-nav"] = {"links": nav_ok}

        # --- Topbar health dot tooltip ---
        page.goto(f"{BASE}/overview", wait_until="networkidle")
        page.wait_for_timeout(6000)
        tooltip = page.locator("[title*='Backend']").first.get_attribute("title") if page.locator("[title*='Backend']").count() else None
        print(f"INTERACTION topbar health tooltip: {tooltip!r}")
        results["interaction-topbar"] = {"tooltip": tooltip}

        browser.close()

    with open(f"{OUT}/probe_results.json", "w") as f:
        json.dump(results, f, indent=2)
    print("WROTE", f"{OUT}/probe_results.json")


if __name__ == "__main__":
    main()
