import { classifyRisk } from '../utils/colors'
import { clamp, createRng, hashSeed, round } from '../utils/rng'
import { getDemoTick } from '../services/demoState'
import type { FloodRiskRecord, RiskLevel } from '../types'
import { LOCATIONS, getLocation } from './locationsData'
import { getRainfallSeries, hourAlignedNow, offsetIndex } from './rainfallData'

/* ------------------------------------------------------------------
   Illustrative flood-risk records (DEMO DATA).
   A transparent, deterministic formula combines rainfall, terrain,
   drainage and river proximity into a 0–100 index.  This is a
   teaching model for the UI — NOT a validated prediction.
------------------------------------------------------------------ */

export const RISK_STEPS_H = 3
export const RISK_HORIZON_H = 72

let cache: { tick: number; records: FloodRiskRecord[] } | null = null

export function computeRiskRecord(
  locationId: string,
  offsetH: number,
  tick = getDemoTick(),
): FloodRiskRecord {
  const loc = getLocation(locationId)
  const series = getRainfallSeries(locationId)
  const mm = series.mmHr[offsetIndex(offsetH)] ?? 0
  const rng = createRng(hashSeed(locationId) ^ Math.imul(tick + 3, 0xc2b2ae35) ^ offsetH)

  const wobble = (rng() - 0.5) * 6

  const rainfallContribution = clamp(mm * 1.35, 0, 46)
  const terrainContribution = clamp(
    loc.lowLyingPct * 0.3 + Math.max(0, 46 - loc.elevationM) * 0.45,
    0,
    26,
  )
  const riverFactor = clamp(
    loc.riverProximity * 0.22 * (0.72 + mm / 150 + (rng() * 0.18)),
    0,
    24,
  )
  const drainageRelief = (loc.drainageEfficiency / 100) * 16

  const riskIndex = round(
    clamp(rainfallContribution + terrainContribution + riverFactor - drainageRelief + wobble, 2, 99),
    1,
  )
  const riskLevel: RiskLevel = classifyRisk(riskIndex)

  const total = rainfallContribution + terrainContribution + riverFactor + 0.001
  const populationAtRisk = Math.round(
    loc.population *
      clamp((riskIndex / 100) * (loc.lowLyingPct / 100) * 2.6, 0.02, 0.88),
  )
  const inundationDepthM = round(
    clamp((riskIndex / 100) ** 1.7 * 1.9 * (0.6 + loc.lowLyingPct / 130), 0, 3.4),
    2,
  )
  const areaInundatedHa = Math.round(
    clamp((loc.lowLyingPct / 100) * 740 * (riskIndex / 100), 4, 720),
  )

  const base = hourAlignedNow()

  return {
    locationId,
    timestamp: new Date(base.getTime() + offsetH * 3600_000).toISOString(),
    riskIndex,
    riskLevel,
    populationAtRisk,
    lowLyingPct: loc.lowLyingPct,
    drainageScore: loc.drainageEfficiency,
    rainfallContribution: round((rainfallContribution / total) * 100, 1),
    terrainContribution: round((terrainContribution / total) * 100, 1),
    riverContribution: round((riverFactor / total) * 100, 1),
    inundationDepthM,
    areaInundatedHa,
  }
}

/** Every location at 3-hour steps across the 72 h horizon. */
export function getAllRiskRecords(): FloodRiskRecord[] {
  const tick = getDemoTick()
  if (cache && cache.tick === tick) return cache.records

  const records: FloodRiskRecord[] = []
  for (const loc of LOCATIONS) {
    for (let h = 0; h <= RISK_HORIZON_H; h += RISK_STEPS_H) {
      records.push(computeRiskRecord(loc.id, h, tick))
    }
  }
  cache = { tick, records }
  return records
}

export interface RiskFilter {
  locationId?: string
  level?: RiskLevel
  /** Horizon window in hours: 6 | 24 | 72 */
  horizonH?: number
}

export function getFilteredRiskRecords(filter: RiskFilter = {}): FloodRiskRecord[] {
  const horizon = filter.horizonH ?? 72
  return getAllRiskRecords().filter((r) => {
    const offset = (new Date(r.timestamp).getTime() - hourAlignedNow().getTime()) / 3600_000
    if (offset > horizon) return false
    if (filter.locationId && r.locationId !== filter.locationId) return false
    if (filter.level && r.riskLevel !== filter.level) return false
    return true
  })
}

/** Worst record per location inside the horizon (for KPIs + tables). */
export function getWorstRiskPerLocation(horizonH = 72): FloodRiskRecord[] {
  const worst = new Map<string, FloodRiskRecord>()
  for (const r of getFilteredRiskRecords({ horizonH })) {
    const prev = worst.get(r.locationId)
    if (!prev || r.riskIndex > prev.riskIndex) worst.set(r.locationId, r)
  }
  return [...worst.values()].sort((a, b) => b.riskIndex - a.riskIndex)
}

export function getOverallRiskIndex(horizonH = 24): number {
  const records = getFilteredRiskRecords({ horizonH })
  if (!records.length) return 0
  return round(
    records.reduce((sum, r) => sum + r.riskIndex, 0) / records.length,
    1,
  )
}

export function getRiskDistribution(horizonH = 24): Array<{ level: RiskLevel; count: number }> {
  const levels: RiskLevel[] = ['Low', 'Moderate', 'High', 'Very High', 'Critical']
  const records = getFilteredRiskRecords({ horizonH })
  return levels.map((level) => ({
    level,
    count: records.filter((r) => r.riskLevel === level).length,
  }))
}

export function getVulnerableZones(threshold = 60): FloodRiskRecord[] {
  return getWorstRiskPerLocation(72).filter((r) => r.riskIndex >= threshold)
}
