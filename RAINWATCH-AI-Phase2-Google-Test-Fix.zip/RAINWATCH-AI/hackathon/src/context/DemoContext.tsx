import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react'
import { demoApi } from '../services/dataService'
import type { SimulatorResult } from '../types'

export interface ScenarioState {
  /** Increments on every run so the map can react to a fresh result. */
  id: number
  result: SimulatorResult
}

interface DemoContextValue {
  /** Bump whenever demo data is regenerated — pass into useAsyncData deps. */
  version: number
  refreshing: boolean
  refresh: () => Promise<void>
  /** Latest what-if result, shared with the inundation map. */
  scenario: ScenarioState | null
  setScenario: (result: SimulatorResult) => void
  clearScenario: () => void
}

const DemoContext = createContext<DemoContextValue | null>(null)

export function DemoProvider({ children }: { children: ReactNode }) {
  const [version, setVersion] = useState(0)
  const [refreshing, setRefreshing] = useState(false)
  const [scenario, setScenarioState] = useState<ScenarioState | null>(null)

  const refresh = useCallback(async () => {
    setRefreshing(true)
    try {
      await demoApi.refreshDemoData()
      setVersion((v) => v + 1)
    } finally {
      setRefreshing(false)
    }
  }, [])

  const setScenario = useCallback((result: SimulatorResult) => {
    setScenarioState((prev) => ({ id: (prev?.id ?? 0) + 1, result }))
  }, [])

  const clearScenario = useCallback(() => setScenarioState(null), [])

  const value = useMemo(
    () => ({ version, refreshing, refresh, scenario, setScenario, clearScenario }),
    [version, refreshing, refresh, scenario, setScenario, clearScenario],
  )

  return <DemoContext.Provider value={value}>{children}</DemoContext.Provider>
}

export function useDemo(): DemoContextValue {
  const ctx = useContext(DemoContext)
  if (!ctx) throw new Error('useDemo must be used inside <DemoProvider>')
  return ctx
}
