"""Independent IMD daily validation of the frozen RAINWATCH AI models.

Compares frozen-model predictions against IMD 0.25-degree daily gridded
rainfall (gauge-interpolated, independent of ERA5) at Bhubaneswar — the only
location the frozen models predict. Other locations have no model prediction
(the API serves synthetic demo values there), so they appear only as IMD
observed context.

Day convention (verified, see backend/data/research/check_imd_alignment.py):
IMD daily value labelled date D is the 24 h accumulation ending 08:30 IST
(03:00 UTC) on D, i.e. the window [08:30 IST D-1, 08:30 IST D), per
Pai et al. (2014). The model tables are tz-naive IST wall-clock.

Daily forecast construction (no overlapping windows):
  IMD day D <- four non-overlapping 6 h forecasts issued at 09:00, 15:00,
  21:00 IST on D-1 and 03:00 IST on D. Each 6 h forecast covers the 6 h
  after its issue time, so the four windows tile [09:00 D-1, 09:00 D) IST
  — the true IMD window shifted +30 min (documented approximation: the
  hourly tables cannot resolve 08:30 starts).
  daily_total = sum of the four 6 h regression predictions (shared v3
  regressors — identical for v3, v3.2, v3.3; see ml/predict.py).
  Daily classifier signal per version = max calibrated P(6h >= 10 mm)
  over the same four issue times (3 h signals use eight 3 h-spaced issues).

Windows: 2025 is PRIMARY (test year for v3/v3.2; benchmark year for v3.3 —
v3.3 was selected using 2025 PR-AUC, so its 2025 numbers carry a selection
caveat). 2024 is SUPPLEMENTARY and labelled non-independent (weights,
Platt and thresholds were fitted on 2024). 2026 is never touched: the IMD
file ends 2025-12-31 and 2026 is reserved.

No retraining, no threshold changes, no production changes. Read-only
with respect to every model artifact.

Run (backend venv — it holds xgboost/lightgbm):
  .venv/bin/python ml/validate_imd_daily.py
Outputs:
  data/research/processed/validate_imd_daily.csv  (daily frame)
  docs/imd_validation/metrics.json               (all metrics)
"""
import json
import logging
import os
import sys
from datetime import datetime

import joblib
import lightgbm as lgb
import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.metrics import average_precision_score, brier_score_loss

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v33_common import platt_apply  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger("validate_imd_daily")

BACKEND = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RESEARCH = os.path.join(BACKEND, "data", "research")
OUT_DIR = os.path.join(BACKEND, "docs", "imd_validation")
os.makedirs(OUT_DIR, exist_ok=True)

TARGETS = ["y_3h_ge_10mm", "y_6h_ge_10mm", "y_3h_ge_5mm"]
FAMILIES = ("xgb", "lgbm", "hgb")
YEARS = {"2025": "primary (test year v3/v3.2; benchmark year v3.3 — selection caveat applies)",
         "2024": "supplementary (validation year — weights/Platt/thresholds fitted on 2024, not independent)"}

# IMD day D (label) <- issue times 09:00, 15:00, 21:00 on D-1 and 03:00 on D (IST).
ISSUE_HOURS_DMINUS1 = (9, 15, 21)
ISSUE_HOUR_D = 3
# 3 h classifier signal uses eight 3 h-spaced issues tiling the same window.
ISSUE_3H = [( -1, h) for h in (9, 12, 15, 18, 21)] + [(0, h) for h in (0, 3, 6)]

VERSIONS = [
    ("v3", os.path.join(BACKEND, "models", "rainfall_xgb_v3"),
     os.path.join(BACKEND, "data", "model_ready", "bhubaneswar_features.csv"),
     "thresholds.json"),
    ("v3.2", os.path.join(BACKEND, "models", "rainfall_xgb_v3_2"),
     os.path.join(BACKEND, "data", "model_ready", "bhubaneswar_features_v32.csv"),
     "thresholds.json"),
    ("v3.3", os.path.join(BACKEND, "models", "rainfall_xgb_v3_3", "frozen"),
     os.path.join(BACKEND, "data", "model_ready", "bhubaneswar_features_v33.csv"),
     "thresholds_optimized.json"),
]


def _norm_key(key: str) -> str:
    return key[4:] if key.startswith("clf_") else key


def _lookup(d: dict, key: str):
    if key in d:
        return d[key]
    short = key[4:] if key.startswith("clf_") else key
    if short in d:
        return d[short]
    raise KeyError(key)


def _unwrap_threshold(t):
    if isinstance(t, dict):
        return float(t["threshold"])
    return float(t)


def _load_member(model_dir: str, stem: str, fam: str):
    if fam == "xgb":
        p = os.path.join(model_dir, stem + ".json")
        bst = xgb.Booster()
        bst.load_model(p)
        return ("xgb", bst)
    if fam == "lgbm":
        return ("lgbm", lgb.Booster(model_file=os.path.join(model_dir, stem + ".txt")))
    return ("hgb", joblib.load(os.path.join(model_dir, stem + ".pkl")))


def _predict(model, X: np.ndarray, is_classifier: bool = False) -> np.ndarray:
    kind, m = model
    if kind == "xgb":
        return m.predict(xgb.DMatrix(X))
    if kind == "lgbm":
        return m.predict(X)
    if is_classifier:
        return m.predict_proba(X)[:, 1]
    return m.predict(X)


def _ensemble_predict_members(members, weights, X, is_classifier: bool = False):
    out = np.zeros(len(X))
    for fam, model in members.items():
        w = float(weights.get(fam, 0.0))
        if w:
            out += w * _predict(model, X, is_classifier=is_classifier)
    return out


def score_regressor_6h_and_p90():
    """Shared v3 regressors: 6 h expected mm and 6 h P90 at every v3-table hour."""
    model_dir = os.path.join(BACKEND, "models", "rainfall_xgb_v3")
    feats = json.load(open(os.path.join(model_dir, "feature_schema.json")))["features"]
    weights = json.load(open(os.path.join(model_dir, "ensemble_weights.json")))
    df = pd.read_csv(os.path.join(BACKEND, "data", "model_ready",
                                  "bhubaneswar_features.csv"),
                     parse_dates=["timestamp"])
    X = df[feats].to_numpy(dtype=float)
    out = pd.DataFrame({"timestamp": df["timestamp"]})
    for kind, wkey in (("reg_6h", "reg_6h"), ("p90_6h", "p90_6h")):
        members = {fam: _load_member(model_dir, f"{kind}_{fam}", fam) for fam in FAMILIES}
        pred = _ensemble_predict_members(members, weights[wkey], X)
        out["pred_6h" if kind == "reg_6h" else "p90_6h"] = np.clip(pred, 0, None)
    log.info("regressors scored on %d v3-table rows", len(out))
    return out


def score_classifiers(name, model_dir, table_path, schema_path):
    """Calibrated classifier probabilities per hour for one version."""
    feats = json.load(open(schema_path))["features"]
    weights = {_norm_key(k): v for k, v in
               json.load(open(os.path.join(model_dir, "ensemble_weights.json"))).items()}
    platt = json.load(open(os.path.join(model_dir, "platt.json")))
    df = pd.read_csv(table_path, parse_dates=["timestamp"])
    df = df[df["timestamp"] < "2026-01-01"].reset_index(drop=True)  # never touch 2026
    X = df[feats].to_numpy(dtype=float)
    out = pd.DataFrame({"timestamp": df["timestamp"]})
    for target in TARGETS:
        ens = np.zeros(len(df))
        for fam in FAMILIES:
            w = float(weights[target][fam])
            if w == 0:
                continue
            base = target.replace("y_", "")
            model = None
            for stem in (f"clf_{base}_{fam}", f"clf_y_{base}_{fam}"):
                p = os.path.join(model_dir, stem + (".json" if fam == "xgb" else
                                                    ".txt" if fam == "lgbm" else ".pkl"))
                if os.path.exists(p):
                    model = _load_member(model_dir, stem, fam)
                    break
            if model is None:
                raise FileNotFoundError(f"no member for {target}/{fam} in {model_dir}")
            ens += w * _predict(model, X, is_classifier=True)
        pl = platt[target]
        out[f"p_{target}"] = platt_apply(ens, float(pl["w"]), float(pl["b"]))
    log.info("%s classifiers scored on %d rows (%s)", name, len(out), table_path)
    return out


def load_thresholds(name, model_dir, fname):
    raw = json.load(open(os.path.join(model_dir, fname)))
    out = {}
    for target in TARGETS:
        out[target] = {lvl: _unwrap_threshold(raw[target][lvl])
                       for lvl in ("elevated", "high")}
    log.info("%s thresholds from %s: %s", name, fname, out)
    return out


def build_daily_frame(reg, clf_by_version, thresholds, era5_hourly, imd_bbsr):
    """Assemble the daily frame for 2024-2025 IMD dates at Bhubaneswar."""
    reg_idx = reg.set_index("timestamp")
    clf_idx = {v: c.set_index("timestamp") for v, c in clf_by_version.items()}
    era_idx = era5_hourly.set_index("timestamp")["precipitation_mm"]
    imd_idx = imd_bbsr.set_index("date")["rainfall_mm"]

    rows = []
    missing = {"reg": 0, "clf": {v: 0 for v in clf_idx}, "era5": 0}
    for date in pd.date_range("2024-01-01", "2025-12-31"):
        d = date.date()
        dminus = (date - pd.Timedelta(days=1)).date()
        issue6 = [pd.Timestamp(dminus) + pd.Timedelta(hours=h) for h in ISSUE_HOURS_DMINUS1]
        issue6.append(pd.Timestamp(d) + pd.Timedelta(hours=ISSUE_HOUR_D))
        issue3 = ([pd.Timestamp(dminus) + pd.Timedelta(hours=h) for _, h in ISSUE_3H[:5]]
                  + [pd.Timestamp(d) + pd.Timedelta(hours=h) for _, h in ISSUE_3H[5:]])
        row = {"date": pd.Timestamp(d), "imd_mm": float(imd_idx.get(pd.Timestamp(d), np.nan))}
        # Regression daily total: sum of the four non-overlapping 6 h forecasts.
        try:
            preds = [float(reg_idx.at[t, "pred_6h"]) for t in issue6]
            p90s = [float(reg_idx.at[t, "p90_6h"]) for t in issue6]
            row["model_daily_mm"] = float(sum(preds))
            row["model_p90_daily_mm"] = float(sum(p90s))
        except KeyError:
            missing["reg"] += 1
            row["model_daily_mm"] = np.nan
            row["model_p90_daily_mm"] = np.nan
        # ERA5 reference daily total over the same window (24 hourly values).
        era_hours = pd.date_range(pd.Timestamp(dminus) + pd.Timedelta(hours=9),
                                  pd.Timestamp(d) + pd.Timedelta(hours=8), freq="h")
        try:
            row["era5_daily_mm"] = float(era_idx.loc[era_hours].sum())
        except KeyError:
            missing["era5"] += 1
            row["era5_daily_mm"] = np.nan
        # Classifier daily signals per version.
        for v, cidx in clf_idx.items():
            try:
                p6 = [float(cidx.at[t, "p_y_6h_ge_10mm"]) for t in issue6]
                p3_10 = [float(cidx.at[t, "p_y_3h_ge_10mm"]) for t in issue3]
                p3_5 = [float(cidx.at[t, "p_y_3h_ge_5mm"]) for t in issue3]
                row[f"{v}_maxp_6h10"] = float(max(p6))
                row[f"{v}_maxp_3h10"] = float(max(p3_10))
                row[f"{v}_maxp_3h5"] = float(max(p3_5))
                t6 = thresholds[v]["y_6h_ge_10mm"]
                t3 = thresholds[v]["y_3h_ge_10mm"]
                row[f"{v}_fire6_elev"] = int(max(p6) >= t6["elevated"])
                row[f"{v}_fire6_high"] = int(max(p6) >= t6["high"])
                row[f"{v}_fire3_elev"] = int(max(p3_10) >= t3["elevated"])
                row[f"{v}_fire3_high"] = int(max(p3_10) >= t3["high"])
            except KeyError:
                missing["clf"][v] += 1
                for k in ("maxp_6h10", "maxp_3h10", "maxp_3h5",
                          "fire6_elev", "fire6_high", "fire3_elev", "fire3_high"):
                    row[f"{v}_{k}"] = np.nan
        rows.append(row)
    log.info("daily frame built; missing issue rows: %s", missing)
    frame = pd.DataFrame(rows)
    frame["persist_mm"] = frame["imd_mm"].shift(1)  # yesterday's IMD total
    return frame, missing


def _prf(y, pred):
    tp = int(((y == 1) & (pred == 1)).sum())
    fp = int(((y == 0) & (pred == 1)).sum())
    fn = int(((y == 1) & (pred == 0)).sum())
    tn = int(((y == 0) & (pred == 0)).sum())
    prec = tp / max(1, tp + fp)
    rec = tp / max(1, tp + fn)
    f1 = 2 * prec * rec / max(1e-9, prec + rec)
    return {"precision": round(prec, 4), "recall": round(rec, 4),
            "f1": round(f1, 4), "tp": tp, "fp": fp, "fn": fn, "tn": tn}


def _block_bootstrap_ci(values_fn, frame, n_boot=1000, seed=42):
    """7-day block bootstrap CI for a scalar computed by values_fn(frame)."""
    rng = np.random.default_rng(seed)
    idx = np.arange(len(frame))
    blocks = [idx[i:i + 7] for i in range(0, len(idx), 7)]
    base = values_fn(frame)
    boots = []
    for _ in range(n_boot):
        pick = rng.choice(len(blocks), size=len(blocks), replace=True)
        sel = np.concatenate([blocks[i] for i in pick])
        boots.append(values_fn(frame.iloc[sel]))
    lo, hi = np.percentile(boots, [2.5, 97.5])
    return {"estimate": round(float(base), 4), "ci95": [round(float(lo), 4), round(float(hi), 4)],
            "n_boot": n_boot}


def metrics_for_year(frame_year, label):
    y = frame_year["imd_mm"].to_numpy()
    out = {"n_days": int(len(frame_year)), "label": label,
           "observed": {"mean_mm": round(float(np.mean(y)), 3),
                        "total_mm": round(float(np.sum(y)), 1),
                        "days_ge_10mm": int((y >= 10).sum()),
                        "days_ge_50mm": int((y >= 50).sum()),
                        "days_ge_100mm": int((y >= 100).sum()),
                        "max_mm": round(float(np.max(y)), 1)}}
    # --- Daily totals: model (shared regressors), ERA5, persistence ---
    for col, name in (("model_daily_mm", "model_shared_regressors"),
                      ("era5_daily_mm", "era5_reference"),
                      ("persist_mm", "persistence_yesterday")):
        sub = frame_year.dropna(subset=[col])
        p = sub[col].to_numpy()
        o = sub["imd_mm"].to_numpy()
        err = p - o
        out[name] = {
            "n": int(len(sub)),
            "mae": round(float(np.mean(np.abs(err))), 3),
            "rmse": round(float(np.sqrt(np.mean(err ** 2))), 3),
            "bias": round(float(np.mean(err)), 3),
            "pearson_r": round(float(np.corrcoef(o, p)[0, 1]), 4),
            "spearman_rho": round(float(pd.Series(o).corr(pd.Series(p), method="spearman")), 4),
        }
        wet = o >= 1
        out[name]["mae_wet_days"] = round(float(np.mean(np.abs(err[wet]))), 3) if wet.sum() else None
        out[name]["rmse_wet_days"] = round(float(np.sqrt(np.mean(err[wet] ** 2))), 3) if wet.sum() else None
        jjas = sub["date"].dt.month.isin([6, 7, 8, 9]).to_numpy()
        out[name]["mae_jjas"] = round(float(np.mean(np.abs(err[jjas]))), 3) if jjas.sum() else None
        out[name]["pearson_r_jjas"] = (round(float(np.corrcoef(o[jjas], p[jjas])[0, 1]), 4)
                                       if jjas.sum() > 10 else None)
    # P90 daily envelope coverage (model only).
    sub = frame_year.dropna(subset=["model_p90_daily_mm"])
    out["model_p90_envelope"] = {
        "n": int(len(sub)),
        "coverage_obs_le_p90": round(float(np.mean(sub["imd_mm"] <= sub["model_p90_daily_mm"])), 4),
        "mean_p90_minus_obs_mm": round(float(np.mean(sub["model_p90_daily_mm"] - sub["imd_mm"])), 2),
    }
    # --- Events from the regression daily total ---
    out["events_regression_total"] = {}
    for thr in (10, 50, 100):
        sub = frame_year.dropna(subset=["model_daily_mm"])
        out["events_regression_total"][f"ge_{thr}mm"] = _prf(
            (sub["imd_mm"] >= thr).astype(int).to_numpy(),
            (sub["model_daily_mm"] >= thr).astype(int).to_numpy())
    # --- Classifier daily signals per version ---
    out["classifier_daily"] = {}
    for v in ("v3", "v3.2", "v3.3"):
        sig = out["classifier_daily"][v] = {}
        for obs_thr in (10, 50):
            yb = (frame_year["imd_mm"] >= obs_thr).astype(int).to_numpy()
            p = frame_year[f"{v}_maxp_6h10"].to_numpy()
            ok = ~np.isnan(p)
            sig[f"pr_auc_maxp6h10_vs_daily_ge_{obs_thr}"] = round(
                float(average_precision_score(yb[ok], p[ok])), 4)
            sig[f"brier_maxp6h10_vs_daily_ge_{obs_thr}"] = round(
                float(brier_score_loss(yb[ok], p[ok])), 4)
            for lvl, col in (("elevated", f"{v}_fire6_elev"), ("high", f"{v}_fire6_high")):
                pred = frame_year[col].fillna(0).astype(int).to_numpy()
                sig[f"anyfire6_{lvl}_vs_daily_ge_{obs_thr}"] = _prf(yb, pred)
        # 3 h detector any-fire vs daily >= 10 mm (secondary; its windows
        # cover only 12 of the 24 hours at the four block starts, 24 h at
        # the eight 3 h-spaced issues used here).
        yb = (frame_year["imd_mm"] >= 10).astype(int).to_numpy()
        for lvl, col in (("elevated", f"{v}_fire3_elev"), ("high", f"{v}_fire3_high")):
            pred = frame_year[col].fillna(0).astype(int).to_numpy()
            sig[f"anyfire3_{lvl}_vs_daily_ge_10"] = _prf(yb, pred)
    # --- Bootstrap CIs (model daily total) ---
    out["bootstrap_ci95"] = {
        "mae_model_daily": _block_bootstrap_ci(
            lambda f: float(np.mean(np.abs(f["model_daily_mm"] - f["imd_mm"]))),
            frame_year.dropna(subset=["model_daily_mm"])),
        "f1_regression_ge50": _block_bootstrap_ci(
            lambda f: _prf((f["imd_mm"] >= 50).astype(int).to_numpy(),
                           (f["model_daily_mm"] >= 50).astype(int).to_numpy())["f1"],
            frame_year.dropna(subset=["model_daily_mm"])),
    }
    return out


def per_location_imd(imd_all):
    """IMD observed context for all six cells (no model prediction outside
    Bhubaneswar — the API serves synthetic demo values there)."""
    out = {}
    for loc, sub in imd_all.groupby("location"):
        sub = sub.copy()
        sub["date"] = pd.to_datetime(sub["date"])
        for year in (2025, 2024):
            s = sub[sub["date"].dt.year == year]["rainfall_mm"]
            s = s.dropna()
            imax = s.idxmax()
            out.setdefault(loc, {})[str(year)] = {
                "grid_lat": float(sub["grid_lat"].iloc[0]),
                "grid_lon": float(sub["grid_lon"].iloc[0]),
                "n_days": int(len(s)),
                "annual_total_mm": round(float(s.sum()), 1),
                "mean_daily_mm": round(float(s.mean()), 3),
                "days_ge_1mm": int((s >= 1).sum()),
                "days_ge_10mm": int((s >= 10).sum()),
                "days_ge_50mm": int((s >= 50).sum()),
                "max_daily_mm": round(float(s.max()), 1),
                "date_of_max": str(sub.loc[imax, "date"].date()),
            }
    out["puri"]["note"] = ("Puri uses the nearest LAND cell (20.0N, 85.75E), "
                           "22.6 km inland — its nearest cell is ocean and "
                           "100% missing. Spatial approximation, not an exact match.")
    out["_note"] = ("Observed IMD only. The frozen models predict at Bhubaneswar "
                   "only; no model prediction exists at the other five cells, so "
                   "no model-vs-IMD comparison is possible there.")
    return out


def main():
    reg = score_regressor_6h_and_p90()
    clf_by_version, thresholds = {}, {}
    for name, model_dir, table_path, thr_file in VERSIONS:
        clf_by_version[name] = score_classifiers(
            name, model_dir, table_path,
            os.path.join(model_dir, "feature_schema.json"))
        thresholds[name] = load_thresholds(name, model_dir, thr_file)

    era5 = pd.read_csv(os.path.join(BACKEND, "data", "processed",
                                    "bhubaneswar_weather.csv"),
                       parse_dates=["timestamp"]).sort_values("timestamp")
    imd_all = pd.read_csv(os.path.join(RESEARCH, "processed",
                                       "odisha_imd_daily_2021_2025.csv"),
                          parse_dates=["date"])
    imd_bbsr = imd_all[imd_all["location"] == "bhubaneswar"].copy()

    frame, missing = build_daily_frame(reg, clf_by_version, thresholds, era5, imd_bbsr)
    frame_path = os.path.join(RESEARCH, "processed", "validate_imd_daily.csv")
    frame.to_csv(frame_path, index=False)
    log.info("saved %s (%d rows)", frame_path, len(frame))

    metrics = {
        "generated_ist": datetime.now().isoformat(timespec="seconds"),
        "imd_file": "data/research/raw/IMD_RF25_1901_2025_merged.nc (SHA-256 d102d52e…ae564c5)",
        "day_convention": ("IMD date D = 24 h ending 08:30 IST (03:00 UTC) on D, "
                           "window [08:30 IST D-1, 08:30 IST D), per Pai et al. (2014); "
                           "empirically confirmed: best ERA5 alignment shift 10 h IST, "
                           "r=0.601 vs IST-day r=0.498 and UTC-day r=0.459."),
        "issue_times_ist": "09:00, 15:00, 21:00 on D-1 and 03:00 on D; four non-overlapping "
                           "6 h forecasts tile [09:00 D-1, 09:00 D) IST — the true IMD "
                           "window shifted +30 min (hourly tables cannot resolve 08:30).",
        "regression_note": ("Daily totals use the SHARED v3 regressors (reg_6h: xgb 0.5, "
                            "lgbm 0.5); v3, v3.2 and v3.3 therefore share one daily-total "
                            "forecast. Versions differ only in their classifiers."),
        "missing_issue_rows": missing,
        "years": {y: metrics_for_year(frame[frame["date"].dt.year == int(y)], label)
                  for y, label in YEARS.items()},
        "per_location_imd": per_location_imd(imd_all),
    }
    out_path = os.path.join(OUT_DIR, "metrics.json")
    json.dump(metrics, open(out_path, "w"), indent=2)
    log.info("saved %s", out_path)
    for y in ("2025", "2024"):
        m = metrics["years"][y]["model_shared_regressors"]
        log.info("%s model daily: MAE %.3f RMSE %.3f bias %+.3f r %.3f (n=%d)",
                 y, m["mae"], m["rmse"], m["bias"], m["pearson_r"], m["n"])
        e = metrics["years"][y]["era5_reference"]
        log.info("%s ERA5 daily:  MAE %.3f RMSE %.3f bias %+.3f r %.3f",
                 y, e["mae"], e["rmse"], e["bias"], e["pearson_r"])


if __name__ == "__main__":
    main()
