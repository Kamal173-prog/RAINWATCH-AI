# RAINWATCH AI — Final End-to-End Acceptance Report

**Date:** 2026-11-24, 17:22–18:05 IST
**Scope:** verification only. No new features, no redesign, no retraining, no
threshold/data/API-contract changes, no deployment, no presentation or Drive
edits. No working code was changed to improve this report.
**Environment:** this VM. Backend `backend/.venv` (pytest 9.2.0, httpx 0.28.1).
Research/probe venv `backend/.venv-audit` (Playwright, Chromium 1255).
Frontend: vite dev server. Demo config per `HACKATHON_HANDOFF.md`:
backend `MODEL_VERSION=rainfall-xgb-v3.3` on :8001, frontend
`VITE_API_URL=http://localhost:8001` on :5173; production :8000 with no flag.

## Verdict

# PASS — ENGINEERING FREEZE APPROVED

Every critical workflow was exercised against the running system and works.
No release-blocking issue was found. The remaining items are documented
limitations and demo-day operating notes (§9–§10), none of which blocks the
finale on Thu 2026-11-26. **Do not change code, models, thresholds or data
after this point except to fix a release-blocking bug.**

## 1. Environment and startup

- At test start no servers were listening (the :8000 left running after the
  integrity check had died — consistent with a VM replacement between turns).
  `.env` has no `MODEL_VERSION`. No git repo (known, unchanged).
- Clean startup, first run:
  - production :8000 → API 1.3.0, `rainfall-xgb-v3`, `loaded: true`, dataset
    loaded: true.
  - demo :8001 (`MODEL_VERSION=rainfall-xgb-v3.3`) → API 1.3.0,
    `rainfall-xgb-v3.3`, `loaded: true`; first health request returned
    `loaded: true` after **9.1 s** (Stage 6 baseline 10.3 s — no regression).
  - vite :5173 → HTTP 200, title "RAINWATCH AI — Predict. Prepare. Protect."
- **A runtime/VM restart killed all three servers mid-test** (between the API
  checks and the browser probe; `/tmp` logs were wiped with it). All three
  were restarted cleanly and re-verified — second run: :8000 loaded after
  **8.9 s**, :8001 after **8.2 s**, vite HTTP 200. The restart is an
  environment property, not a product defect (see §10, demo-day note).
  Acceptance-run server logs live in `~/workspace/acceptance-logs/`
  (workspace, so they survive a restart).

## 2. Artifact integrity (frozen v3.3)

- **15/15 frozen files match `models/rainfall_xgb_v3_3/frozen/RELEASE_MANIFEST.json`
  SHA-256 + byte size** (verified at test start; manifest:
  model_version `rainfall-xgb-v3.3`, production_model
  "rainfall-xgb-v3 (unchanged; v3.3 is flag-gated, not deployed)").
  Frozen dir mtimes all 2026-11-23 (freeze date, nothing modified since).
- Thresholds confirmed unchanged (`thresholds_optimized.json`):
  3h ≥ 10 mm Watch 0.070 / Warning 0.125; 6h ≥ 10 mm 0.085 / 0.185;
  3h ≥ 5 mm 0.125 / 0.225. Selected on pooled out-of-sample 2024+2025 only.
- 2026 guard intact: `ml/validate_imd_daily.py:163` still filters to
  < 2026-01-01. The reserved 2026 evaluation period was not touched.
- `model_input_as_of` is ISO on both servers: `"2025-12-31T23:00:00Z"`
  (Stage 6 fix holds; the field is nested under `model` in `/api/health`).

## 3. Regression suite (actual results)

| Check | Result |
|---|---|
| Backend pytest (`backend/.venv/bin/python -m pytest -p no:warnings`) | **152 passed, 0 failed, in 60.00 s** |
| Frontend TypeScript (`tsc -b`) | **clean** |
| Production build (`vite build`) | **passes, 2.06 s** |

## 4. API prediction workflow (live, :8001 v3.3 unless noted)

Script: `backend/ml/acceptance_api_check.py`.

| Check | Observed |
|---|---|
| `GET /api/forecast?locationId=old-town&hours=24` | 24 points: **6 model + 18 demo**. Every model point carries `model_version: rainfall-xgb-v3.3` and nested `model` metadata (`expected_mm` per horizon, `upper_bound_p90_mm`, `heavy_rain_probability`). Sample model point: 0.0 mm/hr, P(3h ≥ 10 mm) = 0.001 (dry December evening — correct, not a bug). |
| `GET /api/forecast?locationId=brahmapur&hours=24` | 24/24 demo, no `model_version` anywhere. |
| `GET /api/forecast` cuttack, puri | 6 model points each, **byte-identical to old-town's MODEL points** (timestamp, rainfallMmHr, expected_mm) — the shared Bhubaneswar grid cell, confirmed at the API level. |
| `GET /api/risk/records?locationId=old-town&horizonH=72` | 25 records: 3 model + 22 demo. |
| `GET /api/risk/all` | 525 records: **42 model + 483 demo**. |
| `GET /api/data-sources` | Taxonomy correct: history = Historical dataset / **Archive**; 3 real-time observations, **none Live**; NWP = Forecast feed / Awaiting Integration. **No source has status "Live".** |
| `GET /api/forecast?locationId=old-town&hours=24` on :8000 (production) | 6 model points, version `rainfall-xgb-v3`. |
| v3.2 benchmark (`MODEL_VERSION=rainfall-xgb-v3.2` on spare :8002) | Loaded after 9.7 s, API 1.3.0, `rainfall-xgb-v3.2`, `loaded: true`. Stopped afterwards. |
| `/api/overview`, `/api/map/layers`, `/api/history/daily` (120 rows), `/api/alerts/upcoming` (16) | All respond correctly. |

Two HTTP 422s seen during setup were the probe author's own wrong query
parameter names (`location_id`/`horizon_hours` instead of the contract's
`locationId`/`hours`) — not product defects. The contract is unchanged.

## 5. Browser probe — all routes (fresh session)

Script: `backend/ml/probe_acceptance.py` (Playwright, Chromium, 1440×900).
Screenshots + `probe_results.json` in `~/workspace/acceptance-screenshots/`.

| Route | h1 | Body | Console errors | Failed API reqs | Zero-height charts | Badges (MODEL / DEMO / UNKNOWN) |
|---|---|---|---|---|---|---|
| Landing `/` | Predict. Prepare. Protect. | 3,276 ch | 0 | 0 | 0 | 0 / 1 / 0 |
| Overview `/overview` | Weather Intelligence Overview | 4,266 ch | 0 | 0 | 0 | 1 / 2 / 0 |
| Live Weather `/live-weather` | Live Weather | 3,139 ch | 0 | 0 | 0 | 0 / 1 / 0 |
| Rainfall Forecast `/forecast` | Rainfall Forecast | 4,790 ch | 0 | 0 | 0 | **7 / 20 / 0** |
| Flood Intelligence `/flood-intelligence` | Flood Intelligence | 3,753 ch | 0 | 0 | 0 | **5 / 8 / 0** |
| Inundation Map `/map` | Interactive Inundation Map | 3,132 ch | 0 | 0 | 0 | 0 / 1 / 0 |
| What-If Simulator `/simulator` | What-If Simulator | 2,546 ch | 0 | 0 | 0 | 0 / 1 / 0 |
| Early Warning Alerts `/alerts` | Early Warning Alerts | 5,794 ch | 0 | 0 | 0 | 0 / 1 / 0 |
| Historical Analysis `/historical` | Historical Analysis | 2,589 ch | 0 | 0 | 0 | 0 / 1 / 0 |
| Data Sources `/data-sources` | Data Sources | 5,053 ch | 0 | 0 | 0 | 0 / 1 / 0 |
| Settings `/settings` | Settings | 3,823 ch | 0 | 0 | 0 | 0 / 1 / 0 |

**11/11 routes render; zero console errors; zero failed API requests; zero
zero-height charts; UNKNOWN 0 on every page.** (OpenStreetMap tile failures
and one external font fetch failing in this sandbox were excluded as known
sandbox-only noise; the map's graceful fallback covers the tile case — §5.2.
Route load times 11.3–12.7 s include the probe's fixed 10 s settle wait, so
real load is ~1.3–2.7 s; frontend `/overview` DOMContentLoaded measured
1,109 ms.)

### 5.1 Interactions (all passed)

- **Forecast CSV export:** 24 rows, 6 model + 18 demo, header has a `Source`
  column. Grid-cell note present: "Single grid cell: MODEL values are the
  forecast for the single Bhubaneswar grid cell (20.28°N, 85.84°E), applied
  to every Bhubaneswar-region location — including Cuttack and Puri."
- **Forecast location switch → Cuttack:** MODEL 7 / DEMO 20, note stays.
  **→ Brahmapur:** MODEL 0 / DEMO 26.
- **Flood location switch → Cuttack:** MODEL 5 / DEMO 8; disclaimer carries
  the grid-cell note.
- **Historical (Old Town):** **92 days in range**, 232 mm total, peak daily
  48.4 mm, trend/monthly/annual/risk charts all drawn. CSV: 92 rows
  (2025-10-01 → 2025-12-31) with a `Source` column. (The probe's first
  `days_in_range` read printed 0 because its regex expected label and value
  on one line; the screenshot proves 92 — probe artifact, not a defect.)
- **Simulator:** Run Simulation POSTs `/api/simulate`; result card renders
  (risk index 1.9/100, LOW, scenario prism, contribution breakdown) and the
  run appears in the Scenario Comparison table. Subtitle is honest:
  "deterministic demo formula, not the ML model."
- **Sidebar navigation:** 4/4 tested links land on the right route.
- **Topbar health dot:** tooltip "Backend live · API 1.3.0 ·
  rainfall-xgb-v3.3" (green, model loaded).

### 5.2 Rechecks (probe follow-ups)

- **Overview charts** (Rainfall Trend, Flood Risk Distribution, Forecast
  Timeline) looked empty in the first screenshot at 10 s — recheck after a
  **20 s settle shows all three fully drawn** (trend area chart, 5 risk bars,
  accumulated timeline). This is Recharts mount-animation timing, not a
  defect. Demo tip: allow ~20 s after loading Overview before presenting or
  screenshotting it.
- **Map overlays with tiles down:** `leaflet-overlay-pane` contains **56
  paths** — the illustrative polygons render on the schematic background even
  when OpenStreetMap tiles fail, and the "Basemap tiles unavailable /
  GRACEFUL FALLBACK ACTIVE" banner shows. The fallback promise holds.
- **Simulator after-run state:** verified by screenshot (see §5.1).

## 6. Scientific integrity checks

- **Grid-cell disclosure:** visible on Forecast (note strip + footer),
  Flood (disclaimer), Overview (note strip), Map (subtitle), every MODEL
  badge tooltip ("· Bhubaneswar grid cell"). Cuttack/Puri MODEL points are
  identical to Bhubaneswar's at the API level (§4) and are never presented
  as independently modelled.
- **Data Sources honesty:** the page states the four-way distinction
  explicitly; summary cards read Source types 7 / Historical archive served
  1 / **Live observation feeds 0** / Awaiting integration 2. ERA5 row:
  Archive, "Static archive — no live updates", "ERA5 reanalysis, not station
  measurements".
- **Copy grep** (`src/pages`, `src/components`, `src/data`) for
  real-time/live/statewide/accurate-extreme/guaranteed/inundation-boundary
  claims: no false claims found. Remaining "live" wording is accurate in
  context ("served live by the integrated backend"; the Data Sources page
  explicitly says no live external feed is connected). The "Live Weather"
  module name is legacy; the page copy is demo-honest.
- **Risk vs amount:** risk classification is computed from the susceptibility
  model, distinct from the amount regression; the UI never claims accurate
  extreme amounts. The health payload's heavy-risk note carries the honest
  v3.3 precision/recall (3h ≥ 10 mm P 0.12 / R 0.39; 6h ≥ 10 mm P 0.16 /
  R 0.72) and the "Thresholds optimised on 2024+2025; 2026 was not used"
  statement.
- **Daily validation:** presented only as the deck's one validation slide
  (IMD daily gridded rainfall, Bhubaneswar-only, r = 0.58, P90 coverage
  94%); it is never presented in the app as 3 h/6 h accuracy. F1 labelling
  follows the two-family rule (regression daily-total F1 vs classifier
  any-fire F1).

## 7. Performance vs Stage 6 baselines

Warm latency, 20 runs each, median (p50) — script
`backend/ml/acceptance_perf.py`.

| Endpoint | :8001 v3.3 p50 | :8000 v3 p50 | Stage 6 baseline |
|---|---|---|---|
| /api/health | 0.8 ms | 1.5 ms | 1 ms |
| /api/forecast (old-town, 24 h) | 1.6 ms | 1.9 ms | 2 ms |
| /api/risk/all | 17.9 ms | 18.5 ms | 18 ms |
| /api/overview | 4.1 ms | 4.5 ms | 4–5 ms |
| /api/history/daily (120 d) | 3.8 ms | 4.0 ms | 9 ms |
| /api/map/layers | 4.4 ms | 4.5 ms | — |
| /api/alerts/upcoming | 2.2 ms | 1.4 ms | — |

No regression. Cold start to first `loaded: true`: 8.2–9.1 s (baseline
10.3 s). Memory (RSS): :8000 **175 MB** (baseline 169), :8001 **210 MB**
(baseline 185) — the :8001 drift is consistent with the known per-tick
response-cache growth across a long probe session (§9.3), not a model
change. Frontend `/overview` DOMContentLoaded: **1,109 ms**.

## 8. Server logs

Acceptance-run logs (`~/workspace/acceptance-logs/`): **zero tracebacks,
zero ERROR/exception lines, zero 4xx/5xx responses** across both backends
and vite for the whole probe session.

## 9. Remaining limitations (known, non-blocking)

1. **Charts and KPI aggregates mix MODEL + DEMO values without per-point
   distinction.** The Forecast timeline/bars and the Overview trend/KPIs plot
   the 24 h mixed series (model 0 mm for hours 1–6, demo 95–118 mm/hr after)
   as one curve; the peak/total KPIs (118.8 mm/hr, 1,942.5 mm) are
   demo-driven. Per-row table badges, CSV `Source` columns and the footers
   are correct and disclose it, but a judge reading only the charts sees a
   dramatic heavy-rain event the model itself does not predict. This was
   already documented in `KNOWN_LIMITATIONS.md`; it is the single most
   important honesty gap left. A per-point MODEL/DEMO split (or a
   model-only chart) would close it — a post-freeze decision for Kam, not
   an acceptance fix.
2. No git repo / CI.
3. Per-tick response caches grow unboundedly across demo ticks (RSS drift
   §7). Harmless for a finale-length session; restart the demo backend if
   it runs for hours.
4. The map's OpenStreetMap base tiles need internet at the venue; the
   graceful fallback is verified (§5.2), overlays render regardless.
5. No live external feeds by design (ERA5 archive only; Ganjam archive
   still unfetched — rate-limited).
6. `/api/simulations/run` and `/api/simulations/compare` do not exist by
   design (simulator is `POST /api/simulate`; comparison is client-side).
   The test suite asserts their absence.
7. Alerts page is local-only demo alerts (backend `/api/alerts` not wired
   in); the page is labelled as such.
8. `fetchOverview`'s activity feed is hardcoded demo content (labelled
   "Demo data pipeline events").
9. Pre-existing cosmetic nits, unchanged: deck slide 2 subtitle clips
   behind the aerial image; slide 4 and References titles wrap at 66 pt;
   `risk.py` docstring says "rainfall-xgb-v1"; `history.py` caches a
   missing CSV until restart; no `response_model=` on routes; pandas
   `dayofyear` deprecation warning; sklearn feature-names warnings.

## 10. Demo-day operating notes (finale Thu 2026-11-26)

- **Dev servers are not supervised.** A runtime/VM restart kills them
  (observed twice during this run). If the app stops responding, re-run
  the startup commands from `HACKATHON_HANDOFF.md`:
  backend `MODEL_VERSION=rainfall-xgb-v3.3 uvicorn app.main:app --port 8001`,
  frontend `VITE_API_URL=http://localhost:8001 npm run dev -- --port 5173`
  (launch vite via `node node_modules/vite/bin/vite.js` — the `.bin` shim
  lost its exec bit). Production stays on :8000 / v3. Allow ~10 s after
  starting the backend before the first health check (lazy model load).
- **Wait ~20 s after loading Overview** before presenting or screenshotting
  — the trend/distribution/timeline charts animate in and look empty before
  that.
- The map needs internet for base tiles; without it the fallback banner
  shows and overlays still work.
- Rollback at any time: stop the :8001 demo server; :8000 keeps serving v3.
- The Drive deck copy is still the 5-slide version (local deck is 6 slides
  with the IMD validation slide) — update only with Kam's go-ahead.

## 11. Evidence

- This report: `backend/docs/FINAL_ACCEPTANCE_REPORT.md`
- API check: `backend/ml/acceptance_api_check.py`
- Browser probe: `backend/ml/probe_acceptance.py` (+ recheck
  `backend/ml/probe_acceptance_recheck.py`, perf
  `backend/ml/acceptance_perf.py`)
- Screenshots + JSON: `~/workspace/acceptance-screenshots/` (11 route
  screenshots, overview-20s, simulator-after-run, map-15s,
  probe_results.json, recheck_results.json)
- Acceptance-run server logs: `~/workspace/acceptance-logs/`
- Prior verification it builds on: `V33_DEMO_READINESS.md`,
  `ENGINEERING_AUDIT.md`, `TESTING.md`, `KNOWN_LIMITATIONS.md`,
  `HACKATHON_HANDOFF.md`, `IMD_DAILY_VALIDATION.md`
