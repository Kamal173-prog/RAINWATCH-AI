"""Model selection tests: v3 production, v3.3 demo, v3.2 benchmark,
invalid MODEL_VERSION, loading failures, and actual loaded-version
reporting.

Version switching is done in-process via ``set_model_version`` (see
conftest.py): each version is loaded at most once per session and the
caches are reset on every switch, mirroring a server restart.
"""

import json
import os

import pytest

from app import model_service as ms
from conftest import (
    VERSION_V3, VERSION_V32, VERSION_V33,
    clear_response_caches, reset_model_caches, set_model_version,
)

BACKEND = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def test_default_is_v3(v3_client):
    body = v3_client.get("/api/health").json()
    assert body["model"]["loaded"] is True
    assert body["model"]["model_version"] == VERSION_V3


def test_v33_health_reports_v33(v33_client):
    body = v33_client.get("/api/health").json()
    model = body["model"]
    assert model["loaded"] is True
    assert model["model_version"] == VERSION_V33
    assert "thresholds" in model["note"].lower() or "2024+2025" in model["note"]
    assert model["scope"].startswith("Bhubaneswar grid cell only")


def test_v32_health_reports_v32(v32_client):
    body = v32_client.get("/api/health").json()
    model = body["model"]
    assert model["loaded"] is True
    assert model["model_version"] == VERSION_V32


def test_invalid_model_version_falls_back_to_v3(client, monkeypatch):
    """An unknown MODEL_VERSION serves v3 AND reports v3 — never the
    requested (nonexistent) version. This is the no-silent-fallback
    rule at the selection layer."""
    set_model_version(monkeypatch, "rainfall-xgb-v9.9")
    body = client.get("/api/health").json()
    assert body["model"]["loaded"] is True
    assert body["model"]["model_version"] == VERSION_V3
    points = client.get("/api/forecast?locationId=patia&hours=6").json()
    assert all(p["model_version"] == VERSION_V3 for p in points)


@pytest.mark.parametrize("bad", ["", "v3", "V3.3", "rainfall-xgb-v3.3 ", "rainfall_xgb_v33"])
def test_malformed_model_version_falls_back_to_v3(client, monkeypatch, bad):
    set_model_version(monkeypatch, bad)
    body = client.get("/api/health").json()
    assert body["model"]["model_version"] == VERSION_V3


def test_v33_load_failure_falls_back_to_v3(client, monkeypatch):
    """If the frozen v3.3 directory fails to load, the API serves v3
    and reports v3. Simulated by making the forecaster raise for the
    v3.3 directory only (the frozen artifacts themselves are untouched)."""
    import ml.predict as predict_mod
    from conftest import _LOADED

    # Evict any previously loaded v3.3 forecaster so the failure path
    # is genuinely exercised (not the session cache).
    _LOADED.pop(VERSION_V33, None)

    real_init = predict_mod.RainfallForecaster.__init__

    def failing_init(self, model_dir=predict_mod.MODEL_DIR, model_version=None):
        if os.path.basename(os.path.normpath(model_dir)) == "frozen":
            raise RuntimeError("simulated corrupt frozen artifacts")
        return real_init(self, model_dir, model_version)

    monkeypatch.setattr(predict_mod.RainfallForecaster, "__init__", failing_init)
    set_model_version(monkeypatch, VERSION_V33)
    body = client.get("/api/health").json()
    assert body["model"]["loaded"] is True
    assert body["model"]["model_version"] == VERSION_V3
    points = client.get("/api/forecast?locationId=patia&hours=6").json()
    assert all(p["model_version"] == VERSION_V3 for p in points)


def test_model_unavailable_falls_back_to_demo(client, monkeypatch):
    """When no model loads at all, the API keeps working on demo data
    and health reports loaded:false with an error. Simulated by
    forcing get_forecaster to return None (no artifact is touched)."""
    monkeypatch.setattr(ms, "get_forecaster", lambda: None)
    reset_model_caches()
    clear_response_caches()
    body = client.get("/api/health").json()
    assert body["model"]["loaded"] is False
    assert "error" in body["model"]
    assert body["status"] == "ok"  # the API itself stays up
    points = client.get("/api/forecast?locationId=patia&hours=24").json()
    assert all(p["source"] == "demo" for p in points)
    assert all("model_version" not in p for p in points)


def test_version_switch_without_cache_clear_serves_new_version(client, monkeypatch):
    """Strong regression test for the cache-key fix (ENGINEERING_AUDIT.md
    §6): forecast/risk/map caches are keyed by the model flag, so a
    MODEL_VERSION switch with warm response caches must still serve the
    new version. Deliberately does NOT clear response caches — only the
    model caches are reset, as a restart would do for the model."""
    monkeypatch.setattr(ms, "MODEL_VERSION_ENV", VERSION_V3)
    reset_model_caches()
    v3_points = client.get("/api/forecast?locationId=patia&hours=6").json()
    assert all(p["model_version"] == VERSION_V3 for p in v3_points)
    v3_risk = client.get("/api/risk/records?locationId=old-town").json()
    assert all(r["model_version"] == VERSION_V3 for r in v3_risk if r["source"] == "model")

    monkeypatch.setattr(ms, "MODEL_VERSION_ENV", VERSION_V33)
    reset_model_caches()  # model caches only — response caches stay warm
    v33_points = client.get("/api/forecast?locationId=patia&hours=6").json()
    assert all(p["model_version"] == VERSION_V33 for p in v33_points)
    v33_risk = client.get("/api/risk/records?locationId=old-town").json()
    assert all(r["model_version"] == VERSION_V33 for r in v33_risk if r["source"] == "model")


def test_version_switch_without_restart_serves_new_version(client, monkeypatch):
    """Regression test for the cache-key fix: switching MODEL_VERSION
    in-process (no tick bump) must change the served model_version.
    Before the fix, forecast/risk caches keyed only by tick served
    stale points labelled with the previous version."""
    set_model_version(monkeypatch, VERSION_V3)
    v3_points = client.get("/api/forecast?locationId=patia&hours=6").json()
    assert all(p["model_version"] == VERSION_V3 for p in v3_points)
    set_model_version(monkeypatch, VERSION_V33)
    v33_points = client.get("/api/forecast?locationId=patia&hours=6").json()
    assert all(p["model_version"] == VERSION_V33 for p in v33_points)
    assert v3_points[0]["model"] != v33_points[0]["model"]


def test_forecaster_version_detection_from_directory():
    """RainfallForecaster derives its version from the model directory:
    v3.2 dir -> rainfall-xgb-v3.2, frozen v3.3 dir -> rainfall-xgb-v3.3,
    anything else -> rainfall-xgb-v3."""
    from ml.predict import RainfallForecaster

    v32 = RainfallForecaster(model_dir=os.path.join(BACKEND, "models", "rainfall_xgb_v3_2"))
    assert v32.model_version == VERSION_V32
    assert v32.thresholds_source == "thresholds.json"

    v33 = RainfallForecaster(
        model_dir=os.path.join(BACKEND, "models", "rainfall_xgb_v3_3", "frozen"))
    assert v33.model_version == VERSION_V33
    assert v33.thresholds_source == "thresholds_optimized.json"

    v3 = RainfallForecaster()
    assert v3.model_version == VERSION_V3
    assert v3.thresholds_source == "thresholds.json"


def test_forecaster_missing_directory_raises():
    from ml.predict import RainfallForecaster

    with pytest.raises((FileNotFoundError, OSError)):
        RainfallForecaster(model_dir=os.path.join(BACKEND, "models", "does-not-exist"))


def test_model_confidence_is_bounded():
    for horizon in (1, 3, 6, 24, 0, -1):
        c = ms.model_confidence(horizon)
        assert 55 <= c <= 95
