"""Pydantic schemas — mirrors ``hackathon/src/types/index.ts`` exactly,
so the JSON the API returns drops straight into the frontend's types
with no mapping.
"""

from typing import List, Literal, Optional

from pydantic import BaseModel, Field

RiskLevel = Literal["Low", "Moderate", "High", "Very High", "Critical"]
RainfallClass = Literal["Light", "Moderate", "Heavy", "Very Heavy", "Extremely Heavy"]
AlertSeverity = Literal["Information", "Advisory", "Watch", "Warning", "Critical"]
AlertCategory = Literal[
    "Heavy Rainfall Warning",
    "Extremely Heavy Rainfall Warning",
    "Flood Risk Warning",
    "Potential Inundation Warning",
    "Weather Monitoring Update",
]
AlertStatus = Literal["active", "acknowledged", "dismissed"]
VulnerabilityLevel = Literal["Low", "Moderate", "High", "Very High"]


class GeoLocation(BaseModel):
    id: str
    name: str
    zone: str
    regionId: Optional[str] = None
    lat: float
    lng: float
    population: int
    elevationM: float
    lowLyingPct: float
    drainageEfficiency: float
    riverProximity: float
    vulnerability: VulnerabilityLevel


class WeatherReading(BaseModel):
    locationId: str
    timestamp: str
    temperatureC: float
    humidityPct: float
    windSpeedKmph: float
    windDirectionDeg: float
    pressureHpa: float
    visibilityKm: float
    cloudCoverPct: float
    rainfallMmHr: float


class ForecastPoint(BaseModel):
    locationId: str
    timestamp: str
    rainfallMmHr: float
    accumulatedMm: float
    confidence: float
    classification: RainfallClass
    # Provenance (Stage 4): "model" when the rainfall comes from the
    # trained XGBoost model (hours 1-6, Bhubaneswar region), else "demo".
    source: Optional[str] = None
    model_version: Optional[str] = None
    # v2 two-stage detail (model points only): expected accumulations,
    # P90 upper bound, calibrated heavy-event probabilities, risk tier.
    model: Optional[dict] = None


class IntensitySlice(BaseModel):
    label: str
    hours: int
    color: str


class MergedForecastPoint(BaseModel):
    """One hour of the merged forecast (GET /api/forecast/merged).

    Source priority: MODEL > GOOGLE WEATHER > UNAVAILABLE. Model points
    are the v3.3 ensemble output, byte-identical to /api/forecast.
    Google points carry Google's QPF (mm in the hour) — a different
    quantity from the model's hourly rate, labelled by ``valueKind``.
    Unavailable rows carry no value at all: rainfall, accumulated,
    confidence and classification are all null, never fabricated.
    """
    locationId: str
    timestamp: str
    rainfallMmHr: Optional[float] = None
    # "model_rate_mm_hr" | "google_qpf_mm" | None (unavailable).
    valueKind: Optional[str] = None
    # Running total of displayed per-hour values; null for an
    # unavailable hour and for every later hour (the total is unknown
    # once an hour is missing).
    accumulatedMm: Optional[float] = None
    # Model confidence 0-100 on model rows only; null on Google rows
    # (Google's precipitation probability is NOT confidence) and on
    # unavailable rows.
    confidence: Optional[int] = None
    classification: Optional[RainfallClass] = None
    # "model" | "google_weather" | "unavailable" — never "demo".
    source: str
    model_version: Optional[str] = None
    # v2 two-stage detail (model points only).
    model: Optional[dict] = None
    # Google metadata (google_weather points only).
    precipitationProbabilityPct: Optional[int] = None
    precipitationType: Optional[str] = None
    temperatureC: Optional[float] = None
    relativeHumidityPct: Optional[int] = None
    windSpeedKmh: Optional[float] = None
    windDirectionDeg: Optional[float] = None
    condition: Optional[str] = None
    conditionText: Optional[str] = None
    # Google interval startTime of the matched hour.
    googleTimestamp: Optional[str] = None


class MergedForecastMeta(BaseModel):
    model: dict
    google: dict
    sources: dict


class MergedForecastResponse(BaseModel):
    locationId: str
    hours: int
    points: List[MergedForecastPoint]
    meta: MergedForecastMeta


class FloodRiskRecord(BaseModel):
    locationId: str
    timestamp: str
    # Susceptibility index (0-100, illustrative composite) — NOT a
    # validated flood prediction. inundationDepthM / areaInundatedHa are
    # derived from the index by a formula, not modelled/measured depths.
    riskIndex: float
    riskLevel: RiskLevel
    populationAtRisk: int
    lowLyingPct: float
    drainageScore: float
    rainfallContribution: float
    terrainContribution: float
    riverContribution: float
    inundationDepthM: float
    areaInundatedHa: int
    # Provenance (Stage 4): "model" when the rainfall came from the
    # trained XGBoost model (offsets 0/3/6 h, Bhubaneswar region), else "demo".
    source: Optional[str] = None
    model_version: Optional[str] = None
    # v2 two-stage detail (model records only): expected accumulations,
    # P90 upper bound, calibrated heavy-event probabilities, risk tier.
    model: Optional[dict] = None


class RiskSummary(BaseModel):
    overallIndex: float
    distribution: List[dict]
    worst: List[FloodRiskRecord]
    vulnerable: List[FloodRiskRecord]


class Alert(BaseModel):
    id: str
    severity: AlertSeverity
    category: AlertCategory
    title: str
    locationId: str
    locationName: str
    timestamp: str
    description: str
    guidance: str
    status: AlertStatus


class HistoricalDay(BaseModel):
    date: str
    locationId: str
    rainfallMm: float
    peakHourMmHr: float
    riskIndex: float


class MonthlySummary(BaseModel):
    month: str
    rainfallMm: float
    rainyDays: int
    peakMmHr: float
    avgRiskIndex: float


class AnnualSummary(BaseModel):
    year: int
    rainfallMm: float
    heavyRainDays: int
    maxDailyMm: float


class PeakEvent(BaseModel):
    date: str
    locationId: str
    locationName: str
    dailyMm: float
    durationH: int
    riskLevel: RiskLevel


class LocationComparisonRow(BaseModel):
    locationId: str
    name: str
    rainfallMm: float
    peakMmHr: float
    avgRiskIndex: float


class MapRiskZone(BaseModel):
    id: str
    name: str
    level: RiskLevel
    polygon: List[List[float]]
    rainfallMmHr: float


class InundationZone(BaseModel):
    id: str
    name: str
    polygon: List[List[float]]
    depthM: float
    confidencePct: int


class MonitoringStation(BaseModel):
    id: str
    name: str
    lat: float
    lng: float
    rainfallMmHr: float
    status: Literal["online", "offline", "maintenance"]
    lastUpdate: str


class PopulationCell(BaseModel):
    id: str
    lat: float
    lng: float
    densityPerKm2: int
    label: str


class VulnerableSite(BaseModel):
    id: str
    name: str
    lat: float
    lng: float
    type: Literal["Hospital", "School", "Old-age Home", "Slum Area", "Subway / Underpass"]
    vulnerability: VulnerabilityLevel


class MapLayersPayload(BaseModel):
    riskZones: List[MapRiskZone]
    inundation: List[InundationZone]
    stations: List[MonitoringStation]
    population: List[PopulationCell]
    vulnerable: List[VulnerableSite]


class RegionCondition(BaseModel):
    locationId: str
    name: str
    zone: str
    lat: float
    lng: float
    rainfallMmHr: float
    riskIndex: float
    riskLevel: RiskLevel
    inundationDepthM: float
    populationAtRisk: int
    vulnerability: VulnerabilityLevel
    lowLyingPct: float
    drainageEfficiency: float


class DataSourceInfo(BaseModel):
    id: str
    name: str
    category: str
    kind: str  # Historical dataset | Real-time observation | Forecast feed | Static dataset
    description: str
    intendedUse: str
    status: Literal["Live", "Demo Data", "Not Connected", "Awaiting Integration", "Archive", "Error"]
    cadence: str
    icon: Literal["satellite", "radar", "station", "model", "terrain", "drainage", "archive", "cloud"]
    # Live Google Weather fields (present on the google-weather entry
    # when the backend can report them; None elsewhere).
    lastRetrievedAt: Optional[str] = None
    recordsRetrieved: Optional[int] = None
    error: Optional[str] = None


class PipelineNode(BaseModel):
    id: str
    label: str
    detail: str


class DataSourcesPayload(BaseModel):
    sources: List[DataSourceInfo]
    pipeline: List[PipelineNode]


class OverviewKpis(BaseModel):
    currentRainfall: float
    rainfallDelta: float
    accumulated24h: float
    accumulatedTrend: float
    maxForecast: dict
    floodRiskIndex: float
    riskLevel: str
    vulnerableZones: int
    activeAlerts: int


class OverviewBundle(BaseModel):
    kpis: OverviewKpis
    sparkline: List[float]
    weather: WeatherReading
    forecast: List[ForecastPoint]
    intensity: List[IntensitySlice]
    riskDistribution: List[dict]
    vulnerable: List[dict]
    upcomingAlerts: List[Alert]
    activity: List[dict]


class SimulatorInputs(BaseModel):
    locationId: str
    rainfallMmHr: float = Field(ge=0, le=300)
    durationH: float = Field(ge=1, le=72)
    soilSaturationPct: float = Field(ge=0, le=100)
    drainageEfficiencyPct: float = Field(ge=0, le=100)
    riverLevelPct: float = Field(ge=0, le=100)


class SimulatorResult(BaseModel):
    riskIndex: float
    riskLevel: RiskLevel
    affectedZones: int
    inundationSeverity: Literal["None", "Minor", "Moderate", "Severe", "Extreme"]
    peakDepthM: float
    durationToImpactH: float
    breakdown: List[dict]
    inputs: SimulatorInputs


# ------------------------------------------------------------------
# Satellite rainfall (NASA GPM IMERG, Phase 2)
# ------------------------------------------------------------------
# Observed satellite rainfall — observations, never forecasts. A cell
# with no usable value is reported MISSING/INVALID with null numerics,
# never zero-filled. The location uses latitude/longitude keys, NOT
# GeoLocation's lat/lng — the service returns exactly these keys.


class SatelliteLocation(BaseModel):
    """Requested coordinates of a satellite observation."""
    latitude: float
    longitude: float


class SatelliteGridCell(BaseModel):
    """Nearest IMERG 0.1-degree grid cell to the requested coordinates."""
    latitude: float
    longitude: float
    latIndex: int
    lonIndex: int
    distanceKm: float


class SatelliteGranuleRef(BaseModel):
    """Granule reference. The location response carries the 4-field
    subset; the region response carries the full cached-granule
    metadata (all extra fields optional)."""
    filename: str
    nativeId: Optional[str] = None
    conceptId: Optional[str] = None
    version: Optional[str] = None
    observationStartUtc: Optional[str] = None
    observationEndUtc: Optional[str] = None
    observationIntervalMinutes: Optional[int] = None
    sizeBytes: Optional[int] = None
    sha256: Optional[str] = None
    path: Optional[str] = None
    retrievedAtUtc: Optional[str] = None
    cached: Optional[bool] = None


class SatelliteRainfallResponse(BaseModel):
    """One observed satellite rainfall value (GET /api/satellite/rainfall)."""
    source: str
    product: str
    version: Optional[str] = None
    location: SatelliteLocation
    gridCell: SatelliteGridCell
    precipitationRateMmHr: Optional[float] = None
    accumulationMm: Optional[float] = None
    observationTimeUtc: Optional[str] = None
    observationTimeIst: Optional[str] = None
    observationIntervalMinutes: Optional[int] = None
    status: Literal["VALID_ZERO", "VALID_RAINFALL", "MISSING", "INVALID"]
    granule: SatelliteGranuleRef
    retrievedAtUtc: Optional[str] = None


class SatelliteRegionInfo(BaseModel):
    id: str
    name: str
    shortName: Optional[str] = None
    bbox: List[float]


class SatelliteRegionResponse(BaseModel):
    """Observed satellite rainfall for a region (GET /api/satellite/rainfall/region).

    coverageNote states the coverage honestly: the Bhubaneswar region
    bounding box excludes Cuttack and Puri, so that region returns 12
    of its 14 locations; Ganjam is complete at 7/7.
    """
    region: SatelliteRegionInfo
    granule: SatelliteGranuleRef
    coverageNote: str
    locations: List[SatelliteRainfallResponse]


class SatelliteStatusResponse(BaseModel):
    """Satellite service status (GET /api/satellite/status)."""
    configured: bool
    status: Literal["Not Configured", "Ready", "Error"]
    lastRetrievedAt: Optional[str] = None
    recordsRetrieved: Optional[int] = None
    error: Optional[str] = None
    cachedGranules: int
    latestGranule: Optional[str] = None
