import { classifyRisk } from '../utils/colors'
import { clamp, createRng, hashSeed, round } from '../utils/rng'
import { getDemoTick } from '../services/demoState'
import type { AnnualSummary, HistoricalDay, MonthlySummary, PeakEvent } from '../types'
import { LOCATIONS, getLocation } from './locationsData'

/* ------------------------------------------------------------------
   Locally generated historical rainfall & risk archive (DEMO DATA).
   Seasonality follows Odisha's monsoon pattern (peak Jul–Aug) purely
   as a plausible-looking sample dataset for the analytics page.
------------------------------------------------------------------ */

const MONTH_RAIN_FACTOR = [0.9, 0.7, 0.8, 1.4, 4.6, 14.5, 26.0, 25.2, 16.8, 7.2, 2.1, 0.8]

const dailyCache = new Map<string, { tick: number; rows: HistoricalDay[] }>()

function seedFor(locationId: string, days: number): number {
  return hashSeed(locationId) ^ Math.imul(getDemoTick() + 11, 0x27d4eb2f) ^ days
}

export function getDailyHistory(locationId: string, days = 120): HistoricalDay[] {
  const tick = getDemoTick()
  const key = `${locationId}:${days}:${tick}`
  const cached = dailyCache.get(key)
  if (cached && cached.tick === tick) return cached.rows

  const loc = getLocation(locationId)
  const rng = createRng(seedFor(locationId, days))
  const exposure = clamp(0.8 + loc.lowLyingPct / 300 + loc.riverProximity / 500, 0.7, 1.5)
  const rows: HistoricalDay[] = []

  const today = new Date()
  today.setHours(0, 0, 0, 0)

  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(today.getTime() - i * 86400_000)
    const month = d.getMonth()
    const base = MONTH_RAIN_FACTOR[month]

    // Monsoon spells: a wet-day probability plus occasional cyclonic spikes.
    const wetDay = rng() < Math.min(0.92, 0.24 + base / 34)
    let rainfallMm = 0
    let peakHourMmHr = 0

    if (wetDay) {
      const burst = rng() < 0.12 ? 2.6 + rng() * 4.2 : 0.5 + rng() * 1.5
      rainfallMm = round(clamp(base * burst * exposure * (0.35 + rng() * 1.1), 0.4, 385), 1)
      peakHourMmHr = round(clamp((rainfallMm / (3 + rng() * 9)) * (1.4 + rng()), 0.2, 172), 1)
    }

    const rainComponent = clamp(rainfallMm * 0.42, 0, 58)
    const terrainComponent = loc.lowLyingPct * 0.28
    const riskIndex = round(
      clamp(
        rainComponent + terrainComponent + rng() * 14 - (loc.drainageEfficiency / 100) * 14,
        3,
        97,
      ),
      1,
    )

    rows.push({
      date: d.toISOString().slice(0, 10),
      locationId,
      rainfallMm,
      peakHourMmHr,
      riskIndex,
    })
  }

  dailyCache.set(key, { tick, rows })
  return rows
}

export function getMonthlyHistory(locationId: string): MonthlySummary[] {
  const daily = getDailyHistory(locationId, 365)
  const buckets = new Map<string, MonthlySummary>()
  const labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

  // Use the most recent 12 calendar months present in the data.
  const seen = new Set<string>()
  for (const row of daily) {
    const key = row.date.slice(0, 7)
    seen.add(key)
  }
  const months = [...seen].sort().slice(-12)

  for (const key of months) {
    const [y, m] = key.split('-').map(Number)
    const rows = daily.filter((r) => r.date.startsWith(key))
    buckets.set(key, {
      month: `${labels[m - 1]} ${String(y).slice(2)}`,
      rainfallMm: round(
        rows.reduce((s, r) => s + r.rainfallMm, 0),
        1,
      ),
      rainyDays: rows.filter((r) => r.rainfallMm >= 2.5).length,
      peakMmHr: round(Math.max(...rows.map((r) => r.peakHourMmHr)), 1),
      avgRiskIndex: round(
        rows.reduce((s, r) => s + r.riskIndex, 0) / Math.max(1, rows.length),
        1,
      ),
    })
  }
  return [...buckets.values()]
}

export function getAnnualHistory(): AnnualSummary[] {
  const tick = getDemoTick()
  const rng = createRng(hashSeed('annual-history') ^ Math.imul(tick + 5, 0x1b873593))
  const currentYear = new Date().getFullYear()
  const out: AnnualSummary[] = []

  for (let i = 4; i >= 0; i--) {
    const year = currentYear - i
    const monsoon = 1680 + rng() * 760
    const partial = i === 0 ? 0.72 : 1 // current year incomplete
    out.push({
      year,
      rainfallMm: round(monsoon * partial, 0),
      heavyRainDays: Math.round((18 + rng() * 26) * partial),
      maxDailyMm: round(120 + rng() * 190, 1),
    })
  }
  return out
}

export function getPeakEvents(locationId?: string, limit = 8): PeakEvent[] {
  const pool = locationId ? [locationId] : LOCATIONS.map((l) => l.id)
  const events: PeakEvent[] = []

  for (const id of pool) {
    const daily = getDailyHistory(id, 365)
    const sorted = [...daily].sort((a, b) => b.rainfallMm - a.rainfallMm).slice(0, 3)
    for (const row of sorted) {
      if (row.rainfallMm < 45) continue
      events.push({
        date: row.date,
        locationId: id,
        locationName: getLocation(id).name,
        dailyMm: row.rainfallMm,
        durationH: Math.round(clamp(row.rainfallMm / Math.max(1, row.peakHourMmHr) + 4, 4, 30)),
        riskLevel: classifyRisk(row.riskIndex),
      })
    }
  }

  return events.sort((a, b) => b.dailyMm - a.dailyMm).slice(0, limit)
}

/** Location-wise comparison for a trailing window (default 90 days). */
export function getLocationComparison(days = 90): Array<{
  locationId: string
  name: string
  rainfallMm: number
  peakMmHr: number
  avgRiskIndex: number
}> {
  return LOCATIONS.map((loc) => {
    const rows = getDailyHistory(loc.id, days)
    return {
      locationId: loc.id,
      name: loc.name,
      rainfallMm: round(
        rows.reduce((s, r) => s + r.rainfallMm, 0),
        1,
      ),
      peakMmHr: round(Math.max(...rows.map((r) => r.peakHourMmHr)), 1),
      avgRiskIndex: round(
        rows.reduce((s, r) => s + r.riskIndex, 0) / Math.max(1, rows.length),
        1,
      ),
    }
  }).sort((a, b) => b.rainfallMm - a.rainfallMm)
}
