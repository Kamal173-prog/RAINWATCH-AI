"""Service bridging the trained XGBoost rainfall model into the API.

The model (``rainfall-xgb-v3``) is a spatial-thermodynamic ensemble:
- Mean regressors predict the EXPECTED rainfall accumulation (1 / 3 / 6 h),
  blending XGBoost + LightGBM + HistGradientBoosting.
- Classifiers give the calibrated probability of heavy/moderate events
  (3 h >= 10 mm, 6 h >= 10 mm, 3 h >= 5 mm), plus a heavy-risk tier,
  with TWO thresholds per event: ``elevated`` (Watch, F2-optimal) and
  ``high`` (Warning, F1-optimal).
- P90 quantile regressors give a 90th-percentile upper-bound envelope.

It is loaded once (lazily, on first use) and cached. If the model files
are missing or fail to load, every caller falls back to the demo engine
and the API keeps working — the model is an enhancement, never a single
point of failure.

Honesty notes (do not remove):
- The model input is the last available hourly observations
  (2025-12-31T23:00, the archive end). There is no live feed, so the
  forecast is anchored to "now" for display but its input is the last
  available data — see ``model_input_as_of`` in the status/metadata.
- The model covers Bhubaneswar-region locations only. Ganjam locations
  always use the demo engine (their archive is not fetched yet).
- Heavy-event detection is improved but still limited: 3 h >= 10 mm
  test PR-AUC 0.168; at the elevated (Watch) threshold Precision 0.15 at
  Recall 0.30 (F1 0.198, caught 26/87); at the high (Warning) threshold
  Precision 0.16 at Recall 0.22 (F1 0.185, caught 19/87).
  6 h >= 10 mm: elevated catches 222/258 (Recall 0.86, Precision 0.11);
  high catches 75/258 (Recall 0.29, Precision 0.19).
  Treat "high" tiers as an early-warning signal, not a confirmed forecast.
  See docs/MODEL_REPORT.md.
- CAPE is not used (all nulls from Open-Meteo for this region).
  See data/README.md.
"""

import json
import logging
import os
import sys

logger = logging.getLogger("rainwatch.model")

BACKEND_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BACKEND_ROOT not in sys.path:
    sys.path.insert(0, BACKEND_ROOT)

# Feature flag: MODEL_VERSION selects the model served by the API.
# - "rainfall-xgb-v3" (default): the v3 spatial-thermodynamic ensemble.
# - "rainfall-xgb-v3.2": the v3.2-GFS classifier ensemble (same v3
#   regressors; classifiers trained on v3 41 features + 12 GFS features).
#   v3.2 improves PR-AUC on all three events on both the 2025 benchmark
#   and the fresh 2026 evaluation (see docs/V32_EXPERIMENTS.md), but its
#   operating thresholds were optimised on 2024 validation only —
#   re-optimise on validation including 2025 before switching production
#   traffic, and never optimise thresholds on 2026.
# - "rainfall-xgb-v3.3": the frozen v3.3 classifier ensemble (94 features:
#   39 v3 features + 55 GFS features incl. moisture-profile features;
#   same v3 regressors). Operating thresholds are thresholds_optimized.json
#   in the frozen directory, optimised on pooled out-of-sample 2024+2025
#   evidence (docs/V33_THRESHOLDS.md). 2026 was NOT used for threshold
#   selection. Production default stays v3; v3.3 is the hackathon
#   candidate, behind this flag.
# Any other value (or a v3.2/v3.3 load failure) falls back to v3.
MODEL_VERSION_ENV = os.environ.get("MODEL_VERSION", "rainfall-xgb-v3").strip()
V32_MODEL_DIR = os.path.join(BACKEND_ROOT, "models", "rainfall_xgb_v3_2")
V33_MODEL_DIR = os.path.join(BACKEND_ROOT, "models", "rainfall_xgb_v3_3", "frozen")

_forecaster = None
_forecaster_error = None
_hourly_rates_cache = None
_model_status_cache = None
_model_detail_cache = None

# Test MAE (mm) per horizon, from models/rainfall_xgb_v3/evaluation.json (v3).
# Used only to set an indicative confidence that decreases with horizon.
MODEL_HORIZON_MAE = {1: 0.2089, 3: 0.6311, 6: 1.2111}


def model_confidence(horizon_h: int) -> int:
    """Indicative confidence (0-100) for a model point at a given horizon.

    Derived from the model's test MAE: confidence falls as error grows.
    This is a documented heuristic, not a calibrated probability.
    """
    mae = MODEL_HORIZON_MAE.get(horizon_h, 1.0)
    return int(max(55, min(95, round(95 - 12 * mae))))


def get_forecaster():
    """Return the loaded RainfallForecaster, or None if unavailable.

    Honors the MODEL_VERSION env flag: "rainfall-xgb-v3.2" loads the
    v3.2-GFS classifiers and "rainfall-xgb-v3.3" loads the frozen v3.3
    classifiers; anything else (or a v3.2/v3.3 load failure) falls
    back to v3, so the API never breaks on a bad flag value.
    """
    global _forecaster, _forecaster_error
    if _forecaster is not None:
        return _forecaster
    if _forecaster_error is not None:
        return None
    try:
        from ml.predict import RainfallForecaster

        if MODEL_VERSION_ENV == "rainfall-xgb-v3.2":
            try:
                _forecaster = RainfallForecaster(model_dir=V32_MODEL_DIR)
                logger.info("Rainfall model loaded: rainfall-xgb-v3.2 (GFS classifier ensemble)")
            except Exception as exc:  # noqa: BLE001 - v3.2 failure falls back to v3
                logger.warning("v3.2 model failed to load, falling back to v3: %s", exc)
                _forecaster = RainfallForecaster()
                logger.info("Rainfall model loaded: rainfall-xgb-v3 (spatial-thermodynamic ensemble)")
        elif MODEL_VERSION_ENV == "rainfall-xgb-v3.3":
            try:
                _forecaster = RainfallForecaster(model_dir=V33_MODEL_DIR)
                logger.info("Rainfall model loaded: rainfall-xgb-v3.3 (frozen, thresholds_optimized)")
            except Exception as exc:  # noqa: BLE001 - v3.3 failure falls back to v3
                logger.warning("v3.3 model failed to load, falling back to v3: %s", exc)
                _forecaster = RainfallForecaster()
                logger.info("Rainfall model loaded: rainfall-xgb-v3 (spatial-thermodynamic ensemble)")
        else:
            _forecaster = RainfallForecaster()
            logger.info("Rainfall model loaded: rainfall-xgb-v3 (spatial-thermodynamic ensemble)")
    except Exception as exc:  # noqa: BLE001 - model must never break the API
        _forecaster_error = str(exc)
        logger.warning("Rainfall model unavailable, using demo fallback: %s", exc)
    return _forecaster


def _archive_csv_path() -> str:
    override = os.environ.get("BHUBANESWAR_CSV", "")
    if override:
        return override if os.path.isabs(override) else os.path.join(BACKEND_ROOT, override)
    return os.path.join(BACKEND_ROOT, "data", "processed", "bhubaneswar_weather.csv")


def get_model_detail() -> dict | None:
    """Full v3 model output: expected_mm, P90, probabilities, tier.

    Returns the dict from RainfallForecaster.predict_with_provenance(),
    or None when the model is unavailable. Cached: the model input is
    the fixed archive end, so the output is constant until the data
    is refreshed.
    """
    global _model_detail_cache
    if _model_detail_cache is not None:
        return _model_detail_cache
    fc = get_forecaster()
    if fc is None:
        return None
    try:
        sys.path.insert(0, os.path.join(BACKEND_ROOT, "ml"))
        import features as feat  # noqa: E402

        hourly = feat.load_hourly(_archive_csv_path())
        _model_detail_cache = fc.predict_with_provenance(hourly)
        logger.info(
            "Model detail: expected=%s tier=%s",
            _model_detail_cache["expected_mm"], _model_detail_cache["heavy_risk_tier"],
        )
    except Exception as exc:  # noqa: BLE001 - fall back to demo
        logger.warning("Model inference failed, using demo fallback: %s", exc)
        return None
    return _model_detail_cache


def get_model_hourly_rates() -> dict | None:
    """Hourly rainfall rates (mm/hr) for forecast hours 1..6, from the model.

    Derives per-hour rates from the model's 1h / 3h / 6h accumulations:
    hour 1 = y_1h; hours 2-3 = (y_3h - y_1h) / 2; hours 4-6 = (y_6h - y_3h) / 3.
    Returns ``{1: rate, ..., 6: rate}`` or None when the model is unavailable.
    Cached: the model input is the fixed archive end, so the rates are
    constant until the underlying data is refreshed.
    """
    global _hourly_rates_cache
    if _hourly_rates_cache is not None:
        return _hourly_rates_cache
    detail = get_model_detail()
    if detail is None:
        return None
    preds = detail["expected_mm"]
    y1, y3, y6 = preds["1h"], preds["3h"], preds["6h"]
    rate_1 = max(y1, 0.0)
    rate_23 = max((y3 - y1) / 2.0, 0.0)
    rate_456 = max((y6 - y3) / 3.0, 0.0)
    _hourly_rates_cache = {
        1: round(rate_1, 1),
        2: round(rate_23, 1),
        3: round(rate_23, 1),
        4: round(rate_456, 1),
        5: round(rate_456, 1),
        6: round(rate_456, 1),
    }
    logger.info("Model hourly rates (mm/hr): %s", _hourly_rates_cache)
    return _hourly_rates_cache


def get_model_status() -> dict:
    """Status block for /api/health and response metadata."""
    global _model_status_cache
    if _model_status_cache is not None:
        return _model_status_cache
    fc = get_forecaster()
    if fc is None:
        status = {
            "loaded": False,
            "model": "xgboost+lightgbm+histgradientboosting",
            "model_version": "rainfall-xgb-v3",
            "error": _forecaster_error or "model files not found",
            "note": "Forecast and risk fall back to the demo engine.",
        }
    else:
        detail = get_model_detail()
        status = {
            "loaded": True,
            "model": "xgboost+lightgbm+histgradientboosting",
            "model_version": fc.model_version,
            "horizons_h": [1, 3, 6],
            "data_source": "Open-Meteo ERA5 archive, Bhubaneswar grid cell "
                           "(lat 20.281195, lng 85.843376), hourly 2021-01-01 to 2025-12-31, "
                           "plus convective columns and upwind Puri Coast / Offshore Bay grids"
                           + (" + GFS forecast + moisture-profile features"
                              if fc.model_version == "rainfall-xgb-v3.3" else
                              " + GFS forecast features" if fc.use_gfs else ""),
            "model_input_as_of": detail["model_input_as_of"] + "Z" if detail else "2025-12-31T23:00:00Z",
            "scope": "Bhubaneswar grid cell only (lat 20.281195, lng 85.843376); not state-wide",
            "heavy_risk_tier": detail["heavy_risk_tier"] if detail else None,
            "note": "Forecast uses the model for hours 1-6 (Bhubaneswar region); "
                    "hours 7+ and Ganjam locations use the demo engine. "
                    "Heavy-event detection (elevated/Watch threshold): "
                    + ("v3.3 (pooled out-of-sample 2024+2025, optimized thresholds): "
                       "3h>=10mm Precision 0.12 / Recall 0.39; "
                       "6h>=10mm Precision 0.16 / Recall 0.72; "
                       "3h>=5mm Precision 0.26 / Recall 0.69. "
                       "Thresholds optimised on 2024+2025 development evidence; "
                       "2026 was not used for threshold selection."
                       if fc.model_version == "rainfall-xgb-v3.3" else
                       "v3.2 (2026 fresh evaluation): 3h>=10mm Precision 0.23 / Recall 0.54; "
                       "6h>=10mm Precision 0.28 / Recall 0.80; 3h>=5mm Precision 0.39 / Recall 0.60. "
                       "Thresholds optimised on 2024 validation — re-optimise on validation "
                       "including 2025 before switching production traffic."
                       if fc.use_gfs else
                       "v3 (2025 test): 3h>=10mm Precision 0.15 / Recall 0.30 (caught 26/87); "
                       "6h>=10mm Precision 0.11 / Recall 0.86 (caught 222/258)."),
        }
    _model_status_cache = status
    return status


def model_version() -> str | None:
    fc = get_forecaster()
    return fc.model_version if fc is not None else None
