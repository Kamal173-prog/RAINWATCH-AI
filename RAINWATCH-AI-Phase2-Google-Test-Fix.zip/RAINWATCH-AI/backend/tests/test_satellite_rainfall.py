"""Tests for the NASA GPM IMERG satellite rainfall service (Phase 1).

All HDF5 fixtures here are SYNTHETIC, built locally with the exact
layout verified from a real V07C granule (shape (1, 3600, 1800),
dims (time, lon, lat), _FillValue -9999.9, Grid/time seconds since
1980-01-06 UTC). They test the extraction/indexing logic only — the
values inside them are NOT real NASA data and are never reported as
observations. No test makes a live NASA call: earthaccess is replaced
by a fake via the service's lazy-import helper.
"""

import os
import shutil
from datetime import datetime, timezone

import h5py
import numpy as np
import pytest

from app.services import satellite_rainfall as sr

# --- Synthetic fixture constants (labelled SYNTHETIC throughout) ---
# Real granule filename, reused so interval parsing is exercised.
GRANULE_FILENAME = (
    "3B-HHR-E.MS.MRG.3IMERG.20261125-S030000-E032959.0180.V07C.HDF5")
EPOCH = datetime(1980, 1, 6, tzinfo=timezone.utc)
T0 = int((datetime(2026, 11, 25, 3, 0, 0, tzinfo=timezone.utc) - EPOCH)
         .total_seconds())  # 2026-11-25T03:00:00Z
OLD_TOWN_LAT, OLD_TOWN_LON = 20.2662, 85.8418
# Nearest 0.1-degree cell to Old Town (verified from the real granule).
CELL_LAT, CELL_LON = 20.25, 85.85
CELL_LAT_IDX, CELL_LON_IDX = 697, 2658


def _grid():
    lat = 89.95 - 0.1 * np.arange(1800)
    lon = -179.95 + 0.1 * np.arange(3600)
    return lat, lon


def _cell_index(lat, lon, target_lat, target_lon):
    li = int(np.argmin(np.abs(lat - target_lat)))
    lo = int(np.argmin(np.abs(lon - target_lon)))
    return li, lo


def build_synthetic_granule(path, dims=("time", "lon", "lat"),
                            shape=(1, 3600, 1800), time_seconds=T0):
    """Write a SYNTHETIC IMERG-layout HDF5 file (not real NASA data).

    The full-size array is 0.0 everywhere except: Old Town cell 2.5
    mm/hr, one _FillValue cell, one NaN cell.
    """
    lat, lon = _grid()
    if shape == (1, 3600, 1800):
        precip = np.zeros(shape, dtype=np.float32)
        precip[0, CELL_LON_IDX, CELL_LAT_IDX] = 2.5
        li, lo = _cell_index(lat, lon, 19.35, 84.95)
        precip[0, lo, li] = -9999.9  # float32 -> -9999.900390625
        li, lo = _cell_index(lat, lon, 19.45, 85.05)
        precip[0, lo, li] = np.nan
        lat_ds, lon_ds = lat.astype(np.float32), lon.astype(np.float32)
    else:
        # Small fixture: same layout, scaled-down grids.
        nlat, nlon = shape[2], shape[1]
        lat_ds = (89.95 - 0.1 * np.arange(nlat)).astype(np.float32)
        lon_ds = (-179.95 + 0.1 * np.arange(nlon)).astype(np.float32)
        precip = np.zeros(shape, dtype=np.float32)
        precip[0, 0, 0] = 1.0
    with h5py.File(path, "w") as f:
        g = f.create_group("Grid")
        ds = g.create_dataset("precipitation", data=precip)
        ds.attrs["DimensionNames"] = np.array([d.encode() for d in dims])
        ds.attrs["Units"] = "mm/hr"
        # Deliberately float64 attr vs float32 array (the real file's
        # mismatch that the 1e-3 fill tolerance exists for).
        ds.attrs["_FillValue"] = -9999.9
        g.create_dataset("lat", data=lat_ds)
        g.create_dataset("lon", data=lon_ds)
        g.create_dataset("time", data=np.array([time_seconds], dtype=np.int64))
    return path


@pytest.fixture(scope="module")
def granule_file(tmp_path_factory):
    """One full-size SYNTHETIC granule, shared by the module's tests."""
    path = (tmp_path_factory.mktemp("sat")
            / GRANULE_FILENAME)
    return build_synthetic_granule(str(path))


def _result(filename, size_bytes=None):
    """A fake CMR search result in earthaccess's shape."""
    umm = {"GranuleUR": filename}
    if size_bytes is not None:
        umm["DataGranule"] = {"ArchiveAndDistributionInformation":
                              [{"SizeInBytes": size_bytes}]}
    return {"umm": umm, "meta": {"concept-id": "C2723758340-GES_DISC"}}


V07C_RESULT = _result(GRANULE_FILENAME)
V07B_RESULT = _result(
    "3B-HHR-E.MS.MRG.3IMERG.20261125-S023000-E025959.0170.V07B.HDF5")


class FakeEarthaccess:
    """Stand-in for the earthaccess module (no network, no credentials)."""

    def __init__(self, results=None, fixture_file=None,
                 fail_search=False, fail_download=False,
                 download_mode="copy"):
        self.results = list(results) if results is not None else []
        self.fixture_file = fixture_file
        self.fail_search = fail_search
        self.fail_download = fail_download
        self.download_mode = download_mode  # "copy" | "garbage"
        self.login_calls = 0
        self.search_calls = []
        self.download_calls = []

    def login(self):
        self.login_calls += 1
        return True

    def search_data(self, concept_id=None, temporal=None, bounding_box=None):
        self.search_calls.append({"concept_id": concept_id,
                                  "temporal": temporal,
                                  "bounding_box": bounding_box})
        if self.fail_search:
            raise RuntimeError("CMR unavailable (fake)")
        return list(self.results)

    def download(self, granules, local_dir):
        self.download_calls.append(granules)
        if self.fail_download:
            raise RuntimeError("download failed (fake)")
        g = granules if isinstance(granules, dict) else granules[0]
        filename = g["umm"]["GranuleUR"]
        # Real earthaccess names the downloaded file from the data-link
        # URL basename (the producer filename), never from GranuleUR —
        # mimic that, so a GranuleUR containing ":" (the real CMR form
        # is "GPM_3IMERGHHE.07:3B-HHR-E...HDF5") does not break the
        # fake itself on Windows. The service's cache destination is
        # what the filename tests exercise, not this tmpdir name.
        filename = filename.rsplit(":", 1)[-1]
        dest = os.path.join(local_dir, filename)
        if self.download_mode == "garbage":
            with open(dest, "wb") as f:
                f.write(b"not an hdf5 file" * 10)
        else:
            shutil.copyfile(self.fixture_file, dest)
        return [dest]


@pytest.fixture(autouse=True)
def _reset(monkeypatch, tmp_path):
    sr.reset_state()
    monkeypatch.setenv("EARTHDATA_USERNAME", "test-user")
    monkeypatch.setenv("EARTHDATA_PASSWORD", "test-pass")
    monkeypatch.setenv("SATELLITE_CACHE_DIR", str(tmp_path / "cache"))
    yield
    sr.reset_state()


def _install_fake(monkeypatch, fake):
    monkeypatch.setattr(sr, "_earthaccess", lambda: fake)
    return fake


def _cached_copy(granule_file, tmp_path):
    """Pre-place a valid granule in the test cache dir (reuse tests)."""
    cache = tmp_path / "cache"
    cache.mkdir(parents=True, exist_ok=True)
    dest = cache / GRANULE_FILENAME
    shutil.copyfile(str(granule_file), str(dest))
    return str(dest)


# ------------------------------------------------------------------
# Extraction from a synthetic granule (structure only, not real data)
# ------------------------------------------------------------------

def test_valid_nonzero_rainfall_old_town(granule_file, monkeypatch):
    fake = _install_fake(monkeypatch, FakeEarthaccess(
        results=[V07C_RESULT], fixture_file=str(granule_file)))
    out = sr.get_rainfall_for_location(
        OLD_TOWN_LAT, OLD_TOWN_LON, "2026-11-25T03:15:00Z")
    assert out["source"] == "NASA GPM IMERG"
    assert out["product"] == "IMERG Early Run"
    assert out["version"] == "V07C"
    assert out["status"] == "VALID_RAINFALL"
    assert out["precipitationRateMmHr"] == 2.5
    assert out["accumulationMm"] == 1.25  # 2.5 mm/hr x 0.5 h
    assert out["gridCell"]["latitude"] == pytest.approx(CELL_LAT, abs=1e-4)
    assert out["gridCell"]["longitude"] == pytest.approx(CELL_LON, abs=1e-4)
    assert out["gridCell"]["latIndex"] == CELL_LAT_IDX
    assert out["gridCell"]["lonIndex"] == CELL_LON_IDX
    assert abs(out["gridCell"]["distanceKm"] - 1.99) < 0.05
    assert out["observationTimeUtc"] == "2026-11-25T03:00:00Z"
    assert out["observationTimeIst"] == "2026-11-25T08:30:00+05:30"
    assert out["observationIntervalMinutes"] == 30
    assert out["granule"]["filename"] == GRANULE_FILENAME
    assert out["granule"]["nativeId"] == GRANULE_FILENAME
    assert out["granule"]["conceptId"] == "C2723758340-GES_DISC"
    assert out["retrievedAtUtc"] is not None
    assert fake.download_calls  # one download happened


def test_valid_zero_rainfall(granule_file, monkeypatch):
    _install_fake(monkeypatch, FakeEarthaccess(
        results=[V07C_RESULT], fixture_file=str(granule_file)))
    # Cell (20.35, 85.85) is 0.0 in the synthetic fixture: a real zero,
    # not missing data.
    out = sr.get_rainfall_for_location(20.35, 85.85, "2026-11-25T03:15:00Z")
    assert out["status"] == "VALID_ZERO"
    assert out["precipitationRateMmHr"] == 0.0
    assert out["accumulationMm"] == 0.0


def test_fill_value_is_missing_not_zero(granule_file, monkeypatch):
    _install_fake(monkeypatch, FakeEarthaccess(
        results=[V07C_RESULT], fixture_file=str(granule_file)))
    # Cell holds float32 -9999.900390625 vs float64 attr -9999.9.
    out = sr.get_rainfall_for_location(19.35, 84.95, "2026-11-25T03:15:00Z")
    assert out["status"] == "MISSING"
    assert out["precipitationRateMmHr"] is None
    assert out["accumulationMm"] is None


def test_nan_is_missing_not_zero(granule_file, monkeypatch):
    _install_fake(monkeypatch, FakeEarthaccess(
        results=[V07C_RESULT], fixture_file=str(granule_file)))
    out = sr.get_rainfall_for_location(19.45, 85.05, "2026-11-25T03:15:00Z")
    assert out["status"] == "MISSING"
    assert out["precipitationRateMmHr"] is None
    assert out["accumulationMm"] is None


def test_haversine_distance_old_town():
    assert abs(sr.haversine_km(20.2662, 85.8418, 20.25, 85.85) - 1.99) < 0.05
    assert sr.haversine_km(20.2662, 85.8418, 20.2662, 85.8418) == 0.0


def test_nearest_cell_calculation(granule_file, monkeypatch):
    _install_fake(monkeypatch, FakeEarthaccess(
        results=[V07C_RESULT], fixture_file=str(granule_file)))
    out = sr.get_rainfall_for_location(
        OLD_TOWN_LAT, OLD_TOWN_LON, "2026-11-25T03:15:00Z")
    assert out["gridCell"]["latitude"] == pytest.approx(20.25, abs=1e-4)
    assert out["gridCell"]["longitude"] == pytest.approx(85.85, abs=1e-4)
    assert out["gridCell"]["distanceKm"] == 1.99


# ------------------------------------------------------------------
# Structural refusal (small synthetic fixtures)
# ------------------------------------------------------------------

def test_wrong_dimension_order_refused(tmp_path):
    bad = build_synthetic_granule(
        str(tmp_path / "wrong.h5"), dims=("time", "lat", "lon"),
        shape=(1, 36, 18))
    with pytest.raises(sr.SatelliteError) as excinfo:
        sr._read_granule(bad)
    assert "dimension order" in str(excinfo.value).lower()


def test_shape_mismatch_refused(tmp_path):
    # Dims say (time, lon, lat) but shape disagrees with lon length.
    path = str(tmp_path / "badshape.h5")
    with h5py.File(path, "w") as f:
        g = f.create_group("Grid")
        ds = g.create_dataset("precipitation",
                              data=np.zeros((1, 36, 19), dtype=np.float32))
        ds.attrs["DimensionNames"] = np.array([b"time", b"lon", b"lat"])
        ds.attrs["Units"] = "mm/hr"
        ds.attrs["_FillValue"] = -9999.9
        g.create_dataset("lat", data=np.zeros(18, dtype=np.float32))
        g.create_dataset("lon", data=np.zeros(36, dtype=np.float32))
        g.create_dataset("time", data=np.array([T0], dtype=np.int64))
    with pytest.raises(sr.SatelliteError):
        sr._read_granule(path)


def test_missing_fill_value_refused(tmp_path):
    path = str(tmp_path / "nofill.h5")
    build_synthetic_granule(path, shape=(1, 36, 18))
    with h5py.File(path, "r+") as f:
        del f["Grid/precipitation"].attrs["_FillValue"]
    with pytest.raises(sr.SatelliteError):
        sr._read_granule(path)


def test_filename_interval_parsing():
    parsed = sr._parse_filename(GRANULE_FILENAME)
    assert parsed["version"] == "V07C"
    assert parsed["intervalMinutes"] == 30
    assert parsed["start"] == datetime(2026, 11, 25, 3, 0, tzinfo=timezone.utc)
    assert parsed["end"] == datetime(2026, 11, 25, 3, 29, 59, tzinfo=timezone.utc)
    assert sr._parse_filename("garbage.h5")["version"] is None
    assert sr._parse_filename("garbage.h5")["intervalMinutes"] is None


# ------------------------------------------------------------------
# Auth / discovery / cache / download
# ------------------------------------------------------------------

def test_missing_credentials(monkeypatch):
    monkeypatch.delenv("EARTHDATA_USERNAME", raising=False)
    monkeypatch.delenv("EARTHDATA_PASSWORD", raising=False)
    with pytest.raises(sr.SatelliteNotConfigured):
        sr.get_rainfall_for_location(OLD_TOWN_LAT, OLD_TOWN_LON)
    status = sr.get_satellite_status()
    assert status["configured"] is False
    assert status["status"] == "Not Configured"


def test_empty_search_results(monkeypatch):
    _install_fake(monkeypatch, FakeEarthaccess(results=[]))
    with pytest.raises(sr.SatelliteError) as excinfo:
        sr.get_rainfall_for_location(OLD_TOWN_LAT, OLD_TOWN_LON)
    assert "No GPM IMERG granules" in str(excinfo.value)
    assert sr.get_satellite_status()["status"] == "Error"


def test_search_failure_is_satellite_error(monkeypatch):
    _install_fake(monkeypatch, FakeEarthaccess(
        results=[V07C_RESULT], fail_search=True))
    with pytest.raises(sr.SatelliteError):
        sr.get_rainfall_for_location(OLD_TOWN_LAT, OLD_TOWN_LON)


def test_cached_granule_reused_no_second_download(
        granule_file, monkeypatch, tmp_path):
    _cached_copy(granule_file, tmp_path)
    fake = _install_fake(monkeypatch, FakeEarthaccess(
        results=[V07C_RESULT], fixture_file=str(granule_file)))
    out = sr.get_rainfall_for_location(
        OLD_TOWN_LAT, OLD_TOWN_LON, "2026-11-25T03:15:00Z")
    assert out["status"] == "VALID_RAINFALL"
    assert out["precipitationRateMmHr"] == 2.5
    assert fake.download_calls == []
    assert fake.search_calls == []


def test_latest_granule_reused_when_fresh(
        granule_file, monkeypatch, tmp_path):
    _cached_copy(granule_file, tmp_path)
    # The synthetic granule is dated 2026-11-25; treat it as fresh.
    monkeypatch.setattr(sr, "CACHE_FRESH_SECONDS", 10 ** 9)
    fake = _install_fake(monkeypatch, FakeEarthaccess(
        results=[V07C_RESULT], fixture_file=str(granule_file)))
    meta = sr.get_latest_granule()
    assert meta["filename"] == GRANULE_FILENAME
    assert meta["cached"] is True
    assert fake.download_calls == []
    assert fake.search_calls == []


def test_failed_download_leaves_no_partial_file(
        granule_file, monkeypatch, tmp_path):
    fake = _install_fake(monkeypatch, FakeEarthaccess(
        results=[V07C_RESULT], fixture_file=str(granule_file),
        fail_download=True))
    with pytest.raises(sr.SatelliteError):
        sr.get_rainfall_for_location(
            OLD_TOWN_LAT, OLD_TOWN_LON, "2026-11-25T03:15:00Z")
    cache = tmp_path / "cache"
    assert not list(cache.glob("*.HDF5"))
    assert not [d for d in cache.iterdir() if d.name.startswith(".download-")]


def test_garbage_download_rejected(granule_file, monkeypatch, tmp_path):
    fake = _install_fake(monkeypatch, FakeEarthaccess(
        results=[V07C_RESULT], fixture_file=str(granule_file),
        download_mode="garbage"))
    with pytest.raises(sr.SatelliteError):
        sr.get_rainfall_for_location(
            OLD_TOWN_LAT, OLD_TOWN_LON, "2026-11-25T03:15:00Z")
    cache = tmp_path / "cache"
    assert not list(cache.glob("*.HDF5"))
    assert fake.download_calls


def test_cmr_size_mismatch_rejected(granule_file, monkeypatch, tmp_path):
    size = os.path.getsize(str(granule_file))
    wrong = _result(GRANULE_FILENAME, size_bytes=size + 12345)
    fake = _install_fake(monkeypatch, FakeEarthaccess(
        results=[wrong], fixture_file=str(granule_file)))
    with pytest.raises(sr.SatelliteError) as excinfo:
        sr.get_rainfall_for_location(
            OLD_TOWN_LAT, OLD_TOWN_LON, "2026-11-25T03:15:00Z")
    assert "size" in str(excinfo.value).lower()
    assert not list((tmp_path / "cache").glob("*.HDF5"))


def test_v07c_preferred_over_v07b(granule_file, monkeypatch):
    fake = _install_fake(monkeypatch, FakeEarthaccess(
        results=[V07B_RESULT, V07C_RESULT], fixture_file=str(granule_file)))
    meta = sr.get_latest_granule()
    assert meta["version"] == "V07C"
    assert meta["filename"] == GRANULE_FILENAME
    downloaded = fake.download_calls[0]
    assert downloaded["umm"]["GranuleUR"] == GRANULE_FILENAME


def test_v07b_used_when_no_v07c(granule_file, monkeypatch):
    fake = _install_fake(monkeypatch, FakeEarthaccess(
        results=[V07B_RESULT], fixture_file=str(granule_file)))
    meta = sr.get_latest_granule()
    assert meta["version"] == "V07B"
    assert fake.download_calls


def test_time_outside_any_granule_is_error_not_substitution(
        granule_file, monkeypatch):
    _install_fake(monkeypatch, FakeEarthaccess(
        results=[V07C_RESULT], fixture_file=str(granule_file)))
    with pytest.raises(sr.SatelliteError) as excinfo:
        # 05:00Z is covered by no granule in the fake search window.
        sr.get_rainfall_for_location(
            OLD_TOWN_LAT, OLD_TOWN_LON, "2026-11-25T05:00:00Z")
    assert "covers" in str(excinfo.value)


def test_sidecar_written_on_download(granule_file, monkeypatch, tmp_path):
    _install_fake(monkeypatch, FakeEarthaccess(
        results=[V07C_RESULT], fixture_file=str(granule_file)))
    sr.get_rainfall_for_location(
        OLD_TOWN_LAT, OLD_TOWN_LON, "2026-11-25T03:15:00Z")
    sidecar = tmp_path / "cache" / (GRANULE_FILENAME + ".json")
    assert sidecar.exists()
    import json
    data = json.loads(sidecar.read_text())
    assert data["filename"] == GRANULE_FILENAME
    assert data["version"] == "V07C"
    assert data["nativeId"] == GRANULE_FILENAME
    assert data["conceptId"] == "C2723758340-GES_DISC"
    assert data["sizeBytes"] == os.path.getsize(str(granule_file))
    assert data["sha256"] is not None
    assert data["observationStartUtc"] == "2026-11-25T03:00:00Z"
    assert data["observationIntervalMinutes"] == 30


# ------------------------------------------------------------------
# Validation, status, region
# ------------------------------------------------------------------

def test_invalid_coordinates():
    for lat, lon in [(100, 85.8), (-91, 85.8), (20.2, 200), (20.2, -181)]:
        with pytest.raises(ValueError):
            sr.get_rainfall_for_location(lat, lon)
    with pytest.raises(ValueError):
        sr.get_rainfall_for_location("not-a-number", 85.8)


def test_status_ready_after_success(granule_file, monkeypatch):
    _install_fake(monkeypatch, FakeEarthaccess(
        results=[V07C_RESULT], fixture_file=str(granule_file)))
    before = sr.get_satellite_status()
    assert before["status"] == "Ready"
    assert before["configured"] is True
    assert before["lastRetrievedAt"] is None
    sr.get_rainfall_for_location(
        OLD_TOWN_LAT, OLD_TOWN_LON, "2026-11-25T03:15:00Z")
    after = sr.get_satellite_status()
    assert after["status"] == "Ready"
    assert after["lastRetrievedAt"] is not None
    assert after["recordsRetrieved"] == 1
    assert after["cachedGranules"] == 1
    assert after["latestGranule"] == GRANULE_FILENAME


def test_region_bhubaneswar_shares_one_granule(
        granule_file, monkeypatch):
    fake = _install_fake(monkeypatch, FakeEarthaccess(
        results=[V07C_RESULT], fixture_file=str(granule_file)))
    out = sr.get_rainfall_for_region("bhubaneswar")
    assert out["region"]["id"] == "bhubaneswar"
    assert out["granule"]["filename"] == GRANULE_FILENAME
    # 12 RAINWATCH locations fall inside the Bhubaneswar bbox (Cuttack
    # and Puri belong to the region by regionId but lie outside its
    # bbox), in LOCATIONS order.
    assert len(out["locations"]) == 12
    assert out["locations"][0]["location"] == {
        "latitude": 20.3546, "longitude": 85.8006}  # Patia, first in list
    old_town = [l for l in out["locations"]
                if l["location"] == {"latitude": 20.2662,
                                     "longitude": 85.8418}][0]
    assert old_town["status"] == "VALID_RAINFALL"
    assert old_town["precipitationRateMmHr"] == 2.5
    assert len(fake.download_calls) == 1  # one shared download
    assert sr.get_satellite_status()["recordsRetrieved"] == 12


def test_region_ganjam_dict_bbox(granule_file, monkeypatch):
    _install_fake(monkeypatch, FakeEarthaccess(
        results=[V07C_RESULT], fixture_file=str(granule_file)))
    out = sr.get_rainfall_for_region(
        {"minLat": 19.1, "maxLat": 19.52, "minLon": 84.53, "maxLon": 85.09})
    assert len(out["locations"]) == 7  # the Ganjam locations
    assert all(l["source"] == "NASA GPM IMERG" for l in out["locations"])


def test_region_unknown_id():
    with pytest.raises(ValueError):
        sr.get_rainfall_for_region("nowhere")


def test_region_bad_bbox():
    with pytest.raises(ValueError):
        sr.get_rainfall_for_region({"minLat": 10, "maxLat": 5,
                                    "minLon": 80, "maxLon": 81})

# ------------------------------------------------------------------
# Windows filename safety (WinError 123 regression, 2026-11-26)
#
# CMR GranuleURs for this collection are "<ShortName>:<filename>"
# (e.g. "GPM_3IMERGHHE.07:3B-HHR-E...HDF5"). The service used the raw
# GranuleUR as the cache destination, so on Windows the download
# failed with [WinError 123] at os.replace() — ":" is invalid in a
# Windows filename. The fix percent-encodes invalid characters in
# the ON-DISK name only; the native ID, remote URL and metadata are
# untouched. All fixtures below are SYNTHETIC (same layout as the
# real V07C granule); no test makes a live NASA call.
# ------------------------------------------------------------------

# The exact GranuleUR form from the reported Windows failure.
COLON_GRANULE_UR = (
    "GPM_3IMERGHHE.07:3B-HHR-E.MS.MRG.3IMERG.20261125-S030000-E032959"
    ".0180.V07C.HDF5")
COLON_GRANULE_SAFE = (
    "GPM_3IMERGHHE.07%3A3B-HHR-E.MS.MRG.3IMERG.20261125-S030000-E032959"
    ".0180.V07C.HDF5")
WINDOWS_INVALID = '<>:"/\\|?*'


def _assert_windows_safe(name):
    assert ":" not in name
    for ch in WINDOWS_INVALID:
        assert ch not in name, f"invalid char {ch!r} in {name!r}"
    for ch in name:
        assert ord(ch) >= 0x20, f"control char in {name!r}"
    assert not name.endswith((".", " "))


def test_sanitize_colon_granule_ur():
    assert sr._sanitize_cache_filename(COLON_GRANULE_UR) == COLON_GRANULE_SAFE
    _assert_windows_safe(COLON_GRANULE_SAFE)
    # The sanitized name still parses: same version, start, interval.
    parsed = sr._parse_filename(COLON_GRANULE_SAFE)
    assert parsed["version"] == "V07C"
    assert parsed["intervalMinutes"] == 30
    assert parsed["start"] == datetime(2026, 11, 25, 3, 0, tzinfo=timezone.utc)


def test_sanitize_all_windows_invalid_chars():
    for ch in WINDOWS_INVALID:
        safe = sr._sanitize_cache_filename(f"a{ch}b.HDF5")
        assert ch not in safe
        _assert_windows_safe(safe)
    # Control characters are encoded too.
    assert "\x01" not in sr._sanitize_cache_filename("a\x01b.HDF5")
    _assert_windows_safe(sr._sanitize_cache_filename("a\x01b.HDF5"))


def test_sanitize_percent_is_escaped_not_confused():
    # "%" itself is encoded first, so a literal "%3A" in the input can
    # never be mistaken for an encoded ":".
    assert sr._sanitize_cache_filename("a%b.HDF5") == "a%25b.HDF5"
    assert sr._sanitize_cache_filename("a%3Ab.HDF5") == "a%253Ab.HDF5"


def test_sanitize_clean_names_unchanged():
    # The plain producer filename (no invalid chars) passes through
    # byte-identical — existing cache files keep their names.
    assert sr._sanitize_cache_filename(GRANULE_FILENAME) == GRANULE_FILENAME
    assert sr._sanitize_cache_filename("plain-name.HDF5") == "plain-name.HDF5"


def test_sanitize_trailing_dots_and_spaces():
    # Windows silently strips trailing dots/spaces, which would break
    # the filename/sidecar round-trip.
    assert sr._sanitize_cache_filename("a.HDF5.") == "a.HDF5%2E"
    assert sr._sanitize_cache_filename("a.HDF5 ") == "a.HDF5%20"
    _assert_windows_safe(sr._sanitize_cache_filename("a.HDF5. "))


def test_sanitize_is_injective_no_collision():
    # Two different native IDs must never map to one cache filename —
    # otherwise one granule could overwrite an unrelated one.
    assert (sr._sanitize_cache_filename("A:B.HDF5")
            != sr._sanitize_cache_filename("A_B.HDF5"))
    assert (sr._sanitize_cache_filename("A%B.HDF5")
            != sr._sanitize_cache_filename("A%25B.HDF5"))
    assert (sr._sanitize_cache_filename("A<B.HDF5")
            != sr._sanitize_cache_filename("A_B.HDF5"))


def test_download_with_colon_granule_ur_uses_safe_filename(
        granule_file, monkeypatch, tmp_path):
    fake = _install_fake(monkeypatch, FakeEarthaccess(
        results=[_result(COLON_GRANULE_UR)],
        fixture_file=str(granule_file)))
    out = sr.get_rainfall_for_location(
        OLD_TOWN_LAT, OLD_TOWN_LON, "2026-11-25T03:15:00Z")
    # The value still extracts from the real (synthetic) layout.
    assert out["status"] == "VALID_RAINFALL"
    assert out["precipitationRateMmHr"] == 2.5
    # On-disk name is sanitized; the native ID is preserved verbatim.
    assert out["granule"]["filename"] == COLON_GRANULE_SAFE
    assert out["granule"]["nativeId"] == COLON_GRANULE_UR
    assert out["granule"]["version"] == "V07C"
    cache = tmp_path / "cache"
    on_disk = [p.name for p in cache.iterdir() if p.is_file()]
    assert COLON_GRANULE_SAFE in on_disk
    assert not [n for n in on_disk if ":" in n], on_disk
    for name in on_disk:
        _assert_windows_safe(name)
    # Sidecar sits next to the sanitized file and keeps the original ID.
    import json
    sidecar = json.loads(
        (cache / (COLON_GRANULE_SAFE + ".json")).read_text())
    assert sidecar["filename"] == COLON_GRANULE_SAFE
    assert sidecar["nativeId"] == COLON_GRANULE_UR


def test_colon_granule_cached_reuse_no_second_download(
        granule_file, monkeypatch, tmp_path):
    fake = _install_fake(monkeypatch, FakeEarthaccess(
        results=[_result(COLON_GRANULE_UR)],
        fixture_file=str(granule_file)))
    first = sr.get_rainfall_for_location(
        OLD_TOWN_LAT, OLD_TOWN_LON, "2026-11-25T03:15:00Z")
    assert first["precipitationRateMmHr"] == 2.5
    assert len(fake.download_calls) == 1
    second = sr.get_rainfall_for_location(
        OLD_TOWN_LAT, OLD_TOWN_LON, "2026-11-25T03:15:00Z")
    assert second["precipitationRateMmHr"] == 2.5
    assert second["granule"]["filename"] == COLON_GRANULE_SAFE
    assert len(fake.download_calls) == 1  # cached, no re-download
    assert len(fake.search_calls) == 1


def test_legacy_colon_cached_file_reused_by_scan(
        granule_file, monkeypatch, tmp_path):
    # A file cached under the RAW colon name (possible on Linux/macOS,
    # impossible on Windows) must still be found and reused, never
    # treated as missing. Skipped on Windows: such a file cannot exist
    # there in the first place.
    import sys
    if sys.platform == "win32":
        pytest.skip("colon filenames cannot exist on Windows")
    cache = tmp_path / "cache"
    cache.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(str(granule_file), str(cache / COLON_GRANULE_UR))
    fake = _install_fake(monkeypatch, FakeEarthaccess(
        results=[_result(COLON_GRANULE_UR)],
        fixture_file=str(granule_file)))
    out = sr.get_rainfall_for_location(
        OLD_TOWN_LAT, OLD_TOWN_LON, "2026-11-25T03:15:00Z")
    assert out["status"] == "VALID_RAINFALL"
    assert out["precipitationRateMmHr"] == 2.5
    assert fake.download_calls == []
    assert fake.search_calls == []


def test_legacy_colon_cached_file_migrated_on_download(
        granule_file, monkeypatch, tmp_path):
    # When the download path itself meets a legacy colon-named file
    # (e.g. the scan did not return it because it is stale), it is
    # renamed in place — file and sidecar — instead of downloading
    # the same granule again. Skipped on Windows: such a file cannot
    # exist there in the first place.
    import sys
    if sys.platform == "win32":
        pytest.skip("colon filenames cannot exist on Windows")
    cache = tmp_path / "cache"
    cache.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(str(granule_file), str(cache / COLON_GRANULE_UR))
    (cache / (COLON_GRANULE_UR + ".json")).write_text(
        '{"filename": "%s", "nativeId": "%s"}'
        % (COLON_GRANULE_UR, COLON_GRANULE_UR))
    fake = _install_fake(monkeypatch, FakeEarthaccess(
        results=[_result(COLON_GRANULE_UR)],
        fixture_file=str(granule_file)))
    meta = sr._download_granule(_result(COLON_GRANULE_UR))
    assert meta["cached"] is True
    assert meta["filename"] == COLON_GRANULE_SAFE
    assert meta["nativeId"] == COLON_GRANULE_UR
    assert fake.download_calls == []
    assert not (cache / COLON_GRANULE_UR).exists()
    assert (cache / COLON_GRANULE_SAFE).exists()
    assert (cache / (COLON_GRANULE_SAFE + ".json")).exists()
    assert not (cache / (COLON_GRANULE_UR + ".json")).exists()
