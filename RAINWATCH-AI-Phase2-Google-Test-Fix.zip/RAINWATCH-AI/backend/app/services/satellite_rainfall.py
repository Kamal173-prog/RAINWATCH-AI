"""NASA GPM IMERG satellite rainfall service — Phase 1 (service only).

Converts the verified Phase 0 spike (``backend/ml/satellite_spike.py``)
into a reusable, FastAPI-independent service. No endpoint code lives
here; Phase 2 will expose these functions through API routes.

Verified facts (2026-11-26, from a real V07C granule):
- Product: GPM IMERG Early Run, collection ``GPM_3IMERGHHE_07``,
  CMR concept ID ``C2723758340-GES_DISC``.
- Variable ``Grid/precipitation``, mm/hr. Dimension order
  (time, longitude, latitude), shape (1, 3600, 1800), lat (1800,),
  lon (3600,). ``Grid/time`` is seconds since 1980-01-06 UTC.
- 30-minute granules, Early Run latency ~4 h. Live files are V07C.
- ``_FillValue`` -9999.9, confirmed from the Early file itself.
- Old Town (20.2662, 85.8418) nearest cell lat 20.25, lon 85.85,
  ~1.99 km away.

Honesty / separation rules:
- Satellite values are OBSERVATIONS, never forecasts. Nothing in this
  module labels them as a forecast, and nothing here feeds the ML
  model, the merged forecast, Google Weather, or any risk calculation.
- No value is ever fabricated. Missing credentials ->
  ``SatelliteNotConfigured``; no granules, a NASA failure, a bad file
  or an unsupported dimension order -> ``SatelliteError``. A missing
  value is reported as MISSING with null numerics, never as zero.
- earthaccess and h5py are imported lazily inside the functions that
  need them, so this module imports cleanly when they are absent and a
  missing dependency can never break the rest of the backend.
- Credentials come from the environment (``backend/.env`` is loaded by
  ``app.core.config`` at import). They are never hardcoded, never
  printed, and never logged.
- Local cache filenames are sanitized (percent-encoded): CMR GranuleURs
  are ``<ShortName>:<filename>`` and the ``:`` is invalid on Windows
  ([WinError 123] at download). The native ID is preserved verbatim in
  metadata (``nativeId``), the remote URL and the sidecar — only the
  on-disk name is encoded. A file cached under the raw name (possible
  on Linux/macOS) is migrated in place instead of re-downloaded.
"""

import hashlib
import json
import logging
import math
import os
import re
import shutil
import tempfile
import threading
from datetime import datetime, timedelta, timezone
from typing import Any, Optional
from zoneinfo import ZoneInfo

import numpy as np

from app.core import config  # noqa: F401  (import loads backend/.env via load_dotenv)
from app.engine import locations as locations_engine

logger = logging.getLogger("rainwatch.satellite_rainfall")

# ------------------------------------------------------------------
# Verified product constants
# ------------------------------------------------------------------

COLLECTION_CONCEPT_ID = "C2723758340-GES_DISC"
SOURCE_NAME = "NASA GPM IMERG"
PRODUCT_NAME = "IMERG Early Run"
EXPECTED_DIMS = ("time", "lon", "lat")
TIME_EPOCH = datetime(1980, 1, 6, tzinfo=timezone.utc)
IST = ZoneInfo("Asia/Kolkata")
# float32 array vs float64 _FillValue: -9999.9 reads back as
# -9999.900390625. A 1e-3 tolerance is safe: real rain rates are >= 0
# and never sit near -9999.9.
FILL_TOLERANCE = 1e-3
# A cached granule is reusable without a time request only while its
# observation is this fresh. Early Run latency is ~4 h.
CACHE_FRESH_SECONDS = 6 * 3600
# Search window for "latest available" (covers the ~4 h latency).
LATEST_SEARCH_WINDOW_HOURS = 8

_FILENAME_RE = re.compile(
    r"(\d{8})-S(\d{6})-E(\d{6})\.\d+\.(V\d+[A-Z])\.HDF5$", re.IGNORECASE)
_VERSION_RE = re.compile(r"\.(V\d+[A-Z])\.HDF5$", re.IGNORECASE)


# ------------------------------------------------------------------
# Errors
# ------------------------------------------------------------------

class SatelliteNotConfigured(Exception):
    """No Earthdata credentials are configured."""


class SatelliteError(Exception):
    """Satellite retrieval/extraction failed (NASA, file, or structure)."""

    def __init__(self, reason: str):
        super().__init__(reason)
        self.reason = reason


# ------------------------------------------------------------------
# Module state (process-local). Reset via reset_state() in tests.
# Disk cache is NOT cleared by reset_state().
# ------------------------------------------------------------------

_last_success_at: Optional[str] = None
_last_error: Optional[str] = None
_records_retrieved: int = 0
_download_lock = threading.Lock()


def reset_state() -> None:
    """Test-only: clear counters and error state (disk cache untouched)."""
    global _last_success_at, _last_error, _records_retrieved
    _last_success_at = None
    _last_error = None
    _records_retrieved = 0


# ------------------------------------------------------------------
# Small helpers
# ------------------------------------------------------------------

def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _fmt_utc(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _fmt_ist(dt: datetime) -> str:
    return dt.astimezone(IST).isoformat()


def _credentials() -> tuple[str, str]:
    """Earthdata credentials from the environment.

    config.load_dotenv() already loaded backend/.env at import, so
    os.environ carries them. Empty/missing -> SatelliteNotConfigured.
    """
    user = os.environ.get("EARTHDATA_USERNAME", "") or ""
    pw = os.environ.get("EARTHDATA_PASSWORD", "") or ""
    if not user.strip() or not pw.strip():
        raise SatelliteNotConfigured(
            "Earthdata credentials not configured "
            "(EARTHDATA_USERNAME / EARTHDATA_PASSWORD)")
    return user, pw


def _cache_dir() -> str:
    """Granule cache directory (SATELLITE_CACHE_DIR overrides the default)."""
    override = os.environ.get("SATELLITE_CACHE_DIR", "").strip()
    if override:
        path = os.path.abspath(override)
    else:
        backend_dir = os.path.dirname(os.path.dirname(
            os.path.dirname(os.path.abspath(__file__))))
        path = os.path.join(backend_dir, "data", "satellite")
    os.makedirs(path, exist_ok=True)
    return path


def _earthaccess():
    """Lazy earthaccess import (mocked in tests via this helper)."""
    try:
        import earthaccess
    except ImportError as exc:
        raise SatelliteError(
            "earthaccess is not installed — run: pip install earthaccess==1.0.0"
        ) from exc
    return earthaccess


def _h5py():
    """Lazy h5py import (mocked in tests via this helper)."""
    try:
        import h5py
    except ImportError as exc:
        raise SatelliteError(
            "h5py is not installed — run: pip install h5py==3.16.0"
        ) from exc
    return h5py


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance between two points, in kilometres."""
    r = 6371.0088
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def _is_fill_value(val: float, fill: float) -> bool:
    return abs(val - fill) <= FILL_TOLERANCE


def _decode_dims(raw: Any) -> tuple:
    """DimensionNames as plain strings, whatever h5py returns."""
    if raw is None:
        return ()
    if isinstance(raw, (bytes, str)):
        text = raw.decode("utf-8", "replace") if isinstance(raw, bytes) else raw
        return tuple(s.strip() for s in text.split(",") if s.strip())
    out = []
    for d in raw:
        if isinstance(d, bytes):
            out.append(d.decode("utf-8", "replace"))
        else:
            out.append(str(d))
    return tuple(out)


def _parse_filename(filename: str) -> dict:
    """Start/end/version from a granule filename, or Nones when unparsable.

    Example: 3B-HHR-E.MS.MRG.3IMERG.20261125-S030000-E032959.0180.V07C.HDF5
    -> start 2026-11-25T03:00:00Z, end 2026-11-25T03:29:59Z, version V07C.
    The filename end is the last second of the interval; the half-open
    interval is [start, start + interval_minutes).
    """
    m = _FILENAME_RE.search(filename)
    if not m:
        vm = _VERSION_RE.search(filename)
        return {"start": None, "end": None, "version":
                vm.group(1) if vm else None, "intervalMinutes": None}
    date_s, start_s, end_s, version = m.groups()
    try:
        start = datetime.strptime(date_s + start_s, "%Y%m%d%H%M%S").replace(
            tzinfo=timezone.utc)
        end = datetime.strptime(date_s + end_s, "%Y%m%d%H%M%S").replace(
            tzinfo=timezone.utc)
    except ValueError:
        return {"start": None, "end": None, "version": version,
                "intervalMinutes": None}
    minutes = int(round((end - start).total_seconds() / 60.0))
    return {"start": start, "end": end, "version": version,
            "intervalMinutes": minutes if minutes > 0 else None}


def _parse_iso(value: Any) -> datetime:
    """Parse an ISO timestamp to an aware UTC datetime (naive -> UTC)."""
    if isinstance(value, datetime):
        dt = value
    else:
        text = str(value).strip()
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        dt = datetime.fromisoformat(text)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _sidecar_path(granule_path: str) -> str:
    return granule_path + ".json"


def _write_sidecar(granule_path: str, meta: dict) -> None:
    sidecar = {
        "filename": meta["filename"],
        "version": meta["version"],
        "nativeId": meta["nativeId"],
        "conceptId": meta["conceptId"],
        "sizeBytes": meta["sizeBytes"],
        "sha256": meta.get("sha256"),
        "observationStartUtc": meta["observationStartUtc"],
        "observationEndUtc": meta["observationEndUtc"],
        "observationIntervalMinutes": meta["observationIntervalMinutes"],
        "retrievedAtUtc": meta["retrievedAtUtc"],
    }
    with open(_sidecar_path(granule_path), "w", encoding="utf-8") as f:
        json.dump(sidecar, f, indent=2, sort_keys=True)


def _read_sidecar(granule_path: str) -> Optional[dict]:
    path = _sidecar_path(granule_path)
    if not os.path.exists(path):
        return None
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else None
    except (OSError, ValueError):
        return None


def _cmr_size_bytes(result: dict) -> Optional[int]:
    """Expected download size from a CMR result, or None when unreported."""
    try:
        info = result["umm"]["DataGranule"]["ArchiveAndDistributionInformation"]
        for entry in info or []:
            if "SizeInBytes" in entry:
                return int(entry["SizeInBytes"])
            if "Size" in entry and "SizeUnit" in entry:
                size = float(entry["Size"])
                unit = str(entry["SizeUnit"]).upper()
                mult = {"BYTES": 1, "KB": 1024, "MB": 1024 ** 2,
                        "GB": 1024 ** 3}.get(unit)
                if mult is not None:
                    # Rounded units cannot be matched exactly — only an
                    # exact byte count is enforced by the caller.
                    return None
        return None
    except (KeyError, TypeError, ValueError):
        return None


def _result_filename(result: dict) -> str:
    return str(result["umm"]["GranuleUR"])


def _result_concept_id(result: dict) -> str:
    try:
        return str(result["meta"]["concept-id"])
    except (KeyError, TypeError):
        return COLLECTION_CONCEPT_ID


def _result_start(result: dict) -> Optional[datetime]:
    return _parse_filename(_result_filename(result))["start"]


def _result_version(result: dict) -> Optional[str]:
    return _parse_filename(_result_filename(result))["version"]


def _pick_granule(results: list) -> dict:
    """Prefer V07C; among those the latest start time; else latest overall.

    Results whose filenames do not parse sort last and keep CMR order.
    """
    def key(item):
        idx, res = item
        parsed = _parse_filename(_result_filename(res))
        version = parsed["version"] or ""
        start = parsed["start"] or datetime.min.replace(tzinfo=timezone.utc)
        return (1 if version == "V07C" else 0, start, -idx)

    indexed = list(enumerate(results))
    indexed.sort(key=key, reverse=True)
    return indexed[0][1]


# ------------------------------------------------------------------
# Granule file handling
# ------------------------------------------------------------------

def _validate_granule_file(path: str) -> bool:
    """True when a cached file is structurally usable (no values read).

    Checks: exists, size > 0, opens with h5py, Grid/precipitation is
    3-D with DimensionNames exactly (time, lon, lat), shape consistent
    with Grid/lat and Grid/lon lengths, and _FillValue present.
    Never raises — a bad file is simply not reusable.
    """
    try:
        if not os.path.isfile(path) or os.path.getsize(path) <= 0:
            return False
        h5py = _h5py()
        with h5py.File(path, "r") as f:
            ds = f["Grid/precipitation"]
            if _decode_dims(ds.attrs.get("DimensionNames")) != EXPECTED_DIMS:
                return False
            if len(ds.shape) != 3 or ds.shape[0] < 1:
                return False
            lat = f["Grid/lat"]
            lon = f["Grid/lon"]
            if ds.shape[1] != len(lon) or ds.shape[2] != len(lat):
                return False
            if ds.attrs.get("_FillValue") is None:
                return False
        return True
    except Exception:  # noqa: BLE001 - any problem means "not reusable"
        return False


def _granule_meta_from_file(path: str, native_id: Optional[str] = None,
                           concept_id: Optional[str] = None,
                           retrieved_at: Optional[str] = None,
                           cached: bool = True) -> dict:
    """Metadata dict for a granule file on disk (sidecar preferred)."""
    filename = os.path.basename(path)
    parsed = _parse_filename(filename)
    sidecar = _read_sidecar(path)
    meta: dict[str, Any] = {
        "filename": filename,
        "nativeId": native_id or (sidecar or {}).get("nativeId") or filename,
        "conceptId": concept_id or (sidecar or {}).get("conceptId")
                     or COLLECTION_CONCEPT_ID,
        "version": parsed["version"] or (sidecar or {}).get("version"),
        "observationStartUtc": None,
        "observationEndUtc": None,
        "observationIntervalMinutes": parsed["intervalMinutes"],
        "sizeBytes": os.path.getsize(path) if os.path.exists(path) else None,
        "sha256": (sidecar or {}).get("sha256"),
        "path": path,
        "retrievedAtUtc": retrieved_at or (sidecar or {}).get("retrievedAtUtc"),
        "cached": cached,
    }
    if parsed["start"] is not None:
        meta["observationStartUtc"] = _fmt_utc(parsed["start"])
        meta["observationEndUtc"] = _fmt_utc(parsed["end"])
    elif sidecar:
        meta["observationStartUtc"] = sidecar.get("observationStartUtc")
        meta["observationEndUtc"] = sidecar.get("observationEndUtc")
        meta["observationIntervalMinutes"] = sidecar.get(
            "observationIntervalMinutes")
    return meta


def _scan_cached_granules() -> list[dict]:
    """Metadata for every granule file in the cache dir (newest first)."""
    cache_dir = _cache_dir()
    metas: list[dict] = []
    try:
        names = os.listdir(cache_dir)
    except OSError:
        return []
    for name in names:
        if not name.lower().endswith(".hdf5") or name.startswith("."):
            continue
        path = os.path.join(cache_dir, name)
        if not os.path.isfile(path):
            continue
        meta = _granule_meta_from_file(path)
        start = _parse_filename(name)["start"]
        meta["_sort_start"] = start or datetime.min.replace(tzinfo=timezone.utc)
        metas.append(meta)
    metas.sort(key=lambda m: m["_sort_start"], reverse=True)
    for meta in metas:
        meta.pop("_sort_start", None)
    return metas


def _find_cached_granule(observation_time: Optional[datetime]) -> Optional[dict]:
    """A reusable cached granule, or None.

    With a requested time: the granule whose [start, start+interval)
    contains it. Without: the latest cached granule, only while its
    observation started within the last 6 hours. Files must pass
    structural validation; a stale or invalid file is never returned.
    """
    now = datetime.now(timezone.utc)
    for meta in _scan_cached_granules():
        path = meta["path"]
        if not _validate_granule_file(path):
            continue
        start = _parse_filename(meta["filename"])["start"]
        if start is None:
            continue
        interval = meta["observationIntervalMinutes"] or 30
        end_exclusive = start + timedelta(minutes=interval)
        if observation_time is not None:
            if start <= observation_time < end_exclusive:
                return meta
            continue
        if (now - start).total_seconds() <= CACHE_FRESH_SECONDS:
            return meta
    return None


# ------------------------------------------------------------------
# CMR discovery + download
# ------------------------------------------------------------------

def _search_granules(start: datetime, end: datetime,
                     bbox: tuple[float, float, float, float]) -> list:
    """CMR search for IMERG granules in a time window and bbox.

    bbox is (minLon, minLat, maxLon, maxLat). Returns the raw result
    list. Empty list and NASA failures are the caller's problem to
    report — nothing is fabricated here.
    """
    ea = _earthaccess()
    _credentials()  # raises SatelliteNotConfigured when missing
    try:
        ea.login()
    except Exception as exc:
        raise SatelliteError(f"Earthdata login failed: {exc}") from exc
    try:
        results = ea.search_data(
            concept_id=COLLECTION_CONCEPT_ID,
            temporal=(_fmt_utc(start), _fmt_utc(end)),
            bounding_box=bbox,
        )
    except Exception as exc:
        raise SatelliteError(f"NASA CMR search failed: {exc}") from exc
    if results is None:
        return []
    return list(results)


def _sanitize_cache_filename(name: str) -> str:
    """A Windows-safe local filename for a granule native ID.

    CMR GranuleURs for this collection are ``<ShortName>:<filename>``
    (e.g. ``GPM_3IMERGHHE.07:3B-HHR-E...HDF5``) — the ``:`` is legal
    on Linux/macOS but makes every filesystem call fail on Windows
    ([WinError 123]). Percent-encode ``%`` first, then every
    Windows-invalid character (``< > : " / \\ | ? *``) and every
    control character (0x00-0x1F) as ``%XX`` (uppercase hex), and
    encode trailing dots/spaces, which Windows silently strips. The
    encoding is injective — two different native IDs can never
    collide in one cache filename — and the original ID is preserved
    untouched in metadata (``nativeId``), the remote URL and the
    sidecar. Clean names pass through byte-identical, so existing
    tests and the ``_parse_filename`` interval parsing are unaffected.
    """
    _INVALID = frozenset('<>:"/\\|?*')
    out: list[str] = []
    for ch in name:
        if ch == "%":
            out.append("%25")
        elif ch in _INVALID or ord(ch) < 0x20:
            out.append(f"%{ord(ch):02X}")
        else:
            out.append(ch)
    safe = "".join(out)
    stripped = safe.rstrip(". ")
    if len(stripped) != len(safe):
        safe = stripped + "".join(
            f"%{ord(c):02X}" for c in safe[len(stripped):])
    return safe


def _download_granule(result: dict) -> dict:
    """Download one CMR granule into the cache (atomic, validated).

    Downloads into a temp directory inside the cache dir, validates
    size, then os.replace() into place and writes the sidecar. Any
    failure removes the temp directory and raises SatelliteError; a
    partial file is never presented as a valid cache entry. An already
    cached valid copy of the same filename is reused without a download.

    The cache destination uses the sanitized filename (see
    ``_sanitize_cache_filename``): the native GranuleUR may contain
    ``:`` and other characters Windows refuses, so the raw ID is
    never used as a filesystem name. The native ID itself is kept
    verbatim in the returned metadata, the sidecar and the logs.
    """
    global _last_success_at
    filename = _result_filename(result)
    cache_filename = _sanitize_cache_filename(filename)
    cache_dir = _cache_dir()
    dest = os.path.join(cache_dir, cache_filename)
    if os.path.isfile(dest) and _validate_granule_file(dest):
        logger.info("satellite: reusing cached granule %s", filename)
        return _granule_meta_from_file(
            dest, native_id=filename,
            concept_id=_result_concept_id(result),
            cached=True)

    # Legacy cache: a file stored under the raw (unsanitized) name.
    # Possible on Linux/macOS, impossible on Windows (it could never
    # have been created there). Migrate it in place — file and sidecar
    # — instead of downloading the same granule again. Any problem
    # falls through to a fresh download below; nothing is deleted.
    legacy_dest = os.path.join(cache_dir, filename)
    if legacy_dest != dest:
        try:
            if (os.path.isfile(legacy_dest)
                    and _validate_granule_file(legacy_dest)):
                os.replace(legacy_dest, dest)
                legacy_sidecar = _sidecar_path(legacy_dest)
                if os.path.isfile(legacy_sidecar):
                    os.replace(legacy_sidecar, _sidecar_path(dest))
                logger.info("satellite: migrated cached granule %s -> %s",
                            filename, cache_filename)
                return _granule_meta_from_file(
                    dest, native_id=filename,
                    concept_id=_result_concept_id(result),
                    cached=True)
        except OSError:
            pass

    expected_size = _cmr_size_bytes(result)
    tmpdir = tempfile.mkdtemp(prefix=".download-", dir=cache_dir)
    try:
        ea = _earthaccess()
        try:
            files = ea.download(result, tmpdir)
        except Exception as exc:
            raise SatelliteError(f"NASA granule download failed: {exc}") from exc
        if not files:
            raise SatelliteError("NASA granule download returned no files")
        src = files[0]
        if not os.path.isfile(src) or os.path.getsize(src) <= 0:
            raise SatelliteError(
                f"Downloaded granule {filename} is empty or missing")
        if expected_size is not None and os.path.getsize(src) != expected_size:
            raise SatelliteError(
                f"Downloaded granule {filename} size "
                f"{os.path.getsize(src)} does not match CMR size {expected_size}")
        os.replace(src, dest)
    except SatelliteError:
        raise
    except Exception as exc:
        raise SatelliteError(f"NASA granule download failed: {exc}") from exc
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)

    # The file is in place and valid; record it.
    if not _validate_granule_file(dest):
        try:
            os.remove(dest)
        except OSError:
            pass
        raise SatelliteError(
            f"Downloaded granule {filename} failed validation after download")
    retrieved_at = _now_iso()
    meta = _granule_meta_from_file(
        dest, native_id=filename,
        concept_id=_result_concept_id(result),
        retrieved_at=retrieved_at, cached=False)
    meta["sizeBytes"] = os.path.getsize(dest)
    meta["sha256"] = _sha256(dest)
    _write_sidecar(dest, meta)
    _last_success_at = retrieved_at
    logger.info("satellite: downloaded granule %s (%s bytes)",
                filename, meta["sizeBytes"])
    return meta


def _union_bbox() -> tuple[float, float, float, float]:
    """bbox (minLon, minLat, maxLon, maxLat) covering all RAINWATCH regions."""
    min_lat = min(r["bbox"][0] for r in locations_engine.REGIONS)
    min_lon = min(r["bbox"][1] for r in locations_engine.REGIONS)
    max_lat = max(r["bbox"][2] for r in locations_engine.REGIONS)
    max_lon = max(r["bbox"][3] for r in locations_engine.REGIONS)
    return (min_lon, min_lat, max_lon, max_lat)


def _ensure_latest_granule() -> dict:
    """Latest available granule (cached when reusable, else CMR + download)."""
    _credentials()
    with _download_lock:
        cached = _find_cached_granule(None)
        if cached is not None:
            return cached
        now = datetime.now(timezone.utc)
        results = _search_granules(
            now - timedelta(hours=LATEST_SEARCH_WINDOW_HOURS), now,
            _union_bbox())
        if not results:
            raise SatelliteError(
                "No GPM IMERG granules found in the last "
                f"{LATEST_SEARCH_WINDOW_HOURS} hours")
        return _download_granule(_pick_granule(results))


def _ensure_granule_for_time(observation_time: datetime) -> dict:
    """Granule whose [start, start+interval) contains observation_time."""
    _credentials()
    with _download_lock:
        cached = _find_cached_granule(observation_time)
        if cached is not None:
            return cached
        results = _search_granules(
            observation_time - timedelta(minutes=30),
            observation_time + timedelta(minutes=30),
            _union_bbox())
        if not results:
            raise SatelliteError(
                "No GPM IMERG granules found near "
                f"{_fmt_utc(observation_time)}")
        for result in sorted(results, key=lambda r: _result_start(r) or
                             datetime.min.replace(tzinfo=timezone.utc),
                             reverse=True):
            start = _result_start(result)
            if start is None:
                continue
            interval = (_parse_filename(_result_filename(result))
                        ["intervalMinutes"] or 30)
            if start <= observation_time < start + timedelta(minutes=interval):
                return _download_granule(result)
        raise SatelliteError(
            "No GPM IMERG granule covers "
            f"{_fmt_utc(observation_time)} — the newest granule is not "
            "silently substituted")


# ------------------------------------------------------------------
# Extraction (ported from backend/ml/satellite_spike.py — same semantics)
# ------------------------------------------------------------------

def _read_granule(path: str) -> dict:
    """Read a granule file and validate its structure.

    Returns arrays + metadata. Raises SatelliteError on any structural
    problem (wrong dimension order, bad shape, missing _FillValue).
    """
    h5py = _h5py()
    fname = os.path.basename(path)
    parsed = _parse_filename(fname)
    try:
        f = h5py.File(path, "r")
    except Exception as exc:
        raise SatelliteError(f"Cannot open granule {fname}: {exc}") from exc
    with f:
        try:
            ds = f["Grid/precipitation"]
            precip = ds[:]
            lat = f["Grid/lat"][:]
            lon = f["Grid/lon"][:]
            attrs = ds.attrs
            dim_names = _decode_dims(attrs.get("DimensionNames"))
            units = attrs.get("Units", attrs.get("units", ""))
            if isinstance(units, bytes):
                units = units.decode("utf-8", "replace")
            fill_raw = attrs.get("_FillValue")
            time_vals = np.atleast_1d(f["Grid/time"][:])
        except KeyError as exc:
            raise SatelliteError(
                f"Granule {fname} is missing a required dataset: {exc}") from exc
        if fill_raw is None:
            raise SatelliteError(
                f"Granule {fname} has no _FillValue — refusing to extract")
        if dim_names != EXPECTED_DIMS:
            raise SatelliteError(
                f"Granule {fname} has unexpected precipitation dimension "
                f"order {dim_names}; expected {EXPECTED_DIMS}")
        if precip.ndim != 3 or precip.shape[0] < 1:
            raise SatelliteError(
                f"Granule {fname} has unexpected precipitation shape "
                f"{precip.shape}; expected (time, lon, lat)")
        if precip.shape[1] != len(lon) or precip.shape[2] != len(lat):
            raise SatelliteError(
                f"Granule {fname} precip shape {precip.shape} is "
                f"inconsistent with lon ({len(lon)}) and lat ({len(lat)})")
        time_start = TIME_EPOCH + timedelta(seconds=float(time_vals[0]))
        if parsed["start"] is not None and abs(
                (time_start - parsed["start"]).total_seconds()) > 60:
            logger.warning(
                "satellite: granule %s Grid/time %s disagrees with filename "
                "start %s; using Grid/time",
                fname, _fmt_utc(time_start), _fmt_utc(parsed["start"]))
    return {
        "filename": fname,
        "precip": precip,
        "lat": lat,
        "lon": lon,
        "fill": float(fill_raw),
        "units": units or "mm/hr",
        "timeStart": time_start,
        "intervalMinutes": parsed["intervalMinutes"],
        "version": parsed["version"],
    }


def _extract_point(data: dict, latitude: float, longitude: float) -> dict:
    """Extract one location's value from already-read granule arrays.

    Returns the location/gridCell/value fields of the section-H
    response (without source/granule wrappers).
    """
    lat = data["lat"]
    lon = data["lon"]
    lat_idx = int(np.argmin(np.abs(lat - latitude)))
    lon_idx = int(np.argmin(np.abs(lon - longitude)))
    cell_lat = float(lat[lat_idx])
    cell_lon = float(lon[lon_idx])
    distance_km = haversine_km(latitude, longitude, cell_lat, cell_lon)

    # Dimension order is (time, lon, lat): index [time, lon, lat].
    # Each granule holds one 30-minute slice; time index 0 is the slice.
    val = float(data["precip"][0, lon_idx, lat_idx])
    fill = data["fill"]

    if math.isnan(val) or _is_fill_value(val, fill):
        status, rate = "MISSING", None
    elif not math.isfinite(val) or val < 0:
        status, rate = "INVALID", None
    elif val == 0.0:
        status, rate = "VALID_ZERO", 0.0
    else:
        status, rate = "VALID_RAINFALL", val

    interval_minutes = data["intervalMinutes"]
    accumulation = None
    if rate is not None and interval_minutes:
        accumulation = rate * (interval_minutes / 60.0)

    return {
        "location": {"latitude": latitude, "longitude": longitude},
        "gridCell": {
            "latitude": cell_lat,
            "longitude": cell_lon,
            "latIndex": lat_idx,
            "lonIndex": lon_idx,
            "distanceKm": round(distance_km, 2),
        },
        "precipitationRateMmHr": rate,
        "accumulationMm": accumulation,
        "observationTimeUtc": _fmt_utc(data["timeStart"]),
        "observationTimeIst": _fmt_ist(data["timeStart"]),
        "observationIntervalMinutes": interval_minutes,
        "status": status,
    }


def _build_response(point: dict, granule_meta: dict) -> dict:
    """Assemble the section-H response dict for one location."""
    return {
        "source": SOURCE_NAME,
        "product": PRODUCT_NAME,
        "version": granule_meta.get("version")
                   or _parse_filename(granule_meta["filename"])["version"],
        "location": point["location"],
        "gridCell": point["gridCell"],
        "precipitationRateMmHr": point["precipitationRateMmHr"],
        "accumulationMm": point["accumulationMm"],
        "observationTimeUtc": point["observationTimeUtc"],
        "observationTimeIst": point["observationTimeIst"],
        "observationIntervalMinutes": point["observationIntervalMinutes"],
        "status": point["status"],
        "granule": {
            "filename": granule_meta["filename"],
            "nativeId": granule_meta["nativeId"],
            "conceptId": granule_meta["conceptId"],
            "version": granule_meta.get("version"),
        },
        "retrievedAtUtc": granule_meta.get("retrievedAtUtc"),
    }


def _validate_coordinates(latitude: float, longitude: float) -> None:
    try:
        lat = float(latitude)
        lon = float(longitude)
    except (TypeError, ValueError) as exc:
        raise ValueError(
            f"Invalid coordinates: {latitude!r}, {longitude!r}") from exc
    if not (-90.0 <= lat <= 90.0):
        raise ValueError(f"Latitude {lat} out of range (-90..90)")
    if not (-180.0 <= lon <= 180.0):
        raise ValueError(f"Longitude {lon} out of range (-180..180)")


# ------------------------------------------------------------------
# Public interface (FastAPI-independent)
# ------------------------------------------------------------------

def get_satellite_status() -> dict:
    """Connection/cache state for the Data Sources page (Phase 2).

    "Not Configured" when no Earthdata credentials are present,
    "Error" when the last operation failed, otherwise "Ready".
    "Ready" means configured with no known failure — it does not claim
    a granule was ever retrieved; lastRetrievedAt says that.
    """
    try:
        _credentials()
        configured = True
    except SatelliteNotConfigured:
        configured = False
    cached = _scan_cached_granules()
    latest = cached[0]["filename"] if cached else None
    if not configured:
        status = "Not Configured"
    elif _last_error:
        status = "Error"
    else:
        status = "Ready"
    return {
        "configured": configured,
        "status": status,
        "lastRetrievedAt": _last_success_at,
        "recordsRetrieved": _records_retrieved,
        "error": _last_error,
        "cachedGranules": len(cached),
        "latestGranule": latest,
    }


def get_latest_granule() -> dict:
    """Metadata of the latest available granule.

    Downloads only when no reusable cached granule exists. Raises
    SatelliteNotConfigured without credentials and SatelliteError when
    no granule is available or the download fails.
    """
    global _last_error
    try:
        meta = _ensure_latest_granule()
    except Exception as exc:
        _last_error = str(exc)
        raise
    _last_error = None
    return {k: v for k, v in meta.items() if not k.startswith("_")}


def get_rainfall_for_location(latitude: float, longitude: float,
                              observation_time: Optional[Any] = None) -> dict:
    """Observed satellite rainfall for one latitude/longitude.

    latitude -90..90, longitude -180..180 (else ValueError).
    observation_time: optional ISO string/datetime; when given, the
    granule whose [start, start+interval) contains it is used, and a
    SatelliteError is raised when no granule covers it — the newest
    granule is never silently substituted. When omitted, the latest
    available granule is used.
    """
    global _last_success_at, _last_error, _records_retrieved
    _validate_coordinates(latitude, longitude)
    obs_time = _parse_iso(observation_time) if observation_time is not None else None
    try:
        if obs_time is not None:
            meta = _ensure_granule_for_time(obs_time)
        else:
            meta = _ensure_latest_granule()
        data = _read_granule(meta["path"])
        point = _extract_point(data, float(latitude), float(longitude))
    except SatelliteNotConfigured:
        raise
    except SatelliteError as exc:
        _last_error = str(exc)
        raise
    except Exception as exc:
        _last_error = str(exc)
        raise SatelliteError(f"Satellite rainfall extraction failed: {exc}") from exc
    _last_success_at = meta.get("retrievedAtUtc") or _now_iso()
    _last_error = None
    _records_retrieved = 1
    return _build_response(point, meta)


def get_rainfall_for_region(region: Any) -> dict:
    """Observed satellite rainfall for every RAINWATCH location in a region.

    region is a region id ("bhubaneswar" / "ganjam") or a dict
    {minLat, maxLat, minLon, maxLon}. One granule download is shared
    across all locations in the region; each location gets its own
    nearest grid cell and distance. Locations are in LOCATIONS order.
    """
    global _last_success_at, _last_error, _records_retrieved
    if isinstance(region, str):
        reg = locations_engine.get_region(region)
        if reg["id"] != region:
            raise ValueError(f"Unknown region id: {region!r}")
        bbox = reg["bbox"]  # [minLat, minLon, maxLat, maxLon]
        region_out = {"id": reg["id"], "name": reg["name"],
                      "shortName": reg.get("shortName"),
                      "bbox": list(bbox)}
    elif isinstance(region, dict):
        try:
            min_lat = float(region["minLat"])
            max_lat = float(region["maxLat"])
            min_lon = float(region["minLon"])
            max_lon = float(region["maxLon"])
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError(
                "Region dict needs minLat, maxLat, minLon, maxLon") from exc
        if not (-90.0 <= min_lat <= max_lat <= 90.0):
            raise ValueError(f"Invalid region latitudes: {min_lat}, {max_lat}")
        if not (-180.0 <= min_lon <= max_lon <= 180.0):
            raise ValueError(f"Invalid region longitudes: {min_lon}, {max_lon}")
        bbox = [min_lat, min_lon, max_lat, max_lon]
        region_out = {"bbox": list(bbox)}
    else:
        raise ValueError(f"Region must be an id string or a bbox dict, got {type(region)}")

    min_lat, min_lon, max_lat, max_lon = bbox
    inside = [loc for loc in locations_engine.LOCATIONS
              if min_lat <= loc["lat"] <= max_lat
              and min_lon <= loc["lng"] <= max_lon]
    try:
        meta = _ensure_latest_granule()
        data = _read_granule(meta["path"])
        points = [_extract_point(data, float(loc["lat"]), float(loc["lng"]))
                  for loc in inside]
    except SatelliteNotConfigured:
        raise
    except SatelliteError as exc:
        _last_error = str(exc)
        raise
    except Exception as exc:
        _last_error = str(exc)
        raise SatelliteError(f"Satellite region extraction failed: {exc}") from exc
    _last_success_at = meta.get("retrievedAtUtc") or _now_iso()
    _last_error = None
    _records_retrieved = len(points)
    return {
        "region": region_out,
        "granule": {k: v for k, v in meta.items() if not k.startswith("_")},
        "locations": [_build_response(point, meta) for point in points],
    }
