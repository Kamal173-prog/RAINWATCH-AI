import { ChevronDown } from 'lucide-react'
import type { SelectHTMLAttributes } from 'react'

export interface SelectOption {
  value: string
  label: string
  disabled?: boolean
}

export interface SelectProps extends Omit<SelectHTMLAttributes<HTMLSelectElement>, 'onChange'> {
  options: SelectOption[]
  value: string
  onValueChange: (value: string) => void
  label?: string
  hint?: string
  compact?: boolean
}

export function Select({
  options,
  value,
  onValueChange,
  label,
  hint,
  compact = false,
  className = '',
  id,
  ...rest
}: SelectProps) {
  const selectId = id ?? (label ? `sel-${label.replace(/\W+/g, '-').toLowerCase()}` : undefined)

  return (
    <label className={`flex flex-col gap-1.5 ${className}`} htmlFor={selectId}>
      {label ? (
        <span className="text-[11px] font-semibold tracking-wider text-muted uppercase">{label}</span>
      ) : null}
      <span className="relative block">
        <select
          id={selectId}
          value={value}
          onChange={(e) => onValueChange(e.target.value)}
          className={`w-full cursor-pointer appearance-none rounded-lg border border-line bg-surface ${
            compact ? 'h-9 pl-3 pr-8 text-xs' : 'h-10 pl-3.5 pr-9 text-sm'
          } text-ink transition-colors hover:border-accent/40 focus:border-accent/60 focus:outline-none`}
          {...rest}
        >
          {options.map((o) => (
            <option key={o.value} value={o.value} disabled={o.disabled}>
              {o.label}
            </option>
          ))}
        </select>
        <ChevronDown
          size={compact ? 13 : 15}
          className="pointer-events-none absolute top-1/2 right-3 -translate-y-1/2 text-muted"
          aria-hidden
        />
      </span>
      {hint ? <span className="text-[11px] text-muted">{hint}</span> : null}
    </label>
  )
}
