"""Optimize Watch (elevated) and Warning (high) thresholds.

Selection data: pooled out-of-sample 2024 (train-only models) + 2025
(deployed artifacts) probabilities from build_threshold_probs.py.
2026 is NEVER used here -- not for selection, not for validation.

Rules (same for every version; v3.3 is the deliverable, v3.2/v3 are
optimized the same way for the matched comparison):
  Watch:   maximize F2 subject to recall >= R_WATCH and precision >= 0.10
  Warning: maximize F1 subject to recall >= R_WARN and precision >= 0.15
Recall floors (v3.1 operating policy):
  3h>=10mm: Watch 0.25 / Warning 0.20
  6h>=10mm: Watch 0.50 / Warning 0.25
  3h>=5mm:   Watch 0.50 / Warning 0.30
If no threshold satisfies a rule's constraints, the precision floor is
relaxed first and the relaxation is recorded.

Also reports, per event and version: unconstrained F1/F2/F3 optima;
recall at precision floors {0.15, 0.20, 0.25, 0.30, 0.40}; precision
at recall floors {0.25, 0.40, 0.50, 0.70, 0.80}; and per-year (2024 /
2025) metrics at the chosen thresholds.

Outputs:
  threshold_work/thresholds_optimized.json  (chosen thresholds + rationale)
  threshold_work/threshold_curves.json     (per-threshold metrics, pooled)
"""

import json
import logging
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v33_common import event_metrics, hour_metrics  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger("optimize_thresholds")

BACKEND = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORK = os.path.join(BACKEND, "models", "rainfall_xgb_v3_3", "threshold_work")
TARGETS = ["y_3h_ge_10mm", "y_6h_ge_10mm", "y_3h_ge_5mm"]
VERSIONS = ("v3", "v3.2", "v3.3")

FLOORS = {
    "y_3h_ge_10mm": {"watch_recall": 0.25, "warn_recall": 0.20},
    "y_6h_ge_10mm": {"watch_recall": 0.50, "warn_recall": 0.25},
    "y_3h_ge_5mm": {"watch_recall": 0.50, "warn_recall": 0.30},
}
PRECISION_FLOORS = [0.15, 0.20, 0.25, 0.30, 0.40]
RECALL_FLOORS = [0.25, 0.40, 0.50, 0.70, 0.80]


def _metrics(y: np.ndarray, p: np.ndarray, t: float) -> dict:
    hm = hour_metrics(y, p, t)
    em = event_metrics(y, p, t, n_days=len(y) / 24.0)
    return {**hm, **em,
            "missed_storms": int(em["n_true_storms"] - em["detected_storms"])}


def _scan(y: np.ndarray, p: np.ndarray) -> list[dict]:
    out = []
    for t in np.arange(0.01, 0.601, 0.005):
        t = round(float(t), 3)
        out.append({"threshold": t, **_metrics(y, p, t)})
    return out


def _best(curve: list[dict], score: str, recall_floor: float,
          precision_floor: float) -> tuple[dict, str]:
    cands = [r for r in curve if r["recall"] >= recall_floor
             and r["precision"] >= precision_floor]
    note = ""
    if not cands:
        cands = [r for r in curve if r["recall"] >= recall_floor]
        note = "precision floor relaxed (no threshold met both floors)"
    if not cands:
        cands = curve
        note = "recall floor relaxed too (no threshold met the recall floor)"
    best = max(cands, key=lambda r: r[score])
    return best, note


def _at_floor(curve: list[dict], kind: str, floor: float) -> dict | None:
    """Best recall at a precision floor, or best precision at a recall floor."""
    if kind == "precision":
        cands = [r for r in curve if r["precision"] >= floor]
        if not cands:
            return None
        return max(cands, key=lambda r: r["recall"])
    cands = [r for r in curve if r["recall"] >= floor]
    if not cands:
        return None
    return max(cands, key=lambda r: r["precision"])


def optimize(version: str, target: str) -> tuple[dict, list[dict]]:
    df = pd.read_csv(os.path.join(WORK, f"probs_{version}_{target}.csv"),
                     parse_dates=["timestamp"])
    y = df["y"].to_numpy().astype(int)
    p = df["p_cal"].to_numpy(dtype=float)
    curve = _scan(y, p)
    fl = FLOORS[target]
    watch, w_note = _best(curve, "f2", fl["watch_recall"], 0.10)
    warn, h_note = _best(curve, "f1", fl["warn_recall"], 0.15)
    # Per-year metrics at the chosen thresholds.
    per_year = {}
    for yr in (2024, 2025):
        m = df["timestamp"].dt.year == yr
        per_year[str(yr)] = {
            "n": int(m.sum()),
            "positives": int(df.loc[m, "y"].sum()),
            "watch": _metrics(y[m.to_numpy()], p[m.to_numpy()], watch["threshold"]),
            "warning": _metrics(y[m.to_numpy()], p[m.to_numpy()], warn["threshold"]),
        }
    result = {
        "watch": {"threshold": watch["threshold"], "metrics": watch, "note": w_note,
                  "rule": f"max F2 s.t. recall >= {fl['watch_recall']}, precision >= 0.10"},
        "warning": {"threshold": warn["threshold"], "metrics": warn, "note": h_note,
                    "rule": f"max F1 s.t. recall >= {fl['warn_recall']}, precision >= 0.15"},
        "unconstrained": {
            "f1": max(curve, key=lambda r: r["f1"]),
            "f2": max(curve, key=lambda r: r["f2"]),
            "f3": max(curve, key=lambda r: r["f3"]),
        },
        "recall_at_precision_floor": {
            str(f): (_at_floor(curve, "precision", f) or {"threshold": None})
            for f in PRECISION_FLOORS},
        "precision_at_recall_floor": {
            str(f): (_at_floor(curve, "recall", f) or {"threshold": None})
            for f in RECALL_FLOORS},
        "per_year": per_year,
        "n_pooled": int(len(y)),
        "positives_pooled": int(y.sum()),
    }
    return result, curve


def main() -> None:
    chosen, curves = {}, {}
    for version in VERSIONS:
        chosen[version] = {}
        curves[version] = {}
        for target in TARGETS:
            res, curve = optimize(version, target)
            chosen[version][target] = res
            curves[version][target] = curve
            log.info("%s %s: Watch t=%.3f F2=%.3f P=%.3f R=%.3f FA=%.2f/100h storms %d/%d | "
                     "Warn t=%.3f F1=%.3f P=%.3f R=%.3f FA=%.2f/100h storms %d/%d",
                     version, target,
                     res["watch"]["threshold"], res["watch"]["metrics"]["f2"],
                     res["watch"]["metrics"]["precision"], res["watch"]["metrics"]["recall"],
                     res["watch"]["metrics"]["alerts_per_100h"],
                     res["watch"]["metrics"]["detected_storms"],
                     res["watch"]["metrics"]["n_true_storms"],
                     res["warning"]["threshold"], res["warning"]["metrics"]["f1"],
                     res["warning"]["metrics"]["precision"], res["warning"]["metrics"]["recall"],
                     res["warning"]["metrics"]["alerts_per_100h"],
                     res["warning"]["metrics"]["detected_storms"],
                     res["warning"]["metrics"]["n_true_storms"])
    json.dump(chosen, open(os.path.join(WORK, "thresholds_optimized.json"), "w"), indent=2)
    json.dump(curves, open(os.path.join(WORK, "threshold_curves.json"), "w"), indent=2)
    log.info("saved thresholds_optimized.json + threshold_curves.json")


if __name__ == "__main__":
    main()
