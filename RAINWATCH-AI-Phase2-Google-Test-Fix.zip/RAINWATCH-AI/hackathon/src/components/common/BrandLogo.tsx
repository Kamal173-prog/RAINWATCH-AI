import logo from '../../assets/rainwatch-logo.png'

/**
 * Official RAINWATCH emblem. The source artwork has transparent corners
 * so it sits cleanly on both the dark console and light theme surfaces.
 */
export function BrandLogo({
  size = 36,
  className = '',
  alt = 'RAINWATCH AI emblem',
  glow = false,
}: {
  size?: number
  className?: string
  alt?: string
  glow?: boolean
}) {
  return (
    <span
      className={`relative inline-flex shrink-0 items-center justify-center ${className}`}
      style={{ width: size, height: size }}
    >
      {glow ? (
        <span
          className="absolute inset-0 border border-accent/50"
          style={{ transform: 'scale(1.12)' }}
          aria-hidden
        />
      ) : null}
      <img
        src={logo}
        alt={alt}
        width={size}
        height={size}
        className="relative h-full w-full object-contain"
        draggable={false}
      />
    </span>
  )
}
