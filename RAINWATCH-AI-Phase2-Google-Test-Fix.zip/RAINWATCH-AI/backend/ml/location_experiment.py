"""v3.3 Phase 7: location-aware training across Odisha, geographic holdouts.

Questions:
1. Does pooling 5 Odisha locations help Bhubaneswar vs the
   Bhubaneswar-only point model (same feature set, same protocol)?
2. Does a model trained on N-1 locations transfer to a held-out
   location (leave-one-location-out, LOLO)?

Feature set: POINT-ONLY features (no spatial), identical for every
location, from data/model_ready/odisha_locations.csv. Location is
encoded as lat/lon (numeric) + one-hot; in LOLO the held-out
location's one-hot is all zeros, so transfer relies on lat/lon +
weather features.

Protocol: train 2021-2023 (+2024 for the refit), weights/Platt on 2024
validation (from the training locations only), evaluate on 2025
benchmark. 2026 is untouched until the final phase. Same fixed
hyperparameters as v3.2 (v33_common.BEST_PARAMS) and the same
pos_weight rule. No resampling across locations; no shuffling.

Usage:
    cd backend && .venv/bin/python ml/location_experiment.py
"""

from __future__ import annotations

import json
import logging
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from sklearn.metrics import average_precision_score  # noqa: E402
from v33_common import (  # noqa: E402
    BEST_PARAMS, FAMILIES, TARGETS, full_eval, make_classifier, platt_apply,
    platt_fit,
)
from train_rainfall_v33 import _ensemble_weights  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger("location_experiment")

BACKEND = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.join(BACKEND, "models", "rainfall_xgb_v3_3")

LOCATIONS = ["bhubaneswar", "cuttack", "paradip", "brahmapur", "sambalpur"]
LATLON = {
    "bhubaneswar": (20.281195, 85.843376),
    "cuttack": (20.46, 85.88),
    "paradip": (20.32, 86.62),
    "brahmapur": (19.31, 84.79),
    "sambalpur": (21.47, 83.97),
}
EXCLUDE = {"timestamp", "location", "y_1h", "y_3h", "y_6h",
           "y_3h_ge_10mm", "y_6h_ge_10mm", "y_3h_ge_5mm"}


def _prep(df: pd.DataFrame, locations: list[str]) -> tuple[pd.DataFrame, list[str]]:
    """Add lat/lon + one-hot location columns for the given locations."""
    df = df[df["location"].isin(locations)].copy()
    df["lat"] = df["location"].map(lambda s: LATLON[s][0])
    df["lon"] = df["location"].map(lambda s: LATLON[s][1])
    for loc in LOCATIONS:
        df[f"loc_{loc}"] = (df["location"] == loc).astype(int)
    feats = [c for c in df.columns if c not in EXCLUDE]
    return df, feats


def _train_eval(target: str, tr: pd.DataFrame, va: pd.DataFrame,
                te: pd.DataFrame, feats: list[str]) -> dict:
    X_tr = tr[feats].to_numpy(dtype=float)
    y_tr = tr[target].to_numpy().astype(int)
    X_va = va[feats].to_numpy(dtype=float)
    y_va = va[target].to_numpy().astype(int)
    X_te = te[feats].to_numpy(dtype=float)
    y_te = te[target].to_numpy().astype(int)
    pos = max(1, int(y_tr.sum()))
    neg = max(1, int((1 - y_tr).sum()))
    val_probs, models = {}, {}
    for fam in FAMILIES:
        m = make_classifier(fam, BEST_PARAMS[target][fam], neg / pos)
        m.fit(X_tr, y_tr)
        models[fam] = m
        val_probs[fam] = m.predict_proba(X_va)[:, 1]
    w = _ensemble_weights(y_va, val_probs)
    ens_va = sum(w[f] * val_probs[f] for f in FAMILIES)
    wp, bp = platt_fit(ens_va, y_va)
    # Refit on train+val, evaluate on test.
    tv = pd.concat([tr, va], ignore_index=True)
    X_tv = tv[feats].to_numpy(dtype=float)
    y_tv = tv[target].to_numpy().astype(int)
    pos2 = max(1, int(y_tv.sum()))
    neg2 = max(1, int((1 - y_tv).sum()))
    te_probs = {}
    for fam in FAMILIES:
        m = make_classifier(fam, BEST_PARAMS[target][fam], neg2 / pos2)
        m.fit(X_tv, y_tv)
        te_probs[fam] = m.predict_proba(X_te)[:, 1]
    ens = sum(w[f] * te_probs[f] for f in FAMILIES)
    cal = platt_apply(ens, wp, bp)
    n_days = len(te) / 24.0
    return full_eval(y_te, cal, {"elevated": 0.07, "high": 0.15}, n_days=n_days)


def _save(results: dict) -> None:
    with open(os.path.join(OUT_DIR, "location_experiment.json"), "w") as f:
        json.dump(results, f, indent=2)


def main() -> None:
    df = pd.read_csv(os.path.join(BACKEND, "data", "model_ready", "odisha_locations.csv"),
                     parse_dates=["timestamp"])
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True).dt.tz_localize(None)
    # Resume: keep already-completed configs from a previous interrupted run.
    results_path = os.path.join(OUT_DIR, "location_experiment.json")
    if os.path.exists(results_path):
        with open(results_path) as f:
            results = json.load(f)
        log.info("resuming from %s (%d LOLO held, %d pooled done)",
                 results_path,
                 len(results.get("lolo", {})),
                 len(results.get("pooled_vs_single_bhubaneswar", {})))
    else:
        results = {"lolo": {}, "pooled_vs_single_bhubaneswar": {}}

    # --- LOLO: train on 4 locations, test on the 5th (2025) ------------
    for held in LOCATIONS:
        if held in results["lolo"] and len(results["lolo"][held]) == len(TARGETS):
            log.info("LOLO held=%s already complete, skipping", held)
            continue
        train_locs = [l for l in LOCATIONS if l != held]
        sub, feats = _prep(df, LOCATIONS)
        tr = sub[(sub["timestamp"].dt.year.isin([2021, 2022, 2023]))
                 & (sub["location"].isin(train_locs))].reset_index(drop=True)
        va = sub[(sub["timestamp"].dt.year == 2024)
                 & (sub["location"].isin(train_locs))].reset_index(drop=True)
        te = sub[(sub["timestamp"].dt.year == 2025)
                 & (sub["location"] == held)].reset_index(drop=True)
        results["lolo"][held] = {}
        for target in TARGETS:
            ev = _train_eval(target, tr, va, te, feats)
            results["lolo"][held][target] = ev
            log.info("LOLO held=%s %s: 2025 PR-AUC %.4f | F1-elev P %.3f R %.3f | "
                     "storm det %.3f",
                     held, target, ev["pr_auc"],
                     ev["levels"]["elevated"]["precision"],
                     ev["levels"]["elevated"]["recall"],
                     ev["levels"]["elevated"]["storm_detection_rate"])
        _save(results)
        log.info("checkpoint saved after LOLO held=%s", held)

    # --- Pooled vs Bhubaneswar-only (Bhubaneswar 2025) -----------------
    sub, feats = _prep(df, LOCATIONS)
    for mode, locs in (("pooled_all5", LOCATIONS), ("bhubaneswar_only", ["bhubaneswar"])):
        if mode in results["pooled_vs_single_bhubaneswar"] and \
                len(results["pooled_vs_single_bhubaneswar"][mode]) == len(TARGETS):
            log.info("%s already complete, skipping", mode)
            continue
        tr = sub[(sub["timestamp"].dt.year.isin([2021, 2022, 2023]))
                 & (sub["location"].isin(locs))].reset_index(drop=True)
        va = sub[(sub["timestamp"].dt.year == 2024)
                 & (sub["location"].isin(locs))].reset_index(drop=True)
        te = sub[(sub["timestamp"].dt.year == 2025)
                 & (sub["location"] == "bhubaneswar")].reset_index(drop=True)
        results["pooled_vs_single_bhubaneswar"][mode] = {}
        for target in TARGETS:
            ev = _train_eval(target, tr, va, te, feats)
            results["pooled_vs_single_bhubaneswar"][mode][target] = ev
            log.info("%s %s: Bhubaneswar 2025 PR-AUC %.4f | F1-elev P %.3f R %.3f",
                     mode, target, ev["pr_auc"],
                     ev["levels"]["elevated"]["precision"],
                     ev["levels"]["elevated"]["recall"])
        _save(results)
        log.info("checkpoint saved after %s", mode)

    _save(results)
    log.info("saved %s", results_path)


if __name__ == "__main__":
    main()
