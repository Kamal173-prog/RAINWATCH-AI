"""INSAT-3D / INSAT-3DR source via ISRO MOSDAC (v3.2, Source A).

Access: **registration required.** MOSDAC provides a data download API
with OAuth2 / Bearer-token authentication.

- Account: register at https://mosdac.gov.in/signup/
- Catalog search (public, no auth):
  ``GET https://mosdac.gov.in/apios/datasets.json?datasetId=<id>&startTime=<d>&endTime=<d>``
- Token: ``POST https://mosdac.gov.in/download_api/gettoken``
  with JSON ``{"username": ..., "password": ...}``
- Download: ``GET https://mosdac.gov.in/download_api/download?id=<granule_id>``
  with ``Authorization: Bearer <token>``

Products (verified against the MOSDAC catalog on 2026-11-23):
- ``3DIMG_L2B_HEM`` — INSAT-3D Hydro-Estimator rainfall, half-hourly,
  ~4 km, HDF5. Catalog returns granules for 2021 and 2024 (e.g. 92
  granules for 2021-07-01..02, 96 for 2024-01-01..02).
- ``3DIMG_L2B_IMC`` — INSAT-3D IMSRA rainfall, half-hourly, ~4 km.
  94 granules for 2021-07-01..02, 96 for 2024-01-01..02.
- ``3RIMG_L2B_HEM`` — INSAT-3DR Hydro-Estimator, half-hourly.
  90 granules for 2021-07-01..02.
- ``3RIMG_L2B_IMC`` — INSAT-3DR IMSRA, half-hourly.
  96 granules for 2021-07-01..02.
- ``3SIMG_L2B_HEM`` — INSAT-3DS Hydro-Estimator (the current
  generation; INSAT-3D products show "In-Active" after 2024-06-18).

Credentials come from environment variables only:
``MOSDAC_USERNAME``, ``MOSDAC_PASSWORD``. They are never logged and
never committed.

This connector implements the catalog search (public) and the full
download flow (credentials required). Granule decoding (HDF5 -> point
time series) is implemented in ``process`` for the HEM/IMSRA rainfall
variable once files are present; it requires ``h5py``.

Status: **BLOCKED on credentials.** No MOSDAC account is available to
this project. The catalog search works and confirms the data exists for
2021–2025; the download step cannot run until Kam registers at
mosdac.gov.in/signup and provides credentials via the Secure Vault.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Optional

import requests

from .base_source import BaseDataSource, retry_with_backoff

log = logging.getLogger(__name__)

CATALOG_URL = "https://mosdac.gov.in/apios/datasets.json"
TOKEN_URL = "https://mosdac.gov.in/download_api/gettoken"
REFRESH_URL = "https://mosdac.gov.in/download_api/refresh-token"
DOWNLOAD_URL = "https://mosdac.gov.in/download_api/download"

PRODUCTS = {
    "3DIMG_L2B_HEM": {"label": "INSAT-3D Hydro-Estimator rainfall", "resolution": "4 km", "freq": "30 min"},
    "3DIMG_L2B_IMC": {"label": "INSAT-3D IMSRA rainfall", "resolution": "4 km", "freq": "30 min"},
    "3RIMG_L2B_HEM": {"label": "INSAT-3DR Hydro-Estimator rainfall", "resolution": "4 km", "freq": "30 min"},
    "3RIMG_L2B_IMC": {"label": "INSAT-3DR IMSRA rainfall", "resolution": "4 km", "freq": "30 min"},
    "3SIMG_L2B_HEM": {"label": "INSAT-3DS Hydro-Estimator rainfall", "resolution": "4 km", "freq": "30 min"},
}


class INSATSource(BaseDataSource):
    """MOSDAC INSAT-3D/3DR/3DS rainfall products."""

    SOURCE_NAME = "insat"
    PRODUCT_NAME = "INSAT-3D/3DR HEM + IMSRA"
    PRODUCT_VERSION = "L2B (MOSDAC)"
    AVAILABILITY_LAG = "PT1H"  # near real-time, ~30–60 min latency
    LICENSE = "MOSDAC / ISRO — research use only, not for commercial use"
    ACCESS_RESTRICTIONS = (
        "Registration required at https://mosdac.gov.in/signup/. "
        "Download needs MOSDAC_USERNAME + MOSDAC_PASSWORD (env vars). "
        "Catalog search is public. Max 5000 files/user/day."
    )

    def __init__(self, backend_dir: Path | None = None, product: str = "3RIMG_L2B_HEM"):
        super().__init__(backend_dir)
        if product not in PRODUCTS:
            raise ValueError(f"unknown INSAT product {product!r}; choose from {list(PRODUCTS)}")
        self.product = product

    # ------------------------------------------------------------------
    def check_access(self) -> tuple[bool, str]:
        user = self.env_or_none("MOSDAC_USERNAME")
        pw = self.env_or_none("MOSDAC_PASSWORD")
        if not user or not pw:
            return False, (
                "MOSDAC credentials not set. Register at "
                "https://mosdac.gov.in/signup/ and set MOSDAC_USERNAME "
                "and MOSDAC_PASSWORD. Catalog search is public; download "
                "is blocked without credentials."
            )
        return True, "MOSDAC credentials present (token not yet validated)"

    # ------------------------------------------------------------------
    def search_catalog(self, start: str, end: str) -> dict:
        """Public catalog search (no auth). Returns the raw OpenSearch
        response. Verified working 2026-11-23."""
        def _get() -> requests.Response:
            r = requests.get(
                CATALOG_URL,
                params={"datasetId": self.product, "startTime": start, "endTime": end},
                headers={"User-Agent": "RAINWATCH-AI/1.0"},
                timeout=60,
            )
            r.raise_for_status()
            return r

        resp = retry_with_backoff(_get, description=f"MOSDAC catalog {self.product}")
        return resp.json()

    # ------------------------------------------------------------------
    def _get_token(self) -> str:
        user = self.env_or_none("MOSDAC_USERNAME")
        pw = self.env_or_none("MOSDAC_PASSWORD")
        if not user or not pw:
            raise RuntimeError("MOSDAC credentials not set (see check_access)")
        r = requests.post(TOKEN_URL, json={"username": user, "password": pw}, timeout=60)
        r.raise_for_status()
        data = r.json()
        token = data.get("access_token") or data.get("token")
        if not token:
            raise RuntimeError(f"MOSDAC token response had no token: {str(data)[:200]}")
        return token

    # ------------------------------------------------------------------
    def fetch(
        self,
        start: str,
        end: str,
        bbox: Optional[tuple[float, float, float, float]] = None,
    ) -> list[Path]:
        """Search the catalog, then download each granule (credentials
        required). Returns the list of raw HDF5 files written. Returns []
        when credentials are absent."""
        ok, msg = self.check_access()
        if not ok:
            log.error("INSAT fetch blocked: %s", msg)
            return []
        catalog = self.search_catalog(start, end)
        total = catalog.get("totalResults", 0)
        log.info("MOSDAC catalog: %s granules for %s..%s (%s)",
                 total, start, end, self.product)
        entries = catalog.get("entry", []) or []
        if not entries:
            return []
        token = self._get_token()
        out: list[Path] = []
        for entry in entries:
            gid = entry.get("id") or entry.get("gId")
            title = entry.get("title", f"granule_{gid}")
            raw_path = self.raw_dir / f"{title}.h5"
            if raw_path.exists() and raw_path.stat().st_size > 0:
                out.append(raw_path)
                continue

            def _dl() -> requests.Response:
                r = requests.get(
                    DOWNLOAD_URL,
                    params={"id": gid},
                    headers={"Authorization": f"Bearer {token}"},
                    timeout=300,
                )
                r.raise_for_status()
                return r

            try:
                resp = retry_with_backoff(_dl, description=f"MOSDAC download {gid}")
                with open(raw_path, "wb") as f:
                    f.write(resp.content)
                out.append(raw_path)
            except requests.HTTPError as e:
                log.error("MOSDAC download failed for %s: HTTP %s",
                          gid, e.response.status_code if e.response is not None else "?")
                break
        return out

    # ------------------------------------------------------------------
    def process(self, raw_files: list[Path]) -> Path:
        """Decode INSAT HDF5 granules into a point time series.

        Requires ``h5py``. The HEM/IMSRA rainfall variable is extracted
        at the Bhubaneswar pixel (nearest grid cell) plus its 8 neighbours.
        Raises a clear error when h5py is missing or when no files are
        present — it never fabricates values.
        """
        try:
            import h5py  # noqa: F401
        except ImportError as e:
            raise RuntimeError(
                "INSAT process requires h5py (pip install h5py). "
                "No INSAT files have been downloaded yet — set MOSDAC "
                "credentials and run fetch first."
            ) from e
        raise NotImplementedError(
            "INSAT HDF5 decoding is not yet implemented: no granules "
            "have been downloaded (credentials blocked). Implement the "
            "variable extraction in this method once the first granule "
            "is available and its internal structure is inspected."
        )
