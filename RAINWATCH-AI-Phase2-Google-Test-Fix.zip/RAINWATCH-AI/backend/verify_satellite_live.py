"""Temporary live-verification script for the Phase 1 NASA IMERG service.

Runs the real service against NASA Earthdata — NOT a mock, NOT a test
fixture. Requires EARTHDATA_USERNAME / EARTHDATA_PASSWORD in
backend/.env (never printed, never logged, never stored anywhere by
this script).

What it checks:
  1. Satellite configuration status.
  2. Real rainfall extraction for Old Town, Bhubaneswar
     (20.2662, 85.8418) from the latest IMERG Early Run granule.
  3. Cached granule reuse: the location function is called twice and
     the two results must name the same granule file — a second
     download would be a failure of the cache.

Run from the backend directory (Windows PowerShell):
    .\\.venv\\Scripts\\python.exe verify_satellite_live.py
or with the system Python if earthaccess + h5py are installed:
    python verify_satellite_live.py

Exit code 0 = live verification succeeded (real value extracted, cache
reused). Exit code 1 = verification did not complete (not configured,
NASA error, or cache not reused) — the printed message says why.

This file is a local helper only. It is not imported by the app, not
an API route, and it changes no application behaviour.
"""

import json
import sys

from app.services.satellite_rainfall import (
    SatelliteError,
    SatelliteNotConfigured,
    get_latest_granule,
    get_rainfall_for_location,
    get_satellite_status,
)

OLD_TOWN_LAT = 20.2662
OLD_TOWN_LON = 85.8418


def show(result, label):
    print(f"--- {label} ---")
    print(f"status: {result['status']}")
    print(f"observation UTC: {result['observationTimeUtc']}")
    print(f"observation IST: {result['observationTimeIst']}")
    print(f"interval: {result['observationIntervalMinutes']} min")
    print(f"rainfall rate: {result['precipitationRateMmHr']} mm/hr")
    print(f"accumulation: {result['accumulationMm']} mm")
    print(f"grid cell: lat {result['gridCell']['latitude']}, "
          f"lon {result['gridCell']['longitude']} "
          f"({result['gridCell']['distanceKm']:.2f} km away)")
    print(f"granule: {result['granule']['filename']} "
          f"(version {result['granule']['version']})")
    print(f"retrieved at (UTC): {result['retrievedAtUtc']}")


def main():
    status = get_satellite_status()
    print("satellite status:")
    print(json.dumps(status, indent=2, default=str))
    if not status.get("configured"):
        print("Earthdata credentials are not configured in backend/.env.")
        print("Add EARTHDATA_USERNAME and EARTHDATA_PASSWORD, then re-run.")
        return 1

    try:
        first = get_rainfall_for_location(OLD_TOWN_LAT, OLD_TOWN_LON)
        show(first, "first call (live extraction)")
        if first["status"] in ("MISSING", "INVALID"):
            print("Live extraction returned no usable value — "
                  "see status above. Not a code failure, but the "
                  "verification cannot confirm a real rainfall value.")
            return 1

        second = get_rainfall_for_location(OLD_TOWN_LAT, OLD_TOWN_LON)
        show(second, "second call (cache reuse check)")
        same_file = (second["granule"]["filename"]
                     == first["granule"]["filename"])
        same_retrieval = (second["retrievedAtUtc"]
                          == first["retrievedAtUtc"])
        print(f"same granule file on second call: {same_file}")
        print(f"same retrieval time on second call: {same_retrieval}")
        if not (same_file and same_retrieval):
            print("Cache reuse FAILED: the second call fetched a "
                  "different granule instead of reusing the cached one.")
            return 1

        latest = get_latest_granule()
        print(f"latest granule (cached={latest.get('cached')}): "
              f"{latest['filename']}")
        print("LIVE VERIFICATION PASSED: real value extracted and "
              "cached granule reused.")
        return 0
    except SatelliteNotConfigured:
        print("Earthdata credentials are not configured in backend/.env.")
        return 1
    except SatelliteError as exc:
        # Service error messages never contain credentials.
        print(f"Satellite service error: {exc}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
