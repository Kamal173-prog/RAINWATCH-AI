import type { DataSourceInfo } from '../types'

/** Types of data sources the production platform is designed to ingest. */
export const DATA_SOURCES: DataSourceInfo[] = [
  {
    id: 'satellite',
    kind: 'Real-time observation',
    name: 'Satellite Rainfall Data',
    category: 'Space-based observation',
    description:
      'Polar and geostationary microwave/IR precipitation estimates (e.g. GPM-style products) providing wide-area rainfall coverage including over oceans and sparse regions.',
    intendedUse: 'Spatial rainfall field forcing for nowcasting and bias-adjustment of radar estimates.',
    status: 'Awaiting Integration',
    cadence: '~30 min revisit (target)',
    icon: 'satellite',
  },
  {
    id: 'radar',
    kind: 'Real-time observation',
    name: 'Weather Radar Data',
    category: 'Remote sensing',
    description:
      'Doppler radar reflectivity and derived QPE mosaics offering high-resolution rainfall intensity at 5–10 minute update cycles.',
    intendedUse: 'Short-term nowcasting, cell tracking, and intensity classification for early warnings.',
    status: 'Not Connected',
    cadence: '~5 min (target)',
    icon: 'radar',
  },
  {
    id: 'stations',
    kind: 'Real-time observation',
    name: 'Ground Weather Stations',
    category: 'In-situ observation',
    description:
      'Automatic weather and rain-gauge stations providing point observations of rainfall, temperature, wind, pressure and humidity.',
    intendedUse: 'Ground-truth calibration, threshold verification and operational alerts.',
    status: 'Demo Data',
    cadence: '~10 min (target)',
    icon: 'station',
  },
  {
    id: 'nwp',
    kind: 'Forecast feed',
    name: 'Numerical Weather Prediction',
    category: 'Model output',
    description:
      'Deterministic and ensemble NWP forecasts supplying quantitative precipitation forecasts out to 72 hours and beyond.',
    intendedUse: 'Driving the rainfall forecast timelines and scenario ensembles.',
    status: 'Awaiting Integration',
    cadence: '~6 h cycles (target)',
    icon: 'model',
  },
  {
    id: 'dem',
    kind: 'Static dataset',
    name: 'Digital Elevation Models',
    category: 'Terrain',
    description:
      'High-resolution DEMs (1–10 m class) describing slope, aspect, flow accumulation and depression storage.',
    intendedUse: 'Inundation extent derivation, flow routing and low-lying area identification.',
    status: 'Demo Data',
    cadence: 'Static (target)',
    icon: 'terrain',
  },
  {
    id: 'drainage',
    kind: 'Static dataset',
    name: 'Drainage and Terrain Data',
    category: 'Urban infrastructure',
    description:
      'Storm-water network geometry, outfall capacities, culvert/underpass locations and canal command areas.',
    intendedUse: 'Drainage stress scoring, ponding hotspots and infrastructure vulnerability.',
    status: 'Not Connected',
    cadence: 'Static / periodic (target)',
    icon: 'drainage',
  },
  {
    id: 'history',
    kind: 'Historical dataset',
    name: 'Historical Rainfall Records',
    category: 'Archive',
    description:
      'Open-Meteo ERA5 archive, hourly 2021–2025 for Bhubaneswar, served by this backend for Bhubaneswar-region locations; Ganjam locations use the demo generator until their archive is fetched. ERA5 reanalysis, not station measurements.',
    intendedUse: 'Historical analysis, threshold tuning and event comparison.',
    status: 'Archive',
    cadence: 'Static archive — no live updates',
    icon: 'archive',
  },
  {
    id: 'google-weather',
    kind: 'Forecast feed',
    name: 'Google Weather API',
    category: 'External forecast',
    description:
      'Google Maps Platform Weather API hourly forecast (up to 240 hours, METRIC units) for each location\u2019s coordinates. An independent external forecast shown for comparison with the ML ensemble — especially where the model has no coverage (hours 7–72 and Ganjam locations). Never presented as a RAINWATCH ML prediction.',
    intendedUse:
      'Independent external forecast for comparison with the ML ensemble; the only real (non-demo) series where the model has no coverage.',
    // Fallback copy only (used when the backend is unreachable): live
    // status is unknown here, so never "Live" — the backend reports
    // the real status when it answers.
    status: 'Awaiting Integration',
    cadence: 'On demand, 30 min cache',
    icon: 'cloud',
  },
]

export interface PipelineNode {
  id: string
  label: string
  detail: string
}

/** Data pipeline visualised on the Data Sources page. */
export const PIPELINE_NODES: PipelineNode[] = [
  { id: 'sat', label: 'Satellite Data', detail: 'Wide-area rainfall estimates' },
  { id: 'radar', label: 'Weather Radar', detail: 'High-res nowcast mosaics' },
  { id: 'obs', label: 'Ground Observations', detail: 'Stations & gauges' },
  { id: 'fc', label: 'Forecast Inputs', detail: 'NWP & blended QPF' },
  { id: 'risk', label: 'Risk Assessment', detail: 'Terrain + drainage model' },
  { id: 'dash', label: 'Early Warning Dashboard', detail: 'RAINWATCH AI' },
]
