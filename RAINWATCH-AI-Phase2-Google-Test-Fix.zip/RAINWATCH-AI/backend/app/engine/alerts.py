"""Sample early-warning alerts — a faithful port of
``hackathon/src/data/alertsData.ts``.

Status (active / acknowledged / dismissed) is layered on top by the
frontend's AlertsContext and persisted in localStorage, so the API
always returns status "active" for the seed alerts.
"""

from datetime import datetime, timedelta, timezone

from .locations import get_location
from .rng import SEVERITY_ORDER

_SEEDS = [
    {"id": "RW-2401", "severity": "Critical", "category": "Extremely Heavy Rainfall Warning",
     "locationId": "old-town", "hoursBack": 1.4,
     "title": "Extremely heavy rainfall expected over Old Town",
     "description": "Sample radar-derived estimate indicates rainfall rates of 88–112 mm/hr likely between the next 2–5 hours over Old Town and adjoining temple corridor pockets.",
     "guidance": "Move low-lying street populations to higher ground. Pre-position pumps at the Canal Road staging point. Demo scenario — not an operational warning."},
    {"id": "RW-2402", "severity": "Warning", "category": "Flood Risk Warning",
     "locationId": "sishupalgarh", "hoursBack": 2.6,
     "title": "Flood risk escalated to Very High in Sishupalgarh",
     "description": "Composite illustrative risk index crossed 78/100 as soil saturation and drainage stress combine with forecast rainfall of 61 mm over 6 hours.",
     "guidance": "Review evacuation routes for four sample vulnerable zones. Demo data for interface validation only."},
    {"id": "RW-2403", "severity": "Watch", "category": "Potential Inundation Warning",
     "locationId": "damana", "hoursBack": 4.1,
     "title": "Inundation watch for Damana low-lying belt",
     "description": "Illustrative inundation model projects 0.6–1.1 m ponding in three low-lying cells if rainfall exceeds 45 mm in 6 hours.",
     "guidance": "Keep dewatering equipment on standby. Verify storm-water inlet clearing records. Demo scenario."},
    {"id": "RW-2404", "severity": "Advisory", "category": "Heavy Rainfall Warning",
     "locationId": "rasulgarh", "hoursBack": 6.3,
     "title": "Heavy rainfall advisory for Rasulgarh corridor",
     "description": "Sustained 24–38 mm/hr rainfall is simulated for the next 12 hours along the Rasulgarh–Damana stretch.",
     "guidance": "Advisory for commuters on the sample highway stretch. Allow extra travel time. Demo data."},
    {"id": "RW-2405", "severity": "Warning", "category": "Heavy Rainfall Warning",
     "locationId": "nayapalli", "hoursBack": 8.7,
     "title": "Heavy rainfall warning — Nayapalli ward cluster",
     "description": "Forecast series shows 6 consecutive hours above the 15.6 mm/hr heavy threshold with accumulating totals near 132 mm.",
     "guidance": "Pre-clear inlets in the sample ward cluster. Demo warning generated from local sample series."},
    {"id": "RW-2406", "severity": "Information", "category": "Weather Monitoring Update",
     "locationId": "patia", "hoursBack": 11.2,
     "title": "Monitoring update — Patia station online",
     "description": "Sample ground station PAT-04 resumed reporting after a scheduled communications test. Latest observation: 4.2 mm/hr, wind 11 km/h.",
     "guidance": "No action required. Informational update for the demo dashboard."},
    {"id": "RW-2407", "severity": "Watch", "category": "Flood Risk Warning",
     "locationId": "cuttack", "hoursBack": 14.5,
     "title": "River-proximity watch for Cuttack delta wards",
     "description": "Illustrative river contribution factor elevated to 0.82 with combined rainfall and tide-like river level inputs in the sample model.",
     "guidance": "Monitor sample gauge readings at 3-hour intervals. Demo watch — not an operational bulletin."},
    {"id": "RW-2408", "severity": "Advisory", "category": "Potential Inundation Warning",
     "locationId": "sishupalgarh", "hoursBack": 19.0,
     "title": "Underpass ponding advisory — Sishupalgarh",
     "description": "Simulated drainage stress suggests ponding depth of 0.4 m at two sample subway underpasses within 4 hours of sustained rain.",
     "guidance": "Demo advisory: consider closure protocols for the sample underpass locations."},
    {"id": "RW-2409", "severity": "Information", "category": "Weather Monitoring Update",
     "locationId": "airport", "hoursBack": 23.4,
     "title": "Visibility fluctuation noted at Biju Patnaik Airport",
     "description": "Sample observation series shows visibility dipping to 3.2 km during the heaviest simulated hour, recovering to 11 km thereafter.",
     "guidance": "Informational only. Demo observations for the live weather page."},
    {"id": "RW-2410", "severity": "Critical", "category": "Flood Risk Warning",
     "locationId": "old-town", "hoursBack": 27.8,
     "title": "Critical flood risk index for Old Town canal belt",
     "description": "Illustrative composite index peaked at 91/100 in the sample model as terrain, river proximity and rainfall contributions aligned.",
     "guidance": "Demonstration of a critical-severity card, status controls and modal detail view. Not a real alert."},
    {"id": "RW-2411", "severity": "Watch", "category": "Heavy Rainfall Warning",
     "locationId": "mancheswar", "hoursBack": 31.5,
     "title": "Industrial belt rainfall watch — Mancheswar",
     "description": "Sample forecast places 48–66 mm over 6 hours across the industrial estate, with drainage capacity modelled at 62%.",
     "guidance": "Demo watch for industrial-zone drainage stress scenarios."},
    {"id": "RW-2412", "severity": "Advisory", "category": "Weather Monitoring Update",
     "locationId": "puri", "hoursBack": 36.2,
     "title": "Coastal monitoring advisory — Puri",
     "description": "Illustrative coastal rainfall series updated with an onshore wind component; sample totals revised upward by 12%.",
     "guidance": "Informational advisory for the demo data-sources view."},
    {"id": "RW-2413", "severity": "Information", "category": "Weather Monitoring Update",
     "locationId": "vss-nagar", "hoursBack": 44.0,
     "title": "Drainage sensor batch synced — VSS Nagar",
     "description": "Four sample drainage-level sensors reported nominal readings between 18% and 34% of channel capacity.",
     "guidance": "No action required. Demo integration status update."},
    {"id": "RW-2414", "severity": "Warning", "category": "Extremely Heavy Rainfall Warning",
     "locationId": "khandagiri", "hoursBack": 52.5,
     "title": "Extremely heavy rainfall cell — Khandagiri hills",
     "description": "Simulated convective cell produced a 3-hour accumulation of 214 mm in the sample series, the highest event in the demo window.",
     "guidance": "Hill-slope runoff example used to demonstrate severity escalation in the UI. Demo data only."},
    {"id": "RW-2415", "severity": "Warning", "category": "Potential Inundation Warning",
     "locationId": "gopalpur", "hoursBack": 3.4,
     "title": "Coastal ponding watch — Gopalpur-on-Sea",
     "description": "Illustrative tidal-backwater and rainfall combination produces an estimated 0.8–1.4 m ponding depth across three sample coastal cells near Gopalpur.",
     "guidance": "Demo coastal-inundation example for the Brahmapur / Ganjam region. Not an operational bulletin."},
    {"id": "RW-2416", "severity": "Watch", "category": "Flood Risk Warning",
     "locationId": "brahmapur", "hoursBack": 7.8,
     "title": "Urban flood-risk watch — Brahmapur city",
     "description": "Sample composite index crosses 68/100 as heavy rainfall combines with 56% drainage efficiency in the Brahmapur urban core.",
     "guidance": "Demonstration of the second monitoring region. Values are illustrative and not validated predictions."},
]


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _hours_ago(hours: float) -> str:
    return _iso(datetime.now(timezone.utc) - timedelta(hours=hours))


def get_alerts() -> list:
    return [
        {
            "id": s["id"],
            "severity": s["severity"],
            "category": s["category"],
            "title": s["title"],
            "locationId": s["locationId"],
            "locationName": get_location(s["locationId"])["name"],
            "timestamp": _hours_ago(s["hoursBack"]),
            "description": s["description"],
            "guidance": s["guidance"],
            "status": "active",
        }
        for s in _SEEDS
    ]


def _severity_rank(severity: str) -> int:
    return SEVERITY_ORDER.index(severity) if severity in SEVERITY_ORDER else 0


def get_upcoming_alerts(limit: int = 5) -> list:
    alerts = sorted(get_alerts(), key=lambda a: _severity_rank(a["severity"]), reverse=True)
    return alerts[:limit]
