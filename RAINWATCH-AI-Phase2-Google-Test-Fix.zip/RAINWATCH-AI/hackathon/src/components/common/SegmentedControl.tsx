import { motion } from 'framer-motion'
import type { ReactNode } from 'react'

export interface SegmentedOption<T extends string> {
  value: T
  label: ReactNode
  title?: string
}

export function SegmentedControl<T extends string>({
  options,
  value,
  onChange,
  ariaLabel,
  size = 'md',
  className = '',
}: {
  options: SegmentedOption<T>[]
  value: T
  onChange: (v: T) => void
  ariaLabel: string
  size?: 'sm' | 'md'
  className?: string
}) {
  return (
    <div
      role="radiogroup"
      aria-label={ariaLabel}
      className={`inline-flex max-w-full flex-wrap gap-0 border border-line bg-surface p-0.5 ${className}`}
    >
      {options.map((opt) => {
        const active = opt.value === value
        return (
          <button
            key={opt.value}
            type="button"
            role="radio"
            aria-checked={active}
            title={opt.title}
            onClick={() => onChange(opt.value)}
            className={`relative mono font-semibold transition-colors duration-200 ${
              size === 'sm' ? 'px-2.5 py-1 text-[10px]' : 'px-3 py-1.5 text-[11px]'
            } ${active ? 'text-[var(--rw-on-accent)]' : 'text-muted hover:text-ink'}`}
          >
            {active ? (
              <motion.span
                layoutId={`seg-${ariaLabel}`}
                className="cut-br absolute inset-0 bg-accent"
                transition={{ type: 'spring', stiffness: 420, damping: 34 }}
                aria-hidden
              />
            ) : null}
            <span className="relative z-10 flex items-center gap-1.5 whitespace-nowrap">{opt.label}</span>
          </button>
        )
      })}
    </div>
  )
}
