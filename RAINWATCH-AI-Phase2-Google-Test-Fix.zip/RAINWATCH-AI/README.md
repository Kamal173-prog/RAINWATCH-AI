# RAINWATCH AI — Predict. Prepare. Protect.

Integrated heavy-rainfall early-warning and inundation-prediction system for
Odisha (HACK-KALP 2026, team Wanda_Maximoff). A React frontend over a FastAPI
backend (API v1.3.0) serving a trained XGBoost rainfall ensemble on real ERA5
reanalysis data, with optional Google Weather forecasts and NASA GPM IMERG
satellite rainfall served by a backend service and API endpoints.

**This package (2026-11-26, built fresh from the latest source):** the full
project including the Google Weather integration, the **merged forecast** —
the Forecast page now shows genuine values only, with source priority
**MODEL → GOOGLE WEATHER → UNAVAILABLE** — and the NASA GPM IMERG
integration through **Phase 2: a backend service
(`backend/app/services/satellite_rainfall.py`) plus three API endpoints**
(`GET /api/satellite/status`, `/api/satellite/rainfall`,
`/api/satellite/rainfall/region`), **including the Windows filename fix**
(CMR GranuleURs contain `:` — invalid on Windows — so cache filenames are
now percent-encoded; see the satellite section below) **and the Google
Weather test-isolation fix** (see the testing section below). It supersedes
`RAINWATCH-AI-Phase2-Windows-Fix.zip` (same date, which predated the test
fix). See `VERIFICATION.md` for the checks run on this package.

> ⚠️ Early-warning signal, not a confirmed forecast. Do not use any output for
> real emergency decisions.

## What is real and what is not

| Area | Source |
|---|---|
| Forecast, hours 1–6 (Bhubaneswar region) | **Trained ensemble model** (`rainfall-xgb-v3.3` demo / `rainfall-xgb-v3` production). Each point carries `source: "model"` + `model_version` + expected_mm, P90 bound, heavy-rain probabilities, risk tier. |
| Forecast, hours 7+ / Ganjam (merged endpoint) | **Google Weather** hourly forecast (QPF, mm in the hour) where Google can provide one; **UNAVAILABLE** (null values, never 0) where it cannot. No synthetic values. |
| Forecast, `/api/forecast` (old endpoint) | Still serves MODEL (hours 1–6) + deterministic DEMO (hours 7+). Kept for the simulator, risk, map and overview, which still use it. The Forecast page does **not** use it. |
| Historical rainfall | **Real** Open-Meteo ERA5 archive, hourly 2021-01-01 → 2025-12-31, Bhubaneswar grid cell (43,824 records). Ganjam archive not fetched yet (rate-limited) — Ganjam uses the demo generator there. |
| Flood risk / map / simulator / other pages | Composite susceptibility index + deterministic demo engine, clearly labelled DEMO. Not validated predictions. |
| Satellite rainfall (IMERG) | **Real NASA GPM IMERG Early Run observations** via the backend service + API endpoints (see below). **Live verification PASSED twice on 2026-11-26** (`backend/verify_satellite_live.py`, exit 0 both times): first run — a real V07C granule was downloaded, a valid zero rainfall observation (VALID_ZERO, 0.0 mm/hr at 2026-11-25T19:30:00Z / 01:00 IST, grid cell 20.25 / 85.849998) was extracted, and the second request reused the cached granule; second run — VALID_ZERO again, 0.0 mm/hr at 2026-11-25T20:30:00Z / 02:00 IST, same cached granule reused. No key or password ships in this package. The frontend does not display satellite data yet, and the Data Sources entry still reads "Awaiting Integration". |

**Forecast source priority (merged endpoint `GET /api/forecast/merged`):**
MODEL first, then GOOGLE WEATHER, then UNAVAILABLE. Each point carries
`source` (`model` / `google_weather` / `unavailable`) and `valueKind`
(`model_rate_mm_hr` / `google_qpf_mm`). The model's hourly rate and Google's
hourly QPF are different quantities and are never averaged or mixed: the table
labels each row's unit, Google's precipitation probability is carried
separately and is never confidence, and accumulated rainfall is the running
total of displayed values, unknown (null) from the first unavailable hour on.
Google's hour intervals sit on the local hour, so matching is by interval
containment, not equal timestamps. Google's accuracy has **not** been validated
against RAINWATCH — no claim is made that it is more accurate.

## NASA GPM IMERG satellite rainfall — status (honest)

Phase 0 investigation, Phase 1 service and Phase 2 endpoints are **done**
(`backend/docs/SATELLITE_IMERG_PHASE0.md`,
`backend/docs/SATELLITE_IMERG_PHASE2.md`). What is established:

- The old GES DISC on-premises endpoints are **dead since 30 Sep 2026**.
  The current mechanism is Earthdata Cloud via CMR + the `earthaccess`
  Python package. Collection concept ID `C2723758340-GES_DISC`.
- Auth: a **free Earthdata Login account**, with NASA GESDISC DATA ARCHIVE
  authorised as an application. No billing.
- Product: `GPM_3IMERGHHE_07` Early Run, variable `Grid/precipitation`
  (mm/hr), 30-minute granules, 0.1° grid. **Live files are V07C, not V07B.**
- **Verified dimension order: (time, longitude, latitude)** — shape
  (1, 3600, 1800). The extraction reads `DimensionNames` from the file and
  refuses any other order. Nearest cell to Old Town (20.2662, 85.8418) is
  lat 20.25, lon 85.85, ~1.99 km away.
- **Phase 1 service** (`backend/app/services/satellite_rainfall.py`):
  Earthdata auth, CMR granule discovery (V07C preferred), download with a
  file cache in `backend/data/satellite/` (atomic writes, sidecar metadata,
  reuse instead of re-downloading), HDF5 extraction with fill/NaN/invalid
  handling — missing is reported as MISSING with null values, never zero.
  Functions: `get_satellite_status`, `get_latest_granule`,
  `get_rainfall_for_location`, `get_rainfall_for_region`.
- **Phase 2 endpoints** (see the table below): status, rainfall for any
  latitude/longitude, rainfall for a region. Missing credentials → 503,
  NASA/service failure → 502, bad coordinates → 422, unknown region → 400.
  A successful observation is 200 even when the cell value is MISSING or
  INVALID — the observation succeeded, the cell simply has no usable value.

**Live verification PASSED 2026-11-26** (`backend/verify_satellite_live.py`,
exit 0, run on Kam's Windows machine): a real NASA V07C granule was
downloaded, extraction returned VALID_ZERO (0.0 mm/hr) at
2026-11-25T19:30:00Z for grid cell 20.25 / 85.849998, the cache file was
created with the sanitized filename, and the second request reused the
same granule with an identical retrieval timestamp. What is **not** done:
there is no satellite map layer, no satellite time series and no
satellite value in any forecast, comparison or risk calculation; the Data
Sources satellite entry still reads "Awaiting Integration". (The live
check can be re-run any time with `backend/verify_satellite_live.py` —
see the next section.)

**Second live verification, same day (2026-11-26):**
`backend/verify_satellite_live.py` passed again (exit 0). Observation
2026-11-25T20:30:00Z (2026-11-26T02:00:00+05:30 IST), NASA GPM IMERG
Early Run V07C, status VALID_ZERO, rainfall 0.0 mm/hr, accumulation
0.0 mm, grid cell lat 20.25, lon ~85.85, ~1.99 km from Old Town; granule
filename sanitization successful; the second request reused the same
cached granule and the retrieval timestamp was unchanged.

**What VALID_ZERO means:** it is a valid satellite observation in which
the grid cell genuinely recorded zero rainfall. It is not missing data
(missing is reported as MISSING with null values, never zero) and it is
not synthetic demo data — the value came from a real IMERG granule.

**Windows filename fix (2026-11-26):** CMR GranuleURs are
`<ShortName>:<filename>` (`GPM_3IMERGHHE.07:3B-HHR-E...HDF5`) and the
service used the raw ID as the cache destination, so on Windows the
download failed with `[WinError 123]`. Cache filenames are now
percent-encoded (`:` → `%3A`, plus every other Windows-invalid
character, control characters and trailing dots/spaces); the encoding
is injective, so two granule IDs can never collide into one file, and
clean names pass through unchanged. The native ID is preserved
verbatim in metadata (`nativeId`), the sidecar, the logs and the
remote URL — only the on-disk name is encoded. A file cached under
the raw colon name (possible on Linux/macOS) is reused by the cache
scan and migrated in place if the download path meets it. 10
regression tests cover the fix (`backend/tests/test_satellite_rainfall.py`).

**Regional coverage limitation:** the Bhubaneswar region bounding box
`[20.23, 85.77, 20.37, 85.87]` excludes Cuttack (20.462, 85.883) and Puri
(19.8135, 85.831), so `GET /api/satellite/rainfall/region?region=bhubaneswar`
returns **12 of 14** locations. The response carries a `coverageNote` stating
exactly that. Ganjam returns all 7 locations. The bounding box was
deliberately not changed in this package.

### Google Weather test isolation (2026-11-26)

**Test-only fix, no production change.** `app.core.config` snapshots
`GOOGLE_WEATHER_API_KEY` at import time (from `backend/.env`), and the
service falls back to that snapshot when the env var is absent — so the
old test fixtures' `monkeypatch.delenv` did NOT unconfigure the service
when `.env` held a real key, and the four no-key tests failed (real
Google calls attempted, or the mock transport's key assertion tripped).
The fix, in test files only:

- `backend/tests/conftest.py` — new autouse fixture
  `_no_google_key_by_default`: clears the env var **and** the config
  snapshot, resets the Google service state and transport before every
  test; `monkeypatch` restores everything afterwards.
- `backend/tests/test_google_weather.py` and
  `backend/tests/test_forecast_merged.py` — the `keyed` fixtures now set
  **both** the env var and the config snapshot to the mock key
  `test-demo-key`.

Result: the suite passes whether or not `backend/.env` contains a real
key (verified both ways before packaging). Production behaviour is
unchanged — a genuinely missing key still produces
`GoogleWeatherNotConfigured` (HTTP 503) and the merged forecast still
marks non-model hours unavailable.

**One test needs `npm install` first:** `test_provenance.py::
test_frontend_source_resolver_never_infers_from_version` compiles the
frontend resolver with `hackathon/node_modules/typescript/bin/tsc`.
`node_modules` is not shipped in this package, so run `npm install` in
`hackathon/` before the backend suite, or that one test fails with
`MODULE_NOT_FOUND`.

## Layout

```
RAINWATCH-AI/
  README.md            this file
  MANIFEST.md          file inventory with sizes
  VERIFICATION.md      checks run on this package
  backend/             FastAPI backend (API v1.3.0), models, data, docs, tests
  hackathon/           React 19 + Vite frontend
  presentation/        HACK-KALP deck, 6 slides (pptx + pdf)
```

## Setup — backend (Windows PowerShell)

```powershell
cd backend
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env        # then edit .env if needed (see below)
```

The install works with no manual edits: `.env.example` already has the correct
paths (`BHUBANESWAR_CSV=data/processed/bhubaneswar_weather.csv`) and empty
`GOOGLE_WEATHER_API_KEY=`, `EARTHDATA_USERNAME=` and `EARTHDATA_PASSWORD=`
placeholders. **Never put a real key or password in `.env.example`.**

`requirements.txt` now includes `earthaccess==1.0.0` and `h5py==3.16.0`
(the satellite service dependencies, spike-verified versions).

To run the tests (optional):

```powershell
pip install -r requirements-test.txt   # test-only deps (pytest); needed before the suite runs
python -m pytest        # full suite, ~90 s; expected: 245 passed
```

## Google Weather configuration (optional)

Without a key, RAINWATCH works fully: `/api/weather/google` answers 503 and
the merged forecast fills non-model hours with UNAVAILABLE. With a key:

1. Google Cloud Console → create a project → enable the **Weather API**.
2. Create an API key, restricted to the Weather API only.
   - A **Maps Demo Key** works for prototyping (no billing, daily limits
     unpublished). A standard key needs a billing account on the project.
     India pricing for standard keys: 70,000 events/month free, then
     $0.06/1,000.
3. Paste it in `backend/.env` as `GOOGLE_WEATHER_API_KEY=<key>` — never in
   `.env.example`, never in git, never in the frontend, never in a screenshot.
4. Restart the backend. First live check:
   `GET /api/forecast/merged?locationId=old-town&hours=24` — expect
   6 MODEL + 18 GOOGLE WEATHER.

The backend caches Google responses for 30 minutes per location, so repeated
page loads do not burn quota.

## NASA Earthdata configuration + live satellite check (optional)

**Live verification already passed 2026-11-26** (see the satellite section
above). The steps below are for re-running the check or setting it up on a
new machine.

1. Create a free account at https://urs.earthdata.nasa.gov/users/new
   (username, email, password; Affiliation "Education", Study Area
   "Hydrologic Cycle" fit a student project). Complete the email verification.
2. On first use of a GES DISC download, Earthdata asks you to authorise the
   **NASA GESDISC DATA ARCHIVE** application — tick the agreement and click
   Agree.
3. Put the credentials in `backend/.env` (never in `.env.example`):
   `EARTHDATA_USERNAME=<your username>` and
   `EARTHDATA_PASSWORD=<your password>`.
4. Run the live check from the backend folder (run it from `backend/` — the
   script loads `.env` from the current working directory):
   ```powershell
   .\.venv\Scripts\python.exe verify_satellite_live.py
   ```
   It checks the satellite status, extracts the real Old Town observation
   from the latest IMERG Early Run granule, calls the location function a
   second time to prove the cached granule is reused, and exits 0 only if
   a real value was extracted and the cache was reused. Exit 1 with a plain
   message means not configured, a NASA error, or a missing/invalid cell
   value — never a fabricated number.

The standalone spike script is still included (`backend/ml/satellite_spike.py`):
it authenticates, finds the latest granule over Odisha via CMR, downloads it
to `backend/data/satellite/`, verifies the HDF5 file, and prints the
precipitation rate (mm/hr) and 30-minute accumulation for the grid cell
nearest Old Town, Bhubaneswar (20.2662, 85.8418), with the cell's coordinates
and distance. A value equal to the file's `_FillValue` is reported as
**missing data, not zero rainfall**. If authentication, download or extraction
fails, the script exits non-zero and reports the exact error — it never
invents a value.

## Run it

Two terminals. The demo and production servers are separate; the demo never
touches production.

**Demo (v3.3 model — the hackathon configuration):**

```powershell
# Terminal 1 — backend on :8001
cd backend
$env:MODEL_VERSION = "rainfall-xgb-v3.3"
.\.venv\Scripts\Activate.ps1
python -m uvicorn app.main:app --port 8001
# Wait ~10 s, then check: curl http://localhost:8001/api/health
# Expect: "model_version": "rainfall-xgb-v3.3", "loaded": true

# Terminal 2 — frontend on :5173 (must be :5173 — the backend CORS
# allow-list covers :5173 only; any other port silently falls back to DEMO)
cd hackathon
npm install
$env:VITE_API_URL = "http://localhost:8001"
npm run dev -- --port 5173
# Open http://localhost:5173 — wait ~20 s after loading Overview before
# presenting (charts animate in).
```

**Production (v3 model, untouched):** same commands without `MODEL_VERSION`,
backend on port 8000, frontend `VITE_API_URL=http://localhost:8000`.
Rollback from the demo = stop the :8001 server.

Linux/macOS equivalents: `python3 -m venv .venv`, `source .venv/bin/activate`,
`MODEL_VERSION=rainfall-xgb-v3.3 .venv/bin/python -m uvicorn app.main:app --port 8001`,
`VITE_API_URL=http://localhost:8001 node node_modules/vite/bin/vite.js --port 5173`.

## Key endpoints

| Method | Path | Notes |
|---|---|---|
| GET | `/api/health` | Model + dataset status |
| GET | `/api/forecast?locationId&hours` | MODEL (hours 1–6) + DEMO (hours 7+); used by simulator/risk/map/overview |
| GET | `/api/forecast/merged?locationId&hours` | **MODEL → GOOGLE WEATHER → UNAVAILABLE**; used by the Forecast page |
| GET | `/api/weather/google?locationId&hours` | Google hourly forecast; 503 no key, 502 Google error |
| GET | `/api/satellite/status` | Satellite service state; always 200, even when not configured |
| GET | `/api/satellite/rainfall?latitude&longitude&observationTime` | Real IMERG observation for any point; 422 bad coords, 503 no creds, 502 NASA error; 200 even when the cell is MISSING/INVALID |
| GET | `/api/satellite/rainfall/region?region` | One observation per RAINWATCH location in a region (`bhubaneswar` / `ganjam`); Bhubaneswar returns 12 of 14 — see the `coverageNote` in the response |
| GET | `/api/risk/all`, `/api/risk/records`, `/api/map/regions` | Risk + map (demo engine + model offsets) |
| GET | `/api/history/daily?locationId&days` | Real ERA5 daily history |
| GET | `/api/data-sources` | Source catalogue incl. Google Weather status |
| POST | `/api/simulate` | What-if scenario (deterministic demo formula) |

`hours` ∈ 3/6/12/24/48/72. Unknown location → 404, bad hours → 400.

## Tests (expected results)

```powershell
cd hackathon
npm install     # required BEFORE the backend suite: one provenance test
                # compiles the frontend resolver with node_modules/typescript
cd ..\backend
python -m pytest        # 245 passed (after installing requirements-test.txt)
cd ..\hackathon
node node_modules/typescript/bin/tsc -b    # expected: clean
node node_modules/vite/bin/vite.js build   # expected: passes
```

The backend suite passes whether or not `backend/.env` contains a real
Google key (test-isolation fix, 2026-11-26 — see above).

Frozen v3.3 artifacts: 15/15 SHA-256 + sizes match
`backend/models/rainfall_xgb_v3_3/frozen/RELEASE_MANIFEST.json`. Never retrain,
re-tune or overwrite them; thresholds live in `thresholds_optimized.json`
(3h≥10mm Watch 0.070 / Warning 0.125; 6h≥10mm 0.085 / 0.185;
3h≥5mm 0.125 / 0.225, selected on pooled out-of-sample 2024+2025 only).

Note: `npm run build` may fail on the `tsc` step if the `.bin` shim lost its
exec bit — use the direct `node node_modules/typescript/bin/tsc -b` and
`node node_modules/vite/bin/vite.js build` commands above instead.

## Known limitations (honest)

- The model predicts for a single Bhubaneswar ERA5 grid cell
  (20.28°N, 85.84°E); the same cell's forecast is applied to every
  Bhubaneswar-region location, including Cuttack and Puri — not per-city models.
- The backend's live Google call with a real key is unverified in this
  package (no key ships by design); verify with the first-live-check above.
- Google's accuracy has not been validated against RAINWATCH or IMD data.
- Satellite (IMERG) service + endpoints are **live-verified twice**
  (two real V07C granules downloaded, VALID_ZERO 0.0 mm/hr extracted in
  both runs, cache reuse proven — 2026-11-26). No satellite map layer,
  time series, or frontend display yet; no satellite value in any
  forecast, comparison or risk calculation; the Data Sources satellite
  entry still reads "Awaiting Integration".
- The Bhubaneswar satellite region returns 12 of 14 locations (Cuttack and
  Puri lie outside the region bounding box); see the `coverageNote`.
- Ganjam/Brahmapur ERA5 archive not fetched (rate-limited); Ganjam history
  uses the demo generator. Run `backend/fetch_brahmapur.py` later, then restart.
- The app shell still labels itself "Demo Mode" — that is app-wide chrome;
  only the Forecast page is guaranteed free of synthetic forecast values.
- Dev servers are unsupervised: a machine restart stops them; re-run the
  startup commands. The map page needs internet for OpenStreetMap base tiles
  (overlays render regardless, with a graceful-fallback banner).
- No git repo / CI in this package. See `backend/docs/KNOWN_LIMITATIONS.md`
  for the full list.

## Documentation

- `backend/docs/HACKATHON_HANDOFF.md` — demo-day runbook (startup, checks, say-lines)
- `backend/docs/MODEL_REPORT.md`, `V33_*.md` — model reports and thresholds
- `backend/docs/IMD_DAILY_VALIDATION.md` — model vs IMD daily gridded rainfall
- `backend/docs/SATELLITE_IMERG_PHASE0.md` — IMERG investigation findings + spike
- `backend/docs/SATELLITE_IMERG_PHASE2.md` — satellite service + endpoint contracts
- `backend/docs/DATA_PROVENANCE.md` — what is real, what is demo, source priority
- `backend/docs/TESTING.md` — test inventory (245 backend tests + probe scripts)
- `backend/docs/FINAL_ACCEPTANCE_REPORT.md`, `PROJECT_COMPLETENESS_AUDIT.md`
