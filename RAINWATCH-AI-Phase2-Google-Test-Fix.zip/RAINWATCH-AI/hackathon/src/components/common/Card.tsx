import { motion, useMotionValue, useReducedMotion, useSpring, useTransform } from 'framer-motion'
import type { PointerEvent, ReactNode } from 'react'

export interface CardProps {
  children: ReactNode
  className?: string
  /** Lift the card slightly on hover. */
  hover?: boolean
  /** Pointer-driven 3D tilt (instrument feel, disabled under reduced motion). */
  tilt?: boolean
  /** Hard offset plate shadow instead of a diffuse glow. */
  plate?: boolean
  /** Draw small accent corner brackets. */
  brackets?: boolean
  /** Entrance animation delay in seconds. */
  delay?: number
  pad?: boolean
  id?: string
  onClick?: () => void
  'aria-label'?: string
  role?: 'region' | 'group' | 'listitem' | 'article'
}

export function Card({
  children,
  className = '',
  hover = false,
  tilt = false,
  plate = true,
  brackets = false,
  delay = 0,
  pad = true,
  id,
  onClick,
  ...rest
}: CardProps) {
  const reduce = useReducedMotion()
  const mx = useMotionValue(0)
  const my = useMotionValue(0)
  const sx = useSpring(mx, { stiffness: 190, damping: 22, mass: 0.4 })
  const sy = useSpring(my, { stiffness: 190, damping: 22, mass: 0.4 })
  const rotateX = useTransform(sx, (v) => `${v}deg`)
  const rotateY = useTransform(sy, (v) => `${v}deg`)

  const handleMove = (e: PointerEvent<HTMLDivElement>) => {
    if (!tilt || reduce) return
    const r = e.currentTarget.getBoundingClientRect()
    const px = (e.clientX - r.left) / r.width - 0.5
    const py = (e.clientY - r.top) / r.height - 0.5
    my.set(-py * 6)
    mx.set(px * 6)
  }

  const resetTilt = () => {
    mx.set(0)
    my.set(0)
  }

  return (
    <motion.div
      id={id}
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.42, delay, ease: [0.16, 1, 0.3, 1] }}
      whileHover={hover ? { y: -3 } : undefined}
      onPointerMove={handleMove}
      onPointerLeave={resetTilt}
      style={tilt && !reduce ? { rotateX, rotateY, transformPerspective: 900, transformStyle: 'preserve-3d' } : undefined}
      className={`group/card relative min-w-0 border border-line bg-card ${
        pad ? 'p-[var(--rw-card-pad)]' : ''
      } ${plate ? 'plate' : ''} ${brackets ? 'corner-brackets' : ''} ${
        hover ? 'transition-colors duration-200 hover:border-accent/60' : ''
      } ${className}`}
      onClick={onClick}
      {...rest}
    >
      {children}
    </motion.div>
  )
}

export function CardHeader({
  title,
  subtitle,
  actions,
  icon,
}: {
  title: ReactNode
  subtitle?: ReactNode
  actions?: ReactNode
  icon?: ReactNode
}) {
  return (
    <div className="mb-4 flex flex-wrap items-start justify-between gap-3 border-b border-line pb-3">
      <div className="flex min-w-0 items-start gap-3">
        {icon ? (
          <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center border border-line bg-surface text-accent">
            {icon}
          </span>
        ) : null}
        <div className="min-w-0">
          <h3 className="truncate text-[15px] font-semibold text-ink">{title}</h3>
          {subtitle ? <p className="mono mt-1 text-[10px] text-muted">{subtitle}</p> : null}
        </div>
      </div>
      {actions ? <div className="flex shrink-0 flex-wrap items-center gap-2">{actions}</div> : null}
    </div>
  )
}
