"""Final 2026 evaluation -- run ONCE, after the v3.3 freeze.

Scores the DEPLOYED artifacts of all four versions on the same
reserved 2026 data (Jan-Nov 2026, never used for any selection,
threshold, weight or feature decision) with identical metric code:
  v3    models/rainfall_xgb_v3/        41 features, v3 table
  v3.1  models/rainfall_xgb_v3_1/      41 features, v3 table
  v3.2  models/rainfall_xgb_v3_2/      53 features (41 + 12 GFS), v32 table
  v3.3  models/rainfall_xgb_v3_3/frozen  94 features, v33 table
Each version is evaluated at its OWN saved operating thresholds
(elevated/high), as it would actually alert; PR-AUC is the
threshold-free headline. Regressors are shared across all four
versions (v3's), so MAE/RMSE on 2026 is computed once.

Output: models/rainfall_xgb_v3_3/final_2026_comparison.json
"""

import json
import logging
import os
import sys

import joblib
import lightgbm as lgb
import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.metrics import (average_precision_score, brier_score_loss,
                             mean_absolute_error, mean_squared_error,
                             roc_auc_score)

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v33_common import event_metrics, hour_metrics, platt_apply  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger("evaluate_2026")

BACKEND = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
V33_DIR = os.path.join(BACKEND, "models", "rainfall_xgb_v3_3")
TARGETS = ["y_3h_ge_10mm", "y_6h_ge_10mm", "y_3h_ge_5mm"]
FAMILIES = ("xgb", "lgbm", "hgb")


def _load_member(model_dir: str, target: str, fam: str):
    """Load one family member, trying both artifact namings."""
    base = target.replace("y_", "")
    for stem in (f"clf_{base}_{fam}", f"clf_y_{base}_{fam}"):
        if fam == "xgb":
            p = os.path.join(model_dir, stem + ".json")
            if os.path.exists(p):
                bst = xgb.Booster()
                bst.load_model(p)
                return ("xgb", bst)
        elif fam == "lgbm":
            p = os.path.join(model_dir, stem + ".txt")
            if os.path.exists(p):
                return ("lgbm", lgb.Booster(model_file=p))
        else:
            p = os.path.join(model_dir, stem + ".pkl")
            if os.path.exists(p):
                return ("hgb", joblib.load(p))
    raise FileNotFoundError(f"no member for {target}/{fam} in {model_dir}")


def _predict(model, X: np.ndarray) -> np.ndarray:
    kind, m = model
    if kind == "xgb":
        return m.predict(xgb.DMatrix(X))
    if kind == "lgbm":
        return m.predict(X)
    return m.predict_proba(X)[:, 1]


def _ece(y: np.ndarray, p: np.ndarray, bins: int = 10) -> float:
    edges = np.linspace(0, 1, bins + 1)
    tot = 0.0
    for i in range(bins):
        m = (p > edges[i]) & (p <= edges[i + 1] if i == bins - 1 else p < edges[i + 1])
        if m.sum():
            tot += abs(p[m].mean() - y[m].mean()) * m.sum() / len(y)
    return round(float(tot), 4)


def _norm_key(key: str) -> str:
    return key[4:] if key.startswith("clf_") else key


def evaluate_version(name: str, model_dir: str, table_path: str,
                     schema_path: str) -> dict:
    feats = json.load(open(schema_path))["features"]
    weights = {_norm_key(k): v for k, v in
               json.load(open(os.path.join(model_dir, "ensemble_weights.json"))).items()}
    platt = json.load(open(os.path.join(model_dir, "platt.json")))
    thresholds = json.load(open(os.path.join(model_dir, "thresholds.json")))
    df = pd.read_csv(table_path, parse_dates=["timestamp"])
    d26 = df[df["timestamp"].dt.year == 2026].reset_index(drop=True)
    log.info("%s: %d 2026 rows, %d features", name, len(d26), len(feats))

    out: dict = {}
    for target in TARGETS:
        sub = d26.dropna(subset=[target]).reset_index(drop=True)
        y = sub[target].to_numpy().astype(int)
        X = sub[feats].to_numpy(dtype=float)
        ens = np.zeros(len(y))
        for fam in FAMILIES:
            w = float(weights[target][fam])
            if w == 0:
                continue
            ens += w * _predict(_load_member(model_dir, target, fam), X)
        pl = platt[target]
        cal = platt_apply(ens, float(pl["w"]), float(pl["b"]))
        n_days = len(y) / 24.0
        ev = {
            "n": int(len(y)),
            "pr_auc": round(float(average_precision_score(y, cal)), 4),
            "roc_auc": round(float(roc_auc_score(y, cal)), 4),
            "brier": round(float(brier_score_loss(y, cal)), 4),
            "ece": _ece(y, cal),
            "levels": {},
        }
        for level in ("elevated", "high"):
            t = thresholds[target][level]
            # v3.1 stores each level as {"threshold": ..., "precision": ...};
            # v3/v3.2/frozen store a plain number. Unwrap either way.
            if isinstance(t, dict):
                t = t["threshold"]
            t = float(t)
            ev["levels"][level] = {**hour_metrics(y, cal, t),
                                   **event_metrics(y, cal, t, n_days)}
        out[target] = ev
        log.info("  %s %s: PR-AUC %.4f | elev P %.3f R %.3f F1 %.3f | "
                 "high P %.3f R %.3f F1 %.3f",
                 name, target, ev["pr_auc"],
                 ev["levels"]["elevated"]["precision"],
                 ev["levels"]["elevated"]["recall"],
                 ev["levels"]["elevated"]["f1"],
                 ev["levels"]["high"]["precision"],
                 ev["levels"]["high"]["recall"],
                 ev["levels"]["high"]["f1"])
    return out


def regressors_2026() -> dict:
    """Shared v3 regressors scored on the 2026 v3 table (all versions
    carry these regressors unchanged)."""
    model_dir = os.path.join(BACKEND, "models", "rainfall_xgb_v3")
    feats = json.load(open(os.path.join(model_dir, "feature_schema.json")))["features"]
    weights = json.load(open(os.path.join(model_dir, "ensemble_weights.json")))
    df = pd.read_csv(os.path.join(BACKEND, "data", "model_ready",
                                  "bhubaneswar_features_2026.csv"),
                     parse_dates=["timestamp"])
    out = {}
    for horizon, key, ycol in (("1h", "reg_1h", "y_1h"), ("3h", "reg_3h", "y_3h"),
                               ("6h", "reg_6h", "y_6h")):
        sub = df.dropna(subset=[ycol]).reset_index(drop=True)
        y = sub[ycol].to_numpy(dtype=float)
        X = sub[feats].to_numpy(dtype=float)
        pred = np.zeros(len(y))
        for fam in FAMILIES:
            w = float(weights[key][fam])
            if w == 0:
                continue
            stem = f"reg_{horizon}_{fam}"
            if fam == "xgb":
                bst = xgb.Booster()
                bst.load_model(os.path.join(model_dir, stem + ".json"))
                p = bst.predict(xgb.DMatrix(X))
            elif fam == "lgbm":
                p = lgb.Booster(
                    model_file=os.path.join(model_dir, stem + ".txt")).predict(X)
            else:
                p = joblib.load(os.path.join(model_dir, stem + ".pkl")).predict(X)
            pred += w * p
        out[horizon] = {
            "n": int(len(y)),
            "mae": round(float(mean_absolute_error(y, pred)), 4),
            "rmse": round(float(mean_squared_error(y, pred) ** 0.5), 4),
        }
        log.info("  regressor %s: MAE %.4f RMSE %.4f (n=%d)",
                 horizon, out[horizon]["mae"], out[horizon]["rmse"], len(y))
    return out


def main() -> None:
    versions = [
        ("v3", os.path.join(BACKEND, "models", "rainfall_xgb_v3"),
         os.path.join(BACKEND, "data", "model_ready", "bhubaneswar_features_2026.csv"),
         os.path.join(BACKEND, "models", "rainfall_xgb_v3", "feature_schema.json")),
        ("v3.1", os.path.join(BACKEND, "models", "rainfall_xgb_v3_1"),
         os.path.join(BACKEND, "data", "model_ready", "bhubaneswar_features_2026.csv"),
         os.path.join(BACKEND, "models", "rainfall_xgb_v3_1", "feature_schema.json")),
        ("v3.2", os.path.join(BACKEND, "models", "rainfall_xgb_v3_2"),
         os.path.join(BACKEND, "data", "model_ready", "bhubaneswar_features_v32.csv"),
         os.path.join(BACKEND, "models", "rainfall_xgb_v3_2", "feature_schema.json")),
        ("v3.3-frozen", os.path.join(V33_DIR, "frozen"),
         os.path.join(BACKEND, "data", "model_ready", "bhubaneswar_features_v33.csv"),
         os.path.join(V33_DIR, "frozen", "feature_schema.json")),
    ]
    results: dict = {"regressors_2026_shared": regressors_2026()}
    for name, model_dir, table, schema in versions:
        results[name] = evaluate_version(name, model_dir, table, schema)
    out_path = os.path.join(V33_DIR, "final_2026_comparison.json")
    json.dump(results, open(out_path, "w"), indent=2)
    log.info("saved %s", out_path)


if __name__ == "__main__":
    main()
