"""Historical rainfall & risk archive.

Two sources, kept honest:
- **Real data** — the Open-Meteo ERA5 archive (``data/bhubaneswar_weather.csv``,
  hourly 2021-01-01 → 2025-12-31 for Bhubaneswar). Used for locations in the
  Bhubaneswar region. Daily totals are scaled by the same per-location
  exposure factor the frontend uses, so nearby wards differ plausibly.
  This is ERA5 *reanalysis*, not direct station measurements.
- **Demo generator** — a faithful port of ``hackathon/src/data/historicalData.ts``.
  Used for the Ganjam / Brahmapur region (its archive fetch was rate-limited
  by Open-Meteo) and as a fallback if the CSV is missing.

The response shapes are identical either way, so the frontend never changes.
"""

import csv
import math
import os
from datetime import date, datetime, timedelta, timezone

from .demo_state import get_demo_tick
from .locations import LOCATIONS, get_location, is_ganjam
from .rng import clamp, classify_risk, create_rng, hash_seed, imul, js_round

MONTH_RAIN_FACTOR = [0.9, 0.7, 0.8, 1.4, 4.6, 14.5, 26.0, 25.2, 16.8, 7.2, 2.1, 0.8]
MONTH_LABELS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

# ------------------------------------------------------------------
# Real Open-Meteo archive (lazy-loaded, cached)
# ------------------------------------------------------------------

_daily_cache = None  # date -> {"total": mm, "peak": mm/hr, "mean_temp": C}


def _csv_path() -> str:
    override = os.environ.get("BHUBANESWAR_CSV", "")
    if override:
        return override
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(here, "..", "..", "data", "processed", "bhubaneswar_weather.csv")


def _load_real_daily():
    """Aggregate the hourly CSV into per-day totals. Returns None if missing."""
    global _daily_cache
    if _daily_cache is not None:
        return _daily_cache
    path = _csv_path()
    if not os.path.exists(path):
        _daily_cache = {}
        return _daily_cache
    daily = {}
    with open(path, newline="") as f:
        for row in csv.DictReader(f):
            day = row["timestamp"][:10]
            precip = float(row["precipitation_mm"] or 0)
            entry = daily.setdefault(day, {"total": 0.0, "peak": 0.0})
            entry["total"] += precip
            entry["peak"] = max(entry["peak"], precip)
    _daily_cache = daily
    return daily


def _exposure(loc: dict) -> float:
    return clamp(0.8 + loc["lowLyingPct"] / 300 + loc["riverProximity"] / 500, 0.7, 1.5)


def _risk_from_rain(rainfall_mm: float, loc: dict, rng) -> float:
    rain_component = clamp(rainfall_mm * 0.42, 0, 58)
    terrain_component = loc["lowLyingPct"] * 0.28
    return js_round(
        clamp(rain_component + terrain_component + rng() * 14 - (loc["drainageEfficiency"] / 100) * 14, 3, 97), 1
    )


def _real_daily_history(location_id: str, days: int) -> list:
    """Daily history from the real archive, scaled by location exposure.

    Anchored to the archive's last date (2025-12-31), not to today —
    the archive ends there, so the trailing window is the most recent
    real data rather than mostly-empty 2026 dates.
    """
    loc = get_location(location_id)
    daily = _load_real_daily()
    if not daily:
        return None
    exposure = _exposure(loc)
    last_date = max(datetime.fromisoformat(k).date() for k in daily)
    rows = []
    for i in range(days - 1, -1, -1):
        d = last_date - timedelta(days=i)
        key = d.isoformat()
        entry = daily.get(key)
        rng = create_rng(hash_seed(f"{location_id}|{key}"))
        if entry is None:
            rainfall_mm = 0.0
            peak = 0.0
        else:
            rainfall_mm = js_round(entry["total"] * exposure, 1)
            peak = js_round(entry["peak"] * exposure, 1)
        rows.append({
            "date": key,
            "locationId": location_id,
            "rainfallMm": rainfall_mm,
            "peakHourMmHr": peak,
            "riskIndex": _risk_from_rain(rainfall_mm, loc, rng),
        })
    return rows


# ------------------------------------------------------------------
# Demo generator (port of historicalData.ts) — Ganjam + fallback
# ------------------------------------------------------------------

_daily_demo_cache: dict = {}


def _seed_for(location_id: str, days: int) -> int:
    return (hash_seed(location_id) ^ imul(get_demo_tick() + 11, 0x27D4EB2F) ^ days) & 0xFFFFFFFF


def _demo_daily_history(location_id: str, days: int = 120) -> list:
    tick = get_demo_tick()
    key = f"{location_id}:{days}:{tick}"
    cached = _daily_demo_cache.get(key)
    if cached is not None and cached["tick"] == tick:
        return cached["rows"]

    loc = get_location(location_id)
    rng = create_rng(_seed_for(location_id, days))
    exposure = _exposure(loc)
    rows = []
    today = datetime.now(timezone.utc).date()

    for i in range(days - 1, -1, -1):
        d = today - timedelta(days=i)
        base = MONTH_RAIN_FACTOR[d.month - 1]

        wet_day = rng() < min(0.92, 0.24 + base / 34)
        rainfall_mm = 0.0
        peak_hour = 0.0
        if wet_day:
            burst = (2.6 + rng() * 4.2) if rng() < 0.12 else (0.5 + rng() * 1.5)
            rainfall_mm = js_round(clamp(base * burst * exposure * (0.35 + rng() * 1.1), 0.4, 385), 1)
            peak_hour = js_round(clamp((rainfall_mm / (3 + rng() * 9)) * (1.4 + rng()), 0.2, 172), 1)

        risk_index = _risk_from_rain(rainfall_mm, loc, rng)
        rows.append({
            "date": d.isoformat(),
            "locationId": location_id,
            "rainfallMm": rainfall_mm,
            "peakHourMmHr": peak_hour,
            "riskIndex": risk_index,
        })

    _daily_demo_cache[key] = {"tick": tick, "rows": rows}
    return rows


# ------------------------------------------------------------------
# Public API (same shapes as the frontend's demoApi)
# ------------------------------------------------------------------

def get_daily_history(location_id: str, days: int = 120) -> list:
    if not is_ganjam(location_id):
        real = _real_daily_history(location_id, days)
        if real is not None:
            return real
    return _demo_daily_history(location_id, days)


def get_monthly_history(location_id: str) -> list:
    daily = get_daily_history(location_id, 365)
    seen = sorted({row["date"][:7] for row in daily})[-12:]
    out = []
    for key in seen:
        year, month = (int(x) for x in key.split("-"))
        rows = [r for r in daily if r["date"].startswith(key)]
        out.append({
            "month": f"{MONTH_LABELS[month - 1]} {str(year)[2:]}",
            "rainfallMm": js_round(sum(r["rainfallMm"] for r in rows), 1),
            "rainyDays": len([r for r in rows if r["rainfallMm"] >= 2.5]),
            "peakMmHr": js_round(max((r["peakHourMmHr"] for r in rows), default=0), 1),
            "avgRiskIndex": js_round(
                sum(r["riskIndex"] for r in rows) / max(1, len(rows)), 1
            ),
        })
    return out


def get_annual_history() -> list:
    """Real annual totals from the Open-Meteo archive (2021-2025)."""
    daily = _load_real_daily()
    if daily:
        years = sorted({k[:4] for k in daily})
        out = []
        for year in years:
            rows = [v for k, v in daily.items() if k.startswith(year)]
            totals = [v["total"] for v in rows]
            out.append({
                "year": int(year),
                "rainfallMm": int(js_round(sum(totals), 0)),
                "heavyRainDays": len([t for t in totals if t >= 25]),
                "maxDailyMm": js_round(max(totals, default=0), 1),
            })
        return out
    # Fallback: demo annual (port of historicalData.getAnnualHistory)
    tick = get_demo_tick()
    rng = create_rng((hash_seed("annual-history") ^ imul(tick + 5, 0x1B873593)) & 0xFFFFFFFF)
    current_year = datetime.now(timezone.utc).year
    out = []
    for i in range(4, -1, -1):
        year = current_year - i
        monsoon = 1680 + rng() * 760
        partial = 0.72 if i == 0 else 1
        out.append({
            "year": year,
            "rainfallMm": int(js_round(monsoon * partial, 0)),
            "heavyRainDays": int(js_round((18 + rng() * 26) * partial, 0)),
            "maxDailyMm": js_round(120 + rng() * 190, 1),
        })
    return out


def get_peak_events(location_id: str = None, limit: int = 8) -> list:
    pool = [location_id] if location_id else [loc["id"] for loc in LOCATIONS]
    events = []
    for loc_id in pool:
        daily = get_daily_history(loc_id, 365)
        top = sorted(daily, key=lambda r: r["rainfallMm"], reverse=True)[:3]
        for row in top:
            if row["rainfallMm"] < 45:
                continue
            events.append({
                "date": row["date"],
                "locationId": loc_id,
                "locationName": get_location(loc_id)["name"],
                "dailyMm": row["rainfallMm"],
                "durationH": int(js_round(
                    clamp(row["rainfallMm"] / max(1, row["peakHourMmHr"]) + 4, 4, 30), 0
                )),
                "riskLevel": classify_risk(row["riskIndex"]),
            })
    events.sort(key=lambda e: e["dailyMm"], reverse=True)
    return events[:limit]


def get_location_comparison(days: int = 90) -> list:
    out = []
    for loc in LOCATIONS:
        rows = get_daily_history(loc["id"], days)
        out.append({
            "locationId": loc["id"],
            "name": loc["name"],
            "rainfallMm": js_round(sum(r["rainfallMm"] for r in rows), 1),
            "peakMmHr": js_round(max((r["peakHourMmHr"] for r in rows), default=0), 1),
            "avgRiskIndex": js_round(
                sum(r["riskIndex"] for r in rows) / max(1, len(rows)), 1
            ),
        })
    out.sort(key=lambda x: x["rainfallMm"], reverse=True)
    return out
