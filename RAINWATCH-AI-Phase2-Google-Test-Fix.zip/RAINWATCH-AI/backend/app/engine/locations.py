"""Monitoring locations — a faithful port of
``hackathon/src/data/locationsData.ts``.

All values are the frontend's demo locations (Bhubaneswar + Cuttack +
Puri + the Ganjam / Brahmapur coast). Coordinates for the Ganjam
locations were verified against OpenStreetMap / Nominatim.
"""

LOCATIONS = [
    {"id": "patia", "name": "Patia", "zone": "Bhubaneswar (East)", "lat": 20.3546, "lng": 85.8006,
     "population": 48200, "elevationM": 45, "lowLyingPct": 24, "drainageEfficiency": 82,
     "riverProximity": 34, "vulnerability": "Moderate"},
    {"id": "chandrasekharpur", "name": "Chandrasekharpur", "zone": "Bhubaneswar (East)", "lat": 20.3024, "lng": 85.7896,
     "population": 36400, "elevationM": 42, "lowLyingPct": 31, "drainageEfficiency": 74,
     "riverProximity": 41, "vulnerability": "Moderate"},
    {"id": "nayapalli", "name": "Nayapalli", "zone": "Bhubaneswar (Central)", "lat": 20.2984, "lng": 85.8124,
     "population": 41100, "elevationM": 38, "lowLyingPct": 44, "drainageEfficiency": 66,
     "riverProximity": 52, "vulnerability": "High"},
    {"id": "khandagiri", "name": "Khandagiri", "zone": "Bhubaneswar (West)", "lat": 20.282, "lng": 85.785,
     "population": 33000, "elevationM": 44, "lowLyingPct": 27, "drainageEfficiency": 70,
     "riverProximity": 38, "vulnerability": "Moderate"},
    {"id": "old-town", "name": "Old Town", "zone": "Bhubaneswar (South)", "lat": 20.2662, "lng": 85.8418,
     "population": 52300, "elevationM": 29, "lowLyingPct": 68, "drainageEfficiency": 44,
     "riverProximity": 76, "vulnerability": "Very High"},
    {"id": "mancheswar", "name": "Mancheswar", "zone": "Bhubaneswar (Industrial)", "lat": 20.3134, "lng": 85.847,
     "population": 29400, "elevationM": 40, "lowLyingPct": 38, "drainageEfficiency": 62,
     "riverProximity": 47, "vulnerability": "High"},
    {"id": "rasulgarh", "name": "Rasulgarh", "zone": "Bhubaneswar (North-East)", "lat": 20.3326, "lng": 85.8558,
     "population": 27100, "elevationM": 36, "lowLyingPct": 47, "drainageEfficiency": 58,
     "riverProximity": 63, "vulnerability": "High"},
    {"id": "damana", "name": "Damana", "zone": "Bhubaneswar (North)", "lat": 20.3434, "lng": 85.8176,
     "population": 24200, "elevationM": 34, "lowLyingPct": 52, "drainageEfficiency": 54,
     "riverProximity": 69, "vulnerability": "High"},
    {"id": "sishupalgarh", "name": "Sishupalgarh", "zone": "Bhubaneswar (South-East)", "lat": 20.2872, "lng": 85.8546,
     "population": 31200, "elevationM": 31, "lowLyingPct": 59, "drainageEfficiency": 51,
     "riverProximity": 71, "vulnerability": "Very High"},
    {"id": "airport", "name": "Biju Patnaik Airport", "zone": "Bhubaneswar (South)", "lat": 20.244, "lng": 85.817,
     "population": 4200, "elevationM": 38, "lowLyingPct": 35, "drainageEfficiency": 75,
     "riverProximity": 55, "vulnerability": "Moderate"},
    {"id": "saheed-nagar", "name": "Saheed Nagar", "zone": "Bhubaneswar (Central)", "lat": 20.293, "lng": 85.83,
     "population": 38400, "elevationM": 37, "lowLyingPct": 42, "drainageEfficiency": 63,
     "riverProximity": 49, "vulnerability": "High"},
    {"id": "vss-nagar", "name": "VSS Nagar", "zone": "Bhubaneswar (Central)", "lat": 20.31, "lng": 85.823,
     "population": 30100, "elevationM": 41, "lowLyingPct": 33, "drainageEfficiency": 68,
     "riverProximity": 44, "vulnerability": "Moderate"},
    {"id": "cuttack", "name": "Cuttack", "zone": "Cuttack District", "lat": 20.462, "lng": 85.883,
     "population": 301200, "elevationM": 24, "lowLyingPct": 74, "drainageEfficiency": 46,
     "riverProximity": 88, "vulnerability": "Very High"},
    {"id": "puri", "name": "Puri", "zone": "Puri District", "lat": 19.8135, "lng": 85.831,
     "population": 201900, "elevationM": 8, "lowLyingPct": 61, "drainageEfficiency": 57,
     "riverProximity": 72, "vulnerability": "High"},
    # --- Brahmapur / Gopalpur coast (Ganjam district) ---
    {"id": "brahmapur", "name": "Brahmapur", "zone": "Ganjam (Brahmapur)", "regionId": "ganjam",
     "lat": 19.3098, "lng": 84.7972, "population": 356900, "elevationM": 27, "lowLyingPct": 58,
     "drainageEfficiency": 56, "riverProximity": 62, "vulnerability": "High"},
    {"id": "chhatrapur", "name": "Chhatrapur", "zone": "Ganjam (District HQ)", "regionId": "ganjam",
     "lat": 19.3562, "lng": 84.9812, "population": 62700, "elevationM": 14, "lowLyingPct": 71,
     "drainageEfficiency": 48, "riverProximity": 79, "vulnerability": "Very High"},
    {"id": "gopalpur", "name": "Gopalpur-on-Sea", "zone": "Ganjam (Coastal)", "regionId": "ganjam",
     "lat": 19.2599, "lng": 84.9052, "population": 11800, "elevationM": 6, "lowLyingPct": 64,
     "drainageEfficiency": 52, "riverProximity": 74, "vulnerability": "Very High"},
    {"id": "hinjilicut", "name": "Hinjilicut", "zone": "Ganjam (Hinjili)", "regionId": "ganjam",
     "lat": 19.4857, "lng": 84.7443, "population": 28900, "elevationM": 36, "lowLyingPct": 43,
     "drainageEfficiency": 64, "riverProximity": 41, "vulnerability": "Moderate"},
    {"id": "digapahandi", "name": "Digapahandi", "zone": "Ganjam (Inland)", "regionId": "ganjam",
     "lat": 19.3346, "lng": 84.5805, "population": 22400, "elevationM": 52, "lowLyingPct": 35,
     "drainageEfficiency": 69, "riverProximity": 33, "vulnerability": "Moderate"},
    {"id": "patrapur", "name": "Patrapur", "zone": "Ganjam (Inland SW)", "regionId": "ganjam",
     "lat": 19.1309, "lng": 84.5748, "population": 18600, "elevationM": 11, "lowLyingPct": 67,
     "drainageEfficiency": 51, "riverProximity": 81, "vulnerability": "Very High"},
    {"id": "ganjam-town", "name": "Ganjam Town", "zone": "Ganjam (Old Town)", "regionId": "ganjam",
     "lat": 19.3953, "lng": 85.0463, "population": 41200, "elevationM": 17, "lowLyingPct": 62,
     "drainageEfficiency": 54, "riverProximity": 76, "vulnerability": "High"},
]

DEFAULT_LOCATION_ID = "old-town"

_BY_ID = {loc["id"]: loc for loc in LOCATIONS}

REGIONS = [
    {"id": "bhubaneswar", "name": "Bhubaneswar Metropolitan Region, Odisha",
     "shortName": "Bhubaneswar, Odisha", "center": [20.305, 85.8255], "zoom": 12,
     "bbox": [20.23, 85.77, 20.37, 85.87]},
    {"id": "ganjam", "name": "Brahmapur – Gopalpur Coast, Ganjam, Odisha",
     "shortName": "Brahmapur / Gopalpur, Odisha", "center": [19.308, 84.811], "zoom": 11,
     "bbox": [19.1, 84.53, 19.52, 85.09]},
]

_REGION_BY_ID = {r["id"]: r for r in REGIONS}


def get_location(location_id: str) -> dict:
    return _BY_ID.get(location_id, LOCATIONS[0])


def is_known_location(location_id: str) -> bool:
    return location_id in _BY_ID


def get_region(region_id: str) -> dict:
    return _REGION_BY_ID.get(region_id, REGIONS[0])


def region_of(location) -> dict:
    loc = location if isinstance(location, dict) else get_location(location)
    return get_region(loc.get("regionId", "bhubaneswar"))


def is_ganjam(location_id: str) -> bool:
    """True when the location is in the Ganjam / Brahmapur region.

    The real Open-Meteo archive only covers Bhubaneswar, so Ganjam
    locations use the demo generator for historical data (see history.py).
    """
    return region_of(location_id)["id"] == "ganjam"
