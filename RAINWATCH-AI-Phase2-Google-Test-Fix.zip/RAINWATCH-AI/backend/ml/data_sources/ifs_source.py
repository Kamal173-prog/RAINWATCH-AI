"""ECMWF IFS / GFS historical-forecast source (v3.2, Source F).

Access: **keyless** via the Open-Meteo Historical Forecast API.
    https://open-meteo.com/en/docs/historical-forecast-api

What it provides:
- ECMWF IFS (model ``ecmwf_ifs025``, 0.25 deg, hourly) and GFS
  (model ``gfs_global``, 0.25 deg, hourly) historical forecasts.
- Variables: precipitation, CAPE, relative humidity, pressure, wind,
  temperature, cloud cover, vertical velocity (IFS only, where available).

Leakage note (critical): a historical forecast is a *forecast*, not an
observation. Each value has a forecast initialisation time (``run``) and
a lead time. For a prediction issued at time ``t`` you may only use
forecasts whose initialisation time is <= ``t``. The Open-Meteo
Historical Forecast API returns a seamless time series built from the
initial hours of each model run; the ``time`` column is the *valid*
time, not the issue time. For the v3.2 experiments we use the
0-hour-lead (analysis) values, which are available at the valid time,
and we document that explicitly. Any use of longer-lead forecasts must
record the run time and lead time and pass the availability check in
``ml/preprocessing/temporal_alignment.py``.

Availability: GFS from 2021-03-23; ECMWF IFS from 2021-01-01 (via
Open-Meteo). CAPE is populated in both (unlike ERA5 via Open-Meteo,
where CAPE was all nulls).
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

import pandas as pd
import requests

from .base_source import BaseDataSource, SourceManifest, retry_with_backoff, utcnow_iso
from ..preprocessing.quality_control import check_values
from ..preprocessing.temporal_alignment import standardise_hourly

log = logging.getLogger(__name__)

BASE_URL = "https://historical-forecast-api.open-meteo.com/v1/forecast"

# Variables requested per model. ``cape`` is the key addition over ERA5.
IFS_VARIABLES = [
    "precipitation", "cape", "relative_humidity_2m", "pressure_msl",
    "wind_speed_10m", "wind_direction_10m", "temperature_2m",
    "cloud_cover", "surface_pressure",
]
GFS_VARIABLES = IFS_VARIABLES  # same set; GFS may return nulls for some

MODELS = {
    "ecmwf_ifs025": {"label": "ECMWF IFS 0.25 deg", "variables": IFS_VARIABLES},
    "gfs_global": {"label": "GFS 0.25 deg", "variables": GFS_VARIABLES},
}


class IFSSource(BaseDataSource):
    """Open-Meteo Historical Forecast API (ECMWF IFS + GFS)."""

    SOURCE_NAME = "ifs"
    PRODUCT_NAME = "historical-forecast-api"
    PRODUCT_VERSION = "ecmwf_ifs025+gfs_global (Open-Meteo)"
    AVAILABILITY_LAG = "PT0H"  # 0-hour lead; available at the valid time
    LICENSE = "Open-Meteo (CC BY 4.0 for the API; underlying model data ECMWF/NOAA)"
    ACCESS_RESTRICTIONS = "None — keyless public API. Fair-use rate limits apply."

    def __init__(self, backend_dir: Path | None = None, model: str = "ecmwf_ifs025"):
        super().__init__(backend_dir)
        if model not in MODELS:
            raise ValueError(f"unknown IFS model {model!r}; choose from {list(MODELS)}")
        self.model = model
        self.variables = MODELS[model]["variables"]

    # ------------------------------------------------------------------
    def check_access(self) -> tuple[bool, str]:
        try:
            r = requests.get(
                BASE_URL,
                params={
                    "latitude": 20.281195, "longitude": 85.843376,
                    "start_date": "2024-07-20", "end_date": "2024-07-20",
                    "hourly": "precipitation", "models": self.model,
                },
                timeout=30,
            )
            if r.status_code == 200:
                return True, f"Open-Meteo Historical Forecast API reachable ({self.model})"
            return False, f"Open-Meteo returned HTTP {r.status_code}"
        except Exception as e:  # noqa: BLE001 — report, don't raise
            return False, f"Open-Meteo unreachable: {type(e).__name__}: {e}"

    # ------------------------------------------------------------------
    def fetch(
        self,
        start: str,
        end: str,
        bbox: Optional[tuple[float, float, float, float]] = None,
        lat: float = 20.281195,
        lon: float = 85.843376,
        chunk_days: int = 365,
    ) -> list[Path]:
        """Fetch IFS/GFS data for ``start``..``end`` (ISO dates) at a point.
        ``bbox`` is accepted for interface compatibility but this API is
        point-based; use the centre of the bbox. Downloads in
        ``chunk_days``-day chunks with retry + backoff. Returns raw JSON
        files written (skips chunks already present and valid)."""
        ok, msg = self.check_access()
        if not ok:
            log.error("IFS fetch blocked: %s", msg)
            return []
        if bbox is not None:
            min_lon, min_lat, max_lon, max_lat = bbox
            lat = (min_lat + max_lat) / 2.0
            lon = (min_lon + max_lon) / 2.0
        out: list[Path] = []
        d0 = datetime.fromisoformat(start).date()
        d1 = datetime.fromisoformat(end).date()
        cur = d0
        while cur <= d1:
            chunk_end = min(cur + timedelta(days=chunk_days - 1), d1)
            stem = f"{self.model}_{cur.isoformat()}_{chunk_end.isoformat()}"
            raw_path = self.raw_dir / f"{stem}.json"
            if raw_path.exists():
                try:
                    with open(raw_path) as f:
                        json.load(f)
                    log.info("IFS chunk exists, skipping: %s", raw_path.name)
                    out.append(raw_path)
                    cur = chunk_end + timedelta(days=1)
                    continue
                except (json.JSONDecodeError, OSError):
                    log.warning("IFS chunk corrupt, re-fetching: %s", raw_path.name)

            def _get() -> requests.Response:
                r = requests.get(
                    BASE_URL,
                    params={
                        "latitude": lat, "longitude": lon,
                        "start_date": cur.isoformat(),
                        "end_date": chunk_end.isoformat(),
                        "hourly": ",".join(self.variables),
                        "models": self.model,
                        "timezone": "UTC",
                    },
                    timeout=120,
                )
                r.raise_for_status()
                return r

            try:
                resp = retry_with_backoff(_get, description=f"IFS {self.model} {cur}..{chunk_end}")
                data = resp.json()
                with open(raw_path, "w") as f:
                    json.dump(data, f)
                log.info("IFS chunk saved: %s (%d hours)", raw_path.name,
                         len(data.get("hourly", {}).get("time", [])))
                out.append(raw_path)
            except requests.HTTPError as e:
                log.error("IFS fetch failed HTTP %s for %s..%s: %s",
                          e.response.status_code if e.response is not None else "?",
                          cur, chunk_end, e)
                # Stop on a hard failure (e.g. rate limit exhausted) rather
                # than hammering the API; partial results are returned.
                break
            cur = chunk_end + timedelta(days=1)
        return out

    # ------------------------------------------------------------------
    def process(self, raw_files: list[Path]) -> Path:
        """Convert raw IFS JSON chunks into a clean hourly UTC table."""
        frames = []
        for p in raw_files:
            with open(p) as f:
                data = json.load(f)
            hourly = data.get("hourly", {})
            times = hourly.get("time", [])
            if not times:
                log.warning("IFS raw file has no hourly data: %s", p.name)
                continue
            frame = pd.DataFrame({"timestamp": times})
            for var in self.variables:
                vals = hourly.get(var)
                if vals is not None:
                    frame[var] = vals
            # Rename to the project convention.
            rename = {
                "precipitation": "precipitation_mm",
                "cape": "cape_jkg",
                "relative_humidity_2m": "humidity_pct",
                "pressure_msl": "pressure_hpa",
                "wind_speed_10m": "wind_speed_kmh",
                "wind_direction_10m": "wind_direction_deg",
                "temperature_2m": "temperature_c",
                "cloud_cover": "cloud_cover_pct",
                "surface_pressure": "surface_pressure_hpa",
            }
            frame = frame.rename(columns={k: v for k, v in rename.items() if k in frame.columns})
            # Unit conversions: pressure_msl is hPa already; wind_speed_10m
            # is km/h in the Open-Meteo API; surface_pressure is hPa.
            frames.append(frame)
        if not frames:
            raise ValueError("IFS process: no usable raw files")
        df = pd.concat(frames, ignore_index=True)
        df = standardise_hourly(df, "timestamp")
        df, qc = check_values(df, source=f"ifs_{self.model}")
        log.info("IFS QC: %s", qc.summary())
        # Manifest.
        stem = f"{self.model}_processed"
        out_path = self.processed_dir / f"{stem}.csv"
        df.to_csv(out_path, index=False)
        manifest = SourceManifest(
            source_name=self.SOURCE_NAME,
            product_name=f"{self.PRODUCT_NAME} ({MODELS[self.model]['label']})",
            product_version=self.PRODUCT_VERSION,
            retrieval_timestamp_utc=utcnow_iso(),
            observation_start_utc=str(df["timestamp"].min()),
            observation_end_utc=str(df["timestamp"].max()),
            spatial_resolution="0.25 deg (point extraction at Bhubaneswar)",
            temporal_resolution="hourly",
            units={"precipitation_mm": "mm", "cape_jkg": "J/kg",
                   "humidity_pct": "%", "pressure_hpa": "hPa",
                   "wind_speed_kmh": "km/h", "temperature_c": "degC",
                   "cloud_cover_pct": "%"},
            license=self.LICENSE,
            access_restrictions=self.ACCESS_RESTRICTIONS,
            geographic_coverage="Point: Bhubaneswar (20.281195, 85.843376)",
            missing_data_pct=float(df.isna().mean().mean() * 100),
            n_records=len(df),
            n_files=len(raw_files),
            notes=(
                "Historical forecast, 0-hour lead (analysis) values. "
                "Valid time = issue time for these values. Longer-lead "
                "forecasts are NOT included; if added, record run time "
                "and lead time and pass the availability check."
            ),
        )
        self.write_manifest(stem, manifest)
        log.info("IFS processed: %s (%d rows)", out_path, len(df))
        return out_path
