# RAINWATCH AI v3.3 — Calibration Report

Date: 2026-11-24. Evidence: pooled out-of-sample 2024+2025 calibrated
probabilities (train-only models for 2024, deployed artifacts for
2025). 2026 was not used for any fitting or validation claim here.
Script: `ml/matched_comparison.py` (Brier, ECE, 10-bin reliability
tables), `ml/reliability_diagram.py`.
Outputs: `models/rainfall_xgb_v3_3/threshold_work/calibration.json`,
`docs/V33_CALIBRATION_DIAGRAM.html` (inline-SVG reliability diagrams,
one per event, all three versions overlaid).

## 1. Summary scores (pooled 2024+2025)

| Event | Brier v3 | Brier v3.2 | Brier v3.3 | ECE v3 | ECE v3.2 | ECE v3.3 |
|---|---|---|---|---|---|---|
| 3 h >= 10 mm | 0.0100 | 0.0097 | 0.0097 | 0.0016 | 0.0015 | 0.0016 |
| 6 h >= 10 mm | 0.0280 | 0.0276 | 0.0263 | 0.0033 | 0.0063 | 0.0074 |
| 3 h >= 5 mm | 0.0328 | 0.0299 | 0.0294 | 0.0119 | 0.0038 | 0.0036 |

All ECEs are small in absolute terms (0.0015–0.0119): the Platt
calibration (fit on 2024 validation from train-only models) keeps the
probabilities roughly honest on both years. No version is badly
miscalibrated anywhere.

## 2. Reading the scores

- **3 h >= 10 mm**: the three versions are indistinguishable on
  calibration (Brier 0.0097–0.0100, ECE ~0.0016). 99% of hours fall in
  the 0.0–0.1 bin, where all three are well calibrated (v3.3: mean
  predicted 0.009 vs observed 0.008, n = 17,234).
- **6 h >= 10 mm**: v3.3 has the best Brier (0.0263) but the worst ECE
  (0.0074); v3 has the best ECE (0.0033). Brier and ECE disagree
  because Brier also rewards ranking/sharpness. v3.3's ECE comes from
  two bins: 0.1–0.2 (predicted 0.137 vs observed 0.113, n = 1,452 —
  mild over-prediction) and 0.3–0.4 (predicted 0.343 vs observed 0.387,
  n = 142 — mild under-prediction). Neither is large enough to matter
  operationally: at the Warning threshold (0.185) the relevant region
  is the 0.1–0.3 bins, where v3.3 is within ~0.02 of the observed rate.
- **3 h >= 5 mm**: v3.3 is best on both scores (Brier 0.0294,
  ECE 0.0036); v3 is worst (ECE 0.0119), driven by under-predicting
  the base rate in the 0.0–0.1 bin (predicted 0.013 vs observed 0.023,
  n = 16,198). v3.2 over-predicts in the 0.5–0.6 bin (0.542 vs 0.422,
  n = 64); v3.3's 0.6–0.7 bin slightly under-predicts (0.650 vs 0.706,
  n = 34) — small samples, not a systematic problem.

## 3. Reliability diagrams

`docs/V33_CALIBRATION_DIAGRAM.html` shows one diagram per event with
all three versions against the perfect-calibration diagonal. Points
below the diagonal mean over-prediction in that bin; above means
under-prediction. The diagrams confirm the table: the curves hug the
diagonal in the bins that contain most hours, with deviations confined
to sparsely populated high-probability bins (n < 100).

## 4. What calibration does and does not imply

- A probability of 0.20 from v3.3 means roughly a 1-in-5 chance on
  2024+2025 evidence — the numbers shown to users are honest.
- Good calibration does NOT mean good detection: v3.3's 3 h >= 10 mm
  probabilities are well calibrated and still miss most heavy events
  (recall 0.389 at Watch). Calibration is about the honesty of the
  stated probability, not about the model's ability to separate rain
  from no-rain. That separation is PR-AUC (see V33_COMPARISON.md).
- The Platt parameters were fit on 2024 validation. They transfer to
  2025 without visible degradation (the per-year reliability is
  consistent with the pooled table), which is why the same calibration
  is used in production.

## 5. Limits

- The high-probability bins have few samples (e.g. 3 h >= 10 mm
  0.2–0.3 bin: n = 34 for v3.3), so bin-level observed rates there
  have wide uncertainty. Do not over-read single-bin deviations.
- ECE uses equal-width 0.1 bins; with 99% of hours below 0.1, ECE is
  dominated by the low bin and is insensitive to high-bin errors.
  Brier is the more informative single number here.
- Nothing in this report was fit on or validated against 2026.
