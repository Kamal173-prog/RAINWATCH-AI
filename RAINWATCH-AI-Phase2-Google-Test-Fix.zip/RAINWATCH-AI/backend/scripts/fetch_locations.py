"""Fetch ERA5 + GFS data for four additional Odisha locations (v3.3 Phase 7:
location-aware training / geographic holdouts).

Locations (distinct Odisha geography):
- Cuttack (20.46, 85.88) — coastal plain, ~25 km NE of Bhubaneswar
- Paradip (20.32, 86.62) — port on the coast, east
- Brahmapur (19.31, 84.79) — south Odisha, Ganjam (same point as the
  earlier fetch_brahmapur.py, extended to 2026)
- Sambalpur (21.47, 83.97) — western Odisha interior

Per location:
- ERA5 archive 2021-01-01..2026-11-23: core 6 variables + 7 convective
  variables (same sets as the Bhubaneswar fetches).
- GFS Historical Forecast API 2021-03-23..2026-11-23: the v3.2 9
  variables, yearly chunks, 4 s spacing.

Outputs: data/processed/locations/<slug>.csv (ERA5, UTC) and
data/processed/locations/<slug>_gfs.csv (GFS, UTC); raw JSON under
data/raw/locations/.

Usage:
    cd backend && .venv/bin/python scripts/fetch_locations.py
"""

from __future__ import annotations

import json
import logging
import sys
import time
from datetime import date, timedelta
from pathlib import Path

import pandas as pd
import requests

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from ml.data_sources.base_source import retry_with_backoff  # noqa: E402
from ml.preprocessing.temporal_alignment import standardise_hourly  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("fetch_locations")

BACKEND = Path(__file__).resolve().parent.parent
RAW_DIR = BACKEND / "data" / "raw" / "locations"
PROC_DIR = BACKEND / "data" / "processed" / "locations"
ARCHIVE_URL = "https://archive-api.open-meteo.com/v1/archive"
HIST_URL = "https://historical-forecast-api.open-meteo.com/v1/forecast"
SLEEP_S = 4

LOCATIONS = {
    "cuttack": (20.46, 85.88),
    "paradip": (20.32, 86.62),
    "brahmapur": (19.31, 84.79),
    "sambalpur": (21.47, 83.97),
}
ERA5_CORE = ["temperature_2m", "relative_humidity_2m", "precipitation",
             "wind_speed_10m", "pressure_msl", "cloud_cover"]
ERA5_CONV = ["showers", "wind_gusts_10m", "cloud_cover_low", "cloud_cover_mid",
             "cloud_cover_high", "vapour_pressure_deficit",
             "total_column_integrated_water_vapour"]
GFS_VARS = ["precipitation", "cape", "relative_humidity_2m", "pressure_msl",
            "wind_speed_10m", "wind_direction_10m", "temperature_2m",
            "cloud_cover", "surface_pressure"]
START = date(2021, 1, 1)
END = date(2026, 11, 23)
GFS_START = date(2021, 3, 23)

RENAME_ERA5 = {
    "temperature_2m": "temperature_c", "relative_humidity_2m": "humidity_pct",
    "precipitation": "precipitation_mm", "wind_speed_10m": "wind_speed_kmh",
    "pressure_msl": "pressure_hpa", "cloud_cover": "cloud_cover_pct",
    "showers": "showers_mm", "wind_gusts_10m": "wind_gusts_kmh",
    "cloud_cover_low": "cloud_cover_low_pct", "cloud_cover_mid": "cloud_cover_mid_pct",
    "cloud_cover_high": "cloud_cover_high_pct",
    "vapour_pressure_deficit": "vapour_pressure_deficit_hpa",
    "total_column_integrated_water_vapour": "tcwv_kg_m2",
}
RENAME_GFS = {
    "precipitation": "precipitation_mm", "cape": "cape_jkg",
    "relative_humidity_2m": "humidity_pct", "pressure_msl": "pressure_hpa",
    "wind_speed_10m": "wind_speed_kmh", "wind_direction_10m": "wind_direction_deg",
    "temperature_2m": "temperature_c", "cloud_cover": "cloud_cover_pct",
    "surface_pressure": "surface_pressure_hpa",
}


def _get(url: str, params: dict) -> dict:
    def _do() -> requests.Response:
        r = requests.get(url, params=params, timeout=120)
        r.raise_for_status()
        return r
    return retry_with_backoff(_do, description=f"GET {url.split('/')[2]}").json()


def _frame(data: dict, variables: list[str], rename: dict) -> pd.DataFrame:
    hourly = data.get("hourly", {})
    frame = pd.DataFrame({"timestamp": hourly.get("time", [])})
    for var in variables:
        vals = hourly.get(var)
        if vals is not None:
            frame[rename.get(var, var)] = vals
    return frame


def fetch_era5(slug: str, lat: float, lon: float) -> Path:
    out_csv = PROC_DIR / f"{slug}.csv"
    if out_csv.exists():
        log.info("%s exists, skipping ERA5 fetch", out_csv.name)
        return out_csv
    frames = []
    for variables, tag in ((ERA5_CORE, "core"), (ERA5_CONV, "conv")):
        raw_path = RAW_DIR / f"{slug}_era5_{tag}.json"
        if raw_path.exists():
            data = json.loads(raw_path.read_text())
        else:
            data = _get(ARCHIVE_URL, {
                "latitude": lat, "longitude": lon,
                "start_date": START.isoformat(), "end_date": END.isoformat(),
                "hourly": ",".join(variables), "timezone": "UTC",
            })
            raw_path.write_text(json.dumps(data))
            log.info("saved %s (%d hours)", raw_path.name,
                     len(data.get("hourly", {}).get("time", [])))
            time.sleep(SLEEP_S)
        frames.append(_frame(data, variables, RENAME_ERA5))
    df = frames[0].merge(frames[1], on="timestamp", how="outer", validate="one_to_one")
    df = standardise_hourly(df, "timestamp")
    df = df.drop_duplicates(subset=["timestamp"]).sort_values("timestamp").reset_index(drop=True)
    df.to_csv(out_csv, index=False)
    log.info("%s: %d rows, %s..%s", out_csv.name, len(df),
             df["timestamp"].min(), df["timestamp"].max())
    return out_csv


def fetch_gfs(slug: str, lat: float, lon: float) -> Path:
    out_csv = PROC_DIR / f"{slug}_gfs.csv"
    if out_csv.exists():
        log.info("%s exists, skipping GFS fetch", out_csv.name)
        return out_csv
    frames = []
    cur = GFS_START
    while cur <= END:
        chunk_end = min(date(cur.year, 12, 31), END)
        raw_path = RAW_DIR / f"{slug}_gfs_{cur.isoformat()}_{chunk_end.isoformat()}.json"
        if raw_path.exists():
            data = json.loads(raw_path.read_text())
        else:
            data = _get(HIST_URL, {
                "latitude": lat, "longitude": lon,
                "start_date": cur.isoformat(), "end_date": chunk_end.isoformat(),
                "hourly": ",".join(GFS_VARS), "models": "gfs_global", "timezone": "UTC",
            })
            raw_path.write_text(json.dumps(data))
            log.info("saved %s (%d hours)", raw_path.name,
                     len(data.get("hourly", {}).get("time", [])))
            time.sleep(SLEEP_S)
        frames.append(_frame(data, GFS_VARS, RENAME_GFS))
        cur = chunk_end + timedelta(days=1)
    df = pd.concat(frames, ignore_index=True)
    df = standardise_hourly(df, "timestamp")
    df = df.drop_duplicates(subset=["timestamp"]).sort_values("timestamp").reset_index(drop=True)
    df.to_csv(out_csv, index=False)
    log.info("%s: %d rows, %s..%s", out_csv.name, len(df),
             df["timestamp"].min(), df["timestamp"].max())
    return out_csv


def main() -> None:
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    PROC_DIR.mkdir(parents=True, exist_ok=True)
    for slug, (lat, lon) in LOCATIONS.items():
        fetch_era5(slug, lat, lon)
        fetch_gfs(slug, lat, lon)
    log.info("location fetch complete")


if __name__ == "__main__":
    main()
