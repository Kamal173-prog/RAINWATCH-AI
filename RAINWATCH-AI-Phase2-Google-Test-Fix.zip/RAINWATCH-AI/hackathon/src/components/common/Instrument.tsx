/**
 * Pure-CSS 3D radar/orbit instrument used as a visual signature on
 * the dashboard. Decorative only — aria-hidden, no interaction.
 */
export function Instrument({
  size = 128,
  label = 'Live scan',
}: {
  size?: number
  label?: string
}) {
  return (
    <div
      className="instrument-stage relative shrink-0"
      style={{ width: size, height: size }}
      aria-hidden
    >
      <div className="instrument-disc">
        <div className="instrument-sweep" />
      </div>
      <div className="instrument-orbit" />
      <div className="absolute inset-[24%] rotate-45 border border-accent/25" />
      <div className="absolute inset-[38%] border border-accent bg-accent/10" />
      <div className="absolute top-1/2 left-0 h-px w-full -translate-y-1/2 bg-accent/15" />
      <div className="absolute top-0 left-1/2 h-full w-px -translate-x-1/2 bg-accent/15" />
      <span className="mono absolute -bottom-1 left-1/2 -translate-x-1/2 bg-bg px-1.5 text-[8px] whitespace-nowrap text-accent">
        {label}
      </span>
    </div>
  )
}
