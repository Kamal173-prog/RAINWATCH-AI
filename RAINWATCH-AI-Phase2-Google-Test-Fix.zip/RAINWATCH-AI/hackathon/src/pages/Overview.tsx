import { AnimatePresence, motion } from 'framer-motion'
import {
  Activity,
  Bell,
  CalendarClock,
  ChevronRight,
  CloudRain,
  Gauge,
  MapPin,
  Radio,
  RefreshCw,
  ShieldAlert,
  ThermometerSun,
  TrendingUp,
  Waves,
} from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip as RTooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { useMemo } from 'react'
import { toast } from 'sonner'
import { RainMap } from '../components/maps/RainMap'
import { Badge, DemoBadge, RainBadge, RiskBadge, SeverityBadge, SourceMixBadge } from '../components/common/Badge'
import { Button } from '../components/common/Button'
import { ChartCard } from '../components/common/ChartCard'
import { Instrument } from '../components/common/Instrument'
import { KpiCard } from '../components/common/KpiCard'
import { PageHeader, SectionTitle } from '../components/common/PageHeader'
import { MODEL_CELL_NOTE, summarizeSources } from '../utils/source'
import { SkeletonCard, StatePanel } from '../components/common/Skeleton'
import { useAlerts } from '../context/AlertsContext'
import { useDemo } from '../context/DemoContext'
import { useSelectedLocation } from '../context/LocationContext'
import { useSettings } from '../context/SettingsContext'
import { useAsyncData } from '../hooks/useAsyncData'
import { demoApi } from '../services/dataService'
import { regionOf } from '../data/locationsData'
import {
  classifyRainfall,
  formatNumber,
  formatTime,
  relativeTime,
  RISK_COLORS,
  temperatureLabel,
} from '../utils/colors'

const conditionsLabel = (id: string) => `SECTOR ${id.replace(/-/g, ' ').toUpperCase()}`

const tooltipStyle = {
  background: 'var(--rw-card)',
  border: '1px solid var(--rw-border)',
  borderRadius: 12,
  color: 'var(--rw-ink)',
  fontSize: 12,
  boxShadow: '0 20px 50px -25px rgba(0,0,0,0.9)',
}

export function Overview() {
  const navigate = useNavigate()
  const { locationId, setLocationId } = useSelectedLocation()
  const { settings } = useSettings()
  const { activeCountValue } = useAlerts()
  const { version, refresh, refreshing } = useDemo()

  const { data, loading, error, reload } = useAsyncData(
    () => demoApi.fetchOverview(locationId, activeCountValue),
    [locationId, version, activeCountValue],
  )

  // Stage 6 — the overview bundle's forecast mixes MODEL hours 1–6 with
  // DEMO hours 7–24. Badge the mix from the per-point `source` metadata,
  // exactly like the Forecast page does; never from the model version.
  const forecastSources = useMemo(() => summarizeSources(data?.forecast ?? []), [data?.forecast])
  const modelVersions = useMemo(
    () => [...new Set((data?.forecast ?? []).filter((p) => p.source === 'model').map((p) => p.model_version).filter(Boolean))],
    [data?.forecast],
  )

  const kpis = data?.kpis

  const trendData = (data?.forecast ?? []).map((p, i) => ({
    time: formatTime(p.timestamp),
    hour: i,
    rainfall: p.rainfallMmHr,
    accumulated: p.accumulatedMm,
  }))

  const intensityData = (data?.intensity ?? []).filter((b) => b.hours > 0)

  const riskData = (data?.riskDistribution ?? []).map((r) => ({
    name: r.level,
    value: r.count,
    color: RISK_COLORS[r.level as keyof typeof RISK_COLORS] ?? '#6FD6C2',
  }))

  const activityTone = {
    info: 'bg-accent',
    warn: 'bg-warning',
    crit: 'bg-critical',
    ok: 'bg-success',
  }

  return (
    <div className="section-gap flex flex-col rainfall-bg">
      <PageHeader
        title="Weather Intelligence Overview"
        subtitle="Monitor rainfall patterns, assess flood risk, and explore potential inundation scenarios."
        meta={
          <>
            {data ? <SourceMixBadge counts={forecastSources} /> : <DemoBadge />}
            <Badge tone="info" dot>Region: {locationId.replace(/-/g, ' ')}</Badge>
            {modelVersions.length ? <Badge tone="muted">Model: {modelVersions.join(', ')}</Badge> : null}
          </>
        }
      >
        <Button
          variant="primary"
          loading={refreshing}
          icon={<RefreshCw size={14} />}
          onClick={async () => {
            await refresh()
            reload()
            toast.success('Demo data refreshed', { description: 'All metrics and overlays regenerated.' })
          }}
        >
          Refresh Demo Data
        </Button>
        <Button variant="secondary" icon={<MapPin size={14} />} onClick={() => navigate('/map')}>
          Open map
        </Button>
      </PageHeader>

      {error ? (
        <StatePanel variant="error" title="Unable to load overview" message={error} actionLabel="Retry" onAction={reload} />
      ) : null}

      {/* Single-cell origin — shown whenever the bundle forecast holds MODEL values. */}
      {forecastSources.model > 0 ? (
        <p className="rounded-xl border border-line bg-surface/60 px-4 py-2.5 text-[11px] leading-relaxed text-muted">
          <strong className="text-ink">Single grid cell: </strong>
          {MODEL_CELL_NOTE}
        </p>
      ) : null}

      {/* ---------------- Instrument status band ---------------- */}
      <div className="corner-brackets plate relative flex flex-wrap items-center gap-5 overflow-hidden border border-line bg-card p-4 sm:gap-8">
        <span className="scan-pass pointer-events-none absolute inset-x-0 top-0 h-8 bg-gradient-to-b from-transparent via-accent/10 to-transparent" aria-hidden />
        <Instrument size={104} label="Demo scan" />
        <div className="min-w-[180px] flex-1">
          <p className="mono text-[9px] text-muted">Observation node / {regionOf(locationId).shortName.toUpperCase()}</p>
          <p className="mt-1.5 text-2xl leading-none font-bold tracking-[-0.05em] text-ink">
            {kpis ? kpis.riskLevel.toUpperCase() : 'STANDBY'} <span className="text-accent">RISK</span>
          </p>
          <p className="mono mt-2 text-[10px] text-muted">
            INDEX {kpis ? kpis.floodRiskIndex.toFixed(1) : '—'} / 100 · {conditionsLabel(locationId)}
          </p>
        </div>
        <div className="hidden flex-1 grid-cols-3 gap-4 border-l border-line pl-6 md:grid">
          {[
            { k: 'RAIN RATE', v: kpis ? `${kpis.currentRainfall.toFixed(1)}` : '—', u: 'MM/HR' },
            { k: '24H TOTAL', v: kpis ? Math.round(kpis.accumulated24h).toString() : '—', u: 'MM' },
            { k: 'WARNINGS', v: kpis ? String(kpis.activeAlerts) : '—', u: 'ACTIVE' },
          ].map((s) => (
            <div key={s.k}>
              <p className="mono text-[9px] text-muted">{s.k}</p>
              <p className="num mt-1 text-xl font-bold text-ink">{s.v} <span className="mono text-[9px] font-normal text-accent">{s.u}</span></p>
            </div>
          ))}
        </div>
      </div>

      {/* ---------------- KPI grid ---------------- */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-6">
        {loading || !kpis
          ? Array.from({ length: 6 }).map((_, i) => <SkeletonCard key={i} lines={1} />)
          : (
            <>
              <KpiCard
                label="Current Rainfall"
                value={kpis.currentRainfall}
                unit="mm/hr"
                icon={CloudRain}
                tooltip="Simulated rainfall intensity for the current hour at the selected region."
                loading={loading}
                spark={data?.sparkline ?? []}
                trend={{
                  value: kpis.rainfallDelta,
                  suffix: ' mm/hr',
                  tone: kpis.rainfallDelta > 0 ? 'bad' : kpis.rainfallDelta < 0 ? 'good' : 'neutral',
                  label: 'vs previous hour',
                }}
                footnote={<RainBadge label={classifyRainfall(kpis.currentRainfall)} />}
                delay={0.02}
              />
              <KpiCard
                label="24h Accumulated"
                value={kpis.accumulated24h}
                unit="mm"
                icon={TrendingUp}
                tooltip="Total rainfall accumulated over the trailing 24 hours (demo series)."
                trend={{ value: kpis.accumulatedTrend, suffix: '%', tone: kpis.accumulatedTrend >= 0 ? 'bad' : 'good', label: 'vs prior 24h' }}
                delay={0.06}
              />
              <KpiCard
                label="Max Predicted Rainfall"
                value={kpis.maxForecast.rainfallMmHr}
                unit="mm/hr"
                icon={Gauge}
                tooltip="Highest rainfall rate in the illustrative 72-hour forecast window."
                footnote={
                  <span className="flex items-center gap-1 text-[11px] text-muted">
                    <CalendarClock size={11} aria-hidden /> Expected {formatTime(kpis.maxForecast.timestamp)}
                  </span>
                }
                delay={0.1}
              />
              <KpiCard
                label="Flood Risk Index"
                value={kpis.floodRiskIndex}
                unit="/100"
                icon={ShieldAlert}
                tooltip="Composite illustrative index derived from rainfall, terrain and drainage factors."
                footnote={<RiskBadge level={kpis.riskLevel as 'Low'} />}
                delay={0.14}
              />
              <KpiCard
                label="Vulnerable Areas"
                value={kpis.vulnerableZones}
                icon={Waves}
                tooltip="Count of sample zones whose demo risk index crosses 55/100."
                decimals={0}
                footnote={<span className="text-[11px] text-muted">zones above threshold</span>}
                delay={0.18}
              />
              <KpiCard
                label="Active Weather Alerts"
                value={kpis.activeAlerts}
                icon={Bell}
                tooltip="Active demo alerts tracked by the early-warning module."
                decimals={0}
                footnote={
                  <button type="button" onClick={() => navigate('/alerts')} className="text-[11px] font-medium text-accent hover:underline">
                    Open alert center →
                  </button>
                }
                delay={0.22}
              />
            </>
          )}
      </div>

      {/* ---------------- Map + trend ---------------- */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="min-w-0 xl:col-span-2"
        >
          <SectionTitle hint="Click a location to inspect rainfall & risk">Rainfall & Inundation Map</SectionTitle>
          <RainMap height={480} compact selectedLocationId={locationId} onSelectLocation={setLocationId} />
        </motion.div>

        <ChartCard
          title="Rainfall Trend"
          subtitle="Next 24 hours · sample forecast"
          icon={<CloudRain size={16} />}
          tooltip="Hourly rainfall intensity from the local demo forecast series."
          height={452}
          loading={loading}
          delay={0.12}
          footer="Illustrative forecast — not an operational bulletin."
        >
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={trendData} margin={{ top: 12, right: 8, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="rainFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--rw-accent)" stopOpacity={0.45} />
                  <stop offset="100%" stopColor="var(--rw-accent)" stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="var(--rw-border)" strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="time" tickLine={false} axisLine={false} interval={3} />
              <YAxis tickLine={false} axisLine={false} width={44} />
              <RTooltip contentStyle={tooltipStyle} cursor={{ stroke: 'var(--rw-accent)', strokeOpacity: 0.35 }} />
              <Area
                type="monotone"
                dataKey="rainfall"
                stroke="var(--rw-accent)"
                strokeWidth={2.2}
                fill="url(#rainFill)"
                dot={false}
                activeDot={{ r: 5, fill: 'var(--rw-accent)', stroke: 'var(--rw-card)', strokeWidth: 2 }}
                animationDuration={900}
              />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* ---------------- Distribution row ---------------- */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <ChartCard title="Rainfall Intensity Distribution" subtitle="Forecast hours by intensity class (24h)" icon={<CloudRain size={16} />} height={250} loading={loading} delay={0.04}>
          <div className="flex flex-col items-center gap-3 sm:flex-row">
            <div className="h-[180px] w-full min-w-[150px] sm:w-1/2">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={intensityData} dataKey="hours" nameKey="label" cx="50%" cy="50%" innerRadius={46} outerRadius={72} paddingAngle={3} stroke="none" animationDuration={850}>
                    {intensityData.map((b) => <Cell key={b.label} fill={b.color} />)}
                  </Pie>
                  <RTooltip contentStyle={tooltipStyle} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex-1 space-y-1.5">
              {intensityData.map((b) => (
                <div key={b.label} className="flex items-center justify-between text-[11px]">
                  <span className="flex items-center gap-2 text-muted"><span className="h-2 w-2 rounded-full" style={{ background: b.color }} />{b.label}</span>
                  <span className="num font-semibold text-ink">{b.hours} h</span>
                </div>
              ))}
              {intensityData.length === 0 ? <p className="text-xs text-muted">No significant rainfall expected.</p> : null}
            </div>
          </div>
        </ChartCard>

        <ChartCard title="Flood Risk Distribution" subtitle="Sample zones by risk classification" icon={<ShieldAlert size={16} />} height={250} loading={loading} delay={0.08}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={riskData} margin={{ top: 8, right: 8, left: -22, bottom: 0 }}>
              <CartesianGrid stroke="var(--rw-border)" strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="name" tickLine={false} axisLine={false} fontSize={10} />
              <YAxis tickLine={false} axisLine={false} width={40} allowDecimals={false} />
              <RTooltip contentStyle={tooltipStyle} cursor={{ fill: 'var(--rw-accent)', fillOpacity: 0.06 }} />
              <Bar dataKey="value" name="Zones" radius={[5, 5, 0, 0]} animationDuration={850}>
                {riskData.map((r) => <Cell key={r.name} fill={r.color} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Forecast Timeline" subtitle="Accumulated rainfall (mm) · next 24h" icon={<TrendingUp size={16} />} height={250} loading={loading} delay={0.12}>
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={trendData} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="accFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--rw-accent-2)" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="var(--rw-accent-2)" stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="var(--rw-border)" strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="time" tickLine={false} axisLine={false} interval={4} fontSize={10} />
              <YAxis tickLine={false} axisLine={false} width={44} />
              <RTooltip contentStyle={tooltipStyle} />
              <Area type="monotone" dataKey="accumulated" stroke="var(--rw-accent-2)" strokeWidth={2} fill="url(#accFill)" dot={false} animationDuration={900} />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* ---------------- Detail row ---------------- */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {/* Alerts */}
        <ChartCard
          title="Upcoming Weather Alerts"
          subtitle="Highest-severity demo alerts"
          icon={<Bell size={16} />}
          height={320}
          loading={loading}
          delay={0.04}
          actions={<Button size="sm" variant="ghost" onClick={() => navigate('/alerts')}>View all <ChevronRight size={13} /></Button>}
        >
          <div className="space-y-2">
            <AnimatePresence>
              {(data?.upcomingAlerts ?? []).map((a, i) => (
                <motion.button
                  key={a.id}
                  initial={{ opacity: 0, x: -12 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.06 }}
                  type="button"
                  onClick={() => navigate('/alerts')}
                  className="block w-full rounded-xl border border-line bg-surface/60 p-2.5 text-left transition-all hover:border-accent/40 hover:bg-surface"
                >
                  <div className="flex items-center justify-between gap-2">
                    <SeverityBadge severity={a.severity} />
                    <span className="text-[10px] text-muted">{relativeTime(a.timestamp)}</span>
                  </div>
                  <p className="mt-1.5 line-clamp-2 text-xs font-medium text-ink">{a.title}</p>
                  <p className="mt-0.5 flex items-center gap-1 text-[10px] text-muted"><MapPin size={10} /> {a.locationName}</p>
                </motion.button>
              ))}
            </AnimatePresence>
            {(data?.upcomingAlerts ?? []).length === 0 ? <p className="py-8 text-center text-xs text-muted">No active demo alerts.</p> : null}
          </div>
        </ChartCard>

        {/* Vulnerable locations */}
        <ChartCard title="Most Vulnerable Locations" subtitle="Highest illustrative risk indices" icon={<ShieldAlert size={16} />} height={320} loading={loading} delay={0.08}>
          <div className="space-y-2.5">
            {(data?.vulnerable ?? []).map((v, i) => (
              <motion.button
                key={`${v.name}-${i}`}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.05 + i * 0.05 }}
                type="button"
                onClick={() => navigate('/flood-intelligence')}
                className="block w-full text-left"
              >
                <div className="mb-1 flex items-center justify-between gap-2 text-[11px]">
                  <span className="flex min-w-0 items-center gap-1.5 truncate font-medium text-ink">
                    <span className="num text-muted">{String(i + 1).padStart(2, '0')}</span>
                    <span className="truncate">{v.name}</span>
                  </span>
                  <span className="num shrink-0 font-semibold" style={{ color: RISK_COLORS[v.level as keyof typeof RISK_COLORS] }}>{v.riskIndex}</span>
                </div>
                <div className="h-1.5 w-full overflow-hidden rounded-full bg-surface">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${v.riskIndex}%` }}
                    transition={{ duration: 0.8, delay: 0.1 + i * 0.05 }}
                    className="h-full rounded-full"
                    style={{ background: RISK_COLORS[v.level as keyof typeof RISK_COLORS] }}
                  />
                </div>
              </motion.button>
            ))}
          </div>
        </ChartCard>

        {/* Activity feed */}
        <ChartCard title="Recent Activity" subtitle="Demo data pipeline events" icon={<Activity size={16} />} height={320} loading={loading} delay={0.12}>
          <div className="relative space-y-4 before:absolute before:top-2 before:bottom-2 before:left-[5px] before:w-px before:bg-line">
            {(data?.activity ?? []).map((a, i) => (
              <motion.div key={a.id} initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.06 }} className="relative flex gap-3 pl-5">
                <span className={`absolute top-1 left-0 h-2.5 w-2.5 rounded-full border-2 border-card ${activityTone[a.tone]}`} aria-hidden />
                <div className="min-w-0">
                  <p className="text-[11px] leading-relaxed text-ink">{a.text}</p>
                  <p className="mt-0.5 text-[10px] text-muted">{relativeTime(a.time)}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </ChartCard>
      </div>

      {/* Weather snapshot strip */}
      {data ? (
        <motion.div
          initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-line bg-card p-[var(--rw-card-pad)]"
        >
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-accent/30 bg-accent/10 text-accent"><ThermometerSun size={18} /></span>
            <div>
              <p className="text-[10px] font-semibold tracking-wider text-muted uppercase">Current conditions snapshot</p>
              <p className="num text-lg font-bold text-ink">{temperatureLabel(data.weather.temperatureC, settings.units)} <span className="text-xs font-normal text-muted">· Humidity {data.weather.humidityPct}% · Wind {formatNumber(data.weather.windSpeedKmph, 1)} km/h</span></p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Badge tone="muted" dot>Visibility {data.weather.visibilityKm} km</Badge>
            <Badge tone="muted">Pressure {data.weather.pressureHpa} hPa</Badge>
            <Button size="sm" variant="outline" icon={<Radio size={13} />} onClick={() => navigate('/live-weather')}>Live weather</Button>
          </div>
        </motion.div>
      ) : null}
    </div>
  )
}
