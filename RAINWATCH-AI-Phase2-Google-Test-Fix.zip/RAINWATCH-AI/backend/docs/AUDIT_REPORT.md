# FloodGuard Odisha — Repository Audit Report (Phase 1)

**Date:** 23 November 2026
**Auditor:** Senior engineering review (AI/ML, geospatial, hydrology, full-stack)
**Scope:** `~/workspace/hackathon/` (React + Vite + TypeScript frontend) and
`~/workspace/backend/` (Python + FastAPI backend)
**Rule followed:** No application files were modified during this audit.

---

## 1. Executive summary

The application is a **well-built, working dashboard with a real historical
dataset and a fully synthetic prediction layer**. The frontend is complete
and polished. The backend is clean, modular, and correctly serves all 22
contracted endpoints. The one real dataset — the Open-Meteo ERA5 archive
for Bhubaneswar (43,824 hourly records, 2021–2025) — is correctly ingested
and powers the historical charts for Bhubaneswar-region locations.

**Nothing in the current system is a trained ML model.** Every forecast,
flood-risk score, flood depth, map polygon, weather reading and simulator
result is produced by deterministic formulas and a seeded pseudo-random
generator ported from the frontend. The API responses carry **no
source/model metadata**, so a consumer cannot tell real data from demo
data programmatically.

The upgrade path is real but bounded by the data: the archive is a **single
ERA5 grid cell** (one point, not a spatial grid), it is **80.8% dry hours**,
and it contains **no hour above 25 mm** — so heavy-rainfall classification
and state-wide generalisation are not supportable from this data alone.
The credible deliverable is a **genuine XGBoost rainfall forecaster**
trained on this archive, integrated into the existing forecast endpoint
with explicit model provenance, while flood outputs remain an honestly
labelled susceptibility index (not inundation depth).

---

## 2. Repository structure

### 2.1 Backend — `backend/` (4.0 MB total, excluding `.venv`)

| Path | Contents |
|---|---|
| `app/main.py` (304 lines) | FastAPI app, CORS, 22 routes, error handling |
| `app/schemas.py` (272 lines) | 26 Pydantic models mirroring `src/types/index.ts` |
| `app/core/config.py` | `.env` settings (PORT, HOST, CORS_ORIGINS, DATABASE_URL, BHUBANESWAR_CSV) |
| `app/engine/` (11 modules, ~1,450 lines) | Data engine ported from the frontend |
| `data/bhubaneswar_weather.csv` (1.9 MB) | Real ERA5 archive, 43,824 rows |
| `data/bhubaneswar_weather_raw.json` (2.0 MB) | Raw Open-Meteo API response (provenance) |
| `fetch_brahmapur.py` | Script to fetch the Ganjam archive (rate-limited, not yet run successfully) |
| `requirements.txt` | fastapi 0.115.6, uvicorn 0.34.0, pydantic 2.10.4, python-dotenv 1.0.1 |
| `README.md`, `.env.example`, `.gitignore` | Docs and config templates |

Notes:
- `app/routers/` exists but is **empty** — all routes live in `main.py`. Acceptable at this size, but a `routers/` split is the natural next refactor if the API grows.
- **No `.env` file exists** (only `.env.example`). The server currently runs on defaults. Works for dev; a `.env` should be created for reproducibility.
- **No test suite exists** anywhere (no `tests/` directory, no pytest/unittest files, no frontend test files). This is the single biggest engineering gap for Phase 7.
- **No database is actually used.** `DATABASE_URL` is read in config only; there is no SQLAlchemy/psycopg code, no models, no migrations. The API is stateless. Alert acknowledgement state lives in the frontend's `localStorage` only.
- A development server is currently running on port 8000 (`demoTick: 1`, dataset loaded). It is a `uvicorn` dev server, not a production deployment.

### 2.2 Frontend — `hackathon/` (React 19 + Vite 8 + TypeScript 7)

| Area | Contents |
|---|---|
| `src/pages/` (11 pages) | Landing, Overview, LiveWeather, RainfallForecast, FloodIntelligence, HistoricalAnalysis, InundationMap, Simulator, Alerts, DataSources, Settings, NotFound |
| `src/components/` | Design system (Card, Badge, KpiCard, ChartCard, Modal, etc.), layout (AppShell, Sidebar, Topbar), maps (RainMap, Leaflet) |
| `src/data/` (9 modules) | Local demo-data generators (locations, rainfall, weather, risk, history, alerts, maps, sources, settings) |
| `src/services/dataService.ts` | `demoApi` — **wired to the backend** via `VITE_API_URL` with local demo fallback (`viaApi` helper) |
| `src/types/index.ts` | 32 exported types/interfaces; the contract the backend mirrors |
| `src/context/` | AlertsContext, DemoContext, LocationContext, SettingsContext |
| `src/utils/` | `rng.ts` (seeded LCG), `colors.ts` (classify helpers), `csv.ts` |
| `docs/UI_CONTRACT.md` | Page-by-page contract; mandates `<DemoBadge />` for simulated values; forbids editing shared files and running `npm run build`/`dev` in parallel |
| `package.json` | react 19, react-leaflet 5, recharts 3, framer-motion 14, tailwind 4, lucide-react, sonner; TS 7.0.2, vite 8 |
| `.env` | `VITE_API_URL=http://localhost:8000` |

Type-check status: `tsc --noEmit` passes clean (verified 23 Nov 2026, 59 files).

---

## 3. API audit — all 22 endpoints

All 22 routes are present in `app/main.py` and were verified live on
23 Nov 2026 (all 200, plus correct 404 for unknown location and 400 for
invalid `hours`/`horizonH`). CORS allows `http://localhost:5173`.

| # | Method & path | Mirrors (`demoApi`) | Data source today |
|---|---|---|---|
| 1 | GET `/api/health` | — | Static + dataset status |
| 2 | GET `/api/locations` | `listLocations` | Static location table |
| 3 | GET `/api/weather` | `fetchWeather` | **Demo engine** |
| 4 | GET `/api/weather/current` | `fetchCurrentWeather` | **Demo engine** |
| 5 | GET `/api/forecast` | `fetchForecast` | **Demo engine** |
| 6 | GET `/api/forecast/intensity` | `fetchIntensityDistribution` | **Demo engine** |
| 7 | GET `/api/risk/records` | `fetchRiskRecords` | **Demo formula** |
| 8 | GET `/api/risk/summary` | `fetchRiskSummary` | **Demo formula** |
| 9 | GET `/api/risk/all` | `fetchAllRiskRecords` | **Demo formula** |
| 10 | GET `/api/alerts` | `fetchAlerts` | 16 hardcoded seed alerts |
| 11 | GET `/api/alerts/upcoming` | `fetchUpcomingAlerts` | 16 hardcoded seed alerts |
| 12 | GET `/api/history/daily` | `fetchDailyHistory` | **Real ERA5** (Bhubaneswar region); demo (Ganjam) |
| 13 | GET `/api/history/monthly` | `fetchMonthlyHistory` | **Real ERA5** (Bhubaneswar region); demo (Ganjam) |
| 14 | GET `/api/history/annual` | `fetchAnnualHistory` | **Real ERA5** (2021–2025) |
| 15 | GET `/api/history/peaks` | `fetchPeakEvents` | **Real ERA5** (Bhubaneswar region); demo (Ganjam) |
| 16 | GET `/api/history/comparison` | `fetchLocationComparison` | Mixed real/demo by region |
| 17 | GET `/api/map/layers` | `fetchMapLayers` | **Demo engine** (synthetic polygons) |
| 18 | GET `/api/map/regions` | `fetchRegionConditions` | **Demo engine** |
| 19 | GET `/api/data-sources` | `fetchDataSources` | Static catalogue |
| 20 | GET `/api/overview` | `fetchOverview` | **Demo engine** (+ real history where used) |
| 21 | POST `/api/simulate` | `runSimulation` | **Demo formula** |
| 22 | POST `/api/demo/refresh` | `refreshDemoData` | Demo tick bump |

**Contract risk:** None of the 22 responses carries source/model metadata
(`source`, `model`, `model_version`, `generated_at`, `is_demo`). The
frontend therefore cannot distinguish real, model, and demo values
programmatically — it relies on hardcoded `<DemoBadge />` labels. Any
Phase 5 integration **must add optional metadata fields** without renaming
or removing existing fields.

---

## 4. Data audit — the one real dataset

### 4.1 `backend/data/bhubaneswar_weather.csv`

| Property | Value |
|---|---|
| Source | Open-Meteo Historical Weather API (ERA5 reanalysis) |
| Retrieved | 23 Nov 2026 (raw JSON preserved alongside) |
| Grid cell | lat 20.281195, lng 85.843376 (API snapped from requested 20.2961, 85.8245); elevation 44 m |
| Timezone | Asia/Kolkata |
| Range | 2021-01-01T00:00 → 2025-12-31T23:00 (hourly) |
| Rows | 43,824 (header + 43,824 = 43,825 lines) |
| Columns | `timestamp, temperature_c, humidity_pct, precipitation_mm, wind_speed_kmh, pressure_hpa, cloud_cover_pct` |
| Missing values | **0 in every column** |
| Timestamp continuity | **No gaps, no duplicates, strictly ascending** (all steps exactly 3600 s) |
| Units | °C, %, mm, km/h, hPa, % — consistent with Open-Meteo |

Value ranges (all physically plausible):

| Variable | Min | Max | Mean |
|---|---|---|---|
| temperature_c | 11.4 | 42.4 | 26.9 |
| humidity_pct | 9 | 100 | 76.4 |
| precipitation_mm | 0.0 | **22.3** | 0.2 |
| wind_speed_kmh | 0.0 | 39.7 | 9.5 |
| pressure_hpa | 989.0 | 1022.2 | 1007.8 |
| cloud_cover_pct | 0 | 100 | 52.8 |

Total precipitation 2021–2025: **8,681.4 mm** (~1,736 mm/year — plausible
for Bhubaneswar).

### 4.2 Critical ML finding — the precipitation target

| Fact | Implication |
|---|---|
| **80.8% of hours are exactly 0.0 mm** (35,428 / 43,824) | Target is heavily zero-inflated. A naive regressor will learn to predict ~0. Needs a zero-aware approach (e.g. two-stage classify-then-regress, or predicting multi-hour accumulation instead of hourly). |
| **Max hourly precipitation is 22.3 mm** | The archive contains **no hour above 25 mm** and only **68 hours above 10 mm** in 5 years. |
| IMD classes in the frontend: Heavy ≥15.6, Very Heavy ≥64.5, Extremely Heavy ≥115.5 mm/hr | **Very Heavy and Extremely Heavy never occur in this data.** A classifier for those classes cannot be trained here — there are zero positive examples. Heavy (≥15.6) is barely represented. |
| ERA5 is reanalysis, not observations | ERA5 smooths convective extremes. Real station/gauge data would show higher peaks. Any "heavy rainfall" threshold work must state this. |
| Single grid cell (one point) | No spatial variation. **ConvLSTM is not supportable** — it needs gridded sequential data. State-wide generalisation is not supportable from this data. |
| 5 years | Short for climatology and for rare-event modelling. Fine for a baseline forecaster; not for extremes. |

**Bottom line:** the archive supports a credible **short-horizon rainfall
regression** (predicting mm over the next 1–6 h from recent lags and
meteorology) with honest baselines. It does **not** support heavy-event
classification at IMD thresholds, spatial modelling, or state-wide claims.

### 4.3 What data is missing

| Dataset | Status | Notes |
|---|---|---|
| Ganjam / Brahmapur archive (Open-Meteo) | **Not fetched** | Rate-limited (HTTP 429) on 23 Nov 2026 after the Bhubaneswar download. `fetch_brahmapur.py` exists; retry responsibly with backoff. |
| IMD station observations | Not available | No accessible public API found in this audit; IMD data is typically via paid/registered access. Do not claim integration. |
| Weather radar (IMD) | Not available | No public API; do not claim radar integration. |
| NWP forecast feed (live) | Not available | No live forecast API is wired. The "forecast" is currently synthetic. A live NWP feed (e.g. Open-Meteo forecast API) is a future step, not part of this archive. |
| NASA GPM IMERG | Named in spec, **not downloaded** | Would add satellite precipitation; needs investigation of access (GES DISC, Earthdata login). |
| NASA SRTM DEM | Not downloaded | Location `elevationM` values are static attributes, not a DEM. No terrain grid exists. |
| River network / watershed / soil / land-use | Not available | No shapefiles or rasters in the repo. |
| Sentinel-1 SAR flood extent | Not available | No flood-extent observations exist, so **no labelled flood data** exists for training a susceptibility classifier. |
| River level / discharge | Not available | No gauge data. |
| Real-time feed | None | Everything is either the 2021–2025 archive or synthetic. There is no live data path. |

---

## 5. What is simulated (the demo engine)

Every module in `app/engine/` except the history loader is a port of the
frontend's deterministic demo generators. All use a seeded LCG
(`rng.py`, multiplier 1664525) and closed-form formulas — **no model, no
training, no observations**.

| Module | What it does | Simulated? |
|---|---|---|
| `rng.py` | Seeded LCG + `classifyRainfall` / `classifyRisk` thresholds | Infrastructure (deterministic) |
| `demo_state.py` | Demo tick (bumped by "Refresh demo data") | Demo control |
| `locations.py` | 21 static locations + terrain attributes | Static data (not measurements) |
| `rainfall.py` | Hourly series −72h…+72h from two Gaussian storm events + sinusoidal ambient + seeded noise | **Yes — synthetic** |
| `weather.py` | Temperature/humidity/wind/pressure/visibility/cloud derived from synthetic rainfall + diurnal formula | **Yes — synthetic** |
| `risk.py` | `riskIndex = rainfall×1.35 + terrain + river − drainage + wobble`, clamped 2–99 | **Yes — hand-built formula, uncalibrated, unvalidated** |
| `history.py` | Real CSV for Bhubaneswar region; demo generator for Ganjam; demo annual fallback | **Mixed** (see §4) |
| `alerts.py` | 16 hardcoded seed alerts with fixed `hoursBack` | **Yes — static** |
| `maps.py` | Synthetic risk-zone polygons, synthetic inundation cells with synthetic depths, synthetic population density, synthetic station readings | **Yes — synthetic geometry** |
| `datasources.py` | Static catalogue; statuses mostly "Awaiting Integration" / "Not Connected" / "Demo Data" | Static |
| `simulator.py` | Deterministic what-if formula + seeded rng | **Yes — formula, not a model** |

**Highest credibility risk:** `risk.py` returns `inundationDepthM` and
`areaInundatedHa` — numbers that *look like* real flood-depth predictions
but are computed from an uncalibrated formula (`(riskIndex/100)^1.7 × 1.9 ×
terrain factor`). They must never be presented as measured or modelled
inundation. Phase 4 must relabel these as a susceptibility index and
remove/qualify depth claims unless a calibrated hydraulic model exists.

---

## 6. Frontend integration audit

- `dataService.ts` is correctly wired: `API_BASE` from `VITE_API_URL`,
  `viaApi()` tries the backend and falls back to local demo data on any
  failure. All 22 `demoApi` methods are wired (verified by grep).
- `DemoBadge` exists and is used on Alerts, DataSources,
  FloodIntelligence, HistoricalAnalysis, InundationMap, Landing, RainMap,
  Sidebar, Topbar — the UI already has the labelling pattern Phase 6 needs.
- Pages map to endpoints cleanly (Overview → `fetchOverview`;
  RainfallForecast → `fetchForecast` + `fetchIntensityDistribution`;
  FloodIntelligence → risk endpoints; HistoricalAnalysis → history
  endpoints; InundationMap → `fetchRegionConditions`; Simulator →
  `runSimulation`; Alerts → `fetchAlerts`; DataSources →
  `fetchDataSources`).
- **Gap:** because backend responses carry no provenance metadata, the
  frontend cannot switch a badge from DEMO to MODEL automatically — it
  would need either response metadata or a hardcoded assumption. Phase 5
  should add optional `source`/`model` fields.

---

## 7. Risks

| # | Risk | Severity | Mitigation |
|---|---|---|---|
| R1 | Presenting formula-derived `inundationDepthM` / `areaInundatedHa` as real flood predictions | **High** | Relabel as susceptibility index; qualify or remove depth fields; never fabricate depths. |
| R2 | Claiming state-wide generalisation from one ERA5 grid cell | **High** | Scope all model claims to "Bhubaneswar grid cell"; document the limitation prominently. |
| R3 | Heavy-rainfall classifier with ~zero positive examples (max 22.3 mm/hr) | **High** | Do not train IMD-threshold classifiers on this data. Use regression + a low, documented threshold (e.g. ≥10 mm/hr) or accumulation-based event definition, and report the class imbalance. |
| R4 | ConvLSTM / spatial modelling without gridded data | Medium | Defer ConvLSTM. Only revisit if ERA5 is fetched on a spatial grid. |
| R5 | HEC-HMS / HEC-RAS are Windows desktop tools; no terrain, boundary or calibration data exists | Medium | Do not attempt HEC in this environment. Use a data-driven susceptibility approach only where labelled data exists; otherwise keep the index and document the gap. |
| R6 | No test suite (backend or frontend) | Medium | Add pytest + endpoint regression + model inference tests in Phase 7; run after each stage. |
| R7 | Open-Meteo rate limiting (429 already observed) | Medium | Retry with exponential backoff, cache everything, never re-download the same range. |
| R8 | Breaking the 22 endpoint contracts during integration | Medium | Add only optional fields; run the 22-endpoint regression suite after every change. |
| R9 | Frontend/backend drift (UI_CONTRACT forbids editing shared files / running builds in parallel) | Low | Keep frontend edits to `dataService.ts` wiring only; verify with `tsc --noEmit` (do not run `npm run build`/`dev` here). |
| R10 | ERA5 reanalysis mistaken for station observations | Medium | Label every real-data surface as "ERA5 reanalysis" with grid coordinates; never call it "observed rainfall" without qualification. |

---

## 8. Recommended implementation sequence

Prioritised for a credible hackathon deliverable by the Thu 26 Nov finale,
with the highest-value, lowest-risk work first. **No application code is
changed in this phase (audit only).**

### Stage 1 — Data engineering (foundation, low risk)
- Retry the Ganjam/Brahmapur archive fetch **responsibly** (single attempt, exponential backoff, respect the 429).
- Reorganise `backend/data/` into `raw/` (as-downloaded), `processed/` (cleaned, tz-aware, documented), and `model_ready/` (feature/target tables). Record provenance for every file (source, retrieval time, coordinates, units, row count, quality notes).
- Add a dataset inventory + provenance document.
- Add a `.env` file (from `.env.example`) for reproducibility.
- **Exit criteria:** both archives present (or the Ganjam gap documented with a retry plan); inventory doc written; no endpoint behaviour changed.

### Stage 2 — Real rainfall ML model (the core deliverable)
- Build a reproducible feature pipeline from the Bhubaneswar archive: lagged precipitation (1/3/6/12/24 h), rolling sums, temperature, humidity, wind, pressure, cloud, hour-of-day / day-of-year / monsoon-season flags.
- Targets: rainfall accumulation over the next **1 h, 3 h and 6 h** (accumulation is more learnable than hourly given 80.8% zeros). Units: mm.
- Chronological train/validation/test split (e.g. train 2021–2023, val 2024, test 2025) — no shuffling, no leakage.
- Baselines: persistence (last observed value) and climatology (hour-of-year mean). Tune XGBoost on validation only.
- Metrics: MAE, RMSE, and heavy-event precision/recall at a **documented, data-supported threshold** (e.g. 3-h accumulation ≥ 10 mm), reported against both baselines.
- Save: trained model, feature schema, preprocessing, and a metadata JSON (model version, horizons, training range, metrics, data source). Provide `train.py`, `predict.py`, and inference tests.
- **Exit criteria:** a genuine trained XGBoost model with a holdout evaluation report that beats persistence on MAE/RMSE (or an honest report that it does not); model artifact + metadata saved; no endpoint changed yet.

### Stage 3 — Flood-risk honesty upgrade (no fabricated depths)
- Do **not** build inundation depth/extent (no DEM, no river data, no calibration observations — see R1/R5).
- Instead: (a) relabel the existing risk output as a **susceptibility index** with explicit documentation; (b) feed the **real ML rainfall forecast** into the risk formula in place of the synthetic series, so risk responds to a trained model; (c) add a `source`/`model` annotation to risk responses.
- Investigate Sentinel-1 / IMD flood reports only as a *future* labelled-data source; do not block the deliverable on it.
- **Exit criteria:** risk outputs are traceable to the ML forecast; depth fields are qualified or removed; limitation documented.

### Stage 4 — Model integration (preserve contracts)
- Load the trained model once at FastAPI startup (not per request).
- Replace demo outputs **only** where real model outputs exist (forecast endpoints first; risk second via Stage 3).
- Add **optional** response metadata (`source`, `model`, `model_version`, `generated_at`, `horizon_h`, `is_demo`) — additive only, so all 22 contracts stay compatible.
- Keep demo fallback with an explicit `is_demo: true` flag.
- Add logging and input validation around inference.
- **Exit criteria:** `/api/forecast` returns model predictions with metadata when the model is loaded, demo values with `is_demo: true` otherwise; all 22 endpoint regression tests pass.

### Stage 5 — Frontend integration (no redesign)
- Historical charts already use real data (no change needed).
- Forecast views: show a "Model" vs "Demo" badge driven by the new response metadata (use the existing `<DemoBadge />` pattern; add a model badge alongside it).
- Risk maps: label the susceptibility index honestly; do not render synthetic depths as observed flooding.
- Verify loading / empty / error states still work.
- **Exit criteria:** `tsc --noEmit` clean; the dashboard visibly distinguishes model, real, and demo values; no page redesigned.

### Stage 6 — Validation, tests & handoff
- Add pytest suite: data-pipeline tests, model inference tests, all-22-endpoint regression, chronological holdout evaluation.
- Re-run the full endpoint suite and the frontend type-check.
- Produce the Phase 8 documents: architecture diagram, data-source docs, dataset inventory/provenance, model training & evaluation report, API integration doc, updated `requirements.txt`, env-var docs, exact train/run commands, known limitations & future work.
- **Exit criteria:** backend tests pass; frontend type-check passes; docs complete; the project reproduces from documented instructions.

### Explicitly out of scope for this build
- ConvLSTM (no gridded data — R4).
- HEC-HMS / HEC-RAS hydraulic simulation (Windows desktop tools, no terrain/boundary/calibration data — R5).
- Real inundation depth/extent (no DEM, river, or calibration observations — R1).
- Live radar / IMD integration (no accessible API — §4.3).
- State-wide generalisation claims (single grid cell — R2).
- A live real-time feed (no live data path exists).

---

## 9. Audit sign-off

- **Frontend:** complete, polished, correctly wired. No redesign needed.
- **Backend:** clean, correct, all 22 contracts holding. No rewrite needed.
- **Data:** one real, clean, well-documented archive. The foundation is solid but narrow (single point, 5 years, zero-inflated, no extremes).
- **Models:** none exist yet. This is the work.
- **Biggest gap:** no tests, no response provenance, and flood-depth numbers that are formula-derived rather than modelled.

The plan in §8 is the shortest credible path to a genuine ML-powered
platform without fabricating accuracy or flood depths.
