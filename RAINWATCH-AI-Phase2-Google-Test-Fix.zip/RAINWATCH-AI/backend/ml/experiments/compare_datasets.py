"""Dataset comparison experiments for RAINWATCH AI v3.2.

Compares precipitation datasets (ERA5 vs IFS/GFS, and any other source
once available) over comparable observation periods:
- MAE, RMSE, mean bias, Pearson + Spearman correlation.
- Probability of detection (POD), false alarm ratio (FAR), critical
  success index (CSI) at the 5 mm and 10 mm (3 h) thresholds.
- Broken down by overall rainfall, wet hours, heavy rainfall, monsoon
  periods, and individual storm events.

No satellite product is treated as ground truth. ERA5 is the reference
for these comparisons (it is the training target); IMD station rainfall
is the independent verification source when available.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import spearmanr


def _pod_far_csi(y_true: np.ndarray, y_pred: np.ndarray, threshold: float) -> dict[str, float]:
    """POD / FAR / CSI for a binary event defined by ``threshold``."""
    t = y_true >= threshold
    p = y_pred >= threshold
    tp = int((t & p).sum())
    fp = int((~t & p).sum())
    fn = int((t & ~p).sum())
    pod = tp / max(1, tp + fn)
    far = fp / max(1, tp + fp)
    csi = tp / max(1, tp + fp + fn)
    return {"pod": pod, "far": far, "csi": csi, "tp": tp, "fp": fp, "fn": fn}


def compare_precipitation(
    ref: pd.Series,
    other: pd.Series,
    label: str = "other",
    heavy_threshold_3h: float = 10.0,
    moderate_threshold_3h: float = 5.0,
) -> dict:
    """Compare an hourly precipitation series ``other`` against the
    reference ``ref`` (both in mm/hr, aligned on the same index).
    Returns a dict of metrics. NaN pairs are dropped."""
    df = pd.DataFrame({"ref": ref, "other": other}).dropna()
    r = df["ref"].to_numpy()
    o = df["other"].to_numpy()
    out: dict = {
        "label": label,
        "n": len(df),
        "mae": float(np.mean(np.abs(o - r))),
        "rmse": float(np.sqrt(np.mean((o - r) ** 2))),
        "bias": float(np.mean(o - r)),
        "pearson": float(np.corrcoef(r, o)[0, 1]) if len(df) > 2 else float("nan"),
        "spearman": float(spearmanr(r, o).statistic) if len(df) > 2 else float("nan"),
    }
    # 3 h accumulations for the event metrics.
    ref3 = pd.Series(r).rolling(3, min_periods=3).sum().to_numpy()
    oth3 = pd.Series(o).rolling(3, min_periods=3).sum().to_numpy()
    mask = ~np.isnan(ref3) & ~np.isnan(oth3)
    for thr, name in ((moderate_threshold_3h, "3h_ge_5mm"),
                      (heavy_threshold_3h, "3h_ge_10mm")):
        m = _pod_far_csi(ref3[mask], oth3[mask], thr)
        out[name] = m
    # Wet hours (ref >= 0.5 mm).
    wet = r >= 0.5
    if wet.sum() > 0:
        out["wet_mae"] = float(np.mean(np.abs(o[wet] - r[wet])))
        out["wet_bias"] = float(np.mean(o[wet] - r[wet]))
    # Monsoon (Jun–Sep) vs non-monsoon.
    idx = df.index
    if isinstance(idx, pd.DatetimeIndex):
        monsoon = idx.month.isin([6, 7, 8, 9])
        if monsoon.sum() > 0:
            out["monsoon_mae"] = float(np.mean(np.abs(o[monsoon] - r[monsoon])))
        if (~monsoon).sum() > 0:
            out["non_monsoon_mae"] = float(np.mean(np.abs(o[~monsoon] - r[~monsoon])))
    return out
