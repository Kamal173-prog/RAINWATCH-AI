# RAINWATCH AI — Dataset Inventory & Provenance

## Layout

```
data/
  raw/          as-downloaded, untouched (never edit)
  processed/    cleaned, tz-aware, validated tables the API reads
  model_ready/  ML feature/target tables built by backend/ml/build_features.py
```

## Inventory

### Bhubaneswar — Open-Meteo ERA5 archive (REAL)

| Field | Value |
|---|---|
| Raw file | `raw/bhubaneswar_weather_raw.json` (2,029,253 bytes) |
| Convective raw file | `raw/bhubaneswar_convective_raw.json` (fetched 2026-11-23 evening) |
| Processed file | `processed/bhubaneswar_weather.csv` (1,941,214 bytes) |
| Source | Open-Meteo Historical Weather API (`archive-api.open-meteo.com/v1/archive`), ERA5 reanalysis |
| Retrieved | 2026-11-23 13:24 IST (base 6 variables, HTTP 200); convective columns fetched 2026-11-23 evening (HTTP 200) |
| Requested coords | lat 20.2961, lng 85.8245 (Bhubaneswar) |
| Grid cell returned | lat 20.281195, lng 85.843376; elevation 44 m (ERA5 grid snap) |
| Timezone | Asia/Kolkata |
| Range | 2021-01-01T00:00 → 2025-12-31T23:00, hourly |
| Rows | 43,824 (header + 43,824) |
| Columns | `timestamp, temperature_c, humidity_pct, precipitation_mm, wind_speed_kmh, pressure_hpa, cloud_cover_pct` + convective: `showers_mm, wind_gusts_kmh, cloud_cover_low_pct, cloud_cover_mid_pct, cloud_cover_high_pct, vapour_pressure_deficit_hpa, tcwv_kg_m2` + thermodynamic (v3, fetched 2026-11-23 evening): `cape_jkg, wind_direction_deg, dew_point_2m_c, surface_pressure_hpa` |
| Missing values | 0 in every column **except `tcwv_kg_m2`** (4,368 missing, all 2024-01-01 → 2024-07-01, a 6-month gap in the source) **and `cape_jkg`** (all 43,824 null — CAPE not populated by Open-Meteo; see CAPE note below) |
| Gaps / duplicates | None — continuous hourly, strictly ascending |
| Units | °C, %, mm, km/h, hPa, % |
| Total precip 2021–2025 | 8,681.4 mm (~1,736 mm/year) |
| Max hourly precip | 22.3 mm (no hour above 25 mm in 5 years) |
| Dry hours (0.0 mm) | 35,428 (80.8%) |
| Licence / cost | Free, no API key required (Open-Meteo) |
| Quality note | **ERA5 reanalysis, not station observations.** Modelled ~31 km grid; smooths convective extremes. Real gauge data would show higher peaks. |
| Convective data notes | `showers_mm` is **all zeros** at this grid cell (ERA5 showers not populated here) — the shower-ratio feature is therefore not used. `tcwv_kg_m2` has a 6-month gap (2024-01-01 → 2024-07-01) and is **excluded from model features** (XGBoost would drop those rows); the column is kept in the CSV for provenance. Usable convective columns: wind gusts, low/mid/high cloud cover, vapour pressure deficit. |

### Upwind spatial grids — Puri Coast & Offshore Bay of Bengal (REAL, v3)

| Field | Value |
|---|---|
| File | `processed/upwind_spatial.csv` (43,824 hourly rows, 2021–2025) |
| Raw files | `raw/puri_coast_raw.json`, `raw/offshore_bay_raw.json` |
| Source | Open-Meteo Historical Weather API, ERA5 reanalysis |
| Retrieved | 2026-11-23 evening (HTTP 200, polite 4 s spacing, no 429) |
| Puri Coast | lat 19.81, lng 85.83 (~50 km SE of Bhubaneswar, onshore) |
| Offshore Bay | lat 19.50, lng 86.30 (Bay of Bengal, upwind) |
| Columns | `coast_precip_mm, coast_pressure_hpa, coast_cape_jkg, coast_wind_speed_kmh, coast_wind_direction_deg, coast_humidity_pct, bay_precip_mm, bay_pressure_hpa, bay_cape_jkg, bay_wind_speed_kmh, bay_wind_direction_deg, bay_humidity_pct` |
| Missing values | 0 in every column **except `coast_cape_jkg` and `bay_cape_jkg`** (all 43,824 null — see CAPE note) |
| Ranges | coast precip max 31.5 mm/hr; bay precip max 45.0 mm/hr (higher than Bhubaneswar's 22.3 — more convective over the sea) |
| Quality note | ERA5 reanalysis, not station observations. |

### CAPE unavailable (documented limitation, v3)

The Open-Meteo archive API returned **`cape` as all nulls** (0 non-null out of 43,824) for all three grid cells (Bhubaneswar, Puri Coast, Offshore Bay). The variable name is recognised but the data is not populated in the archive for this region/period. The `cape_jkg`, `coast_cape_jkg` and `bay_cape_jkg` columns are therefore present in the CSVs but entirely empty. **v3 does not use CAPE.** Instead it uses surface-based instability proxies that are available: dew-point depression, moisture-flux proxy, wind-direction-derived onshore flux, and the upwind spatial gradients. Do not claim CAPE features exist.

### Brahmapur / Ganjam — Open-Meteo ERA5 archive (PENDING)

| Field | Value |
|---|---|
| Requested coords | lat 19.3098, lng 84.7972 (Brahmapur) |
| Range requested | 2021-01-01 → 2025-12-31, same 6 hourly variables |
| Status | **NOT FETCHED — rate-limited** |
| Attempts | 2026-11-23 ~13:24 IST (HTTP 429, immediately after the Bhubaneswar download); 2026-11-23 ~19:40 IST (HTTP 429 again) |
| Retry | `python fetch_brahmapur.py` — run later, once the limit clears. Saves to `raw/brahmapur_weather_raw.json` + `processed/brahmapur_weather.csv`. Do not hammer the API. |
| Impact | Ganjam-region locations use the demo generator for historical data until this archive lands. The ML rainfall model is trained on Bhubaneswar only and must not be presented as state-wide. |

## Other sources investigated (not downloaded)

| Source | Status | Reason / note |
|---|---|---|
| NASA GPM IMERG | Not downloaded | Satellite precipitation; needs Earthdata login (GES DISC). Future enhancement, not required for the Bhubaneswar baseline. |
| IMD station observations | API exists, key-gated | `api.imd.gov.in`: `/api/v1/districtrainfall` and `/api/v1/aws_data` (Odisha state ID 10) — both return "API key missing" without a key (verified 2026-11-24). Historical depth unverified. Free key needed; do not claim integration. |
| IMD weather radar | Not available | No public API. Do not claim radar integration. |
| NWP forecast feed (live) | Not wired | No live forecast API is connected. A live feed (e.g. Open-Meteo forecast API) is a future step. |
| NASA SRTM DEM | Not downloaded | Location `elevationM` values are static attributes, not a DEM. No terrain grid exists. |
| River network / watershed / soil / land-use | Not available | No shapefiles or rasters in the repo. |
| Sentinel-1 SAR flood extent | Not available | No flood-extent observations; therefore no labelled flood data for a susceptibility classifier. |
| River level / discharge | Not available | No gauge data. |

## Research data — AIKosh / government rainfall audit (2026-11-24)

Separate directory `data/research/` (raw + processed + `SOURCES.md`); **not used by
production, the API, or any model.** Full report: `backend/docs/AIKOSH_DATA_AUDIT.md`.

- **Reported Odisha hourly telemetry rainfall 2021–2025: NOT FOUND** on AIKosh
  (no hourly/telemetry/rain-gauge dataset), data.gov.in listings, or the IMD API.
  Do not assume it exists.
- **AIKosh** hosts monthly "Daily Rainfall data of [month year] from IMD (IMD GRID
  MODEL)" files (2021 Jan–Dec, 2022 Jan–Sep) — same IMD grid product, monthly
  slices — but **downloads require an AIKosh account** (sign-in gate verified).
  No "IMD Rainfall" dataset under that exact name.
- **IMD 0.25° daily gridded rainfall 1901–2025 downloaded + audited:**
  `research/raw/IMD_RF25_1901_2025_merged.nc` (365,296,737 bytes,
  SHA-256 `d102d52e…ae564c5`, CC BY 4.0, Hugging Face mirror of the official IMD
  product, Pai et al. 2014). 45,656 days, no gaps, units mm, missing as NaN.
  Six Odisha cells 2021–2025: Bhubaneswar/Cuttack/Paradip/Brahmapur/Sambalpur
  complete (0 missing); **Puri's nearest cell is ocean — 100% missing all 125
  years; nearest land cell (20.0°N, 85.75°E) is 22.6 km away.** Max daily at
  Bhubaneswar 337.0 mm on 2021-09-13 (shared across 3 cells). IMD vs ERA5
  Bhubaneswar daily r = 0.498, bias −0.2 mm/day. **File ends 2025-12-31 — it
  cannot validate the reserved 2026 period.** Daily validation only — it cannot
  validate 3 h / 6 h labels. Processed: `research/processed/odisha_imd_daily_2021_2025.csv`
  and `.nc` (Odisha bbox), audit script `research/audit_imd_daily.py`
  (separate `backend/.venv-audit`; production venv untouched).
- **Only live lead for hourly station data:** IMD API AWS/ARG endpoint (key
  needed, historical depth unverified). GPM IMERG still needs a free Earthdata
  account (best hourly satellite candidate).
- **Independent daily validation (DONE 2026-11-24):** frozen models scored
  against this IMD daily data at Bhubaneswar — see
  `backend/docs/IMD_DAILY_VALIDATION.md`. 2025: model daily MAE 4.09 mm,
  r = 0.58; Watch caught 9/9 observed days ≥ 50 mm across 2024–2025; amount
  forecasts compress extremes (never above 30.8 mm/day in 2025). Scripts:
  `ml/validate_imd_daily.py`, `data/research/check_imd_alignment.py`,
  `data/research/plot_imd_validation.py`.

## Rules

- Never edit files in `raw/`. Re-derive `processed/` from `raw/` if a fix is needed.
- Never treat reanalysis as direct station observations — label it "ERA5 reanalysis" everywhere it is surfaced.
- Never re-download a range that is already cached.
- Record source, retrieval time, coordinates, units and row count for every new dataset added here.
