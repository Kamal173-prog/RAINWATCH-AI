# NASA GPM IMERG — Phase 0 investigation (2026-11-25)

Status: **investigation DONE, verdict PROCEED WITH CONDITIONS. No service,
endpoint or UI code exists yet.** Local extraction of a real granule has
**not** run yet — see "Spike status" below. Nothing here is a claim that
satellite data is integrated.

## What was ordered

GPM IMERG Early Run, collection `GPM_3IMERGHHE_07`,
DOI 10.5067/GPM/IMERG/3B-HH-E/07, as an independent satellite-rainfall
source alongside the RAINWATCH model (v3.3) and Google Weather. Satellite
data stays completely separate: never averaged with model or Google values,
never presented as a forecast, never silently substituted for anything.

## Key finding: the old GES DISC endpoints are dead

The on-premises GES DISC endpoints (HTTPS, OPeNDAP, THREDDS, subsetter at
`*.gesdisc.eosdis.nasa.gov`) were **discontinued 30 Sep 2026** — confirmed
from NASA's own server banners. Any plan built on them fails.

**Current mechanism: Earthdata Cloud via CMR + the `earthaccess` Python
package.** Granule links are discovered via CMR at runtime, never
hand-constructed. Collection CMR concept ID: `C2723758340-GES_DISC`.
S3 prefix: `s3://gesdisc-cumulus-prod-protected/GPM_L3/GPM_3IMERGHHE.07/`.

## Auth

Free Earthdata Login account (urs.earthdata.nasa.gov), with **NASA GESDISC
DATA ARCHIVE authorised as an application**. No billing, no anonymous
access. Credentials live in `backend/.env` only
(`EARTHDATA_USERNAME`, `EARTHDATA_PASSWORD`) — never in the frontend,
logs, docs, or any ZIP.

Account created 2026-11-25: username `kamalguru`, email verified, GES DISC
application authorised. An earlier saved login (`kamal_rao`) was rejected
by Earthdata ("Invalid username or password") — that account was never
registered; do not retry it.

## Product facts (verified from CMR / NASA docs)

- Variable: `Grid/precipitation`, mm/hr. Grid 0.1° (3600×1800). Use the
  file's own `Grid/lat` / `Grid/lon` for nearest-cell lookup.
- `Grid/time` is seconds since 1980-01-06 UTC.
- 30-minute granules. Early Run latency ~4 h.
- **Live files are V07C, not V07B** (same collection/DOI). Verified from
  CMR 2026-11-25: latest granule then was
  `3B-HHR-E.MS.MRG.3IMERG.20261125-S033000-E035959.0210.V07C.HDF5`,
  starting 2026-11-25T03:30:00Z (09:00 IST), CMR size 7,182,510 bytes
  (6.85 MB).
- Missing value `_FillValue` −9999.9 — verified from a Late-run granule's
  metadata. **The Early file's own value must be asserted from the first
  downloaded Early granule, not hardcoded.**
- Accumulation = rate × 0.5 h per granule (1 h = 2, 3 h = 6, 6 h = 12,
  24 h = 48 granules). A missing granule makes the accumulation partial —
  report granulesUsed/Expected + `complete: false`, never zero-fill.
- IST = UTC+5:30 (fixed offset).
- All 21 RAINWATCH locations (lat 19.13–20.46, lng 84.57–85.88) fall
  inside the IMERG grid, each in its own 0.1° cell. The single-Bhubaneswar-
  grid-cell caveat is ML-only and does not apply here.

## Spike status (2026-11-25, updated 2026-11-26 00:30 IST)

- CMR search without login works; latest granule identified (above).
- `earthaccess` 1.0.0 + `h5py` 3.16.0 installed (spike venv only, not in
  `requirements.txt`).
- One real granule **downloaded in the browser** 2026-11-25 15:43 IST
  after sign-in + GES DISC authorisation (7,182,510 bytes per CMR).
- **Local extraction ran in VS Code on Kam's machine 2026-11-26 ~00:25 IST:
  Earthdata login OK, 3 granules found, granule
  `3B-HHR-E.MS.MRG.3IMERG.20261125-S030000-E032959.0180.V07C.HDF5`
  downloaded (7,069,601 bytes). Authentication + download VERIFIED.**
- **HDF5 inspection (real granule): `Grid/precipitation` shape
  (1, 3600, 1800), `lat` (1800,), `lon` (3600,), Units mm/hr,
  `_FillValue` −9999.9 — confirmed from the Early file itself (the
  Phase 0 "must be asserted" condition is now met).**
- **VERIFIED DIMENSION ORDER: (time, longitude, latitude).** The first
  spike script assumed (time, lat, lon) and failed with
  `IndexError: index 1102 is out of bounds for axis 0 with size 1`.
  Fixed 2026-11-26: `backend/ml/satellite_spike.py` now reads
  `DimensionNames` from the file's own metadata, refuses to extract
  unless it is exactly (time, lon, lat), and indexes
  `precip[0, lon_idx, lat_idx]` with independent nearest lat/lon
  indices. It also prints the nearest cell + haversine distance,
  granule timestamp in UTC and IST, product version + filename, and
  treats missing data separately from zero (with a 1e-3 tolerance on
  the `_FillValue` comparison, because the file stores precipitation
  as float32 while `_FillValue` may be float64: −9999.9 reads back as
  −9999.900390625 in the array).
- **The fixed script's extraction logic is verified against structural
  test files with the exact reported layout** (real value / fill value
  / wrong dimension order — all three behave correctly). **The real
  Old Town precipitation value has been extracted** — Kam ran the fixed
  spike on his machine against a real V07C granule, and the live
  verification (`backend/verify_satellite_live.py`, 2026-11-26)
  confirmed it end to end: VALID_ZERO, 0.0 mm/hr at
  2026-11-25T19:30:00Z, grid cell 20.25/85.849998. The nearest
  0.1° cell to Old Town (20.2662, 85.8418) is lat 20.25, lon 85.85,
  ~1.99 km away.
- Live verification has now passed (2026-11-26): a real NASA data
  retrieval + local extraction succeeded on Kam's machine.

## Architecture notes for Phases 1–3

- Mirror `backend/app/services/google_weather.py` conventions (lazy
  import, NotConfigured → 503 / Error → 502, cache, `get_status()`).
- A `satellite` Data Sources placeholder already exists (kind
  "Real-time observation", status "Awaiting Integration") — upgrade it to
  live-computed status like google-weather; do not duplicate it.
- There is **no "Delayed" status value** in the Data Sources schema
  (Live / Demo Data / Not Connected / Awaiting Integration / Archive /
  Error). Adding one is a schema + frontend change to decide.
- Map layer must be a **server-rendered PNG heatmap via ImageOverlay**:
  a 0.1° grid over Odisha is ~4,000+ cells, too many Leaflet DOM elements.
- Phase 4 (satellite-informed risk) is flag-gated, keeps the untouched
  baseline, and is explicitly post-finale and unvalidated by design.
