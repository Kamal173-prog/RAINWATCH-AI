# RAINWATCH AI v3.3 — Threshold Optimization Report

Date: 2026-11-24. Author: Muse (ML engineering pass).
Model: `rainfall-xgb-v3.3` (frozen; weights and features unchanged by this work).
API: v1.3.0. Production remains `rainfall-xgb-v3`; v3.3 is flag-gated, not deployed.

## 1. What was optimized

Separate Watch (elevated) and Warning (high) thresholds for each of the
three classifier events:

| Event | Watch (elevated) | Warning (high) |
|---|---|---|
| 3 h >= 10 mm | 0.070 | 0.125 |
| 6 h >= 10 mm | 0.085 | 0.185 |
| 3 h >= 5 mm | 0.125 | 0.225 |

The frozen `thresholds.json` (0.07 / 0.08; 0.08 / 0.20; 0.12 / 0.23) is
untouched as the freeze record. The operating thresholds live in
`models/rainfall_xgb_v3_3/frozen/thresholds_optimized.json` (same format),
and are hashed in `RELEASE_MANIFEST.json`.

## 2. Selection data and protocol

- Pooled out-of-sample probabilities on **2024 + 2025 only**
  (17,520 hours; 2024: 8,766; 2025: 8,754), built by
  `ml/build_threshold_probs.py`:
  - 2024: train-only models (fit on 2021–2023) scored on 2024, combined
    with each version's recorded ensemble weights and Platt calibration
    (both learned on 2024 validation from train-only models — the same
    protocol every version was built with).
  - 2025: the deployed/refit artifacts (fit on 2021–2024) scored on 2025.
- Verification: every 2025 PR-AUC reproduces the version's recorded
  number exactly (v3 0.167/0.190/0.341; v3.2 0.2228/0.2371/0.3575;
  v3.3 0.1687/0.2743/0.3915). 2024 PR-AUCs (train-only): v3
  0.0629/0.1670/0.3069; v3.2 0.0883/0.1748/0.3509; v3.3
  0.1114/0.2602/0.3589 — 2024 is a hard year for every version, hardest
  for 3 h >= 10 mm.
- **2026 was not used anywhere in this report**: not for threshold
  selection, not for calibration, not for any validation claim. The new
  thresholds were NOT re-scored on 2026, and the 2026 storm numbers
  reported earlier (v3.3 26/46 vs v3 35/46 at the old thresholds) still
  stand as measured under the old thresholds only.

## 3. Selection rules

Same rules for every version (v3.3 is the deliverable; v3.2/v3 were
optimized the same way for the matched comparison):

- Watch: maximize F2 subject to recall >= floor and precision >= 0.10.
- Warning: maximize F1 subject to recall >= floor and precision >= 0.15.
- Recall floors (v3.1 operating policy): 3 h >= 10 mm 0.25 / 0.20;
  6 h >= 10 mm 0.50 / 0.25; 3 h >= 5 mm 0.50 / 0.30.
- If no threshold satisfies a rule's constraints, the precision floor is
  relaxed first and the relaxation is recorded in
  `threshold_work/thresholds_optimized.json`.

Threshold grid: 0.01–0.60 in 0.005 steps. Full curves (every threshold)
are in `threshold_work/threshold_curves.json`.

## 4. Optimized operating points (pooled 2024+2025)

### v3.3 (the deliverable)

| Event | Level | t | P | R | F1 | F2 | FA/100 h | Storms |
|---|---|---|---|---|---|---|---|---|
| 3 h >= 10 mm | Watch | 0.070 | 0.121 | 0.389 | 0.185 | 0.270 | 3.39 | 37/69 |
| 3 h >= 10 mm | Warning | 0.125 | 0.203 | 0.216 | 0.209 | 0.213 | 1.12 | 28/69 |
| 6 h >= 10 mm | Watch | 0.085 | 0.157 | 0.723 | 0.258 | 0.420 | 14.56 | 59/104 |
| 6 h >= 10 mm | Warning | 0.185 | 0.287 | 0.372 | 0.324 | 0.351 | 4.09 | 60/104 |
| 3 h >= 5 mm | Watch | 0.125 | 0.262 | 0.686 | 0.379 | 0.518 | 10.21 | 127/176 |
| 3 h >= 5 mm | Warning | 0.225 | 0.370 | 0.487 | 0.420 | 0.458 | 5.12 | 120/176 |

Notes:
- The 3 h >= 10 mm Watch threshold did not move (0.070 = the frozen
  value): the F2 optimum on pooled 2024+2025 is the same point the
  variants phase found on 2024 alone.
- The 6 h >= 10 mm and 3 h >= 5 mm thresholds moved up (Watch 0.08→0.085
  and 0.12→0.125; Warning 0.20→0.185 and 0.23→0.225), trading a little
  recall for precision.

### v3.2 and v3 (same rules, for comparison)

| Version | Event | Watch t | Watch F2 | Warning t | Warning F1 |
|---|---|---|---|---|---|
| v3.2 | 3 h >= 10 mm | 0.060 | 0.280 | 0.080 | 0.218 |
| v3.2 | 6 h >= 10 mm | 0.075 | 0.380 | 0.165 | 0.278 |
| v3.2 | 3 h >= 5 mm | 0.090 | 0.505 | 0.165 | 0.409 |
| v3 | 3 h >= 10 mm | 0.040 | 0.254 | 0.040 | 0.161 |
| v3 | 6 h >= 10 mm | 0.075 | 0.350 | 0.150 | 0.241 |
| v3 | 3 h >= 5 mm | 0.045 | 0.434 | 0.125 | 0.310 |

v3's 3 h >= 10 mm Watch and Warning collapse to the same threshold
(0.040): no threshold satisfies its Warning rule (recall >= 0.20 AND
precision >= 0.15) on pooled 2024+2025, so the precision floor was
relaxed and the F1 optimum at P = 0.100 was taken. v3 cannot reach a
Warning operating point for this event that v3.2 and v3.3 both reach.

## 5. Trade-off tables (v3.3, pooled 2024+2025)

Recall at precision floors (best achievable recall with P >= floor):

| Event | P>=0.15 | P>=0.20 | P>=0.25 | P>=0.30 | P>=0.40 |
|---|---|---|---|---|---|
| 3 h >= 10 mm | 0.270 | 0.216 | 0.162 | 0.070 | 0.038 |
| 6 h >= 10 mm | 0.747 | 0.539 | 0.407 | 0.349 | 0.213 |
| 3 h >= 5 mm | 0.881 | 0.784 | 0.697 | 0.597 | 0.427 |

Precision at recall floors (best achievable precision with R >= floor):

| Event | R>=0.25 | R>=0.40 | R>=0.50 | R>=0.70 | R>=0.80 |
|---|---|---|---|---|---|
| 3 h >= 10 mm | 0.170 | 0.099 | 0.087 | 0.054 | 0.046 |
| 6 h >= 10 mm | 0.345 | 0.256 | 0.209 | 0.157 | 0.133 |
| 3 h >= 5 mm | 0.499 | 0.427 | 0.355 | 0.249 | 0.192 |

Unconstrained optima (v3.3): F1 at t = 0.125 / 0.185 / 0.225
(0.209 / 0.324 / 0.420); F2 at t = 0.070 / 0.085 / 0.125
(0.270 / 0.420 / 0.518); F3 at t = 0.040 / 0.080 / 0.075
(0.350 / 0.535 / 0.613). The chosen Watch points coincide with the
F2 optima and the Warning points with the F1 optima — no rule
constraint binds for v3.3 except the recall floors, which are all met
with margin except 3 h >= 10 mm Warning recall (0.216 vs floor 0.20).

## 6. Year-by-year stability at the chosen thresholds (v3.3)

| Event | Level | 2024 P / R | 2025 P / R |
|---|---|---|---|
| 3 h >= 10 mm | Watch | 0.130 / 0.367 | 0.113 / 0.414 |
| 3 h >= 10 mm | Warning | 0.187 / 0.173 | 0.217 / 0.264 |
| 6 h >= 10 mm | Watch | 0.180 / 0.664 | 0.139 / 0.791 |
| 6 h >= 10 mm | Warning | 0.309 / 0.342 | 0.269 / 0.407 |
| 3 h >= 5 mm | Watch | 0.273 / 0.666 | 0.250 / 0.710 |
| 3 h >= 5 mm | Warning | 0.383 / 0.469 | 0.357 / 0.508 |

The thresholds behave similarly in both years: precision within ~0.04
and recall within ~0.13 of each other. Contrast v3's 3 h >= 10 mm
Watch (2024 R 0.163 vs 2025 R 0.690) and v3.2's (2024 R 0.286 vs 2025
R 0.552) — v3.3's operating points are the most year-stable of the
three versions. That stability is the main thing the pooled
optimization bought: the thresholds are not tuned to one year's quirks.

## 7. What the optimization did NOT do

- It did not change the ranking: the 3 h >= 10 mm F2 (0.270) is still
  below v3.2's (0.280) and the Warning F1 (0.209) below v3.2's (0.218).
  Thresholds cannot fix a ranking gap; see V33_COMPARISON.md.
- It did not recover the 3 h >= 10 mm storm-detection gap: the Watch
  threshold is unchanged, so storm detection stays 37/69 on pooled
  2024+2025. See V33_STORM_DETECTION.md.
- It did not touch 2026, and no claim here is validated on 2026.

## 8. Reproduction

```
.venv/bin/python ml/build_threshold_probs.py   # 2024+2025 probability sets
.venv/bin/python ml/optimize_thresholds.py     # this report's numbers
```
Outputs: `models/rainfall_xgb_v3_3/threshold_work/probs_{v3,v3.2,v3.3}_*.csv`,
`thresholds_optimized.json`, `threshold_curves.json`.
