"""Freeze rainfall-v3.3 and evaluate it once on the reserved 2026 data.

Freeze decision (made on OOF + 2025 only, before touching 2026):
  The frozen v3.3 is the BASE arm -- the three-family ensemble
  (XGBoost + LightGBM + HistGradientBoosting) on the pruned 94-feature
  v33 set, with per-target ensemble weights, Platt calibration and
  F1/F2 thresholds learned on 2024 validation. It is the only config
  that passes every pre-registered gate:
    * best OOF PR-AUC of any v3.3 config on 3h>=10mm (0.1932) and
      6h>=10mm (0.3565), best-or-tied on 3h>=5mm (0.4053);
    * the alternatives that beat it on 2025 all fail a gate:
      - four-family RF (+0.033 PR-AUC on 3h>=10mm) -- block-bootstrap
        CI includes zero, and it detects significantly fewer storms
        at the F1 operating point;
      - v32+v33 stacking (0.4153 on 3h>=5mm, best of any approach) --
        fails the 2024-OOF gate on all three targets;
      - focal arm (0.1824 on 3h>=10mm) -- no OOF record, and below
        the four-family point estimate anyway.
  The frozen members are retrained on 2021-2024 (train+val) with the
  v3.1-tuned hyperparameters and base scale_pos_weight, exactly the
  _refit_arm protocol from the variants phase. The script verifies
  the frozen artifacts reproduce the variants.json 2025 numbers
  before they are used for the 2026 evaluation.

  2026 is evaluated ONCE, by backend/ml/evaluate_2026.py, after this
  freeze. Never re-freeze on 2026 results.
"""

import json
import logging
import os
import sys

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v33_common import BEST_PARAMS, make_classifier  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger("freeze_v33")

BACKEND = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.join(BACKEND, "models", "rainfall_xgb_v3_3", "frozen")
V33_DIR = os.path.join(BACKEND, "models", "rainfall_xgb_v3_3")
TARGETS = ["y_3h_ge_10mm", "y_6h_ge_10mm", "y_3h_ge_5mm"]
FAMILIES = ("xgb", "lgbm", "hgb")


def _save_member(model, family: str, target: str) -> None:
    stem = f"clf_{target.replace('y_', '')}_{family}"
    if family == "xgb":
        model.save_model(os.path.join(OUT_DIR, stem + ".json"))
    elif family == "lgbm":
        model.booster_.save_model(os.path.join(OUT_DIR, stem + ".txt"))
    else:
        joblib.dump(model, os.path.join(OUT_DIR, stem + ".pkl"))


def main() -> None:
    os.makedirs(OUT_DIR, exist_ok=True)
    variants = json.load(open(os.path.join(V33_DIR, "variants.json")))
    base = variants["arms"]["base"]
    feats = json.load(open(os.path.join(V33_DIR, "feature_schema.json")))["features"]
    assert len(feats) == 94, f"expected 94 features, got {len(feats)}"

    df = pd.read_csv(os.path.join(BACKEND, "data", "model_ready",
                                  "bhubaneswar_features_v33.csv"),
                     parse_dates=["timestamp"])
    tv = df[df["timestamp"].dt.year.isin([2021, 2022, 2023, 2024])].reset_index(drop=True)
    te25 = df[df["timestamp"].dt.year == 2025].reset_index(drop=True)
    log.info("train+val rows: %d | 2025 check rows: %d", len(tv), len(te25))

    weights_out, platt_out, thresholds_out = {}, {}, {}
    for target in TARGETS:
        X_tv = tv[feats].to_numpy(dtype=float)
        y_tv = tv[target].to_numpy().astype(int)
        pos = max(1, int(y_tv.sum()))
        neg = max(1, int((1 - y_tv).sum()))
        pw = neg / pos
        models = {}
        for fam in FAMILIES:
            m = make_classifier(fam, BEST_PARAMS[target][fam], pw)
            m.fit(X_tv, y_tv)
            models[fam] = m
            _save_member(m, fam, target)
        log.info("frozen %s (pos_weight %.1f)", target, pw)

        w = base[target]["weights"]
        pl = base[target]["platt"]
        weights_out[target] = {f: float(w[f]) for f in FAMILIES}
        platt_out[target] = {"w": float(pl["w"]), "b": float(pl["b"])}
        th = base[target]["thresholds"]
        thresholds_out[target] = {"elevated": float(th["f2"]["threshold"]),
                                  "high": float(th["f1"]["threshold"])}

        # Verification: the frozen members must reproduce the
        # variants.json 2025 PR-AUC for this target.
        X25 = te25[feats].to_numpy(dtype=float)
        y25 = te25[target].to_numpy().astype(int)
        ens = np.zeros(len(y25))
        for fam in FAMILIES:
            ens += weights_out[target][fam] * models[fam].predict_proba(X25)[:, 1]
        logit = np.log(np.clip(ens, 1e-9, 1 - 1e-9) / (1 - np.clip(ens, 1e-9, 1 - 1e-9)))
        cal = 1 / (1 + np.exp(-(platt_out[target]["w"] * logit + platt_out[target]["b"])))
        pr = float(average_precision_score(y25, cal))
        expected = float(base[target]["eval"]["pr_auc"])
        log.info("  2025 check PR-AUC %.4f (variants.json %.4f, diff %.4f)",
                 pr, expected, pr - expected)
        if abs(pr - expected) > 0.002:
            log.warning("  2025 reproduction mismatch exceeds 0.002!")

    json.dump(weights_out, open(os.path.join(OUT_DIR, "ensemble_weights.json"), "w"), indent=2)
    json.dump(platt_out, open(os.path.join(OUT_DIR, "platt.json"), "w"), indent=2)
    json.dump(thresholds_out, open(os.path.join(OUT_DIR, "thresholds.json"), "w"), indent=2)
    json.dump({"features": feats, "feature_count": len(feats)},
              open(os.path.join(OUT_DIR, "feature_schema.json"), "w"), indent=2)
    json.dump({
        "model": "rainfall-xgb-v3.3",
        "config": "base arm: three-family ensemble (xgb+lgbm+hgb), pruned 94-feature v33 set",
        "protocol": ("weights/Platt/F1-F2 thresholds learned on 2024 validation from "
                     "train-only (2021-2023) models; members refit on train+val "
                     "(2021-2024); thresholds: elevated=F2-optimal, high=F1-optimal"),
        "frozen": "2026-11-24, before any 2026 evaluation",
        "not_adopted": ("four-family RF (bootstrap CI includes zero; fewer storms "
                        "detected at F1 operating point); v32+v33 stacking (fails "
                        "2024-OOF gate); focal arm (no OOF record)"),
    }, open(os.path.join(OUT_DIR, "metadata.json"), "w"), indent=2)
    log.info("saved frozen artifacts to %s", OUT_DIR)


if __name__ == "__main__":
    main()
