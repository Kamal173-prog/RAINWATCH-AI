export function Toggle({
  checked,
  onChange,
  label,
  description,
  disabled = false,
}: {
  checked: boolean
  onChange: (v: boolean) => void
  label: string
  description?: string
  disabled?: boolean
}) {
  return (
    <div className="flex items-start justify-between gap-4">
      <div className="min-w-0">
        <p className="text-sm font-medium text-ink">{label}</p>
        {description ? <p className="mt-0.5 text-xs leading-relaxed text-muted">{description}</p> : null}
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        aria-label={label}
        disabled={disabled}
        onClick={() => onChange(!checked)}
        className={`relative mt-0.5 h-6 w-11 shrink-0 border transition-colors duration-200 disabled:opacity-40 ${
          checked ? 'border-accent bg-accent/25' : 'border-line bg-surface'
        }`}
      >
        <span className="absolute top-0 bottom-0 left-1/2 w-px bg-line/50" aria-hidden />
        <span
          className={`absolute top-[3px] h-4 w-4 transition-all duration-200 ${
            checked ? 'left-[calc(100%-19px)] bg-accent' : 'left-[3px] bg-muted'
          }`}
          aria-hidden
        />
      </button>
    </div>
  )
}
