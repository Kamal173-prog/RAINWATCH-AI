"""Train the RAINWATCH AI rainfall forecaster, v2 (rainfall-xgb-v2).

A decoupled two-stage architecture that fixes the v1 heavy-event
limitation WITHOUT distorting the regression loss:

1. Mean regressors (unchanged in role) — XGBoost regression for the
   expected accumulation over 1 / 3 / 6 h. Retrained on the enriched
   feature set; MAE/RMSE gains are preserved (verified against v1).
2. Heavy-event classifiers — one XGBClassifier per binary target
   (y_3h >= 10 mm, y_6h >= 10 mm, y_3h >= 5 mm). Class imbalance is
   handled with scale_pos_weight, shallow trees, and probability
   calibration on the 2024 validation set. Decision thresholds are tuned
   on validation only (maximising F2) and evaluated once on test.
3. P90 quantile regressors — XGBoost with ``reg:quantileerror``,
   quantile_alpha=0.90, giving a realistic upper-bound accumulation
   for 3 h and 6 h.

Protocol (no leakage)
    - Chronological split: train 2021–2023, validation 2024, test 2025.
    - Features use only data at time t or earlier; targets are strictly
      in the future (t+1 onwards).
    - Hyperparameters tuned on validation only (randomised search,
      seeded). Final models refit on train+validation and evaluated
      once on the untouched 2025 test set.

Baselines (for the mean regressors)
    - Persistence and climatology, as in v1.

Metrics
    - Mean regressors: MAE, RMSE per horizon.
    - Classifiers: PR-AUC, ROC-AUC, Precision, Recall, F1, F2, Brier.
    - Quantile regressors: P90 coverage (fraction of actual <= predicted).

Usage
    python ml/train_rainfall.py [--skip-tuning] [--out models/rainfall_xgb]

Outputs (in --out)
    xgb_1h.json / xgb_3h.json / xgb_6h.json   mean regressors (v2)
    clf_3h_10mm.json / clf_6h_10mm.json / clf_3h_5mm.json
                                              classifier boosters (XGBoost JSON)
    clf_3h_10mm_platt.json / ...              Platt calibration params (w, b)
    xgb_3h_p90.json / xgb_6h_p90.json         P90 quantile regressors
    thresholds.json                           F2-tuned decision thresholds
    feature_schema.json                       feature names + order
    metadata.json                             version, horizons, splits,
                                              data source, best params
    evaluation.json                           test metrics + baselines
"""

import argparse
import itertools
import json
import os
import random
import sys
import time
from datetime import datetime, timezone

import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    precision_score,
    recall_score,
    roc_auc_score,
)

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import features as feat  # noqa: E402

SEED = 42
MODEL_VERSION = "rainfall-xgb-v2"
HEAVY_THRESHOLD_MM_3H = 10.0

HERE = os.path.dirname(os.path.abspath(__file__))
BACKEND = os.path.dirname(HERE)
DEFAULT_OUT = os.path.join(BACKEND, "models", "rainfall_xgb")
DEFAULT_FEATURES_CSV = os.path.join(BACKEND, "data", "model_ready", "bhubaneswar_features.csv")


# ----------------------------------------------------------------------
# Baselines (mean regressors)
# ----------------------------------------------------------------------

def persistence_pred(df: pd.DataFrame, horizon: int) -> np.ndarray:
    if horizon == 1:
        return df["precip_lag1"].to_numpy(dtype=float)
    return df[f"precip_sum{horizon}h"].to_numpy(dtype=float)


def climatology_fit(train: pd.DataFrame, target: str) -> dict:
    key = train["timestamp"].dt.month.astype(str) + "-" + train["timestamp"].dt.hour.astype(str)
    return train.groupby(key)[target].mean().to_dict()


def climatology_pred(table: dict, df: pd.DataFrame, fallback: float) -> np.ndarray:
    key = df["timestamp"].dt.month.astype(str) + "-" + df["timestamp"].dt.hour.astype(str)
    return np.array([table.get(k, fallback) for k in key], dtype=float)


def mae(y: np.ndarray, p: np.ndarray) -> float:
    return float(np.mean(np.abs(y - p)))


def rmse(y: np.ndarray, p: np.ndarray) -> float:
    return float(np.sqrt(np.mean((y - p) ** 2)))


def event_metrics(y: np.ndarray, p: np.ndarray, threshold: float) -> dict:
    yt = y >= threshold
    pt = p >= threshold
    tp = int(np.sum(yt & pt))
    fp = int(np.sum(~yt & pt))
    fn = int(np.sum(yt & ~pt))
    precision = tp / (tp + fp) if (tp + fp) else 0.0
    recall = tp / (tp + fn) if (tp + fn) else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0
    return {
        "threshold_mm": threshold,
        "actual_events": int(np.sum(yt)),
        "predicted_events": int(np.sum(pt)),
        "true_positives": tp,
        "false_positives": fp,
        "false_negatives": fn,
        "precision": round(precision, 3),
        "recall": round(recall, 3),
        "f1": round(f1, 3),
    }


def f2_score(precision: float, recall: float) -> float:
    if precision + recall == 0:
        return 0.0
    return 5 * precision * recall / (4 * precision + recall)


def _logit(p: np.ndarray, eps: float = 1e-6) -> np.ndarray:
    p = np.clip(p, eps, 1 - eps)
    return np.log(p / (1 - p))


def _sigmoid(z: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-z))


def fit_platt_scaling(raw_prob_val: np.ndarray, y_val: np.ndarray) -> dict:
    """Fit Platt (sigmoid) calibration on validation probabilities.

    Fits a logistic regression on logit(raw probability) so the calibrated
    probability reflects the true event frequency. Returns {"w": ..., "b": ...}
    such that calibrated = sigmoid(w * logit(raw) + b).
    """
    lr = LogisticRegression(C=1.0, solver="lbfgs")
    lr.fit(_logit(raw_prob_val).reshape(-1, 1), y_val)
    return {"w": float(lr.coef_[0][0]), "b": float(lr.intercept_[0])}


def apply_platt(raw_prob: np.ndarray, platt: dict) -> np.ndarray:
    return _sigmoid(platt["w"] * _logit(raw_prob) + platt["b"])


# ----------------------------------------------------------------------
# Tuning helpers
# ----------------------------------------------------------------------

REG_PARAM_GRID = {
    "max_depth": [3, 4, 5, 6],
    "learning_rate": [0.03, 0.05, 0.1],
    "n_estimators": [200, 400],
    "subsample": [0.8, 0.9, 1.0],
    "colsample_bytree": [0.7, 0.9, 1.0],
    "min_child_weight": [1, 3, 5],
    "reg_lambda": [1.0, 5.0],
}

# Shallow, strongly regularised — rare positives must not be memorised.
CLF_PARAM_GRID = {
    "max_depth": [3, 4],
    "learning_rate": [0.03, 0.05, 0.1],
    "n_estimators": [100, 200],
    "subsample": [0.8, 1.0],
    "colsample_bytree": [0.8, 1.0],
    "min_child_weight": [1, 5],
    "reg_lambda": [5.0, 10.0],
}


def random_configs(grid: dict, n: int, seed: int = SEED):
    rng = random.Random(seed)
    keys = list(grid)
    combos = [dict(zip(keys, vals)) for vals in itertools.product(*[grid[k] for k in keys])]
    rng.shuffle(combos)
    return combos[:n]


# ----------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--features-csv", default=DEFAULT_FEATURES_CSV)
    ap.add_argument("--out", default=DEFAULT_OUT)
    ap.add_argument("--skip-tuning", action="store_true")
    ap.add_argument("--n-configs", type=int, default=16)
    ap.add_argument("--n-clf-configs", type=int, default=12)
    args = ap.parse_args()

    t0 = time.time()
    os.makedirs(args.out, exist_ok=True)

    df = pd.read_csv(args.features_csv, parse_dates=["timestamp"])
    train, val, test = feat.chronological_split(df)
    X_cols = feat.feature_columns_for(df)
    print(f"rows: train={len(train)} val={len(val)} test={len(test)} | features={len(X_cols)}")
    print(f"feature list saved to feature_schema.json ({len(X_cols)} features)")

    clim = {h: climatology_fit(train, f"y_{h}h") for h in feat.HORIZONS}
    clim_fallback = {h: float(train[f"y_{h}h"].mean()) for h in feat.HORIZONS}

    evaluation = {"model_version": MODEL_VERSION, "horizons": {}, "classifiers": {}, "quantile": {}}
    best_params_all = {}

    # ================================================================
    # 1. Mean regressors (retrain on enriched features, same protocol)
    # ================================================================
    for h in feat.HORIZONS:
        target = f"y_{h}h"
        ytr, yva, yte = train[target].to_numpy(), val[target].to_numpy(), test[target].to_numpy()
        Xtr, Xva, Xte = train[X_cols], val[X_cols], test[X_cols]

        if args.skip_tuning:
            best_params = {"max_depth": 5, "learning_rate": 0.05, "n_estimators": 400,
                           "subsample": 0.9, "colsample_bytree": 0.9,
                           "min_child_weight": 3, "reg_lambda": 1.0}
            best_val_mae = None
        else:
            best_params, best_val_mae = None, float("inf")
            for i, params in enumerate(random_configs(REG_PARAM_GRID, args.n_configs)):
                m = xgb.XGBRegressor(objective="reg:squarederror", random_state=SEED,
                                     n_jobs=-1, early_stopping_rounds=50, **params)
                m.fit(Xtr, ytr, eval_set=[(Xva, yva)], verbose=False)
                vmae = mae(yva, np.clip(m.predict(Xva), 0, None))
                if vmae < best_val_mae:
                    best_val_mae, best_params = vmae, params
            print(f"[reg {h}h] best val MAE={best_val_mae:.3f} params={best_params}")
        best_params_all[h] = best_params

        Xtv = pd.concat([Xtr, Xva], ignore_index=True)
        ytv = np.concatenate([ytr, yva])
        final = xgb.XGBRegressor(objective="reg:squarederror", random_state=SEED,
                                 n_jobs=-1, **best_params)
        final.fit(Xtv, ytv, verbose=False)
        final.save_model(os.path.join(args.out, f"xgb_{h}h.json"))

        pte = np.clip(final.predict(Xte), 0, None)
        block = {
            "xgboost": {"mae": round(mae(yte, pte), 3), "rmse": round(rmse(yte, pte), 3),
                        "n_test": len(yte), "actual_mean_mm": round(float(np.mean(yte)), 3),
                        "actual_max_mm": round(float(np.max(yte)), 3)},
            "persistence": {"mae": round(mae(yte, persistence_pred(test, h)), 3),
                            "rmse": round(rmse(yte, persistence_pred(test, h)), 3)},
            "climatology": {"mae": round(mae(yte, climatology_pred(clim[h], test, clim_fallback[h])), 3),
                            "rmse": round(rmse(yte, climatology_pred(clim[h], test, clim_fallback[h])), 3)},
        }
        if h == 3:
            block["xgboost"]["heavy_event"] = event_metrics(yte, pte, HEAVY_THRESHOLD_MM_3H)
        evaluation["horizons"][f"{h}h"] = block
        print(f"[reg {h}h] TEST xgboost MAE={block['xgboost']['mae']} RMSE={block['xgboost']['rmse']} | "
              f"persistence MAE={block['persistence']['mae']} | climatology MAE={block['climatology']['mae']}")

    # ================================================================
    # 2. Heavy-event classifiers
    # ================================================================
    thresholds = {}
    for target_name, (target, thr) in feat.BINARY_TARGETS.items():
        ytr = train[target_name].to_numpy()
        yva = val[target_name].to_numpy()
        yte = test[target_name].to_numpy()
        Xtr, Xva, Xte = train[X_cols], val[X_cols], test[X_cols]
        n_pos = int(np.sum(ytr == 1))
        n_neg = int(np.sum(ytr == 0))
        spw = n_neg / max(n_pos, 1)
        print(f"\n[clf {target_name}] train pos={n_pos} neg={n_neg} scale_pos_weight={spw:.1f}")

        # --- hyperparameter search on validation (PR-AUC) ---
        if args.skip_tuning:
            best_clf_params = {"max_depth": 3, "learning_rate": 0.05, "n_estimators": 200,
                               "subsample": 0.8, "colsample_bytree": 0.8,
                               "min_child_weight": 5, "reg_lambda": 10.0}
        else:
            best_clf_params, best_pr = None, -1.0
            for i, params in enumerate(random_configs(CLF_PARAM_GRID, args.n_clf_configs)):
                m = xgb.XGBClassifier(objective="binary:logistic", random_state=SEED,
                                      n_jobs=-1, early_stopping_rounds=50,
                                      scale_pos_weight=spw, **params)
                m.fit(Xtr, ytr, eval_set=[(Xva, yva)], verbose=False)
                pr = average_precision_score(yva, m.predict_proba(Xva)[:, 1])
                if pr > best_pr:
                    best_pr, best_clf_params = pr, params
            print(f"[clf {target_name}] best val PR-AUC={best_pr:.3f} params={best_clf_params}")

        # --- train best on train, calibrate on validation (Platt/sigmoid) ---
        # CalibratedClassifierCV's cv="prefit" was removed in sklearn 1.8+,
        # so Platt scaling is done manually: a logistic regression on
        # logit(raw probability), fitted on the 2024 validation set.
        base = xgb.XGBClassifier(objective="binary:logistic", random_state=SEED,
                                 n_jobs=-1, scale_pos_weight=spw, **best_clf_params)
        base.fit(Xtr, ytr, verbose=False)
        p_raw_va = base.predict_proba(Xva)[:, 1]
        platt = fit_platt_scaling(p_raw_va, yva)
        # Save the base booster (XGBoost JSON) + Platt params (JSON).
        # At inference: raw prob -> calibrated = sigmoid(w*logit(raw) + b).
        base.save_model(os.path.join(args.out, f"clf_{target_name[2:]}.json"))
        with open(os.path.join(args.out, f"clf_{target_name[2:]}_platt.json"), "w") as f:
            json.dump(platt, f, indent=2)
        pva = apply_platt(p_raw_va, platt)

        # --- threshold tuning on validation only (maximise F2) ---
        # pva is the calibrated validation probability (from Platt above).
        best_thr, best_f2 = 0.5, -1.0
        for thr_cand in np.arange(0.05, 0.96, 0.01):
            pred = (pva >= thr_cand).astype(int)
            p_ = precision_score(yva, pred, zero_division=0)
            r_ = recall_score(yva, pred, zero_division=0)
            f2 = f2_score(p_, r_)
            if f2 > best_f2:
                best_f2, best_thr = f2, float(thr_cand)
        thresholds[target_name] = best_thr
        print(f"[clf {target_name}] F2-tuned threshold={best_thr:.2f} (val F2={best_f2:.3f})")

        # --- evaluate once on the untouched 2025 test set ---
        p_raw_te = base.predict_proba(Xte)[:, 1]
        pte = apply_platt(p_raw_te, platt)
        pred_te = (pte >= best_thr).astype(int)
        prec = precision_score(yte, pred_te, zero_division=0)
        rec = recall_score(yte, pred_te, zero_division=0)
        f1 = 2 * prec * rec / (prec + rec) if (prec + rec) else 0.0
        ev = {
            "target": f"{target} >= {thr} mm",
            "threshold": best_thr,
            "test_positives": int(np.sum(yte == 1)),
            "test_predicted_positives": int(np.sum(pred_te == 1)),
            "true_positives": int(np.sum((yte == 1) & (pred_te == 1))),
            "precision": round(float(prec), 3),
            "recall": round(float(rec), 3),
            "f1": round(float(f1), 3),
            "f2": round(float(f2_score(prec, rec)), 3),
            "pr_auc": round(float(average_precision_score(yte, pte)), 3),
            "roc_auc": round(float(roc_auc_score(yte, pte)), 3),
            "brier": round(float(brier_score_loss(yte, pte)), 4),
            "scale_pos_weight": round(float(spw), 1),
            "best_params": best_clf_params,
            "calibration": "sigmoid (Platt) on 2024 validation",
        }
        evaluation["classifiers"][target_name] = ev
        print(f"[clf {target_name}] TEST P={ev['precision']} R={ev['recall']} F1={ev['f1']} "
              f"F2={ev['f2']} PR-AUC={ev['pr_auc']} ROC-AUC={ev['roc_auc']} Brier={ev['brier']} "
              f"(caught {ev['true_positives']}/{ev['test_positives']})")

    # ================================================================
    # 3. P90 quantile regressors (upper-bound envelope)
    # ================================================================
    for h in (3, 6):
        target = f"y_{h}h"
        ytr = train[target].to_numpy()
        yva = val[target].to_numpy()
        yte = test[target].to_numpy()
        Xtr, Xva, Xte = train[X_cols], val[X_cols], test[X_cols]
        params = best_params_all[h]
        Xtv = pd.concat([Xtr, Xva], ignore_index=True)
        ytv = np.concatenate([ytr, yva])
        q = xgb.XGBRegressor(objective="reg:quantileerror", quantile_alpha=0.90,
                             random_state=SEED, n_jobs=-1, **params)
        q.fit(Xtv, ytv, verbose=False)
        q.save_model(os.path.join(args.out, f"xgb_{h}h_p90.json"))
        pte = np.clip(q.predict(Xte), 0, None)
        coverage = float(np.mean(yte <= pte))
        evaluation["quantile"][f"{h}h"] = {
            "quantile_alpha": 0.90,
            "coverage": round(coverage, 3),
            "mean_predicted_p90_mm": round(float(np.mean(pte)), 2),
            "mean_actual_mm": round(float(np.mean(yte)), 3),
            "mae_vs_actual": round(mae(yte, pte), 3),
        }
        print(f"[p90 {h}h] TEST coverage={coverage:.3f} (target 0.90) mean P90={np.mean(pte):.2f}mm")

    # ================================================================
    # 4. Artifacts
    # ================================================================
    with open(os.path.join(args.out, "feature_schema.json"), "w") as f:
        json.dump({"features": X_cols, "targets": feat.TARGET_COLUMNS,
                   "binary_targets": list(feat.BINARY_TARGETS),
                   "horizons_h": list(feat.HORIZONS),
                   "heavy_event_threshold_mm_3h": HEAVY_THRESHOLD_MM_3H}, f, indent=2)
    with open(os.path.join(args.out, "thresholds.json"), "w") as f:
        json.dump(thresholds, f, indent=2)

    metadata = {
        "model_version": MODEL_VERSION,
        "model": "XGBoost two-stage: mean regressors + heavy-event classifiers + P90 quantile regressors",
        "trained_at_utc": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "data_source": "Open-Meteo ERA5 archive, Bhubaneswar grid cell "
                       "(lat 20.281195, lng 85.843376), hourly 2021-01-01 to 2025-12-31, "
                       "plus convective columns (wind gusts, low/mid/high cloud, VPD) fetched 2026-11-23",
        "data_note": "ERA5 reanalysis, not station observations. Single grid cell; "
                     "do not present as state-wide. showers column is all zeros at this "
                     "grid cell and TCWV has a 6-month gap (2024-01-01 to 2024-07-01); "
                     "neither is used as a feature.",
        "features_csv": os.path.basename(args.features_csv),
        "n_features": len(X_cols),
        "split": {"train": "2021-01-01 to 2023-12-31",
                  "validation": "2024-01-01 to 2024-12-31",
                  "test": "2025-01-01 to 2025-12-31 (untouched until final evaluation)"},
        "best_params_regressors": {f"{h}h": best_params_all[h] for h in feat.HORIZONS},
        "seed": SEED,
        "notes": "Mean regressors predict expected accumulation. Classifiers give "
                 "heavy-event probabilities (calibrated on 2024 validation); decision "
                 "thresholds maximise F2 on validation. P90 regressors give an upper "
                 "envelope, not a point forecast. Targets are future accumulation "
                 "(t+1 onwards); features use only data at time t or earlier.",
    }
    with open(os.path.join(args.out, "metadata.json"), "w") as f:
        json.dump(metadata, f, indent=2)
    with open(os.path.join(args.out, "evaluation.json"), "w") as f:
        json.dump(evaluation, f, indent=2)

    print(f"\nDone in {time.time() - t0:.1f}s. Artifacts in {args.out}/")
    print("Files:", sorted(os.listdir(args.out)))


if __name__ == "__main__":
    main()
