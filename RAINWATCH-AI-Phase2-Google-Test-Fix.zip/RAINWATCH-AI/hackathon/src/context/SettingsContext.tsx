import { createContext, useCallback, useContext, useMemo, type ReactNode } from 'react'
import { useLocalStorage } from '../hooks/useLocalStorage'
import { useDocumentTheme } from '../hooks/useUi'
import { ACCENT_OPTIONS, DEFAULT_SETTINGS, getAccent } from '../data/settingsData'
import type { AppSettings } from '../types'

interface SettingsContextValue {
  settings: AppSettings
  update: (patch: Partial<AppSettings>) => void
  reset: () => void
  clearPreferences: () => void
  accent: ReturnType<typeof getAccent>
}

const SettingsContext = createContext<SettingsContextValue | null>(null)

const STORAGE_KEY = 'rainwatch.settings.v2'

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useLocalStorage<AppSettings>(STORAGE_KEY, DEFAULT_SETTINGS)
  const accent = getAccent(settings.accent)

  useDocumentTheme(
    settings.theme,
    accent.primary,
    accent.secondary,
    accent.onLight,
    accent.onLightSecondary,
    settings.density,
  )

  const update = useCallback(
    (patch: Partial<AppSettings>) => setSettings((prev) => ({ ...prev, ...patch })),
    [setSettings],
  )

  const reset = useCallback(() => setSettings({ ...DEFAULT_SETTINGS }), [setSettings])

  const clearPreferences = useCallback(() => {
    try {
      window.localStorage.removeItem(STORAGE_KEY)
    } catch {
      /* ignore */
    }
    setSettings({ ...DEFAULT_SETTINGS })
  }, [setSettings])

  const value = useMemo<SettingsContextValue>(
    () => ({ settings, update, reset, clearPreferences, accent }),
    [settings, update, reset, clearPreferences, accent],
  )

  return <SettingsContext.Provider value={value}>{children}</SettingsContext.Provider>
}

export function useSettings(): SettingsContextValue {
  const ctx = useContext(SettingsContext)
  if (!ctx) throw new Error('useSettings must be used inside <SettingsProvider>')
  return ctx
}

export { ACCENT_OPTIONS }
