# v3.1 External-Data Investigation — Radar, Satellite, Higher-Resolution NWP

Date: 2026-11-23. Investigator: Muse. Purpose: check whether reliable
historical radar, satellite or higher-resolution NWP inputs exist that
could improve the RAINWATCH AI heavy-rain classifier, and verify temporal
and spatial alignment before any use. **No data was fabricated and no
external dataset was integrated into v3.1** — the conclusion is that none
of the candidates is usable for the 2021–2025 training period without
additional credentials or with acceptable alignment.

## 1. IMD radar

- **Status: not publicly available.** IMD publishes APIs at
  `api.imd.gov.in` but access requires contacting the nodal officer
  (Dr Sankar Nath, IMD New Delhi) and agreeing to IMD's terms. There is
  no public historical radar download and no keyless API.
- **Verdict: not usable.** Do not pursue unless Kam obtains IMD access
  through an institutional channel.

## 2. NASA GPM IMERG (satellite precipitation)

- **What it is:** Integrated Multi-satellitE Retrievals for GPM.
  Half-hourly, ~10 km resolution, 2000–present. The Final Run product
  incorporates monthly gauge data; the Early/Late runs are near-real-time.
- **Access:** requires a **free NASA Earthdata account** plus authorisation
  of the GES DISC application. The `imergpy` Python package can download
  point time series once credentials exist.
- **Temporal alignment:** IMERG covers 2021–2025 at half-hourly
  resolution, so it aligns with the hourly training windows (aggregate
  two half-hourly values per hour). No temporal gap.
- **Spatial alignment:** ~10 km resolution is finer than ERA5 (~31 km)
  and finer than the upwind grids. A point extraction at Bhubaneswar
  (20.28, 85.84) is straightforward.
- **Verdict: usable in principle, blocked on credentials.** Kam would
  need to create a NASA Earthdata account, authorise GES DISC, and
  provide the credentials (or download the point series himself). IMERG
  is the strongest satellite candidate for a future v3.2: it is a
  satellite *observation* (not a reanalysis), so it could provide a
  better precipitation target and additional features. **Not integrated
  into v3.1 because no credentials were available.**

## 3. IMDAA (Indian Monsoon Data Assimilation and Analysis)

- **What it is:** NCMRWF / IMD / UK Met Office regional reanalysis.
  12 km horizontal, hourly, 4D-Var assimilation, Unified Model.
  The highest-resolution reanalysis for the Indian monsoon region.
- **Temporal alignment: FAILS.** IMDAA covers **1979–2020** (extended to
  2020). The RAINWATCH training period is **2021–2025**. There is no
  overlap. The Hugging Face mirror (`parthawrk/as-dataset`, ~100 GB)
  and the ML-ready subset (`tungnd/IndiaWeatherBench`, 6-hourly,
  2000–2019) are likewise pre-2021.
- **Verdict: not usable for v3.1.** The temporal misalignment is
  fatal — a feature that does not exist for the training years cannot
  be used. Do not attempt to use IMDAA for 2021–2025.

## 4. Open-Meteo Historical Forecast API (GFS / ICON) — tested live

- **What it is:** archives the initial hours of each NWP model update
  into a seamless time series. GFS (NOAA, 0.11° ≈ 13 km, hourly,
  available since 2021-03-23) and ICON (DWD, 0.10° ≈ 11 km, hourly,
  available since 2022-11-24). Keyless, free for non-commercial use.
- **Test performed (2026-11-23):** fetched GFS for Bhubaneswar
  (20.281195, 85.843376) for 2024-01-01 → 2024-12-31 (8,784 hours),
  variables precipitation, CAPE, temperature, humidity, wind speed /
  direction, pressure, cloud cover. All 8,784 rows returned, zero nulls.
- **CAPE is populated** (unlike ERA5 via Open-Meteo, where CAPE was all
  nulls). 2024 CAPE: mean 642 J/kg, max 3,880 J/kg, P99 3,030 J/kg.
- **Temporal alignment: partial.** GFS is available only from
  **2021-03-23**, so 2021-01-01 → 2021-03-22 has no GFS data (the API
  returns rows but CAPE is all null for that range). A GFS feature would
  be missing for the first ~2.7 months of the training period.
- **Quality check (2024, against ERA5):**
  - Correlation ERA5 precip vs GFS precip: **0.107 hourly, 0.194 for
    3 h sums** — very low. The two products disagree substantially.
  - GFS max hourly precip 55.0 mm vs ERA5 max 15.3 mm (2024). GFS
    produces far more extreme values.
  - On ERA5 3 h ≥ 10 mm hours (98 hours in 2024), mean GFS 3 h precip
    is 2.08 mm vs 0.35 mm on non-heavy hours — a signal (6×), but the
    absolute values are far below the heavy threshold.
  - CAPE on heavy hours: mean 710 J/kg vs 642 J/kg on non-heavy hours
    — only a **10% difference**, a weak discriminative signal.
- **Verdict: available but NOT integrated into v3.1.** The evidence does
  not support GFS as a clear improvement: the precipitation correlation
  with ERA5 is low (0.11), the CAPE heavy-event signal is weak, and the
  Jan–Mar 2021 gap complicates the training set. GFS remains a candidate
  for a future controlled test (add GFS CAPE + GFS precip as features,
  measure CV PR-AUC), but it was not added on the basis of this
  investigation alone. **No GFS data was used in v3.1 training.**

## 5. IMD gridded daily rainfall (0.25°, 1901–present)

- **What it is:** IMD daily gridded rainfall, available via the
  `imddaily` Python package, the `imdR` R package, and a Hugging Face
  mirror. 0.25° resolution, daily totals.
- **Temporal alignment: FAILS for hourly features.** The data is daily,
  not hourly. It cannot be aligned to the 1 h / 3 h / 6 h forecast
  windows. It could validate daily totals, but it cannot provide hourly
  heavy-event features.
- **Verdict: not usable for hourly classification.**

## Summary table

| Source | Resolution | Covers 2021–2025? | Access | Verdict |
|---|---|---|---|---|
| IMD radar | — | — | Nodal officer, terms | Not public; not usable |
| NASA GPM IMERG | ~10 km, 30-min | Yes | Free Earthdata account | Needs Kam's credentials; best satellite candidate for v3.2 |
| IMDAA reanalysis | 12 km, hourly | **No (ends 2020)** | NCMRWF portal / HF | **Misaligned; not usable** |
| Open-Meteo GFS (Historical Forecast API) | 13 km, hourly | Partial (from 2021-03-23) | Keyless | Tested; weak signal, low ERA5 correlation; **not integrated** |
| IMD gridded daily rainfall | 0.25°, daily | Yes | Public packages | Daily only; cannot align to hourly windows |

## Recommendation

The most promising next data step is **NASA GPM IMERG** (satellite-observed
precipitation at 10 km, half-hourly, covering 2021–2025). It requires Kam
to create a free NASA Earthdata account and authorise GES DISC. If he does,
the next step is to download the IMERG point series for Bhubaneswar (and
the two upwind points), align it to the hourly ERA5 timestamps, and test
whether IMERG precipitation (as a target or as a feature) improves the
3 h ≥ 10 mm classifier on the 2024 validation set before touching 2025.
Until then, v3.1 proceeds on the existing ERA5 + spatial features, which
is where the measurable gains in this round came from.
