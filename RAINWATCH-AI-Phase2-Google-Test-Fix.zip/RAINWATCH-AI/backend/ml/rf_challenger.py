"""v3.3 Random Forest challenger experiment.

Controlled comparison of sklearn RandomForestClassifier against the
existing three-family gradient-boosting ensemble (XGBoost + LightGBM +
HistGradientBoosting). Phases (run in order; 2026 is NEVER touched):

  tune  - chronological tuning of RF on the primary target 3h >= 10mm
          (grid fold train 2021-22 -> val 2023; top-2 confirmed on
          val 2022 and val 2024), plus a light per-target check of
          class_weight x sample_weight for the other two targets.
  oof   - RF out-of-fold probabilities (expanding window, val years
          2022-2024), same folds as the existing OOF files.
  eval  - single 2025 evaluation of: RF alone, XGB+RF, four-family
          ensemble, OOF stacking (meta-learner over 4 families) vs the
          three-family base arm (numbers read from variants.json).
  analysis - prediction diversity, storm-miss analysis (storms only RF
          detects), calibration (ECE), paired chronological block
          bootstrap (7-day blocks) and storm-event bootstrap.

Rules: no production changes, no overwriting existing artifacts (all
outputs are new files under models/rainfall_xgb_v3_3/ and one doc).
RF is adopted ONLY if it gives a reproducible improvement over the
existing ensemble (beats it on OOF and 2025, with the bootstrap CI
excluding zero, or a clear storm-detection gain).

Usage:
    cd backend && .venv/bin/python ml/rf_challenger.py --phase tune
    cd backend && .venv/bin/python ml/rf_challenger.py --phase oof
    cd backend && .venv/bin/python ml/rf_challenger.py --phase eval
    cd backend && .venv/bin/python ml/rf_challenger.py --phase analysis
"""
from __future__ import annotations

import argparse
import itertools
import json
import logging
import os
import sys

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from v33_common import (  # noqa: E402
    BEST_PARAMS,
    FAMILIES,
    TARGETS,
    _events_merged,
    full_eval,
    make_classifier,
    platt_apply,
    platt_fit,
    threshold_for_fbeta,
)
from train_rainfall_v33 import (  # noqa: E402
    _ensemble_weights,
    _refit_arm,
    _train_arm,
    load_table,
)

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger("rf_challenger")

BACKEND = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.join(BACKEND, "models", "rainfall_xgb_v3_3")
OOF_DIR = os.path.join(OUT_DIR, "oof")
N_JOBS = 2


# ----------------------------------------------------------------------
# RF helpers
# ----------------------------------------------------------------------
def event_weights(y: np.ndarray) -> np.ndarray:
    """Hours within +/-6 h of a heavy-event hour upweighted x2."""
    idx = np.where(y == 1)[0]
    near = np.zeros(len(y), dtype=bool)
    for i in idx:
        near[max(0, i - 6):min(len(y), i + 7)] = True
    return np.where(near, 2.0, 1.0)


def make_rf(cfg: dict) -> RandomForestClassifier:
    return RandomForestClassifier(
        n_estimators=cfg.get("n_estimators", 300),
        max_depth=cfg.get("max_depth"),
        min_samples_leaf=cfg.get("min_samples_leaf", 1),
        max_features=cfg.get("max_features", "sqrt"),
        class_weight=cfg.get("class_weight"),
        random_state=42,
        n_jobs=N_JOBS,
    )


def fit_rf(cfg: dict, X: np.ndarray, y: np.ndarray,
           sample_weight: np.ndarray | None) -> RandomForestClassifier:
    m = make_rf(cfg)
    if sample_weight is not None:
        m.fit(X, y, sample_weight=sample_weight)
    else:
        m.fit(X, y)
    return m


def rf_probs(cfg: dict, X_tr, y_tr, X_va, use_event_w: bool):
    sw = event_weights(y_tr) if use_event_w else None
    m = fit_rf(cfg, X_tr, y_tr, sw)
    return m.predict_proba(X_va)[:, 1], m


def ensemble_weights_n(y_va: np.ndarray, val_probs: dict[str, np.ndarray],
                       fams: list[str]) -> dict[str, float]:
    """Grid-search ensemble weights (step 0.1) for an arbitrary family set."""
    P = np.column_stack([val_probs[f] for f in fams])
    best_w, best_s = None, None
    for w in itertools.product([0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0],
                               repeat=len(fams)):
        if abs(sum(w) - 1.0) > 1e-9:
            continue
        s = average_precision_score(y_va, P @ np.array(w))
        if best_s is None or s > best_s:
            best_w, best_s = w, float(s)
    return dict(zip(fams, [float(x) for x in best_w]))


def _logit(p: np.ndarray) -> np.ndarray:
    p = np.clip(p, 1e-4, 1 - 1e-4)
    return np.log(p / (1 - p))


def ece(y: np.ndarray, p: np.ndarray, n_bins: int = 10) -> float:
    """Expected calibration error (equal-width bins)."""
    edges = np.linspace(0, 1, n_bins + 1)
    tot = 0.0
    for i in range(n_bins):
        m = (p >= edges[i]) & (p < edges[i + 1] if i < n_bins - 1 else p <= 1.0)
        if m.sum() > 0:
            tot += abs(p[m].mean() - y[m].mean()) * m.sum() / len(y)
    return round(float(tot), 4)


def _feats() -> list[str]:
    with open(os.path.join(OUT_DIR, "feature_schema.json")) as f:
        return json.load(f)["features"]


def _split(df: pd.DataFrame):
    tr = df[df["timestamp"].dt.year.isin([2021, 2022, 2023])].reset_index(drop=True)
    va = df[df["timestamp"].dt.year == 2024].reset_index(drop=True)
    tv = pd.concat([tr, va], ignore_index=True)
    te = df[df["timestamp"].dt.year == 2025].reset_index(drop=True)
    return tr, va, tv, te


# ----------------------------------------------------------------------
# Phase: tune
# ----------------------------------------------------------------------
def phase_tune() -> None:
    """Chronological RF tuning. Grid fold: train 2021-22 -> val 2023.
    Stage A: depth/leaf/class_weight. Stage B: trees/features/sample
    weight on the Stage-A winner. Stage C: top-2 confirmed on val 2022
    and val 2024 (folds the grid never saw). Light per-target check for
    the other two targets (class_weight x sample_weight only)."""
    df = load_table("v33")
    feats = _feats()
    target = "y_3h_ge_10mm"
    tr22 = df[df["timestamp"].dt.year.isin([2021, 2022])].reset_index(drop=True)
    va23 = df[df["timestamp"].dt.year == 2023].reset_index(drop=True)
    tr21 = df[df["timestamp"].dt.year == 2021].reset_index(drop=True)
    va22 = df[df["timestamp"].dt.year == 2022].reset_index(drop=True)
    tr, va, _, _ = _split(df)

    def pr(cfg, X_tr, y_tr, X_va, y_va, use_ew):
        p, _ = rf_probs(cfg, X_tr, y_tr, X_va, use_ew)
        return average_precision_score(y_va, p)

    X_a, y_a = tr22[feats].to_numpy(float), tr22[target].to_numpy().astype(int)
    X_b, y_b = va23[feats].to_numpy(float), va23[target].to_numpy().astype(int)

    # Stage A.
    log.info("Stage A: depth/leaf/class_weight (150 trees, fold 2021-22->2023)")
    stage_a = []
    for depth, leaf, cw in itertools.product([None, 12], [1, 5],
                                             [None, "balanced_subsample"]):
        cfg = {"n_estimators": 150, "max_depth": depth, "min_samples_leaf": leaf,
               "max_features": "sqrt", "class_weight": cw}
        s = pr(cfg, X_a, y_a, X_b, y_b, False)
        stage_a.append((round(float(s), 4), cfg))
        log.info("  depth=%s leaf=%s cw=%s -> val2023 PR-AUC %.4f", depth, leaf, cw, s)
    stage_a.sort(key=lambda r: -r[0])
    win_a = stage_a[0][1]
    log.info("Stage A winner: %s (PR-AUC %.4f)", win_a, stage_a[0][0])
    with open(os.path.join(OUT_DIR, "rf_tuning.json"), "w") as f:
        json.dump({"feature_set": "v33_pruned_94", "primary_target": target,
                   "stage_a": [{"pr_auc": s, "cfg": c} for s, c in stage_a]},
                  f, indent=2, default=str)

    # Stage B: trees / max_features / sample weight on the winner.
    log.info("Stage B: n_estimators/max_features/sample_weight on Stage-A winner")
    stage_b = []
    for n_est, mf, ew in itertools.product([150, 300], ["sqrt", 0.3], [False, True]):
        cfg = dict(win_a, n_estimators=n_est, max_features=mf)
        s = pr(cfg, X_a, y_a, X_b, y_b, ew)
        stage_b.append((round(float(s), 4), cfg, ew))
        log.info("  n=%s mf=%s event_w=%s -> val2023 PR-AUC %.4f", n_est, mf, ew, s)
    stage_b.sort(key=lambda r: -r[0])
    log.info("Stage B winner: %s event_w=%s (PR-AUC %.4f)",
             stage_b[0][1], stage_b[0][2], stage_b[0][0])
    with open(os.path.join(OUT_DIR, "rf_tuning.json"), "w") as f:
        json.dump({"feature_set": "v33_pruned_94", "primary_target": target,
                   "stage_a": [{"pr_auc": s, "cfg": c} for s, c in stage_a],
                   "stage_b": [{"pr_auc": s, "cfg": c, "event_w": e}
                               for s, c, e in stage_b]},
                  f, indent=2, default=str)

    # Stage C: confirm top-2 on the two untouched folds (val 2022, val 2024).
    log.info("Stage C: top-2 confirmed on val 2022 and val 2024")
    conf = []
    for score23, cfg, ew in stage_b[:2]:
        X1, y1 = tr21[feats].to_numpy(float), tr21[target].to_numpy().astype(int)
        X2, y2 = va22[feats].to_numpy(float), va22[target].to_numpy().astype(int)
        s22 = pr(cfg, X1, y1, X2, y2, ew)
        X3, y3 = tr[feats].to_numpy(float), tr[target].to_numpy().astype(int)
        X4, y4 = va[feats].to_numpy(float), va[target].to_numpy().astype(int)
        s24 = pr(cfg, X3, y3, X4, y4, ew)
        mean3 = float(np.mean([s22, score23, s24]))
        conf.append({"cfg": cfg, "event_w": ew, "val2022": round(float(s22), 4),
                     "val2023": score23, "val2024": round(float(s24), 4),
                     "mean_oof": round(mean3, 4)})
        log.info("  cfg=%s ew=%s -> 2022 %.4f | 2023 %.4f | 2024 %.4f | mean %.4f",
                 cfg, ew, s22, score23, s24, mean3)
    conf.sort(key=lambda r: -r["mean_oof"])
    winner = conf[0]
    log.info("RF winner for %s: %s event_w=%s (mean OOF PR-AUC %.4f)",
             target, winner["cfg"], winner["event_w"], winner["mean_oof"])
    with open(os.path.join(OUT_DIR, "rf_tuning.json"), "w") as f:
        json.dump({"feature_set": "v33_pruned_94", "primary_target": target,
                   "stage_a": [{"pr_auc": s, "cfg": c} for s, c in stage_a],
                   "stage_b": [{"pr_auc": s, "cfg": c, "event_w": e}
                               for s, c, e in stage_b],
                   "confirmation": conf},
                  f, indent=2, default=str)

    # Light per-target check: class_weight x sample_weight only.
    configs = {target: {"cfg": winner["cfg"], "event_w": winner["event_w"]}}
    for t in ("y_6h_ge_10mm", "y_3h_ge_5mm"):
        log.info("Per-target light check for %s", t)
        y_a2 = tr22[t].to_numpy().astype(int)
        y_b2 = va23[t].to_numpy().astype(int)
        base_cfg = dict(winner["cfg"])
        base_s = pr(base_cfg, X_a, y_a2, X_b, y_b2, winner["event_w"])
        best = (round(float(base_s), 4), dict(base_cfg), winner["event_w"])
        for cw, ew in itertools.product([None, "balanced_subsample"], [False, True]):
            cfg = dict(base_cfg, class_weight=cw)
            s = pr(cfg, X_a, y_a2, X_b, y_b2, ew)
            log.info("  cw=%s event_w=%s -> val2023 PR-AUC %.4f", cw, ew, s)
            if s > best[0] + 0.01:
                best = (round(float(s), 4), cfg, ew)
        configs[t] = {"cfg": best[1], "event_w": best[2]}
        log.info("  %s config: %s event_w=%s (val2023 PR-AUC %.4f)",
                 t, best[1], best[2], best[0])

    out = {"feature_set": "v33_pruned_94", "primary_target": target,
           "stage_a": [{"pr_auc": s, "cfg": c} for s, c in stage_a],
           "stage_b": [{"pr_auc": s, "cfg": c, "event_w": e} for s, c, e in stage_b],
           "confirmation": conf, "configs": configs}
    with open(os.path.join(OUT_DIR, "rf_tuning.json"), "w") as f:
        json.dump(out, f, indent=2, default=str)
    log.info("saved %s", os.path.join(OUT_DIR, "rf_tuning.json"))


# ----------------------------------------------------------------------
# Phase: oof
# ----------------------------------------------------------------------
def phase_oof() -> None:
    """RF out-of-fold probabilities, expanding window (val 2022/2023/
    2024), 200 trees, same folds as the existing OOF files."""
    df = load_table("v33")
    feats = _feats()
    tuning = json.load(open(os.path.join(OUT_DIR, "rf_tuning.json")))
    for target in TARGETS:
        cfg = tuning["configs"][target]["cfg"]
        ew = tuning["configs"][target]["event_w"]
        rows = []
        for val_year in (2022, 2023, 2024):
            tr_y = df[df["timestamp"].dt.year < val_year].reset_index(drop=True)
            va_y = df[df["timestamp"].dt.year == val_year].reset_index(drop=True)
            p, _ = rf_probs(dict(cfg, n_estimators=200),
                            tr_y[feats].to_numpy(float),
                            tr_y[target].to_numpy().astype(int),
                            va_y[feats].to_numpy(float), ew)
            rows.append(pd.DataFrame({
                "timestamp": va_y["timestamp"],
                "y": va_y[target].to_numpy().astype(int),
                "p_rf": p, "fold_val_year": val_year}))
            log.info("%s fold val=%s: RF OOF PR-AUC %.4f", target, val_year,
                     average_precision_score(va_y[target], p))
        out = pd.concat(rows, ignore_index=True)
        out.to_csv(os.path.join(OOF_DIR, f"oof_rf_{target}.csv"), index=False)
        log.info("saved %s (%d rows)", os.path.join(OOF_DIR, f"oof_rf_{target}.csv"),
                 len(out))


# ----------------------------------------------------------------------
# Phase: eval
# ----------------------------------------------------------------------
def _thresholds_from_cal(y_va: np.ndarray, cal: np.ndarray) -> dict:
    out = {}
    for beta, name in ((1.0, "f1"), (2.0, "f2")):
        t, prec, rec = threshold_for_fbeta(y_va, cal, beta)
        out[name] = {"threshold": round(float(t), 2),
                     "precision": round(float(prec), 4),
                     "recall": round(float(rec), 4)}
    return out


def phase_eval() -> None:
    """Single 2025 evaluation of RF-alone, XGB+RF, four-family and
    OOF-stacking vs the three-family base arm. Protocol identical to
    the variants phase: weights/Platt/thresholds learned on 2024
    validation (train 2021-2023), refit on 2021-2024, evaluate ONCE
    on 2025. 2026 untouched."""
    df = load_table("v33")
    feats = _feats()
    tuning = json.load(open(os.path.join(OUT_DIR, "rf_tuning.json")))
    variants = json.load(open(os.path.join(OUT_DIR, "variants.json")))
    tr, va, tv, te = _split(df)
    n_days = len(te) / 24.0
    results: dict = {"arms": {}}

    for target in TARGETS:
        log.info("=== %s ===", target)
        cfg = tuning["configs"][target]["cfg"]
        ew = tuning["configs"][target]["event_w"]
        X_tr = tr[feats].to_numpy(float)
        y_tr = tr[target].to_numpy().astype(int)
        X_va = va[feats].to_numpy(float)
        y_va = va[target].to_numpy().astype(int)
        X_tv = tv[feats].to_numpy(float)
        y_tv = tv[target].to_numpy().astype(int)
        X_te = te[feats].to_numpy(float)
        y_te = te[target].to_numpy().astype(int)

        # Three-family members (base arm) + RF, all trained on 2021-23.
        m3_tr, w3, platt3, thr3 = _train_arm("base", target, tr, va, feats)
        val3 = {f: m3_tr[f].predict_proba(X_va)[:, 1] for f in FAMILIES}
        p_rf_va, _ = rf_probs(cfg, X_tr, y_tr, X_va, ew)

        # Refit members on 2021-24 for the 2025 evaluation.
        m3_tv = _refit_arm("base", target, tv, feats, w3, platt3)
        te3 = {f: m3_tv[f].predict_proba(X_te)[:, 1] for f in FAMILIES}
        sw_tv = event_weights(y_tv) if ew else None
        rf_tv = fit_rf(cfg, X_tv, y_tv, sw_tv)
        p_rf_te = rf_tv.predict_proba(X_te)[:, 1]
        np.savez(os.path.join(OUT_DIR, f"rf_2025_probs_{target}.npz"),
                 y=y_te, **{f: te3[f] for f in FAMILIES}, rf=p_rf_te)

        arms: dict[str, dict] = {}

        # --- three-family baseline (recomputed; must match variants.json)
        ens3_va = sum(w3[f] * val3[f] for f in FAMILIES)
        cal3_va = platt_apply(ens3_va, platt3["w"], platt3["b"])
        ens3_te = sum(w3[f] * te3[f] for f in FAMILIES)
        cal3_te = platt_apply(ens3_te, platt3["w"], platt3["b"])
        ev3 = full_eval(y_te, cal3_te,
                        {k: v["threshold"] for k, v in thr3.items()}, n_days=n_days)
        ev3["ece"] = ece(y_te, cal3_te)
        arms["three_family"] = {"weights": w3, "platt": platt3,
                                "thresholds": thr3, "eval": ev3}
        log.info("  three_family 2025 PR-AUC %.4f (variants.json: %.4f)",
                 ev3["pr_auc"], variants["arms"]["base"][target]["eval"]["pr_auc"])

        # --- RF alone
        wp, bp = platt_fit(p_rf_va, y_va)
        cal_rf_va = platt_apply(p_rf_va, wp, bp)
        thr_rf = _thresholds_from_cal(y_va, cal_rf_va)
        cal_rf_te = platt_apply(p_rf_te, wp, bp)
        ev_rf = full_eval(y_te, cal_rf_te,
                          {k: v["threshold"] for k, v in thr_rf.items()}, n_days=n_days)
        ev_rf["ece"] = ece(y_te, cal_rf_te)
        arms["rf_alone"] = {"weights": {"rf": 1.0}, "platt": {"w": wp, "b": bp},
                            "thresholds": thr_rf, "eval": ev_rf}
        log.info("  rf_alone 2025 PR-AUC %.4f", ev_rf["pr_auc"])

        # --- XGB + RF
        w_xr = ensemble_weights_n(y_va, {"xgb": val3["xgb"], "rf": p_rf_va},
                                  ["xgb", "rf"])
        ens_xr_va = w_xr["xgb"] * val3["xgb"] + w_xr["rf"] * p_rf_va
        wp, bp = platt_fit(ens_xr_va, y_va)
        thr_xr = _thresholds_from_cal(y_va, platt_apply(ens_xr_va, wp, bp))
        ens_xr_te = w_xr["xgb"] * te3["xgb"] + w_xr["rf"] * p_rf_te
        cal_xr_te = platt_apply(ens_xr_te, wp, bp)
        ev_xr = full_eval(y_te, cal_xr_te,
                          {k: v["threshold"] for k, v in thr_xr.items()}, n_days=n_days)
        ev_xr["ece"] = ece(y_te, cal_xr_te)
        arms["xgb_rf"] = {"weights": w_xr, "platt": {"w": wp, "b": bp},
                          "thresholds": thr_xr, "eval": ev_xr}
        log.info("  xgb_rf 2025 PR-AUC %.4f | weights %s", ev_xr["pr_auc"], w_xr)

        # --- four-family ensemble
        val4 = dict(val3, rf=p_rf_va)
        w4 = ensemble_weights_n(y_va, val4, ["xgb", "lgbm", "hgb", "rf"])
        ens4_va = sum(w4[f] * val4[f] for f in ("xgb", "lgbm", "hgb", "rf"))
        wp, bp = platt_fit(ens4_va, y_va)
        thr4 = _thresholds_from_cal(y_va, platt_apply(ens4_va, wp, bp))
        te4 = dict(te3, rf=p_rf_te)
        ens4_te = sum(w4[f] * te4[f] for f in ("xgb", "lgbm", "hgb", "rf"))
        cal4_te = platt_apply(ens4_te, wp, bp)
        ev4 = full_eval(y_te, cal4_te,
                        {k: v["threshold"] for k, v in thr4.items()}, n_days=n_days)
        ev4["ece"] = ece(y_te, cal4_te)
        arms["four_family"] = {"weights": w4, "platt": {"w": wp, "b": bp},
                               "thresholds": thr4, "eval": ev4}
        log.info("  four_family 2025 PR-AUC %.4f | weights %s", ev4["pr_auc"], w4)

        # --- OOF stacking over the four families (94-feature set)
        oof33 = pd.read_csv(os.path.join(OOF_DIR, f"oof_v33_{target}.csv"),
                            parse_dates=["timestamp"])
        oofrf = pd.read_csv(os.path.join(OOF_DIR, f"oof_rf_{target}.csv"),
                            parse_dates=["timestamp"])
        m = oof33.merge(oofrf, on=["timestamp", "y", "fold_val_year"])
        assert len(m) == 26304, f"OOF merge mismatch {len(m)}"
        X_oof = np.column_stack([_logit(m[f"p_{f}"].to_numpy())
                                 for f in ("xgb", "lgbm", "hgb")] +
                                [_logit(m["p_rf"].to_numpy())])
        y_oof = m["y"].to_numpy().astype(int)
        year = m["fold_val_year"].to_numpy()
        meta_a = LogisticRegression(C=1.0, max_iter=1000)
        meta_a.fit(X_oof[year <= 2023], y_oof[year <= 2023])
        p_meta_24 = meta_a.predict_proba(X_oof[year == 2024])[:, 1]
        pr_meta_24 = average_precision_score(y_oof[year == 2024], p_meta_24)
        pr_fixed_24 = average_precision_score(
            y_oof[year == 2024], m["p_ens_cal"].to_numpy()[year == 2024])
        log.info("  stacking 2024-OOF PR-AUC %.4f (3-family fixed %.4f)",
                 pr_meta_24, pr_fixed_24)
        wp, bp = platt_fit(p_meta_24, y_oof[year == 2024])
        thr_s = _thresholds_from_cal(y_oof[year == 2024],
                                     platt_apply(p_meta_24, wp, bp))
        meta_b = LogisticRegression(C=1.0, max_iter=1000)
        meta_b.fit(X_oof, y_oof)
        X25 = np.column_stack([_logit(te3[f]) for f in ("xgb", "lgbm", "hgb")] +
                              [_logit(p_rf_te)])
        p_meta_te = meta_b.predict_proba(X25)[:, 1]
        cal_s_te = platt_apply(p_meta_te, wp, bp)
        ev_s = full_eval(y_te, cal_s_te,
                         {k: v["threshold"] for k, v in thr_s.items()}, n_days=n_days)
        ev_s["ece"] = ece(y_te, cal_s_te)
        arms["stacking"] = {"weights": {"meta": "logreg over 4 families"},
                            "platt": {"w": wp, "b": bp}, "thresholds": thr_s,
                            "eval": ev_s,
                            "oof_2024": {"stack": round(float(pr_meta_24), 4),
                                         "three_family_fixed": round(float(pr_fixed_24), 4)}}
        log.info("  stacking 2025 PR-AUC %.4f", ev_s["pr_auc"])

        # Save calibrated arm probabilities for the analysis phase.
        np.savez(os.path.join(OUT_DIR, f"rf_arm_probs_{target}.npz"),
                 three_family=cal3_te, rf_alone=cal_rf_te, xgb_rf=cal_xr_te,
                 four_family=cal4_te, stacking=cal_s_te)

        results["arms"][target] = arms

    with open(os.path.join(OUT_DIR, "rf_experiment.json"), "w") as f:
        json.dump(results, f, indent=2, default=str)
    log.info("saved %s", os.path.join(OUT_DIR, "rf_experiment.json"))


# ----------------------------------------------------------------------
# Phase: analysis
# ----------------------------------------------------------------------
def _storm_detection(y: np.ndarray, p: np.ndarray, threshold: float):
    """Per-storm detection (gap-merged <=6 h storms, alert-window rule
    identical to v33_common.event_metrics). Returns (detected mask,
    list of (start, end) storms)."""
    from v33_common import _events
    pred = (p >= threshold).astype(int)
    true_storms = _events_merged(y.astype(int), max_gap_h=6)
    pred_ev = _events(pred)
    detected = []
    for s, e in true_storms:
        cands = [a for a, _ in pred_ev if s - 2 <= a <= e + 2]
        detected.append(len(cands) > 0)
    return np.array(detected), true_storms


def phase_analysis() -> None:
    """Diversity, storm-miss analysis, calibration summary, paired
    block bootstrap + storm-event bootstrap. Writes into
    rf_experiment.json."""
    results = json.load(open(os.path.join(OUT_DIR, "rf_experiment.json")))
    rng = np.random.default_rng(42)
    N_BOOT = 1000
    analysis: dict = {"diversity": {}, "storm_miss": {}, "bootstrap": {}}

    for target in TARGETS:
        log.info("=== analysis %s ===", target)
        d = np.load(os.path.join(OUT_DIR, f"rf_2025_probs_{target}.npz"))
        y = d["y"].astype(int)
        fam_p = {f: d[f] for f in ("xgb", "lgbm", "hgb", "rf")}
        arm_p = np.load(os.path.join(OUT_DIR, f"rf_arm_probs_{target}.npz"))
        arms = results["arms"][target]

        # --- diversity: correlation + disagreement at F1 thresholds
        names = ["xgb", "lgbm", "hgb", "rf"]
        corr = np.corrcoef(np.column_stack([fam_p[f] for f in names]).T)
        thr = {a: arms[a]["thresholds"]["f1"]["threshold"] for a in arms}
        pos = {a: arm_p[a] >= thr[a] for a in arms}
        fam_pos = {f: fam_p[f] >= 0.5 for f in names}  # raw family calls
        disag = {}
        for i, f1 in enumerate(names):
            for f2 in names[i + 1:]:
                disag[f"{f1}_vs_{f2}"] = round(
                    float((fam_pos[f1] != fam_pos[f2]).mean()), 4)
        # Jaccard of RF positive set vs each boosting family (at 0.5).
        jac = {}
        for f in ("xgb", "lgbm", "hgb"):
            inter = int((fam_pos["rf"] & fam_pos[f]).sum())
            union = int((fam_pos["rf"] | fam_pos[f]).sum())
            jac[f"rf_vs_{f}"] = round(inter / max(1, union), 4)
        analysis["diversity"][target] = {
            "pearson_corr": {f"{a}_{b}": round(float(corr[i, j]), 3)
                             for i, a in enumerate(names)
                             for j, b in enumerate(names) if j > i},
            "disagreement_rate_at_0.5": disag, "jaccard_rf_vs_family": jac}
        log.info("  RF Pearson corr vs xgb/lgbm/hgb: %.3f / %.3f / %.3f",
                 corr[3, 0], corr[3, 1], corr[3, 2])

        # --- storm-miss: which storms does each arm detect?
        det = {}
        for a in ("three_family", "rf_alone", "xgb_rf", "four_family", "stacking"):
            dm, storms = _storm_detection(y, arm_p[a], thr[a])
            det[a] = dm
        n_storms = len(storms)
        only_rf = [int(i) for i in range(n_storms)
                   if det["rf_alone"][i] and not det["three_family"][i]]
        only_4fam = [int(i) for i in range(n_storms)
                     if det["four_family"][i] and not det["three_family"][i]]
        missed_all = [int(i) for i in range(n_storms)
                      if not any(det[a][i] for a in det)]
        # RF's max probability during the storms only it detects.
        rf_only_maxp = {}
        for i in only_rf:
            s, e = storms[i]
            rf_only_maxp[f"storm_{i}_{s}_{e}"] = round(
                float(fam_p["rf"][s:e + 1].max()), 3)
        analysis["storm_miss"][target] = {
            "n_true_storms": n_storms,
            "detection_rate": {a: round(float(det[a].mean()), 4) for a in det},
            "storms_only_rf_alone_detects": only_rf,
            "storms_only_four_family_detects": only_4fam,
            "storms_missed_by_all_arms": missed_all,
            "rf_max_prob_in_rf_only_storms": rf_only_maxp}
        log.info("  storms: %d | only-RF detects %d | only-4fam detects %d | "
                 "missed by all %d", n_storms, len(only_rf), len(only_4fam),
                 len(missed_all))

        # --- paired block bootstrap (7-day blocks) on PR-AUC differences
        n = len(y)
        block = 168
        n_blocks = n // block
        y_b = y[:n_blocks * block].reshape(n_blocks, block)
        p_b = {a: arm_p[a][:n_blocks * block].reshape(n_blocks, block)
               for a in arm_p.files}
        boot: dict[str, list[float]] = {a: [] for a in arm_p.files
                                        if a != "three_family"}
        for _ in range(N_BOOT):
            idx = rng.integers(0, n_blocks, n_blocks)
            y_r = y_b[idx].ravel()
            if y_r.sum() == 0:
                continue
            base = average_precision_score(y_r, p_b["three_family"][idx].ravel())
            for a in boot:
                boot[a].append(average_precision_score(
                    y_r, p_b[a][idx].ravel()) - base)
        boot_out = {}
        for a, diffs in boot.items():
            diffs = np.array(diffs)
            lo, hi = np.percentile(diffs, [2.5, 97.5])
            boot_out[a] = {"mean_diff": round(float(diffs.mean()), 4),
                           "ci_95": [round(float(lo), 4), round(float(hi), 4)],
                           "p_diff_gt_0": round(float((diffs > 0).mean()), 3)}
            log.info("  block-boot %s - three_family: mean %+.4f 95%% CI "
                     "[%+.4f, %+.4f] P(>0)=%.3f", a, diffs.mean(), lo, hi,
                     (diffs > 0).mean())
        # --- storm-event bootstrap on detection-rate differences
        det_arr = {a: det[a] for a in det}
        s_boot: dict[str, list[float]] = {a: [] for a in det if a != "three_family"}
        for _ in range(N_BOOT):
            idx = rng.integers(0, n_storms, n_storms)
            base_r = det_arr["three_family"][idx].mean()
            for a in s_boot:
                s_boot[a].append(det_arr[a][idx].mean() - base_r)
        storm_out = {}
        for a, diffs in s_boot.items():
            diffs = np.array(diffs)
            lo, hi = np.percentile(diffs, [2.5, 97.5])
            storm_out[a] = {"mean_diff": round(float(diffs.mean()), 4),
                            "ci_95": [round(float(lo), 4), round(float(hi), 4)],
                            "p_diff_gt_0": round(float((diffs > 0).mean()), 3)}
        analysis["bootstrap"][target] = {
            "block_bootstrap_pr_auc_diff_vs_three_family": boot_out,
            "storm_bootstrap_detection_rate_diff_vs_three_family": storm_out,
            "n_boot": N_BOOT, "block_hours": block}

    results["analysis"] = analysis
    # --- verdict: adopt RF only on reproducible improvement
    verdict = {}
    for target in TARGETS:
        ev = results["arms"][target]
        b = analysis["bootstrap"][target]["block_bootstrap_pr_auc_diff_vs_three_family"]
        oof_stack = ev["stacking"].get("oof_2024", {})
        improves = (
            ev["four_family"]["eval"]["pr_auc"] > ev["three_family"]["eval"]["pr_auc"]
            and b["four_family"]["ci_95"][0] > 0)
        verdict[target] = {
            "four_family_beats_three_family_2025":
                ev["four_family"]["eval"]["pr_auc"] > ev["three_family"]["eval"]["pr_auc"],
            "block_boot_ci_excludes_zero": b["four_family"]["ci_95"][0] > 0,
            "stacking_beats_fixed_on_2024_oof":
                oof_stack.get("stack", 0) > oof_stack.get("three_family_fixed", 0),
            "adopt_rf": bool(improves)}
    results["verdict"] = verdict
    with open(os.path.join(OUT_DIR, "rf_experiment.json"), "w") as f:
        json.dump(results, f, indent=2, default=str)
    log.info("saved %s (verdict: %s)", os.path.join(OUT_DIR, "rf_experiment.json"),
             {t: v["adopt_rf"] for t, v in verdict.items()})


# ----------------------------------------------------------------------
def main() -> None:
    ap = argparse.ArgumentParser(description="Random Forest challenger for v3.3")
    ap.add_argument("--phase", required=True,
                    choices=["tune", "oof", "eval", "analysis"])
    args = ap.parse_args()
    {"tune": phase_tune, "oof": phase_oof, "eval": phase_eval,
     "analysis": phase_analysis}[args.phase]()


if __name__ == "__main__":
    main()
