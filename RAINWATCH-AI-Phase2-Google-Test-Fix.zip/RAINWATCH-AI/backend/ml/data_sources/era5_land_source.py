"""ERA5-Land (v3.2, Source E).

Organisation: Copernicus Climate Change Service (C3S) / ECMWF.
Dataset: ``reanalysis-era5-land``.
- Hourly, 0.1 deg (~9 km), 1950–present, ~5 days behind real time.
- Land-surface reanalysis (H-TESSEL, IFS CY45R1), no data assimilation.
- Variables of interest: volumetric soil water layers 1–3, soil
  temperature, total precipitation, surface runoff, sub-surface runoff,
  evaporation.
- Prioritise soil moisture / land-surface features for the separate
  flood-susceptibility component. For rainfall classification, retain
  only features that demonstrate validation improvements.

Access: **CDS account + API token required.**
- Register at https://cds.climate.copernicus.eu/
- ``pip install cdsapi``; set ``CDSAPI_URL`` and ``CDSAPI_KEY`` (or the
  ``~/.cdsapirc`` file).
- The ARCO Zarr archive also exposes public Zarr datacubes, but the
  supported route for this project is the CDS API.

This connector implements the structure and the access check. It does
NOT fabricate ERA5-Land data. ``fetch`` returns [] with a clear blocker
message until CDS credentials are available.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from .base_source import BaseDataSource

log = logging.getLogger(__name__)

DATASET = "reanalysis-era5-land"

VARIABLES = [
    "volumetric_soil_water_layer_1",
    "volumetric_soil_water_layer_2",
    "volumetric_soil_water_layer_3",
    "soil_temperature_level_1",
    "total_precipitation",
    "surface_runoff",
    "sub_surface_runoff",
    "evaporation",
]


class ERA5LandSource(BaseDataSource):
    """ERA5-Land hourly land-surface reanalysis."""

    SOURCE_NAME = "era5_land"
    PRODUCT_NAME = "ERA5-Land hourly single levels"
    PRODUCT_VERSION = "reanalysis-era5-land"
    AVAILABILITY_LAG = "PT120H"  # ~5 days behind real time
    LICENSE = "Copernicus — free for research, attribution required"
    ACCESS_RESTRICTIONS = (
        "CDS account + API token required. Register at "
        "https://cds.climate.copernicus.eu/ and set CDSAPI_URL / "
        "CDSAPI_KEY (or ~/.cdsapirc)."
    )

    def __init__(self, backend_dir: Path | None = None):
        super().__init__(backend_dir)
        self.variables = VARIABLES

    def check_access(self) -> tuple[bool, str]:
        try:
            import cdsapi  # noqa: F401
        except ImportError:
            return False, (
                "cdsapi not installed (pip install cdsapi) and no CDS "
                "credentials are configured. Register at "
                "https://cds.climate.copernicus.eu/ and set CDSAPI_URL / "
                "CDSAPI_KEY."
            )
        key = self.env_or_none("CDSAPI_KEY")
        if not key:
            return False, (
                "cdsapi installed but CDSAPI_KEY is not set. Register at "
                "https://cds.climate.copernicus.eu/ and set CDSAPI_URL / "
                "CDSAPI_KEY."
            )
        return True, "cdsapi installed and CDSAPI_KEY present"

    def fetch(
        self,
        start: str,
        end: str,
        bbox: Optional[tuple[float, float, float, float]] = None,
    ) -> list[Path]:
        ok, msg = self.check_access()
        if not ok:
            log.error("ERA5-Land fetch blocked: %s", msg)
            return []
        raise NotImplementedError(
            "ERA5-Land fetch is not implemented: the CDS request shape "
            "must be confirmed against the live CDS catalogue once "
            "credentials exist. Do not fabricate ERA5-Land data."
        )

    def process(self, raw_files: list[Path]) -> Path:
        raise NotImplementedError(
            "ERA5-Land processing is not implemented: no ERA5-Land files "
            "have been obtained. Implement once the first file is "
            "available and its format is inspected."
        )
