"""Temporal alignment for RAINWATCH AI multi-source data (v3.2).

Rules (from the v3.2 brief):
- Internal timestamps are standardised to UTC.
- Preserve the original observation timestamp, time zone, product
  accumulation interval, retrieval timestamp, forecast initialisation
  time and forecast lead time where applicable.
- Support 30-minute, hourly and daily observations.
- Aggregate rainfall using actual interval semantics. Do not sum
  overlapping accumulation intervals. Do not duplicate rainfall.
- Leakage: every feature records ``available_at`` — the earliest time
  the observation was actually available. ``check_feature_availability``
  rejects any feature whose ``available_at`` is later than the forecast
  issue time ``t``.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Optional

import pandas as pd


def to_utc(series: pd.Series) -> pd.Series:
    """Parse a timestamp series and convert to timezone-aware UTC."""
    ts = pd.to_datetime(series, utc=True, errors="coerce")
    return ts.dt.tz_convert("UTC")


def standardise_hourly(df: pd.DataFrame, time_col: str = "timestamp") -> pd.DataFrame:
    """Standardise a frame to an hourly UTC index.

    - Parses ``time_col`` to UTC.
    - Drops rows with unparseable timestamps.
    - Drops duplicate timestamps (keeps the first).
    - Sorts ascending.
    Returns the frame with ``time_col`` as a tz-aware UTC datetime and a
    boolean ``is_complete`` column is NOT added here; use
    ``quality_control.check_completeness`` for that.
    """
    out = df.copy()
    out[time_col] = to_utc(out[time_col])
    out = out.dropna(subset=[time_col])
    out = out.drop_duplicates(subset=[time_col], keep="first")
    out = out.sort_values(time_col).reset_index(drop=True)
    return out


def resample_to_hourly(
    df: pd.DataFrame,
    value_cols: list[str],
    time_col: str = "timestamp",
    how: str = "sum",
) -> pd.DataFrame:
    """Resample a sub-hourly (e.g. 30-minute) frame to hourly.

    - Rainfall-rate columns are summed over the hour (mm/hr -> mm per
      hour, which equals the hourly accumulation).
    - All other columns are averaged.
    ``how`` is applied only to columns whose name contains "precip" or
    "rain"; the rest use the mean. This keeps the interval semantics
    explicit: a 30-minute rainfall rate of x mm/hr contributes x*0.5 mm
    to the hour, and summing two half-hours gives the hourly total.
    """
    out = standardise_hourly(df, time_col)
    out = out.set_index(time_col)
    rain_cols = [c for c in value_cols if "precip" in c.lower() or "rain" in c.lower()]
    other_cols = [c for c in value_cols if c not in rain_cols]
    parts = []
    if rain_cols:
        # 30-min rates are in mm/hr; each half-hour contributes rate*0.5 mm.
        # If the source already stores 30-min accumulations (mm), the
        # caller must convert to a rate first — see docstring.
        parts.append(out[rain_cols].resample("h").sum(min_count=1))
    if other_cols:
        parts.append(out[other_cols].resample("h").mean())
    if not parts:
        return out.reset_index()
    merged = pd.concat(parts, axis=1).reset_index()
    return merged


def rolling_accumulation(
    df: pd.DataFrame,
    col: str,
    window_h: int,
    time_col: str = "timestamp",
) -> pd.Series:
    """Rolling sum of an hourly rainfall column over ``window_h`` hours,
    ending at the current row (inclusive of the current hour, strictly
    past + present). Returns a Series aligned with ``df``."""
    out = standardise_hourly(df, time_col)
    return out[col].rolling(window=window_h, min_periods=window_h).sum()


# ----------------------------------------------------------------------
# Leakage / feature-availability check
# ----------------------------------------------------------------------

# Availability lag per source (how long after the observation time the
# product is actually available). These are the documented latencies:
#   ERA5 reanalysis: ~5 days (published with a delay)
#   GFS/IFS historical forecast API: the forecast for hour H issued at
#     run time R is available at R; a 0-hour lead forecast issued at R
#     covers R..R+1, so its availability is R, not H.
#   GSMaP NRT: ~4 hours; GSMaP MVK (final): ~3 days
#   IMERG Early: ~4 h; Late: ~12 h; Final: ~3.5 months
#   MSWEP V3: ~2 hours (near real-time)
#   INSAT HEM/IMSRA: ~30–60 minutes (near real-time)
#   IMD AWS: ~1 hour (operational)
AVAILABILITY_LAG_HOURS: dict[str, float] = {
    "era5": 120.0,          # 5 days
    "era5_land": 120.0,     # 5 days
    "ifs": 0.0,             # forecast issued at run time; see below
    "gfs": 0.0,
    "gsmap_nrt": 4.0,
    "gsmap_mvk": 72.0,
    "imerg_early": 4.0,
    "imerg_late": 12.0,
    "imerg_final": 2520.0,  # ~3.5 months
    "mswep": 2.0,
    "insat": 1.0,
    "imd_station": 1.0,
}


def available_at(observation_time: pd.Timestamp, source: str) -> pd.Timestamp:
    """Earliest time a forecaster could have used an observation from
    ``source`` made at ``observation_time``."""
    lag_h = AVAILABILITY_LAG_HOURS.get(source, 0.0)
    return observation_time + timedelta(hours=lag_h)


def check_feature_availability(
    feature_available_at: pd.Timestamp,
    issue_time: pd.Timestamp,
    feature_name: str = "",
) -> None:
    """Raise ValueError if a feature was not actually available at the
    forecast issue time. Call this for every feature before it is used
    in a prediction issued at ``issue_time``."""
    if pd.Timestamp(feature_available_at) > pd.Timestamp(issue_time):
        raise ValueError(
            f"LEAKAGE: feature {feature_name!r} was available at "
            f"{feature_available_at} but the forecast was issued at "
            f"{issue_time}. Refusing to use it."
        )


def check_frame_availability(
    df: pd.DataFrame,
    source: str,
    issue_time: pd.Timestamp,
    time_col: str = "timestamp",
) -> pd.DataFrame:
    """Drop rows whose observation was not yet available at ``issue_time``
    (per the source's availability lag). Returns the filtered frame.
    Use this when building a feature table for a forecast issued at
    ``issue_time``."""
    out = df.copy()
    out["_available_at"] = out[time_col].apply(
        lambda t: available_at(pd.Timestamp(t), source)
    )
    out = out[out["_available_at"] <= pd.Timestamp(issue_time)]
    return out.drop(columns=["_available_at"])
