/**
 * Shared mutable state for the demo experience.
 *
 * `tick` is bumped whenever the user presses "Refresh demo data",
 * which re-seeds every generated series so numbers visibly change
 * without any backend.  Data modules import getDemoTick() so their
 * cache keys invalidate automatically.
 */
let tick = 0

export function getDemoTick(): number {
  return tick
}

export function bumpDemoTick(): number {
  tick += 1
  return tick
}
