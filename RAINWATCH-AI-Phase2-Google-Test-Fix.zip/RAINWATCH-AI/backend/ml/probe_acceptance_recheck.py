"""Focused re-checks for acceptance: (A) Overview trend/distribution/
timeline charts — do they draw after a longer settle? (B) Simulator
result card after Run Simulation. Saves screenshots + JSON."""
import json
import os

from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:5173"
OUT = "/home/hatch/workspace/acceptance-screenshots"
CHROME = "/home/hatch/.cache/ms-playwright/chromium-1255/chrome-linux64/chrome"

out = {}

with sync_playwright() as pw:
    browser = pw.chromium.launch(executable_path=CHROME)
    page = browser.new_page(viewport={"width": 1440, "height": 900})

    # --- A. Overview charts after 20 s settle ---
    page.goto(f"{BASE}/overview", wait_until="networkidle")
    page.wait_for_timeout(20000)
    charts = page.evaluate(
        """() => {
          const res = {};
          document.querySelectorAll('.recharts-responsive-container').forEach(el => {
            const card = el.closest('div');
            let title = 'unknown';
            let node = el;
            for (let i = 0; i < 6 && node; i++) {
              const h = node.querySelector && node.querySelector('h3, h2, [class*=\"title\"]');
              if (h && h.textContent.trim()) { title = h.textContent.trim().slice(0, 60); break; }
              node = node.parentElement;
            }
            const paths = el.querySelectorAll('svg path, svg rect, svg circle').length;
            const r = el.getBoundingClientRect();
            res[title] = {w: Math.round(r.width), h: Math.round(r.height), shapes: paths};
          });
          return res;
        }"""
    )
    print("OVERVIEW charts after 20s:", json.dumps(charts, indent=1))
    out["overview_charts_20s"] = charts
    page.screenshot(path=f"{OUT}/overview-20s.png", full_page=True)

    # --- B. Simulator run + result ---
    page.goto(f"{BASE}/simulator", wait_until="networkidle")
    page.wait_for_timeout(8000)
    page.get_by_text("Run Simulation", exact=True).first.click()
    page.wait_for_timeout(6000)
    body = page.locator("body").inner_text()
    result_visible = ("Scenario prism" in body) or ("risk index" in body.lower())
    # count comparison-history rows
    hist = page.locator("text=Scenario Comparison").count()
    print("SIMULATOR after run: result_visible=", result_visible,
          "| 'No simulation run yet' still present:", "No simulation run yet" in body)
    out["simulator_after_run"] = {
        "result_visible": result_visible,
        "empty_state_gone": "No simulation run yet" not in body,
    }
    page.screenshot(path=f"{OUT}/simulator-after-run.png", full_page=True)
    browser.close()

with open(f"{OUT}/recheck_results.json", "w") as f:
    json.dump(out, f, indent=2)
print("WROTE recheck_results.json")
