"""Compare base vs GFS PR curves on 2026 at matched thresholds."""
import sys, os, json
sys.path.insert(0, 'ml')
import numpy as np, pandas as pd
import importlib.util
spec = importlib.util.spec_from_file_location("tr32", "ml/train_rainfall_v32.py")
tr32 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tr32)
import joblib
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
import lightgbm as lgb

df = pd.read_csv('data/model_ready/bhubaneswar_features_v32.csv', parse_dates=['timestamp'])
df['timestamp'] = pd.to_datetime(df['timestamp'], utc=True).dt.tz_localize(None)
fresh = df[df['timestamp'].dt.year == 2026].reset_index(drop=True)

def load_probs(variant, target):
    with open(f'models/rainfall_xgb_v3_2/{variant}/feature_schema.json') as f:
        feats = json.load(f)['features']
    with open(f'models/rainfall_xgb_v3_2/{variant}/evaluation.json') as f:
        ev = json.load(f)
    X = fresh[feats].to_numpy(dtype=float)
    w = ev['classifiers'][target]['ensemble_weights']
    platt = ev['classifiers'][target]['platt']
    probs = {}
    stem = target.replace('y_', '')
    for fam in ('xgb', 'lgbm', 'hgb'):
        p = f'models/rainfall_xgb_v3_2/{variant}/clf_{stem}_{fam}'
        if fam == 'xgb':
            m = XGBClassifier()
            m.load_model(p + '.json')
        elif fam == 'lgbm':
            booster = lgb.Booster(model_file=p + '.txt')
            probs[fam] = booster.predict(X)
            continue
        else:
            m = joblib.load(p + '.pkl')
        probs[fam] = m.predict_proba(X)[:, 1]
    ens = np.column_stack([probs[f] for f in ('xgb', 'lgbm', 'hgb')]) @ np.array([w[f] for f in ('xgb', 'lgbm', 'hgb')])
    return tr32.platt_apply(ens, platt['w'], platt['b'])

for target in ('y_3h_ge_10mm', 'y_6h_ge_10mm', 'y_3h_ge_5mm'):
    y = fresh[target].to_numpy()
    base_cal = load_probs('base', target)
    gfs_cal = load_probs('gfs', target)
    print(f"\n{target} (2026, n_pos={int(y.sum())}):")
    print(f"  {'threshold':>9} | {'base P':>7} {'base R':>7} | {'GFS P':>7} {'GFS R':>7}")
    for t in (0.05, 0.08, 0.10, 0.15, 0.20, 0.30):
        def pr(p, t):
            pred = p >= t
            tp = int(((y == 1) & pred).sum())
            fp = int(((y == 0) & pred).sum())
            fn = int(((y == 1) & ~pred).sum())
            return tp / max(1, tp + fp), tp / max(1, tp + fn)
        bp, br = pr(base_cal, t)
        gp, gr = pr(gfs_cal, t)
        print(f"  t={t:>6.2f} | {bp:>7.3f} {br:>7.3f} | {gp:>7.3f} {gr:>7.3f}")
