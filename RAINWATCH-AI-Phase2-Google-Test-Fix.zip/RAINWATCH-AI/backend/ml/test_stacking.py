"""v3.3 Phase 8: OOF stacking test — does a logistic-regression
meta-learner over the per-family probabilities (v32-feature models +
v33-feature models) beat the fixed-weight ensembles?

Protocol (no leakage into 2026, which is untouched):
1. OOF year-split: train the meta-learner on OOF folds 2022-2023,
   test on the 2024 OOF fold. Compare PR-AUC vs the fixed-weight
   ensembles (v32 and v33) on the same 2024 rows.
2. 2025 check: generate 2025 per-family probabilities for both feature
   sets with the base-arm protocol (train 2021-23, weights/Platt on
   2024, refit 2021-24), train the meta-learner on ALL OOF 2022-2024,
   apply it to 2025, and compare PR-AUC vs the fixed ensembles.

Adopt stacking ONLY if it beats the fixed-weight ensembles on BOTH
the 2024 OOF fold and the 2025 benchmark. Otherwise keep the fixed
weights (the simpler, already-validated choice).
"""
import json
import os
import sys

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "ml"))
from train_rainfall_v33 import (  # noqa: E402
    TARGETS,
    _refit_arm,
    _train_arm,
    load_table,
    load_v32_features,
    load_v33_features,
)

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "models",
                   "rainfall_xgb_v3_3")
OOF = os.path.join(OUT, "oof")
FAMS = ("xgb", "lgbm", "hgb")


def _logit(p: np.ndarray) -> np.ndarray:
    p = np.clip(p, 1e-4, 1 - 1e-4)
    return np.log(p / (1 - p))


def _load_oof(target: str):
    a = pd.read_csv(os.path.join(OOF, f"oof_v32_{target}.csv"), parse_dates=["timestamp"])
    b = pd.read_csv(os.path.join(OOF, f"oof_v33_{target}.csv"), parse_dates=["timestamp"])
    m = a.merge(b, on=["timestamp", "y", "fold_val_year"],
                suffixes=("_v32", "_v33"))
    assert len(m) == len(a) == 26304, f"merge mismatch {len(m)}"
    X = np.column_stack([_logit(m[f"p_{f}_v32"].to_numpy()) for f in FAMS]
                        + [_logit(m[f"p_{f}_v33"].to_numpy()) for f in FAMS])
    return m, X


def _probs_2025(target: str, feats: list[str], tr, va, tv, te):
    _, w, platt, _ = _train_arm("base", target, tr, va, feats)
    models = _refit_arm("base", target, tv, feats, w, platt)
    X_te = te[feats].to_numpy(dtype=float)
    return {f: models[f].predict_proba(X_te)[:, 1] for f in FAMS}, w


def main() -> None:
    results: dict = {}
    # ---- Part 1: OOF year-split -------------------------------------
    print("=== Part 1: OOF year-split (train meta 2022-23, test 2024) ===",
          flush=True)
    for target in TARGETS:
        m, X = _load_oof(target)
        y = m["y"].to_numpy().astype(int)
        year = m["fold_val_year"].to_numpy()
        tr_idx = year <= 2023
        te_idx = year == 2024
        meta = LogisticRegression(C=1.0, max_iter=1000)
        meta.fit(X[tr_idx], y[tr_idx])
        p_stack = meta.predict_proba(X[te_idx])[:, 1]
        pr_stack = average_precision_score(y[te_idx], p_stack)
        pr_v32 = average_precision_score(
            y[te_idx], m["p_ens_cal_v32"].to_numpy()[te_idx])
        pr_v33 = average_precision_score(
            y[te_idx], m["p_ens_cal_v33"].to_numpy()[te_idx])
        print(f"  {target} 2024-OOF: stack {pr_stack:.4f} | v32 fixed "
              f"{pr_v32:.4f} | v33 fixed {pr_v33:.4f}", flush=True)
        results[target] = {"oof_2024": {"stack": round(float(pr_stack), 4),
                                        "v32_fixed": round(float(pr_v32), 4),
                                        "v33_fixed": round(float(pr_v33), 4)}}

    # ---- Part 2: 2025 check -----------------------------------------
    print("=== Part 2: 2025 check (meta trained on all OOF 2022-24) ===",
          flush=True)
    df = load_table("v33")
    tr = df[df["timestamp"].dt.year.isin([2021, 2022, 2023])].reset_index(drop=True)
    va = df[df["timestamp"].dt.year == 2024].reset_index(drop=True)
    tv = pd.concat([tr, va], ignore_index=True)
    te = df[df["timestamp"].dt.year == 2025].reset_index(drop=True)
    feats32, feats33 = load_v32_features(), load_v33_features()
    for target in TARGETS:
        m, X = _load_oof(target)
        y_oof = m["y"].to_numpy().astype(int)
        meta = LogisticRegression(C=1.0, max_iter=1000)
        meta.fit(X, y_oof)
        p32, w32 = _probs_2025(target, feats32, tr, va, tv, te)
        p33, w33 = _probs_2025(target, feats33, tr, va, tv, te)
        X25 = np.column_stack([_logit(p32[f]) for f in FAMS]
                              + [_logit(p33[f]) for f in FAMS])
        y25 = te[target].to_numpy().astype(int)
        p_stack = meta.predict_proba(X25)[:, 1]
        ens32 = sum(w32[f] * p32[f] for f in FAMS)
        ens33 = sum(w33[f] * p33[f] for f in FAMS)
        pr_stack = average_precision_score(y25, p_stack)
        pr_v32 = average_precision_score(y25, ens32)
        pr_v33 = average_precision_score(y25, ens33)
        print(f"  {target} 2025: stack {pr_stack:.4f} | v32 fixed "
              f"{pr_v32:.4f} | v33 fixed {pr_v33:.4f}", flush=True)
        results[target]["eval_2025"] = {"stack": round(float(pr_stack), 4),
                                        "v32_fixed": round(float(pr_v32), 4),
                                        "v33_fixed": round(float(pr_v33), 4)}
        np.save(os.path.join(OUT, f"stack_2025_{target}.npy"), p_stack)
    with open(os.path.join(OUT, "stacking.json"), "w") as f:
        json.dump(results, f, indent=2)
    print("saved models/rainfall_xgb_v3_3/stacking.json")


if __name__ == "__main__":
    main()
