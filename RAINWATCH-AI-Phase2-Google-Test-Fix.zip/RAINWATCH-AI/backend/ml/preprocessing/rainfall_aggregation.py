"""Rainfall aggregation for RAINWATCH AI multi-source data (v3.2).

Aggregates rainfall using actual interval semantics:
- Hourly rates (mm/hr) summed over N hours give the N-hour accumulation.
- 30-minute rates (mm/hr) contribute rate * 0.5 mm per half-hour.
- 30-minute accumulations (mm) are summed directly.
- Never sum overlapping accumulation intervals (e.g. do not add a
  3-hour accumulation to a 1-hour accumulation covering the same period).
- Never duplicate rainfall observations.

The functions here take an hourly (or 30-minute) rainfall series and
produce strictly-past accumulations for feature use, and forward
accumulations for targets — the caller must use the correct one.
"""

from __future__ import annotations

import pandas as pd


def hourly_accumulation_from_30min(
    df: pd.DataFrame,
    rate_col: str,
    time_col: str = "timestamp",
) -> pd.DataFrame:
    """Convert a 30-minute rainfall-rate series (mm/hr) to hourly
    accumulations (mm). Each half-hour contributes rate * 0.5 mm.
    Returns an hourly frame with ``precipitation_mm``."""
    out = df.copy()
    out[time_col] = pd.to_datetime(out[time_col], utc=True)
    out = out.sort_values(time_col).reset_index(drop=True)
    out["_mm"] = pd.to_numeric(out[rate_col], errors="coerce") * 0.5
    hourly = (
        out.set_index(time_col)["_mm"]
        .resample("h")
        .sum(min_count=1)
        .rename("precipitation_mm")
        .reset_index()
    )
    return hourly


def past_accumulations(
    hourly_mm: pd.Series,
    windows: tuple[int, ...] = (1, 3, 6, 12, 24),
) -> pd.DataFrame:
    """For an hourly rainfall series (mm per hour), return a frame of
    strictly-past accumulations: ``precip_{w}h_sum`` is the sum of the
    previous ``w`` hours (ending at the previous hour, NOT including the
    current hour). This is the leak-free feature form: at time ``t`` the
    model may only see rainfall up to ``t`` (or ``t-1`` for the current
    hour, depending on the convention — here we use up to and including
    the current hour for the 1h feature, and strictly-past for the
    target-aligned windows). See the docstring of each caller for the
    exact convention used.
    """
    out = pd.DataFrame(index=hourly_mm.index)
    for w in windows:
        out[f"precip_{w}h_sum"] = hourly_mm.rolling(window=w, min_periods=w).sum()
    return out


def forward_accumulations(
    hourly_mm: pd.Series,
    windows: tuple[int, ...] = (1, 3, 6),
) -> pd.DataFrame:
    """Forward accumulations for targets: ``y_{w}h`` is the sum of the
    next ``w`` hours (t+1 .. t+w). Strictly future — no leakage."""
    out = pd.DataFrame(index=hourly_mm.index)
    for w in windows:
        # Sum of hours t+1..t+w = rolling sum shifted by -w.
        out[f"y_{w}h"] = hourly_mm[::-1].rolling(window=w, min_periods=w).sum()[::-1].shift(-w)
    return out
