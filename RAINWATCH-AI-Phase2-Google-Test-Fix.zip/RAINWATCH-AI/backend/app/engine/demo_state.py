"""Demo tick — mirrors ``hackathon/src/services/demoState.ts``.

The tick is bumped when the user presses "Refresh demo data", which
re-seeds every generated series so numbers visibly change. All engine
functions read the current tick.
"""

_tick = 0


def get_demo_tick() -> int:
    return _tick


def bump_demo_tick() -> int:
    global _tick
    _tick += 1
    return _tick
