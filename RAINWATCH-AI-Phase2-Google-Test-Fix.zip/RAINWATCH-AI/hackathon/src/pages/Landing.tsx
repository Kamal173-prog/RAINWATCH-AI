import { motion } from 'framer-motion'
import {
  Activity,
  ArrowDown,
  ArrowRight,
  Bell,
  CloudRain,
  Database,
  FlaskConical,
  Gauge,
  Layers3,
  Map as MapIcon,
  Radar,
  Settings2,
  ShieldCheck,
} from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { Badge, DemoBadge, RiskBadge } from '../components/common/Badge'
import { BrandLogo } from '../components/common/BrandLogo'
import { Button } from '../components/common/Button'
import { Instrument } from '../components/common/Instrument'

const MODULES = [
  {
    title: 'Live Weather',
    desc: 'Demo surface conditions, condition metrics and hourly trend charts for every monitoring region.',
    icon: Activity,
    to: '/live-weather',
    tag: 'OBSERVE',
  },
  {
    title: 'Rainfall Forecast',
    desc: 'Six forecast horizons, intensity classes and accumulating rainfall curves.',
    icon: CloudRain,
    to: '/forecast',
    tag: '3 – 72 HOURS',
  },
  {
    title: 'Flood Intelligence',
    desc: 'Composite risk indices built from rainfall, terrain, drainage and river factors.',
    icon: Gauge,
    to: '/flood-intelligence',
    tag: 'RISK MODEL',
  },
  {
    title: 'Early Warning Alerts',
    desc: 'Severity-ranked alert queues with acknowledgement, dismissal and detail views.',
    icon: Bell,
    to: '/alerts',
    tag: 'ALERT OPS',
  },
]

const PIPELINE = ['Satellite', 'Weather Radar', 'Ground Stations', 'Forecast Inputs', 'Risk Assessment', 'Warning Dashboard']

function TelemetryPlate({
  label,
  value,
  sub,
  className = '',
  color = 'var(--rw-accent)',
}: {
  label: string
  value: string
  sub?: string
  className?: string
  color?: string
}) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 0.6, type: 'spring', stiffness: 260, damping: 24 }}
      className={`plate cut-br absolute w-[168px] border border-line bg-card p-3 ${className}`}
    >
      <p className="mono text-[9px] text-muted">{label}</p>
      <p className="num mt-1 text-2xl leading-none font-bold" style={{ color }}>{value}</p>
      {sub ? <p className="mono mt-1.5 text-[9px] text-muted">{sub}</p> : null}
    </motion.div>
  )
}

export function Landing() {
  const navigate = useNavigate()

  return (
    <div className="min-h-screen overflow-x-hidden bg-bg text-ink">
      {/* ------------------------------ nav ------------------------------ */}
      <header className="sticky top-0 z-50 border-b border-line bg-bg/90 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-[1400px] items-center justify-between gap-4 px-4 sm:px-6">
          <button type="button" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="flex items-center gap-3 text-left">
            <BrandLogo size={36} glow className="transition-transform duration-500 hover:rotate-6" />
            <span>
              <span className="block text-sm leading-none font-bold tracking-[-0.04em]">RAINWATCH <span className="text-accent">AI</span></span>
              <span className="mono mt-1 block text-[8px] text-muted">Predict · Prepare · Protect</span>
            </span>
          </button>

          <nav aria-label="Landing sections" className="hidden items-center gap-7 md:flex">
            <a href="#capabilities" className="mono text-[10px] text-muted transition-colors hover:text-accent">Capabilities</a>
            <a href="#pipeline" className="mono text-[10px] text-muted transition-colors hover:text-accent">Pipeline</a>
            <a href="#demo" className="mono text-[10px] text-muted transition-colors hover:text-accent">Demo data</a>
          </nav>

          <div className="flex items-center gap-2">
            <DemoBadge compact />
            <Button variant="primary" size="sm" icon={<ArrowRight size={13} />} onClick={() => navigate('/overview')}>
              Enter Command Center
            </Button>
          </div>
        </div>
      </header>

      {/* ------------------------------ hero ----------------------------- */}
      <section className="rainfall-bg relative overflow-hidden border-b border-line">
        <span className="pointer-events-none absolute -top-24 -right-24 text-[26vw] leading-none font-bold tracking-[-0.09em] text-accent/4 select-none" aria-hidden>RW</span>
        <div className="relative mx-auto grid max-w-[1400px] items-center gap-12 px-4 py-16 sm:px-6 lg:grid-cols-[1.08fr_0.92fr] lg:py-24">
          <div>
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="mono mb-6 flex items-center gap-3 text-[10px] text-accent">
              <span className="h-1.5 w-1.5 bg-accent" /> Integrated early warning system / API v1.3.0
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.06, ease: [0.16, 1, 0.3, 1] }}
              className="max-w-3xl text-[clamp(2.8rem,7vw,5.6rem)] leading-[0.94] font-bold tracking-[-0.06em] text-ink"
            >
              Predict.<br />
              Prepare.<br />
              <span className="text-accent">Protect.</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.16 }}
              className="mt-7 max-w-xl text-[15px] leading-relaxed text-muted"
            >
              Monitor rainfall, assess flood risk and simulate inundation scenarios in one command
              centre — powered by transparent demo data.
            </motion.p>

            <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.24 }} className="mt-9 flex flex-wrap items-center gap-3">
              <Button variant="primary" icon={<ArrowRight size={15} />} onClick={() => navigate('/overview')}>
                Enter Command Center
              </Button>
              <Button variant="outline" icon={<ArrowDown size={14} />} onClick={() => document.getElementById('capabilities')?.scrollIntoView({ behavior: 'smooth' })}>
                Explore capabilities
              </Button>
            </motion.div>

            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }} className="mt-12 grid max-w-2xl grid-cols-2 gap-x-6 gap-y-5 border-t border-line pt-6 sm:grid-cols-4">
              {[
                ['21', 'MONITORING ZONES'],
                ['72 H', 'FORECAST HORIZON'],
                ['07', 'MAP LAYERS'],
                ['100%', 'DEMO DATA'],
              ].map(([v, k]) => (
                <div key={k}>
                  <p className="num text-2xl font-bold text-ink">{v}</p>
                  <p className="mono mt-1 text-[9px] text-muted">{k}</p>
                </div>
              ))}
            </motion.div>
          </div>

          {/* Instrument composition */}
          <div className="instrument-stage relative mx-auto flex h-[360px] w-full max-w-[520px] items-center justify-center sm:h-[440px]">
            <div className="absolute inset-4 border border-line" aria-hidden />
            <div className="absolute inset-4 border-x border-accent/10" aria-hidden />
            <Instrument size={300} label="Radar / demo" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
              <motion.div
                initial={{ opacity: 0, scale: 0.78 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.28, type: 'spring', stiffness: 190, damping: 18 }}
              >
                <BrandLogo size={128} className="animate-float-y" />
              </motion.div>
            </div>

            <TelemetryPlate
              label="FLOOD RISK INDEX"
              value="59.5"
              sub="SAMPLE · HIGH · 24H WINDOW"
              color="#F0823F"
              className="top-6 right-0 sm:right-2"
            />
            <TelemetryPlate
              label="CURRENT RAINFALL"
              value="46.8"
              sub="SAMPLE · MM / HOUR · OLD TOWN"
              className="bottom-10 left-0 sm:left-2"
            />
            <div className="animate-float-y plate cut-br absolute top-1/2 -right-2 flex items-center gap-2 border border-line bg-card px-3 py-2 sm:-right-6" aria-hidden>
              <Radar size={15} className="text-accent" />
              <span className="mono text-[9px] text-muted">21 MONITORING ZONES</span>
            </div>
            <div className="mono absolute -bottom-1 left-1/2 -translate-x-1/2 text-[9px] text-muted" aria-hidden>
              GEOSPATIAL DEMO / BHUBANESWAR + BRAHMAPUR, ODISHA
            </div>
          </div>
        </div>
      </section>

      {/* --------------------------- capabilities ------------------------- */}
      <section id="capabilities" className="scroll-mt-20 border-b border-line py-16 sm:py-20">
        <div className="mx-auto max-w-[1400px] px-4 sm:px-6">
          <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
            <div>
              <h2 className="text-2xl font-bold tracking-[-0.04em] sm:text-3xl">Command modules</h2>
              <p className="mt-2 max-w-xl text-sm text-muted">Ten working modules, one operational picture. Forecasts and flood-risk records are served live by the integrated backend.</p>
            </div>
            <Badge tone="accent">07 MODULES</Badge>
          </div>

          <div className="grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">
            {/* Featured wide tile */}
            <motion.button
              type="button"
              onClick={() => navigate('/map')}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.45 }}
              whileHover={{ y: -4 }}
              className="plate corner-brackets group relative min-h-[230px] border border-line bg-card p-6 text-left lg:col-span-2"
            >
              <span className="mono text-[9px] text-accent">FEATURED / GEOSPATIAL</span>
              <MapIcon size={22} className="mt-5 text-accent" aria-hidden />
              <h3 className="mt-4 text-xl font-bold tracking-[-0.04em]">Interactive inundation map</h3>
              <p className="mt-2 max-w-lg text-sm leading-relaxed text-muted">
                Pan across two demonstration regions — Bhubaneswar and the Brahmapur–Gopalpur
                coast — switch seven overlay layers, inspect sample risk zones and watch what-if
                warnings appear directly on the map.
              </p>
              <span className="mono mt-6 inline-flex items-center gap-2 text-[10px] text-accent transition-transform group-hover:translate-x-1">
                OPEN MAP <ArrowRight size={13} />
              </span>
            </motion.button>

            <motion.button
              type="button"
              onClick={() => navigate('/simulator')}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.45, delay: 0.06 }}
              whileHover={{ y: -4 }}
              className="plate group border border-line bg-card p-6 text-left"
            >
              <span className="mono text-[9px] text-accent">SCENARIO LAB</span>
              <FlaskConical size={22} className="mt-5 text-accent" aria-hidden />
              <h3 className="mt-4 text-xl font-bold tracking-[-0.04em]">What-if simulator</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted">Adjust rainfall, soil and drainage. Watch a 3D risk prism respond and send the warning to the map.</p>
              <span className="mono mt-6 inline-flex items-center gap-2 text-[10px] text-accent transition-transform group-hover:translate-x-1">RUN A SCENARIO <ArrowRight size={13} /></span>
            </motion.button>

            {MODULES.map((m, i) => {
              const Icon = m.icon
              return (
                <motion.button
                  key={m.title}
                  type="button"
                  onClick={() => navigate(m.to)}
                  initial={{ opacity: 0, y: 16 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.2 }}
                  transition={{ duration: 0.4, delay: i * 0.05 }}
                  whileHover={{ y: -4 }}
                  className="plate group border border-line bg-card p-5 text-left"
                >
                  <div className="flex items-start justify-between">
                    <Icon size={19} className="text-accent" aria-hidden />
                    <span className="mono text-[9px] text-muted">{m.tag}</span>
                  </div>
                  <h3 className="mt-4 text-base font-semibold text-ink">{m.title}</h3>
                  <p className="mt-2 text-xs leading-relaxed text-muted">{m.desc}</p>
                  <span className="mono mt-4 inline-flex items-center gap-1.5 text-[9px] text-accent transition-transform group-hover:translate-x-1">OPEN MODULE <ArrowRight size={12} /></span>
                </motion.button>
              )
            })}
          </div>

          <div className="mt-3 flex flex-wrap gap-2 border-t border-line pt-5">
            <span className="mono mr-2 self-center text-[9px] text-muted">ALSO INCLUDED</span>
            {[
              { label: 'Historical Analysis', to: '/historical', icon: Layers3 },
              { label: 'Data Sources', to: '/data-sources', icon: Database },
              { label: 'Settings', to: '/settings', icon: Settings2 },
            ].map((x) => {
              const Icon = x.icon
              return (
                <button key={x.to} type="button" onClick={() => navigate(x.to)}
                  className="cut-br mono inline-flex items-center gap-2 border border-line bg-surface px-3 py-2 text-[9px] text-muted transition-colors hover:border-accent hover:text-accent">
                  <Icon size={12} aria-hidden /> {x.label.toUpperCase()}
                </button>
              )
            })}
          </div>
        </div>
      </section>

      {/* ----------------------------- pipeline --------------------------- */}
      <section id="pipeline" className="scroll-mt-20 border-b border-line py-16 sm:py-20">
        <div className="mx-auto max-w-[1400px] px-4 sm:px-6">
          <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
            <div>
              <h2 className="text-2xl font-bold tracking-[-0.04em] sm:text-3xl">From observation to warning</h2>
              <p className="mt-2 text-sm text-muted">The pipeline the production platform is designed around.</p>
            </div>
            <Button size="sm" variant="outline" icon={<ArrowRight size={13} />} onClick={() => navigate('/data-sources')}>View data sources</Button>
          </div>

          <div className="plate grid grid-cols-2 gap-px border border-line bg-line md:grid-cols-3 lg:grid-cols-6">
            {PIPELINE.map((node, i) => (
              <div key={node} className="relative bg-card p-4">
                <span className="mono text-[9px] text-accent">{String(i + 1).padStart(2, '0')}</span>
                <p className="mt-3 text-xs leading-tight font-semibold text-ink">{node}</p>
                <div className="absolute right-0 bottom-0 left-0 h-0.5 bg-accent/15">
                  <motion.div
                    className="h-full bg-accent"
                    initial={{ width: '0%' }}
                    whileInView={{ width: '100%' }}
                    viewport={{ once: true }}
                    transition={{ duration: 1.1, delay: i * 0.12, ease: [0.16, 1, 0.3, 1] }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* --------------------------- demo honesty ------------------------- */}
      <section id="demo" className="scroll-mt-20 border-b border-line py-16 sm:py-20">
        <div className="mx-auto grid max-w-[1400px] gap-10 px-4 sm:px-6 lg:grid-cols-[1fr_1fr]">
          <div>
            <DemoBadge />
            <h2 className="mt-5 text-3xl leading-[1.05] font-bold tracking-[-0.05em] sm:text-4xl">
              Everything you see is<br /><span className="text-accent">illustrative.</span>
            </h2>
            <p className="mt-5 max-w-xl text-sm leading-relaxed text-muted">
              This is an integrated demonstration. Bhubaneswar-region forecasts and flood-risk records come from the
              trained ML ensemble via the backend; rainfall series, alert records and inundation polygons are
              generated locally so every interaction can be explored end to end — without pretending to be an
              operational forecast.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Button variant="primary" icon={<ArrowRight size={14} />} onClick={() => navigate('/overview')}>Explore the dashboard</Button>
              <Button variant="outline" onClick={() => navigate('/data-sources')}>Integration roadmap</Button>
            </div>
          </div>

          <div className="plate corner-brackets border border-line bg-card p-6">
            <div className="mono mb-5 flex items-center gap-2 border-b border-line pb-4 text-[10px] text-muted">
              <ShieldCheck size={14} className="text-accent" /> DEMO BOUNDARIES / HONEST STATUS
            </div>
            <div className="space-y-4">
              {[
                ['Mixed live and demo data', 'Bhubaneswar-region forecasts and flood-risk records come from the ML ensemble; Ganjam locations, alert statuses and scenario results are demo-generated.'],
                ['Stored locally', 'Theme, units, alert acknowledgements, selected region and map layers persist in localStorage.'],
                ['No satellite, radar or station feeds', 'No satellite feed, radar mosaic, NWP model or station network is attached yet. The backend serves the ML ensemble and the ERA5 archive.'],
                ['Not for emergency decisions', 'All warnings and overlays are teaching examples, not validated predictions.'],
              ].map(([title, body]) => (
                <div key={title} className="flex gap-3 border-l-2 border-accent/50 pl-3">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 bg-accent" aria-hidden />
                  <div>
                    <p className="text-sm font-semibold text-ink">{title}</p>
                    <p className="mt-0.5 text-xs leading-relaxed text-muted">{body}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ---------------------------- final CTA --------------------------- */}
      <section className="rainfall-bg py-16 sm:py-24">
        <div className="mx-auto max-w-[1400px] px-4 text-center sm:px-6">
          <BrandLogo size={64} className="mx-auto" />
          <h2 className="mx-auto mt-5 max-w-3xl text-3xl leading-[1.05] font-bold tracking-[-0.05em] sm:text-5xl">
            The command centre is ready.
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-sm text-muted">Ten working modules. Sixty-plus interactions. Served live by the integrated backend.</p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Button variant="primary" icon={<ArrowRight size={15} />} onClick={() => navigate('/overview')}>Enter Command Center</Button>
            <RiskBadge level="High" />
            <Badge tone="muted">INTEGRATED DEMO</Badge>
          </div>
        </div>
      </section>

      <footer className="border-t border-line px-4 py-6 text-[10px] leading-relaxed text-muted sm:px-6">
        <div className="mx-auto flex max-w-3xl flex-wrap items-center justify-center gap-3 text-center">
          <BrandLogo size={28} />
          <span>
            RAINWATCH AI · Predict. Prepare. Protect. — Frontend demonstration build. All data is simulated and
            must never be used for real-world emergency decisions.
          </span>
        </div>
      </footer>
    </div>
  )
}
