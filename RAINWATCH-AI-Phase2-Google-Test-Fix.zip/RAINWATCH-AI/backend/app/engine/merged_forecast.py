"""Merged forecast — source priority MODEL > GOOGLE WEATHER > UNAVAILABLE.

Builds the Forecast page's primary series from the existing pieces,
without touching them:

- Base series: ``get_forecast_series`` (rainfall.py) — hours 1-6 are
  the trained ensemble model (Bhubaneswar region only), hours 7+ are
  the deterministic demo engine. Model points are kept byte-identical.
- Non-model hours: replaced by genuine Google Weather forecasts
  (``app.services.google_weather``) where Google can provide one.
  Synthetic demo values are NEVER shown in this series.
- If Google cannot provide a value for an hour (no key, quota, timeout,
  missing precipitation, no matching interval), that hour is
  UNAVAILABLE — never fabricated, never silently substituted.

Scientific rules (from the 2026-11-25 brief):
- v3.3 is not modified or retrained; thresholds are untouched.
- Model and Google values are never averaged or combined.
- Google data is never fed into the ML model.
- Google's QPF (mm that fell in the hour) and the model's hourly rate
  (mm/hr) are different quantities: they are carried in separate
  fields and labelled with ``valueKind`` ("google_qpf_mm" vs
  "model_rate_mm_hr"), never treated as interchangeable.
- Google's precipitation probability is NOT confidence: it is carried
  in ``precipitationProbabilityPct``; ``confidence`` is null on Google
  and unavailable rows.

Timestamp matching: RAINWATCH hours are UTC hour-aligned; Google's
hour intervals are aligned to the location's LOCAL hour (for IST that
is :30 UTC), so exact-timestamp matching would fail. For RAINWATCH
hour H, the Google point whose [startTime, endTime) interval CONTAINS
H is used; if none contains H, the point with the nearest startTime
within 60 minutes; otherwise the hour is UNAVAILABLE. This also
handles the mock server's UTC-aligned fixture.

The Google service is imported lazily inside the function so a Google
failure can never break import or the model path, and this function
never raises for Google problems: any Google failure degrades to
UNAVAILABLE rows with the reason recorded in ``meta.google``.
"""

import logging
from datetime import datetime, timezone
from typing import Any, Optional

from app.engine.rainfall import get_forecast_series
from app.engine.rng import classify_rainfall, js_round

logger = logging.getLogger("rainwatch.merged_forecast")

# Nearest-start fallback window (seconds). Google intervals are hourly,
# so a RAINWATCH hour at most 60 minutes from the nearest Google start
# belongs to that interval even when the interval end is unknown or the
# fixture is truncated at the range edge.
NEAREST_START_WINDOW_SECONDS = 3600


def _parse_ts(value: Optional[str]) -> Optional[datetime]:
    """Parse an ISO timestamp (with 'Z' or an offset) to an aware UTC datetime."""
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _match_google_hour(target: datetime, google_points: list[dict]) -> Optional[dict]:
    """Find the Google point covering RAINWATCH hour ``target``.

    1. The point whose [startTime, endTime) interval contains it.
    2. Else the point with the nearest startTime within 60 minutes.
    3. Else None.
    """
    for gp in google_points:
        start = _parse_ts(gp.get("timestamp"))
        end = _parse_ts(gp.get("endTime"))
        if start is not None and end is not None and start <= target < end:
            return gp
    best: Optional[dict] = None
    best_diff: Optional[float] = None
    for gp in google_points:
        start = _parse_ts(gp.get("timestamp"))
        if start is None:
            continue
        diff = abs((start - target).total_seconds())
        if diff <= NEAREST_START_WINDOW_SECONDS and (best_diff is None or diff < best_diff):
            best, best_diff = gp, diff
    return best


def get_merged_forecast(location_id: str, hours: int) -> dict:
    """Merged forecast for ``location_id`` over the next ``hours`` hours.

    Returns {"locationId", "hours", "points", "meta"} where meta carries
    the model version / model-hour count, the Google status, and the
    per-source counts. Never raises for Google problems.
    """
    base = get_forecast_series(location_id)[:hours]

    model_points = [p for p in base if p.get("source") == "model"]
    model_version = None
    for p in model_points:
        if p.get("model_version"):
            model_version = p["model_version"]
            break

    needs_google = any(p.get("source") != "model" for p in base)
    google_status = "not_needed"
    google_reason: Optional[str] = None
    google_retrieved_at: Optional[str] = None
    google_cached = False
    google_records = 0
    google_points: list[dict] = []

    if needs_google:
        try:
            from app.services import google_weather as google_service

            payload = google_service.get_google_forecast(location_id, hours)
            google_points = payload.get("hours", [])
            google_status = "ok"
            google_retrieved_at = payload.get("retrievedAt")
            google_cached = bool(payload.get("meta", {}).get("cached", False))
            google_records = len(google_points)
        except Exception as exc:  # noqa: BLE001 - Google must never break the merge
            from app.services.google_weather import GoogleWeatherNotConfigured

            if isinstance(exc, GoogleWeatherNotConfigured):
                google_status = "not_configured"
            else:
                google_status = "error"
            google_reason = str(exc)
            logger.warning(
                "Merged forecast %s: Google unavailable (%s) — non-model hours are UNAVAILABLE",
                location_id, google_reason)

    points: list[dict] = []
    running_total = 0.0
    total_unknown = False
    counts = {"model": 0, "google_weather": 0, "unavailable": 0}

    for base_point in base:
        ts = base_point["timestamp"]
        if base_point.get("source") == "model":
            # Byte-identical: values, model_version, model detail,
            # confidence and classification are copied untouched.
            point = dict(base_point)
            point["valueKind"] = "model_rate_mm_hr"
            running_total = float(base_point["accumulatedMm"])
            points.append(point)
            counts["model"] += 1
            continue

        target = _parse_ts(ts)
        matched = _match_google_hour(target, google_points) if target is not None else None
        qpf = matched.get("precipitationMm") if matched is not None else None
        if matched is None or qpf is None:
            points.append({
                "locationId": location_id,
                "timestamp": ts,
                "rainfallMmHr": None,
                "valueKind": None,
                "accumulatedMm": None,
                "confidence": None,
                "classification": None,
                "source": "unavailable",
            })
            total_unknown = True
            counts["unavailable"] += 1
            continue

        running_total += float(qpf)
        accumulated = None if total_unknown else js_round(running_total, 1)
        points.append({
            "locationId": location_id,
            "timestamp": ts,
            "rainfallMmHr": qpf,
            "valueKind": "google_qpf_mm",
            "accumulatedMm": accumulated,
            "confidence": None,
            "classification": classify_rainfall(qpf),
            "source": "google_weather",
            "precipitationProbabilityPct": matched.get("precipitationProbabilityPct"),
            "precipitationType": matched.get("precipitationType"),
            "temperatureC": matched.get("temperatureC"),
            "relativeHumidityPct": matched.get("relativeHumidityPct"),
            "windSpeedKmh": matched.get("windSpeedKmh"),
            "windDirectionDeg": matched.get("windDirectionDeg"),
            "condition": matched.get("condition"),
            "conditionText": matched.get("conditionText"),
            "googleTimestamp": matched.get("timestamp"),
        })
        counts["google_weather"] += 1

    return {
        "locationId": location_id,
        "hours": hours,
        "points": points,
        "meta": {
            "model": {
                "model_version": model_version,
                "modelHours": len(model_points),
            },
            "google": {
                "status": google_status,
                "reason": google_reason,
                "retrievedAt": google_retrieved_at,
                "cached": google_cached,
                "recordsRetrieved": google_records,
            },
            "sources": counts,
        },
    }
