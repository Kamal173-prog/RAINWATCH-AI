"""Tests for the satellite endpoints (GET /api/satellite/*, Phase 2).

The Phase 1 service is mocked at the module level (monkeypatch on
app.services.satellite_rainfall) — these tests assert the HTTP
contracts only: status codes, error mapping, response shapes, and the
coverage note. NO live NASA calls, no real credentials anywhere.

The mocked payloads are structural stand-ins built from the real
RAINWATCH location coordinates (so the production coverage-note code
runs against real geography); they are never presented as real
observations.
"""

import pytest

from app.engine import locations as locations_engine
from app.services import satellite_rainfall as sat

GRANULE_FILE = "3B-HHR-E.MS.MRG.3IMERG.20261125-S030000-E032959.0180.V07C.HDF5"


def mock_granule_meta():
    """Full cached-granule metadata, as get_rainfall_for_region returns it."""
    return {
        "filename": GRANULE_FILE,
        "nativeId": "3B-HHR-E.MS.MRG.3IMERG.20261125-S030000-E032959.0180",
        "conceptId": "C2723758340-GES_DISC",
        "version": "V07C",
        "observationStartUtc": "2026-11-25T03:00:00Z",
        "observationEndUtc": "2026-11-25T03:29:59Z",
        "observationIntervalMinutes": 30,
        "sizeBytes": 7069601,
        "sha256": "0" * 64,
        "path": "/tmp/mock/" + GRANULE_FILE,
        "retrievedAtUtc": "2026-11-25T03:30:00Z",
        "cached": True,
    }


def mock_point(lat, lon, status="VALID_RAINFALL", rate=2.5):
    """One section-H response dict, as get_rainfall_for_location returns it."""
    return {
        "source": "NASA GPM IMERG",
        "product": "IMERG Early Run",
        "version": "V07C",
        "location": {"latitude": lat, "longitude": lon},
        "gridCell": {"latitude": 20.25, "longitude": 85.85,
                     "latIndex": 697, "lonIndex": 2658, "distanceKm": 1.99},
        "precipitationRateMmHr": rate,
        "accumulationMm": (rate * 0.5) if rate is not None else None,
        "observationTimeUtc": "2026-11-25T03:00:00Z",
        "observationTimeIst": "2026-11-25T08:30:00+05:30",
        "observationIntervalMinutes": 30,
        "status": status,
        "granule": {
            "filename": GRANULE_FILE,
            "nativeId": "3B-HHR-E.MS.MRG.3IMERG.20261125-S030000-E032959.0180",
            "conceptId": "C2723758340-GES_DISC",
            "version": "V07C",
        },
        "retrievedAtUtc": "2026-11-25T03:30:00Z",
    }


def mock_region_body(region_id):
    """Region body with one mock point per location inside the bbox."""
    reg = locations_engine.get_region(region_id)
    bbox = reg["bbox"]
    inside = [loc for loc in locations_engine.LOCATIONS
              if bbox[0] <= loc["lat"] <= bbox[2]
              and bbox[1] <= loc["lng"] <= bbox[3]]
    return {
        "region": {"id": reg["id"], "name": reg["name"],
                   "shortName": reg.get("shortName"), "bbox": list(bbox)},
        "granule": mock_granule_meta(),
        "locations": [mock_point(loc["lat"], loc["lng"]) for loc in inside],
    }


@pytest.fixture(autouse=True)
def _reset_satellite(monkeypatch):
    sat.reset_state()
    monkeypatch.delenv("EARTHDATA_USERNAME", raising=False)
    monkeypatch.delenv("EARTHDATA_PASSWORD", raising=False)
    yield
    sat.reset_state()


# ------------------------------------------------------------------
# GET /api/satellite/status — always 200
# ------------------------------------------------------------------

def test_status_not_configured(v3_client, monkeypatch):
    monkeypatch.setattr(sat, "get_satellite_status", lambda: {
        "configured": False, "status": "Not Configured",
        "lastRetrievedAt": None, "recordsRetrieved": 0,
        "error": None, "cachedGranules": 0, "latestGranule": None,
    })
    r = v3_client.get("/api/satellite/status")
    assert r.status_code == 200
    body = r.json()
    assert body["configured"] is False
    assert body["status"] == "Not Configured"
    assert body["cachedGranules"] == 0
    assert body["latestGranule"] is None


def test_status_ready(v3_client, monkeypatch):
    monkeypatch.setattr(sat, "get_satellite_status", lambda: {
        "configured": True, "status": "Ready",
        "lastRetrievedAt": "2026-11-25T03:30:00Z", "recordsRetrieved": 1,
        "error": None, "cachedGranules": 1, "latestGranule": GRANULE_FILE,
    })
    r = v3_client.get("/api/satellite/status")
    assert r.status_code == 200
    body = r.json()
    assert body["configured"] is True
    assert body["status"] == "Ready"
    assert body["cachedGranules"] == 1
    assert body["latestGranule"] == GRANULE_FILE


def test_status_error_still_200(v3_client, monkeypatch):
    monkeypatch.setattr(sat, "get_satellite_status", lambda: {
        "configured": True, "status": "Error",
        "lastRetrievedAt": "2026-11-25T03:30:00Z", "recordsRetrieved": 0,
        "error": "Earthdata login failed: mock", "cachedGranules": 0,
        "latestGranule": None,
    })
    r = v3_client.get("/api/satellite/status")
    assert r.status_code == 200
    assert r.json()["status"] == "Error"
    assert "mock" in r.json()["error"]


# ------------------------------------------------------------------
# GET /api/satellite/rainfall — happy paths
# ------------------------------------------------------------------

def test_rainfall_valid_passthrough(v3_client, monkeypatch):
    seen = {}

    def fake(lat, lon, obs_time=None):
        seen["args"] = (lat, lon, obs_time)
        return mock_point(lat, lon)

    monkeypatch.setattr(sat, "get_rainfall_for_location", fake)
    r = v3_client.get("/api/satellite/rainfall?latitude=20.2662&longitude=85.8418")
    assert r.status_code == 200
    body = r.json()
    assert seen["args"] == (20.2662, 85.8418, None)
    assert body["source"] == "NASA GPM IMERG"
    assert body["product"] == "IMERG Early Run"
    assert body["version"] == "V07C"
    assert body["status"] == "VALID_RAINFALL"
    assert body["precipitationRateMmHr"] == 2.5
    assert body["accumulationMm"] == 1.25
    assert body["location"] == {"latitude": 20.2662, "longitude": 85.8418}
    assert body["gridCell"]["latitude"] == 20.25
    assert body["gridCell"]["distanceKm"] == 1.99
    assert body["observationTimeUtc"] == "2026-11-25T03:00:00Z"
    assert body["observationTimeIst"] == "2026-11-25T08:30:00+05:30"
    assert body["granule"]["filename"] == GRANULE_FILE


def test_rainfall_observation_time_passed_through(v3_client, monkeypatch):
    seen = {}

    def fake(lat, lon, obs_time=None):
        seen["obs_time"] = obs_time
        return mock_point(lat, lon)

    monkeypatch.setattr(sat, "get_rainfall_for_location", fake)
    r = v3_client.get("/api/satellite/rainfall?latitude=20.2662&longitude=85.8418"
                      "&observationTime=2026-11-25T03:10:00Z")
    assert r.status_code == 200
    assert seen["obs_time"] == "2026-11-25T03:10:00Z"


def test_rainfall_valid_zero(v3_client, monkeypatch):
    monkeypatch.setattr(
        sat, "get_rainfall_for_location",
        lambda lat, lon, obs_time=None: mock_point(lat, lon, status="VALID_ZERO", rate=0.0))
    r = v3_client.get("/api/satellite/rainfall?latitude=20.2662&longitude=85.8418")
    assert r.status_code == 200
    assert r.json()["status"] == "VALID_ZERO"
    assert r.json()["precipitationRateMmHr"] == 0.0
    assert r.json()["accumulationMm"] == 0.0


def test_rainfall_missing_is_200_with_nulls(v3_client, monkeypatch):
    monkeypatch.setattr(
        sat, "get_rainfall_for_location",
        lambda lat, lon, obs_time=None: mock_point(lat, lon, status="MISSING", rate=None))
    r = v3_client.get("/api/satellite/rainfall?latitude=20.2662&longitude=85.8418")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "MISSING"
    assert body["precipitationRateMmHr"] is None
    assert body["accumulationMm"] is None


# ------------------------------------------------------------------
# GET /api/satellite/rainfall — validation and errors
# ------------------------------------------------------------------

def test_rainfall_latitude_out_of_range_422(v3_client):
    r = v3_client.get("/api/satellite/rainfall?latitude=100&longitude=85.8418")
    assert r.status_code == 422


def test_rainfall_longitude_out_of_range_422(v3_client):
    r = v3_client.get("/api/satellite/rainfall?latitude=20.2662&longitude=200")
    assert r.status_code == 422


def test_rainfall_bad_observation_time_400(v3_client, monkeypatch):
    def fake(lat, lon, obs_time=None):
        raise ValueError("Invalid observationTime: 'not-a-time'")

    monkeypatch.setattr(sat, "get_rainfall_for_location", fake)
    r = v3_client.get("/api/satellite/rainfall?latitude=20.2662&longitude=85.8418"
                      "&observationTime=not-a-time")
    assert r.status_code == 400
    assert "not-a-time" in r.json()["detail"]


def test_rainfall_not_configured_503(v3_client, monkeypatch):
    def fake(lat, lon, obs_time=None):
        raise sat.SatelliteNotConfigured("Earthdata credentials not configured")

    monkeypatch.setattr(sat, "get_rainfall_for_location", fake)
    r = v3_client.get("/api/satellite/rainfall?latitude=20.2662&longitude=85.8418")
    assert r.status_code == 503
    assert "not configured" in r.json()["detail"]


def test_rainfall_service_error_502(v3_client, monkeypatch):
    def fake(lat, lon, obs_time=None):
        raise sat.SatelliteError("Earthdata login failed: mock")

    monkeypatch.setattr(sat, "get_rainfall_for_location", fake)
    r = v3_client.get("/api/satellite/rainfall?latitude=20.2662&longitude=85.8418")
    assert r.status_code == 502
    assert "mock" in r.json()["detail"]


# ------------------------------------------------------------------
# GET /api/satellite/rainfall/region
# ------------------------------------------------------------------

def test_region_bhubaneswar_12_locations_and_coverage_note(v3_client, monkeypatch):
    monkeypatch.setattr(
        sat, "get_rainfall_for_region",
        lambda region: mock_region_body(region))
    r = v3_client.get("/api/satellite/rainfall/region?region=bhubaneswar")
    assert r.status_code == 200
    body = r.json()
    assert body["region"]["id"] == "bhubaneswar"
    assert len(body["locations"]) == 12
    # The bounding box excludes Cuttack and Puri — the note must say so.
    assert body["coverageNote"] == (
        "Bhubaneswar region returns 12 of 14 locations; "
        "Cuttack and Puri lie outside the region bounding box.")
    assert body["granule"]["filename"] == GRANULE_FILE
    assert body["granule"]["cached"] is True


def test_region_ganjam_7_locations_complete(v3_client, monkeypatch):
    monkeypatch.setattr(
        sat, "get_rainfall_for_region",
        lambda region: mock_region_body(region))
    r = v3_client.get("/api/satellite/rainfall/region?region=ganjam")
    assert r.status_code == 200
    body = r.json()
    assert body["region"]["id"] == "ganjam"
    assert len(body["locations"]) == 7
    assert body["coverageNote"] == (
        "All 7 Ganjam locations are inside the region bounding box.")


def test_region_unknown_id_400(v3_client, monkeypatch):
    def fake(region):
        raise ValueError("Unknown region id: 'nowhere'")

    monkeypatch.setattr(sat, "get_rainfall_for_region", fake)
    r = v3_client.get("/api/satellite/rainfall/region?region=nowhere")
    assert r.status_code == 400
    assert "nowhere" in r.json()["detail"]


def test_region_not_configured_503(v3_client, monkeypatch):
    def fake(region):
        raise sat.SatelliteNotConfigured("Earthdata credentials not configured")

    monkeypatch.setattr(sat, "get_rainfall_for_region", fake)
    r = v3_client.get("/api/satellite/rainfall/region?region=bhubaneswar")
    assert r.status_code == 503


def test_region_service_error_502(v3_client, monkeypatch):
    def fake(region):
        raise sat.SatelliteError("No granules found: mock")

    monkeypatch.setattr(sat, "get_rainfall_for_region", fake)
    r = v3_client.get("/api/satellite/rainfall/region?region=bhubaneswar")
    assert r.status_code == 502
    assert "mock" in r.json()["detail"]
