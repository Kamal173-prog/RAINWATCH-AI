# v3.2 Experiments — Results and Ablations

Date: 2026-11-23. All experiments use the same protocol: train 2021–2023,
validation 2024, test 2025 (historical benchmark), fresh evaluation 2026
(Jan–Nov, never used for model selection). Seed 42. Classifiers: XGBoost
+ LightGBM + HistGradientBoosting ensemble, v3.1 tuned hyperparameters,
Platt calibration on validation, dual thresholds optimised on validation
for max precision subject to recall floors.

## Experiment summary

| Variant | Features | 2025 PR-AUC (3h≥10mm) | 2026 PR-AUC (3h≥10mm) |
|---|---|---|---|
| v3.2-base | v3 41 only | 0.1625 | 0.2556 |
| **v3.2-GFS** | v3 41 + 12 GFS | **0.2228** | **0.2983** |
| v3.2-IFS | v3 41 + 12 IFS | 0.1625 (IFS dropped) | 0.2556 (IFS dropped) |
| v3.2-GFS+IFS | v3 41 + 12 GFS + 12 IFS | 0.2228 (IFS dropped) | 0.2983 (IFS dropped) |

## v3.2-GFS vs v3-base — full results

### PR-AUC (threshold-independent)

| Event | 2025 base | 2025 GFS | Δ | 2026 base | 2026 GFS | Δ |
|---|---|---|---|---|---|---|
| 3h ≥ 10 mm | 0.1625 | 0.2228 | **+0.060** | 0.2556 | 0.2983 | **+0.043** |
| 6h ≥ 10 mm | 0.2002 | 0.2371 | **+0.037** | 0.3957 | 0.4293 | **+0.034** |
| 3h ≥ 5 mm | 0.3385 | 0.3575 | **+0.019** | 0.4396 | 0.4898 | **+0.050** |

PR-AUC improves on all three events, on both evaluation periods.

### Operating points — 2026 fresh evaluation

| Event | Level | Base P / R / F1 | GFS P / R / F1 |
|---|---|---|---|
| 3h ≥ 10 mm | elevated | 0.280 / 0.373 / 0.320 | 0.226 / 0.535 / 0.318 |
| 3h ≥ 10 mm | high | 0.290 / 0.324 / 0.306 | 0.254 / 0.476 / 0.331 |
| 6h ≥ 10 mm | elevated | 0.287 / 0.766 / 0.418 | 0.276 / 0.801 / 0.411 |
| 6h ≥ 10 mm | high | 0.404 / 0.409 / 0.406 | **0.442 / 0.480 / 0.460** |
| 3h ≥ 5 mm | elevated | 0.358 / 0.641 / 0.460 | **0.393 / 0.603 / 0.476** |
| 3h ≥ 5 mm | high | 0.476 / 0.378 / 0.421 | **0.522 / 0.413 / 0.461** |

### Operating points — 2025 benchmark

| Event | Level | Base P / R | GFS P / R |
|---|---|---|---|
| 3h ≥ 10 mm | elevated | 0.135 / 0.241 | **0.163 / 0.448** |
| 6h ≥ 10 mm | elevated | 0.132 / 0.698 | **0.137 / 0.752** |
| 3h ≥ 5 mm | elevated | 0.259 / 0.653 | **0.306 / 0.568** |

On 2025, precision AND recall both improve for the heavy events.

### PR-curve comparison at matched thresholds (2026, 3h ≥ 10 mm)

| Threshold | Base P / R | GFS P / R |
|---|---|---|
| 0.05 | 0.180 / 0.573 | 0.168 / 0.686 |
| 0.08 | 0.280 / 0.373 | 0.254 / 0.476 |
| 0.10 | 0.319 / 0.286 | 0.318 / 0.373 |
| 0.15 | 0.474 / 0.146 | 0.477 / 0.222 |
| 0.20 | 0.611 / 0.059 | 0.538 / 0.114 |

At matched precision, GFS achieves higher recall (e.g. at t=0.10 both
P≈0.32, but GFS recall 0.373 vs base 0.286; at t=0.15 both P≈0.475, but
GFS recall 0.222 vs base 0.146). The GFS model's PR curve is better;
the operating-point precision drop at the 2024-optimised thresholds is
a threshold-calibration effect, not a model deficiency.

## Ablation: GFS feature importance

Permutation importance on the 2024 validation set (3h ≥ 10 mm, XGB member):

| Rank | Feature | PR-AUC drop when permuted |
|---|---|---|
| 1 | `precip_max24h` (ERA5) | +0.234 |
| **2** | **`gfs_precip_6h_sum`** | **+0.175** |
| 3 | `cloud_cover_mid_pct` (ERA5) | +0.136 |
| 4 | `bay_pressure_grad` (spatial) | +0.119 |
| 5 | `precip_sum72h` (ERA5) | +0.109 |
| 8 | `gfs_wind_v` | +0.093 |

2 GFS features in the top 15. `gfs_precip_6h_sum` is the second most
important feature overall. The GFS features are genuinely important,
not noise.

## Failed experiments

- **v3.2-IFS:** ECMWF IFS is only available from 2024-02-02, so all 12
  IFS features are entirely NaN in the 2021–2023 training set. They
  were dropped, and the IFS variant reduces exactly to the base model
  (identical metrics). IFS cannot be used with the current chronological
  split. This is a data-availability limitation, not a modelling failure.
- **v3.2-GFS+IFS:** identical to v3.2-GFS (IFS features dropped).

## What was NOT tested

- INSAT, IMD stations, MSWEP, GSMaP, ERA5-Land: not acquired (see
  V32_EXTERNAL_ACCESS.md). Their experiments (v3.2-A, v3.2-B, v3.2-C,
  v3.2-D, v3.2-E) are pending on Kam providing access.
- Regression (1h/3h/6h MAE/RMSE) for v3.2: the regressors are carried
  over from v3 unchanged; the GFS features were only evaluated for the
  classifiers. Testing whether GFS features improve the regressors is
  future work.
