import { AnimatePresence, motion } from 'framer-motion'
import {
  BellRing,
  CloudRain,
  CloudSun,
  Database,
  FlaskConical,
  LayoutDashboard,
  LineChart,
  Map as MapIcon,
  PanelLeftClose,
  PanelLeftOpen,
  Settings as SettingsIcon,
  Waves,
  X,
} from 'lucide-react'
import { Link, NavLink } from 'react-router-dom'
import type { LucideIcon } from 'lucide-react'
import { useAlerts } from '../../context/AlertsContext'
import { DemoBadge } from '../common/Badge'
import { BrandLogo } from '../common/BrandLogo'

export interface NavItem {
  to: string
  label: string
  icon: LucideIcon
  end?: boolean
}

export const NAV_ITEMS: NavItem[] = [
  { to: '/overview', label: 'Overview', icon: LayoutDashboard, end: true },
  { to: '/live-weather', label: 'Live Weather', icon: CloudSun },
  { to: '/forecast', label: 'Rainfall Forecast', icon: CloudRain },
  { to: '/flood-intelligence', label: 'Flood Intelligence', icon: Waves },
  { to: '/map', label: 'Inundation Map', icon: MapIcon },
  { to: '/simulator', label: 'What-If Simulator', icon: FlaskConical },
  { to: '/alerts', label: 'Early Warning Alerts', icon: BellRing },
  { to: '/historical', label: 'Historical Analysis', icon: LineChart },
  { to: '/data-sources', label: 'Data Sources', icon: Database },
  { to: '/settings', label: 'Settings', icon: SettingsIcon },
]

function NavEntry({
  item,
  index,
  collapsed,
  badge,
  onNavigate,
}: {
  item: NavItem
  index: number
  collapsed: boolean
  badge?: number
  onNavigate?: () => void
}) {
  const Icon = item.icon
  return (
    <NavLink
      to={item.to}
      end={item.end}
      onClick={onNavigate}
      title={collapsed ? item.label : undefined}
      className={({ isActive }) =>
        `group relative flex items-center gap-3 py-2.5 text-sm font-medium transition-all duration-200 ${
          collapsed ? 'justify-center px-0' : 'px-3'
        } ${
          isActive
            ? 'cut-br border-l-2 border-accent bg-accent/12 text-accent'
            : 'border-l-2 border-transparent text-muted hover:bg-surface hover:text-ink'
        }`
      }
    >
      {({ isActive }) => (
        <>
          {isActive ? (
            <motion.span
              layoutId="nav-active"
              className="absolute top-1/2 -left-3 h-6 w-1 -translate-y-1/2 bg-accent"
              transition={{ type: 'spring', stiffness: 420, damping: 34 }}
              aria-hidden
            />
          ) : null}
          <span className="relative shrink-0">
            <Icon size={18} aria-hidden />
            {badge && badge > 0 ? (
              <span className="absolute -top-1.5 -right-2 flex h-4 min-w-4 items-center justify-center rounded-full bg-critical px-1 text-[9px] font-bold text-white">
                {badge > 99 ? '99+' : badge}
              </span>
            ) : null}
          </span>
          {!collapsed ? (
            <span className="flex min-w-0 flex-1 items-center gap-2">
              <span className="truncate">{item.label}</span>
              <span className="mono ml-auto text-[9px] text-muted/60">{String(index + 1).padStart(2, '0')}</span>
            </span>
          ) : null}
          {collapsed ? (
            <span className="pointer-events-none absolute left-full z-50 ml-3 hidden rounded-lg border border-line bg-surface px-2.5 py-1.5 text-xs whitespace-nowrap text-ink opacity-0 shadow-[3px_3px_0_#050708] transition-opacity duration-150 group-hover:opacity-100 lg:block">
              {item.label}
            </span>
          ) : null}
        </>
      )}
    </NavLink>
  )
}

interface SidebarProps {
  collapsed: boolean
  onToggleCollapse: () => void
  mobileOpen: boolean
  onCloseMobile: () => void
}

export function Sidebar({ collapsed, onToggleCollapse, mobileOpen, onCloseMobile }: SidebarProps) {
  const { activeCountValue } = useAlerts()

  const body = (
    <div className="flex h-full flex-col">
      {/* Brand */}
      <Link to="/" title="Back to landing page" className={`flex items-center gap-3 border-b border-line px-4 py-4 transition-colors hover:bg-surface ${collapsed ? 'justify-center px-2' : ''}`}>
        <BrandLogo size={40} className="transition-transform duration-500 hover:rotate-6 hover:scale-105" />
        {!collapsed ? (
          <div className="min-w-0">
            <p className="truncate text-[14px] leading-none font-bold tracking-[-0.04em] text-ink">
              RAINWATCH <span className="text-accent">AI</span>
            </p>
            <p className="mono mt-1.5 truncate text-[9px] text-muted">Predict · Prepare · Protect</p>
          </div>
        ) : null}
      </Link>

      {/* Navigation */}
      <nav aria-label="Primary" className="flex-1 space-y-1 overflow-y-auto px-3 py-4">
        {!collapsed ? (
          <p className="mono mb-3 flex items-center gap-2 px-3 text-[9px] text-muted">
            <span className="h-px w-4 bg-accent" /> Command sectors / 10
          </p>
        ) : null}
        {NAV_ITEMS.map((item, i) => (
          <NavEntry
            key={item.to}
            item={item}
            index={i}
            collapsed={collapsed}
            badge={item.to === '/alerts' ? activeCountValue : undefined}
            onNavigate={onCloseMobile}
          />
        ))}
      </nav>

      {/* Footer */}
      <div className="space-y-3 border-t border-line px-3 py-4">
        <div
          className={`cut-br flex items-center gap-2.5 border border-accent/40 bg-accent/8 px-3 py-2 ${
            collapsed ? 'justify-center px-2' : ''
          }`}
        >
          <span className="relative flex h-2.5 w-2.5 shrink-0">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-accent opacity-70" />
            <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-accent" />
          </span>
          {!collapsed ? (
            <div className="min-w-0">
              <p className="mono text-[10px] font-bold text-accent">Demo Mode</p>
              <p className="mono truncate text-[9px] text-muted">Simulated data only</p>
            </div>
          ) : null}
        </div>

        <div className={`flex items-center gap-2.5 ${collapsed ? 'flex-col' : ''}`}>
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-line bg-surface text-[11px] font-bold text-accent">
            DA
          </span>
          {!collapsed ? (
            <div className="min-w-0 flex-1">
              <p className="truncate text-xs font-semibold text-ink">Demo Analyst</p>
              <p className="truncate text-[10px] text-muted">Emergency Ops Cell</p>
            </div>
          ) : null}
          <button
            type="button"
            onClick={onToggleCollapse}
            aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-line text-muted transition-all hover:border-accent/40 hover:text-accent"
          >
            {collapsed ? <PanelLeftOpen size={15} aria-hidden /> : <PanelLeftClose size={15} aria-hidden />}
          </button>
        </div>
      </div>
    </div>
  )

  return (
    <>
      {/* Desktop */}
      <motion.aside
        initial={false}
        animate={{ width: collapsed ? 76 : 264 }}
        transition={{ type: 'spring', stiffness: 320, damping: 34 }}
        className="fixed inset-y-0 left-0 z-40 hidden border-r border-line bg-sidebar lg:block"
        aria-label="Sidebar"
      >
        {body}
      </motion.aside>

      {/* Mobile drawer */}
      <AnimatePresence>
        {mobileOpen ? (
          <div className="fixed inset-0 z-[90] lg:hidden">
            <motion.div
              className="absolute inset-0 bg-[var(--rw-overlay)] backdrop-blur-[2px]"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={onCloseMobile}
              aria-hidden
            />
            <motion.aside
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              transition={{ type: 'spring', stiffness: 340, damping: 34 }}
              className="absolute inset-y-0 left-0 w-[264px] border-r border-line bg-sidebar"
              aria-label="Sidebar"
            >
              <button
                type="button"
                onClick={onCloseMobile}
                aria-label="Close navigation"
                className="absolute top-4 right-3 flex h-8 w-8 items-center justify-center rounded-lg border border-line text-muted"
              >
                <X size={15} aria-hidden />
              </button>
              {body}
            </motion.aside>
          </div>
        ) : null}
      </AnimatePresence>
    </>
  )
}

export { DemoBadge }
