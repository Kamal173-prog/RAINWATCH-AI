"""Surface-weather observations — a faithful port of
``hackathon/src/data/weatherData.ts``.

Derived from the shared rainfall series so the live weather page
always agrees with the forecast and flood-risk pages.
"""

import math
from datetime import timedelta

from .demo_state import get_demo_tick
from .rainfall import PAST_HOURS, get_rainfall_series, hour_aligned_now, offset_index, _iso
from .rng import clamp, create_rng, hash_seed, imul, js_round

_cache: dict = {}


def _build_reading(location_id: str, mm: float, ts, rng) -> dict:
    hour_of_day = ts.hour
    diurnal = 4.4 * math.sin(((hour_of_day - 9) / 24) * math.pi * 2)
    return {
        "locationId": location_id,
        "timestamp": _iso(ts),
        "temperatureC": js_round(clamp(29.4 + diurnal - mm * 0.075 + (rng() - 0.5) * 1.6, 21, 41), 1),
        "humidityPct": int(js_round(clamp(64 + mm * 1.15 - diurnal * 2.6 + (rng() - 0.5) * 8, 42, 99), 0)),
        "windSpeedKmph": js_round(clamp(9 + mm * 0.42 + rng() * 9, 4, 68), 1),
        "windDirectionDeg": int(js_round((118 + mm * 1.4 + rng() * 55) % 360, 0)),
        "pressureHpa": js_round(clamp(1009.5 - mm * 0.11 + (rng() - 0.5) * 2.4, 994, 1014), 1),
        "visibilityKm": js_round(clamp(14.5 - mm * 0.36 + (rng() - 0.5) * 2, 0.7, 16), 1),
        "cloudCoverPct": int(js_round(clamp(38 + mm * 1.7 + (rng() - 0.5) * 24, 4, 100), 0)),
        "rainfallMmHr": mm,
    }


def get_weather_history(location_id: str, hours: int) -> list:
    tick = get_demo_tick()
    key = f"{location_id}:{tick}:{hours}"
    cached = _cache.get(key)
    if cached is not None and cached["tick"] == tick:
        return cached["readings"]

    series = get_rainfall_series(location_id)
    seed = (hash_seed(location_id) ^ imul(tick + 7, 0x85EBCA6B) ^ hours) & 0xFFFFFFFF
    rng = create_rng(seed)
    base = hour_aligned_now()
    start = max(-PAST_HOURS, -hours)

    readings = []
    for h in range(start, 0):
        mm = series["mmHr"][offset_index(h)] if 0 <= offset_index(h) < len(series["mmHr"]) else 0
        ts = base + timedelta(hours=h)
        readings.append(_build_reading(location_id, mm, ts, rng))

    # Attach the current hour as the latest observation.
    now_mm = series["mmHr"][offset_index(0)] if 0 <= offset_index(0) < len(series["mmHr"]) else 0
    readings.append(_build_reading(location_id, now_mm, base, rng))

    _cache[key] = {"tick": tick, "readings": readings}
    return readings


def get_current_weather(location_id: str) -> dict:
    history = get_weather_history(location_id, 6)
    return history[-1]


def get_accumulated_rainfall(location_id: str, hours: int = 24) -> float:
    series = get_rainfall_series(location_id)
    total = 0.0
    for h in range(-hours, 1):
        i = offset_index(h)
        total += series["mmHr"][i] if 0 <= i < len(series["mmHr"]) else 0
    return js_round(total, 1)


def get_current_rainfall(location_id: str) -> float:
    series = get_rainfall_series(location_id)
    i = offset_index(0)
    return series["mmHr"][i] if 0 <= i < len(series["mmHr"]) else 0


def get_rainfall_delta(location_id: str) -> float:
    series = get_rainfall_series(location_id)
    now = series["mmHr"][offset_index(0)] if 0 <= offset_index(0) < len(series["mmHr"]) else 0
    prev = series["mmHr"][offset_index(-1)] if 0 <= offset_index(-1) < len(series["mmHr"]) else 0
    return js_round(now - prev, 1)


def get_max_forecast(location_id: str) -> dict:
    series = get_rainfall_series(location_id)
    best = 0.0
    best_offset = 0
    for h in range(1, 73):
        i = offset_index(h)
        v = series["mmHr"][i] if 0 <= i < len(series["mmHr"]) else 0
        if v > best:
            best = v
            best_offset = h
    base = hour_aligned_now()
    return {
        "rainfallMmHr": best,
        "timestamp": _iso(base + timedelta(hours=best_offset)),
    }


def get_rainfall_sparkline(location_id: str, n: int = 12) -> list:
    series = get_rainfall_series(location_id)
    out = []
    for h in range(-n + 1, 1):
        i = offset_index(h)
        out.append(series["mmHr"][i] if 0 <= i < len(series["mmHr"]) else 0)
    return out
