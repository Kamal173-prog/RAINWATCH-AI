import type { CSSProperties, ReactNode } from 'react'
import type { AlertSeverity, RainfallClass, RiskLevel, VulnerabilityLevel } from '../../types'
import type { DataSourceKind, SourceCounts } from '../../utils/source'
import { MODEL_GRID_CELL } from '../../utils/source'
import { RISK_COLORS, SEVERITY_COLORS } from '../../utils/colors'

type Tone = 'accent' | 'success' | 'warning' | 'critical' | 'muted' | 'info' | 'custom'

const TONES: Record<Tone, string> = {
  accent: 'bg-accent/12 text-accent border-accent/40',
  info: 'bg-accent-2/10 text-accent-2 border-accent-2/35',
  success: 'bg-success/12 text-success border-success/35',
  warning: 'bg-warning/12 text-warning border-warning/35',
  critical: 'bg-critical/12 text-critical border-critical/40',
  muted: 'bg-surface text-muted border-line',
  custom: '',
}

export function Badge({
  tone = 'muted',
  children,
  className = '',
  dot,
  style,
}: {
  tone?: Tone
  children: ReactNode
  className?: string
  dot?: boolean
  style?: CSSProperties
}) {
  return (
    <span
      style={style}
      className={`cut-br mono inline-flex items-center gap-1.5 whitespace-nowrap border px-2 py-0.5 text-[10px] font-semibold ${TONES[tone]} ${className}`}
    >
      {dot ? <span className="h-1.5 w-1.5 bg-current opacity-80" aria-hidden /> : null}
      {children}
    </span>
  )
}

export function RiskBadge({ level, className = '' }: { level: RiskLevel | VulnerabilityLevel; className?: string }) {
  const color = RISK_COLORS[level as RiskLevel] ?? '#8B9996'
  return (
    <Badge tone="custom" className={className} style={{ color, borderColor: `${color}55`, background: `${color}14` }}>
      {level}
    </Badge>
  )
}

export function SeverityBadge({ severity }: { severity: AlertSeverity }) {
  const color = SEVERITY_COLORS[severity]
  return (
    <Badge tone="custom" dot style={{ color, borderColor: `${color}55`, background: `${color}14` }}>
      {severity}
    </Badge>
  )
}

const RAIN_COLORS: Record<RainfallClass, string> = {
  Light: '#69D2A0',
  Moderate: '#6FD6C2',
  Heavy: '#F2A93B',
  'Very Heavy': '#F0823F',
  'Extremely Heavy': '#F05A43',
}

export function RainBadge({ label, className = '' }: { label: RainfallClass | string; className?: string }) {
  const color = RAIN_COLORS[label as RainfallClass] ?? '#6FD6C2'
  return (
    <Badge tone="custom" className={className} style={{ color, borderColor: `${color}55`, background: `${color}14` }}>
      {label}
    </Badge>
  )
}

export function DemoBadge({ compact = false }: { compact?: boolean }) {
  return (
    <span className="cut-br mono inline-flex items-center gap-1.5 border border-accent/50 bg-accent/10 px-2 py-0.5 text-[9px] font-bold tracking-[0.14em] text-accent">
      <span className="dot-live h-1.5 w-1.5 bg-accent" aria-hidden />
      {compact ? 'DEMO' : 'DEMO DATA'}
    </span>
  )
}

/**
 * Stage 5 — provenance badge for a single value. The `source` passed
 * here must come from `resolveSource()` (utils/source.ts), never from
 * the model version or any other field.
 */
export function SourceBadge({
  source,
  modelVersion,
  compact = true,
}: {
  source: DataSourceKind
  /** Shown as a tooltip only; never used to decide the badge. */
  modelVersion?: string
  compact?: boolean
}) {
  if (source === 'model') {
    return (
      <span
        title={modelVersion ? `ML model ${modelVersion} · ${MODEL_GRID_CELL}` : `ML model · ${MODEL_GRID_CELL}`}
        className="cut-br mono inline-flex items-center gap-1.5 border border-success/50 bg-success/10 px-2 py-0.5 text-[9px] font-bold tracking-[0.14em] text-success"
      >
        <span className="dot-live h-1.5 w-1.5 bg-success" aria-hidden />
        MODEL
      </span>
    )
  }
  if (source === 'google_weather') {
    return (
      <span
        title="Google Weather API · external forecast, not a RAINWATCH prediction"
        className="cut-br mono inline-flex items-center gap-1.5 border border-accent-2/40 bg-accent-2/10 px-2 py-0.5 text-[9px] font-bold tracking-[0.14em] text-accent-2"
      >
        <span className="dot-live h-1.5 w-1.5 bg-accent-2" aria-hidden />
        GOOGLE WEATHER
      </span>
    )
  }
  if (source === 'demo') return <DemoBadge compact={compact} />
  if (source === 'unavailable') {
    return (
      <span
        title="No forecast available for this hour — neither the RAINWATCH model nor Google Weather could provide a value"
        className="cut-br mono inline-flex items-center gap-1.5 border border-line bg-surface px-2 py-0.5 text-[9px] font-bold tracking-[0.14em] text-muted"
      >
        UNAVAILABLE
      </span>
    )
  }
  return (
    <span
      title="Source metadata missing — provenance unknown"
      className="cut-br mono inline-flex items-center gap-1.5 border border-line bg-surface px-2 py-0.5 text-[9px] font-bold tracking-[0.14em] text-muted"
    >
      UNKNOWN
    </span>
  )
}

/**
 * Stage 5 — view-level provenance summary for a page header. Shows one
 * badge per kind actually present in the loaded data (MODEL / GOOGLE
 * WEATHER / DEMO / UNAVAILABLE / UNKNOWN), so a mixed view is visible
 * at a glance. Renders nothing while there is no data yet.
 */
export function SourceMixBadge({ counts }: { counts: SourceCounts }) {
  if (counts.total === 0) return null
  return (
    <span className="inline-flex flex-wrap items-center gap-1.5">
      {counts.model > 0 ? <SourceBadge source="model" /> : null}
      {counts.googleWeather > 0 ? <SourceBadge source="google_weather" /> : null}
      {counts.demo > 0 ? <SourceBadge source="demo" /> : null}
      {counts.unavailable > 0 ? <SourceBadge source="unavailable" /> : null}
      {counts.unknown > 0 ? <SourceBadge source="unknown" /> : null}
    </span>
  )
}
