"""Integrity-label probe: Cuttack/Puri grid-cell origin + Data Sources
four-way distinction, against the live demo API (v3.3 on :8001, vite
on :5173). Regression probe for the 2026-11-24 integrity check.

Checks that the UI states, in plain words, that MODEL values are the
single Bhubaneswar grid-cell forecast (not per-city models), and that
the Data Sources page never presents the ERA5 archive as a live
external weather connection.

Test tooling only (not part of the shipped app). Screenshots go to
~/workspace/integrity-screenshots/. Exits non-zero if any check fails.
"""

import json
import os
import re
import sys

from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:5173"
OUT = os.path.expanduser("~/workspace/integrity-screenshots")
CHROME = "/home/hatch/.cache/ms-playwright/chromium-1255/chrome-linux64/chrome"

CELL_NOTE = "single Bhubaneswar grid cell"
CELL_NOTE_FULL = "including Cuttack and Puri"


def count_badges(page):
    text = page.locator("body").inner_text()
    return {
        "MODEL": len(re.findall(r"\bMODEL\b", text)),
        "DEMO": len(re.findall(r"\bDEMO\b", text)),
        "UNKNOWN": len(re.findall(r"\bUNKNOWN\b", text)),
    }


def set_location(page, name):
    """The location picker is a native <select>. Forecast options are
    labelled 'Name · Zone'; Flood options are plain names."""
    sel = page.locator("select").first
    options = sel.locator("option").all_inner_texts()
    match = [o for o in options if o == name or o.startswith(name + " ")]
    assert match, f"no location option for {name}: {options}"
    sel.select_option(label=match[0])
    page.wait_for_timeout(8000)  # refetch + charts animate in


def check(page, name, fn):
    try:
        detail = fn(page)
        return {"check": name, "pass": True, "detail": detail}
    except Exception as exc:  # noqa: BLE001
        return {"check": name, "pass": False, "detail": str(exc)}


def main():
    os.makedirs(OUT, exist_ok=True)
    results = []
    with sync_playwright() as pw:
        browser = pw.chromium.launch(executable_path=CHROME)
        page = browser.new_page(viewport={"width": 1440, "height": 900})

        def forecast_for(location):
            page.goto(f"{BASE}/forecast", wait_until="networkidle")
            page.wait_for_timeout(8000)
            set_location(page, location)
            page.wait_for_selector(f"text={CELL_NOTE}", timeout=15000)
            body = page.locator("body").inner_text()
            assert "Single grid cell:" in body, "grid-cell note strip missing"
            assert CELL_NOTE_FULL in body, "Cuttack/Puri application clause missing"
            badges = count_badges(page)
            assert badges["MODEL"] > 0, f"no MODEL badges for {location}: {badges}"
            tooltips = page.locator(
                "span[title*='Bhubaneswar grid cell']").count()
            assert tooltips > 0, "no MODEL badge tooltip names the grid cell"
            page.screenshot(path=f"{OUT}/forecast-{location.lower()}.png",
                            full_page=True)
            return {"badges": badges, "model_tooltips": tooltips}

        results.append(check(page, "forecast-cuttack",
                             lambda p: forecast_for("Cuttack")))
        results.append(check(page, "forecast-puri",
                             lambda p: forecast_for("Puri")))

        def flood_cuttack(p):
            p.goto(f"{BASE}/flood-intelligence", wait_until="networkidle")
            p.wait_for_timeout(8000)
            set_location(p, "Cuttack")
            body = p.locator("body").inner_text()
            assert CELL_NOTE in body, "grid-cell origin missing from disclaimer"
            assert CELL_NOTE_FULL in body, "Cuttack/Puri clause missing"
            badges = count_badges(p)
            assert badges["MODEL"] > 0, f"no MODEL badges: {badges}"
            p.screenshot(path=f"{OUT}/flood-cuttack.png", full_page=True)
            return {"badges": badges}

        results.append(check(page, "flood-cuttack", flood_cuttack))

        def overview(p):
            p.goto(f"{BASE}/overview", wait_until="networkidle")
            p.wait_for_timeout(8000)
            body = p.locator("body").inner_text()
            assert "Single grid cell:" in body, "grid-cell note missing"
            assert CELL_NOTE_FULL in body, "Cuttack/Puri clause missing"
            p.screenshot(path=f"{OUT}/overview.png", full_page=True)
            return {"model_badges": count_badges(p)["MODEL"]}

        results.append(check(page, "overview-cell-note", overview))

        def map_page(p):
            p.goto(f"{BASE}/map", wait_until="networkidle")
            p.wait_for_timeout(8000)
            body = p.locator("body").inner_text()
            assert "single Bhubaneswar grid-cell forecast" in body, \
                "grid-cell origin missing from map subtitle"
            p.screenshot(path=f"{OUT}/map.png", full_page=True)
            return {}

        results.append(check(page, "map-cell-note", map_page))

        def data_sources(p):
            p.goto(f"{BASE}/data-sources", wait_until="networkidle")
            p.wait_for_timeout(8000)
            body = p.locator("body").inner_text()
            # inner_text() applies CSS text-transform, so kind chips and
            # summary labels render UPPERCASE — compare lower-cased.
            low = body.lower()
            for kind in ("historical dataset", "real-time observation",
                         "forecast feed", "static dataset"):
                assert kind in low, f"kind chip missing: {kind}"
            assert "historical archive served" in low
            assert "live observation feeds" in low
            assert "real-time observations:" in low
            assert "no live satellite, radar or station feed" in low
            assert "static archive — no live updates" in low
            # The history card must say Archive, never Live. The card
            # renders badges UPPERCASE ("ARCHIVE"); its cadence line
            # says "no live updates" in lowercase, so a case-sensitive
            # "LIVE" check is exactly the badge check.
            card = p.locator(
                "xpath=//h3[text()='Historical Rainfall Records']"
                "/ancestor::div[contains(@class,'rounded-2xl')][1]")
            card_text = card.inner_text()
            assert "ARCHIVE" in card_text, f"history card: {card_text!r}"
            assert "LIVE" not in card_text, f"history card claims Live: {card_text!r}"
            # The "Live observation feeds" summary value must be 0
            # (xpath matches DOM textContent, which is not upper-cased).
            summary = p.locator(
                "xpath=//p[text()='Live observation feeds']"
                "/ancestor::div[contains(@class,'rounded-2xl')][1]")
            assert re.search(r"\b0\b", summary.inner_text()), \
                f"live-observation count is not 0: {summary.inner_text()!r}"
            p.screenshot(path=f"{OUT}/data-sources.png", full_page=True)
            return {}

        results.append(check(page, "data-sources", data_sources))
        browser.close()

    print(json.dumps(results, indent=2))
    failed = [r for r in results if not r["pass"]]
    if failed:
        print(f"FAILED: {len(failed)}/{len(results)} checks")
        sys.exit(1)
    print(f"ALL {len(results)} CHECKS PASSED")


if __name__ == "__main__":
    main()
