"""Acceptance: map-overlay check + performance measurements (read-only)."""
import json
import statistics
import subprocess
import time
import urllib.request

from playwright.sync_api import sync_playwright

CHROME = "/home/hatch/.cache/ms-playwright/chromium-1255/chrome-linux64/chrome"

# --- Map overlay check ---
with sync_playwright() as pw:
    browser = pw.chromium.launch(executable_path=CHROME)
    page = browser.new_page(viewport={"width": 1440, "height": 900})
    page.goto("http://127.0.0.1:5173/map", wait_until="networkidle")
    page.wait_for_timeout(15000)
    info = page.evaluate(
        """() => {
          const panes = {};
          document.querySelectorAll('.leaflet-pane').forEach(p => {
            panes[p.className] = p.querySelectorAll('path, circle, marker').length;
          });
          const banner = document.body.innerText.includes('Basemap tiles unavailable');
          return {panes, banner, overlayPaths: document.querySelectorAll('.leaflet-overlay-pane path').length};
        }"""
    )
    print("MAP overlay check:", json.dumps(info))
    page.screenshot(path="/home/hatch/workspace/acceptance-screenshots/map-15s.png")
    browser.close()


# --- Warm latency: 20 runs per endpoint, both servers ---
def time_get(port, path, n=20):
    ts = []
    for _ in range(n):
        t0 = time.perf_counter()
        with urllib.request.urlopen(f"http://127.0.0.1:{port}{path}", timeout=30) as r:
            r.read()
        ts.append((time.perf_counter() - t0) * 1000)
    ts.sort()
    return {"p50": round(ts[len(ts) // 2], 1), "p95": round(ts[int(len(ts) * 0.95) - 1], 1), "max": round(ts[-1], 1)}


ENDPOINTS = [
    "/api/health",
    "/api/forecast?locationId=old-town&hours=24",
    "/api/risk/all",
    "/api/overview?locationId=old-town",
    "/api/history/daily?locationId=old-town&days=120",
    "/api/map/layers",
    "/api/alerts/upcoming?limit=20",
]
for port in (8001, 8000):
    print(f"--- warm latency :{port} (20 runs each, ms) ---")
    for ep in ENDPOINTS:
        print(f"  {ep}: {time_get(port, ep)}")

# --- Memory ---
for port in (8000, 8001):
    out = subprocess.run(
        ["bash", "-c", f"ps -o rss=,pid= -p $(ss -ltnp 2>/dev/null | grep :{port} | grep -o 'pid=[0-9]*' | cut -d= -f2 | head -1)"],
        capture_output=True, text=True,
    ).stdout.strip()
    print(f"uvicorn :{port} RSS(KB): {out}")

# --- Frontend load: cold vite page load (DOM content) ---
with sync_playwright() as pw:
    browser = pw.chromium.launch(executable_path=CHROME)
    page = browser.new_page(viewport={"width": 1440, "height": 900})
    t0 = time.time()
    page.goto("http://127.0.0.1:5173/overview", wait_until="domcontentloaded")
    print(f"frontend /overview domcontentloaded: {(time.time()-t0)*1000:.0f} ms")
    browser.close()
