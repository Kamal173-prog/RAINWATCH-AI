# v3.2 Data Sources — Access, Coverage, and Status

Date: 2026-11-23. This document records the access investigation for
every data source in the v3.2 brief, what was actually acquired, and the
exact blocker for each source that was not acquired. Nothing here is
invented — every access claim was tested live or verified against the
provider's own documentation.

## Summary

| Source | Priority | Access | Status |
|---|---|---|---|
| GFS (Open-Meteo Historical Forecast API) | F (MEDIUM) | Keyless | **ACQUIRED** (2021-03-23 → 2026-11-23) |
| ECMWF IFS (Open-Meteo Historical Forecast API) | F (MEDIUM) | Keyless | **ACQUIRED but unusable for training** (only from 2024-02-02) |
| ERA5 2026 (Open-Meteo archive API) | — (fresh eval) | Keyless | **ACQUIRED** (2026-01-01 → 2026-11-23) |
| 2026 upwind spatial grids (ERA5) | — | Keyless | **ACQUIRED** (2026-01-01 → 2026-11-23) |
| INSAT-3D/3DR (MOSDAC) | A (VERY HIGH) | Registration + credentials | **BLOCKED — needs Kam to register** |
| IMD AWS/ARG stations | B (VERY HIGH) | Institutional approval | **BLOCKED — needs IMD IP whitelisting** |
| MSWEP V3 | C (HIGH) | Request + email | **BLOCKED — needs Kam to submit a request** |
| JAXA GSMaP V8 | D (HIGH) | Earth Engine / JAXA registration | **BLOCKED — needs Kam to sign up** |
| ERA5-Land | E (MEDIUM) | CDS account + API token | **BLOCKED — needs Kam to register** |
| IMD 0.25° daily gridded rainfall | Secondary | Public (`imdlib`) | Not fetched (daily only; cannot align to hourly) |
| CHIRPS v3 | Secondary | Public | Not fetched (daily/pentadal; cannot align to hourly) |
| NOAA PERSIANN-CDR | Secondary | Public | Not fetched (daily; cannot align to hourly) |

## Source A — INSAT-3D / INSAT-3DR (MOSDAC)

- Portal: https://mosdac.gov.in/
- Products: `3DIMG_L2B_HEM` (INSAT-3D Hydro-Estimator), `3DIMG_L2B_IMC`
  (INSAT-3D IMSRA), `3RIMG_L2B_HEM` (INSAT-3DR HEM), `3RIMG_L2B_IMC`
  (INSAT-3DR IMSRA), `3SIMG_L2B_HEM` (INSAT-3DS HEM).
- Resolution: ~4 km, half-hourly, HDF5.
- **Catalog search is public and was tested live on 2026-11-23.**
  `GET https://mosdac.gov.in/apios/datasets.json?datasetId=<id>&startTime=<d>&endTime=<d>`
  returns granules for 2021 and 2024 (e.g. `3DIMG_L2B_HEM`:
  92 granules for 2021-07-01..02, 96 for 2024-01-01..02; `3RIMG_L2B_HEM`:
  90 for 2021-07-01..02). Each granule is ~10 MB. The data EXISTS in
  the archive for 2021–2025.
- **Download requires a MOSDAC account + OAuth2 token.**
  `POST https://mosdac.gov.in/download_api/gettoken` with
  `{"username", "password"}`; download with
  `Authorization: Bearer <token>`. Max 5000 files/user/day.
- **Blocker:** no MOSDAC account is available to this project. Kam must
  register at https://mosdac.gov.in/signup/ and provide credentials via
  the Secure Vault (env vars `MOSDAC_USERNAME`, `MOSDAC_PASSWORD`).
- Connector: `ml/data_sources/insat_source.py` (catalog search works;
  download + HDF5 decoding implemented, awaiting credentials and the
  first granule to inspect its internal structure).

## Source B — IMD AWS / ARG station observations

- Portal: https://dsp.imdpune.gov.in/
- API reference: https://api.imd.gov.in/public/api_reference.html
- **Access requires registration AND IP whitelisting by IMD** (see
  https://mausam.imd.gov.in/responsive/apis.php). Government registrants
  must use a gov.in / nic.in address. There is no public keyless API
  that returns the complete historical hourly AWS/ARG archive for
  2021–2025.
- Candidate stations (to verify once access exists): Bhubaneswar,
  Cuttack, Puri, Paradip, Khordha, Gopalpur. These are requested
  locations, not confirmed station IDs.
- **Blocker:** IMD has not granted access. Kam (or NIST) must register
  at https://api.imd.gov.in/public/register.php, request IP whitelisting,
  and set `IMD_API_KEY`.
- Connector: `ml/data_sources/imd_source.py` (structure implemented;
  fetch/process raise a clear error until access exists).

## Source C — MSWEP V3

- Organisation: GloH2O (https://www.gloh2o.org/).
- Product: MSWEP V3, hourly, 0.1 deg (~11 km), 1979–present, ~2 h latency.
  Variants: Past (gauge-corrected) and Past_nogauge.
- Licence: CC BY-NC 4.0.
- **Access requires submitting a request** at https://www.gloh2o.org/mswep
  — GloH2O emails download instructions (a shared Google Drive folder,
  downloaded with rclone). There is no public keyless download URL.
- **Blocker:** no request has been submitted. Kam must submit the request
  with his email and provide the shared-drive link (`MSWEP_DRIVE_LINK`).
- Reference: Wang et al. (2026), arXiv:2602.01436.
- Connector: `ml/data_sources/mswep_source.py` (structure implemented;
  fetch/process raise a clear error until the drive link exists).

## Source D — JAXA GSMaP V8

- Dataset: `JAXA/GPM_L3/GSMaP/v8/operational`.
- Hourly, 0.1 deg (~11 km), 2000–present.
- Bands: `hourlyPrecipRate` (raw) and `hourlyPrecipRateGC` (gauge-adjusted).
- Access routes: (1) Google Earth Engine (free Google account + Earth
  Engine signup, `earthengine-api` package); (2) JAXA G-Portal / FTP
  (free JAXA registration).
- **Blocker:** no Earth Engine account and no JAXA registration is
  available to this project. Kam must sign up at
  https://earthengine.google.com/ (and run `earthengine authenticate`)
  or register at JAXA G-Portal.
- Connector: `ml/data_sources/gsmap_source.py` (structure implemented;
  fetch/process raise a clear error until auth exists).
- Note: GSMaP is a satellite product, not independent ground truth. Keep
  it separate from IMERG in experiments.

## Source E — ERA5-Land

- Organisation: Copernicus Climate Change Service / ECMWF.
- Dataset: `reanalysis-era5-land`. Hourly, 0.1 deg (~9 km), 1950–present,
  ~5 days behind real time.
- Variables: volumetric soil water layers 1–3, soil temperature, total
  precipitation, surface runoff, sub-surface runoff, evaporation.
- **Access requires a CDS account + API token.** Register at
  https://cds.climate.copernicus.eu/; `pip install cdsapi`; set
  `CDSAPI_URL` / `CDSAPI_KEY` (or `~/.cdsapirc`).
- **Blocker:** no CDS account is available to this project. Kam must
  register and provide the API token via the Secure Vault.
- Connector: `ml/data_sources/era5_land_source.py` (structure implemented;
  fetch/process raise a clear error until credentials exist).

## Source F — Historical ECMWF IFS / GFS forecasts

- Provider: Open-Meteo Historical Forecast API
  (https://open-meteo.com/en/docs/historical-forecast-api).
- **Access: keyless. Acquired.**
- GFS (`gfs_global`, 0.25 deg): 2021-03-23 → 2026-11-23, 49,728 hours.
  One ~15-day gap (2022-11-29 → 2022-12-14, 345 hours missing).
- ECMWF IFS (`ecmwf_ifs025`, 0.25 deg): 2024-02-02 → 2026-11-23,
  23,838 hours. **No data before 2024-02-02** (all nulls for 2021–2023
  and Jan 2024). This is why IFS features cannot be used for training
  with the 2021–2023 split.
- Variables: precipitation, CAPE, relative humidity, pressure, wind
  speed/direction, temperature, cloud cover, surface pressure.
- CAPE is populated in both GFS and IFS (unlike ERA5 via Open-Meteo,
  where CAPE is all nulls).
- Connector: `ml/data_sources/ifs_source.py` (fully working).

## Secondary sources (daily — not used for hourly classification)

- IMD 0.25° daily gridded rainfall: public via `imdlib`, but daily only.
  Cannot align to hourly windows. Not fetched.
- CHIRPS v3: daily/pentadal. Cannot align to hourly windows. Not fetched.
- NOAA PERSIANN-CDR: daily. Cannot align to hourly windows. Not fetched.
- These may support daily verification or monsoon analysis in future
  work, but they must never be treated as hourly observations and hourly
  precipitation must never be fabricated by dividing daily rainfall.
