import { AnimatePresence, motion } from 'framer-motion'
import {
  Activity,
  AlertTriangle,
  BarChart3,
  CloudRain,
  Droplets,
  Gauge,
  MapPin,
  RotateCcw,
  Play,
  Trash2,
  Waves,
  Wind,
} from 'lucide-react'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip as RTooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { toast } from 'sonner'
import { Badge, DemoBadge, RiskBadge } from '../components/common/Badge'
import { Button } from '../components/common/Button'
import { ChartCard } from '../components/common/ChartCard'
import { DataTable, type Column } from '../components/common/DataTable'
import { RiskPrism } from '../components/common/RiskPrism'
import { PageHeader } from '../components/common/PageHeader'
import { Select } from '../components/common/Select'
import { Slider } from '../components/common/Slider'
import { StatePanel } from '../components/common/Skeleton'
import { useAsyncData } from '../hooks/useAsyncData'
import { useDemo } from '../context/DemoContext'
import { useSelectedLocation } from '../context/LocationContext'
import { demoApi } from '../services/dataService'
import type { SimulatorInputs, SimulatorResult } from '../types'
import { RISK_COLORS } from '../utils/colors'

const tooltipStyle = {
  background: 'var(--rw-card)', border: '1px solid var(--rw-border)', borderRadius: 12,
  color: 'var(--rw-ink)', fontSize: 12, boxShadow: '0 20px 50px -25px rgba(0,0,0,0.9)',
}

interface Preset {
  id: string
  label: string
  description: string
  values: Omit<SimulatorInputs, 'locationId'>
}

const PRESETS: Preset[] = [
  { id: 'normal', label: 'Normal Rainfall', description: 'Light, short-duration rainfall with dry soil and healthy drainage.', values: { rainfallMmHr: 8, durationH: 4, soilSaturationPct: 30, drainageEfficiencyPct: 85, riverLevelPct: 20 } },
  { id: 'heavy', label: 'Heavy Rainfall', description: 'Sustained heavy rain with moderately saturated soil.', values: { rainfallMmHr: 42, durationH: 9, soilSaturationPct: 62, drainageEfficiencyPct: 62, riverLevelPct: 45 } },
  { id: 'extreme', label: 'Extreme Rainfall', description: 'Extreme intensity, saturated soil and stressed drainage.', values: { rainfallMmHr: 115, durationH: 6, soilSaturationPct: 88, drainageEfficiencyPct: 38, riverLevelPct: 72 } },
  { id: 'prolonged', label: 'Prolonged Rainfall', description: 'Moderate intensity over a long duration — cumulative saturating effect.', values: { rainfallMmHr: 28, durationH: 36, soilSaturationPct: 92, drainageEfficiencyPct: 48, riverLevelPct: 66 } },
  { id: 'urban', label: 'Urban Drainage Stress', description: 'Urban core with poor drainage efficiency and elevated water level.', values: { rainfallMmHr: 55, durationH: 12, soilSaturationPct: 75, drainageEfficiencyPct: 22, riverLevelPct: 80 } },
]

const DEFAULT_PRESET = PRESETS[0]

function severityColor(s: SimulatorResult['inundationSeverity']): string {
  return s === 'None' ? '#69D2A0' : s === 'Minor' ? '#6FD6C2' : s === 'Moderate' ? '#F2A93B' : s === 'Severe' ? '#F0823F' : '#F05A43'
}

export function Simulator() {
  const navigate = useNavigate()
  const { setScenario } = useDemo()
  const { locationId, setLocationId } = useSelectedLocation()
  const { data: locations } = useAsyncData(() => demoApi.listLocations(), [])
  const [presetId, setPresetId] = useState(DEFAULT_PRESET.id)
  const [inputs, setInputs] = useState<Omit<SimulatorInputs, 'locationId'>>({ ...DEFAULT_PRESET.values })
  const [result, setResult] = useState<SimulatorResult | null>(null)
  const [running, setRunning] = useState(false)
  const [history, setHistory] = useState<Array<SimulatorResult & { label: string }>>([])

  const preset = PRESETS.find((p) => p.id === presetId) ?? DEFAULT_PRESET

  const applyPreset = (id: string) => {
    setPresetId(id)
    const p = PRESETS.find((x) => x.id === id)
    if (p) setInputs({ ...p.values })
  }

  const update = (patch: Partial<Omit<SimulatorInputs, 'locationId'>>) => setInputs((prev) => ({ ...prev, ...patch }))

  const run = async () => {
    setRunning(true)
    try {
      const res = await demoApi.runSimulation({ ...inputs, locationId })
      setResult(res)
      setScenario(res)
      setHistory((h) => [{ ...res, label: preset.label }, ...h].slice(0, 5))
      toast.success('Scenario simulation complete', {
        description: `Risk index ${res.riskIndex}/100 · ${res.riskLevel}. Overlay sent to the Inundation Map.`,
        action: { label: 'View map', onClick: () => navigate('/map') },
      })
    } finally {
      setRunning(false)
    }
  }

  const reset = () => {
    setPresetId(DEFAULT_PRESET.id)
    setInputs({ ...DEFAULT_PRESET.values })
    setResult(null)
    toast.info('Simulator reset to defaults')
  }

  const breakdownData = (result?.breakdown ?? []).map((b) => ({ name: b.factor, value: b.contribution }))

  const historyColumns: Column<SimulatorResult & { label: string }>[] = [
    { key: 'label', header: 'Scenario', render: (r) => <span className="font-medium text-ink">{r.label}</span> },
    { key: 'rain', header: 'Rain (mm/hr)', render: (r) => <span className="num">{r.inputs.rainfallMmHr}</span> },
    { key: 'dur', header: 'Duration', render: (r) => <span className="num">{r.inputs.durationH} h</span>, secondary: true },
    { key: 'drain', header: 'Drainage', render: (r) => <span className="num">{r.inputs.drainageEfficiencyPct}%</span>, secondary: true },
    { key: 'risk', header: 'Risk index', render: (r) => <span className="num font-bold" style={{ color: RISK_COLORS[r.riskLevel] }}>{r.riskIndex}</span> },
    { key: 'level', header: 'Class', render: (r) => <RiskBadge level={r.riskLevel} /> },
    { key: 'use', header: 'Load', render: (r) => <Button size="sm" variant="ghost" onClick={() => { setInputs({ rainfallMmHr: r.inputs.rainfallMmHr, durationH: r.inputs.durationH, soilSaturationPct: r.inputs.soilSaturationPct, drainageEfficiencyPct: r.inputs.drainageEfficiencyPct, riverLevelPct: r.inputs.riverLevelPct }); toast.info('Scenario inputs loaded into sliders') }}>Load</Button> },
  ]

  return (
    <div className="section-gap flex flex-col">
      <PageHeader
        title="What-If Simulator"
        subtitle="Adjust rainfall, soil, drainage and water-level variables to explore illustrative risk outcomes — deterministic demo formula, not the ML model."
        meta={<><DemoBadge /><Badge tone="warning">Demo calculation</Badge></>}
      >
        <Button icon={<RotateCcw size={14} />} onClick={reset}>Reset</Button>
        <Button variant="primary" icon={<Play size={14} />} loading={running} onClick={run}>Run Simulation</Button>
      </PageHeader>

      <div className="flex items-start gap-3 rounded-xl border border-critical/30 bg-critical/8 px-4 py-3">
        <AlertTriangle size={16} className="mt-0.5 shrink-0 text-critical" aria-hidden />
        <p className="text-[11px] leading-relaxed text-critical">
          Educational demo simulation. Results are illustrative and are not suitable for real-world emergency decisions.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-5">
        {/* Controls */}
        <div className="flex flex-col gap-4 xl:col-span-2">
          <ChartCard title="Scenario Controls" subtitle="Preset or customise your own scenario" icon={<Waves size={16} />} height={0}>
            <div className="space-y-4">
              <div>
                <p className="mb-2 text-[11px] font-semibold tracking-wider text-muted uppercase">Preset scenarios</p>
                <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
                  {PRESETS.map((p) => (
                    <button key={p.id} type="button" onClick={() => applyPreset(p.id)} aria-pressed={presetId === p.id}
                      className={`rounded-xl border px-3 py-2 text-left text-xs font-medium transition-all ${
                        presetId === p.id ? 'border-accent/50 bg-accent/12 text-accent' : 'border-line bg-surface/50 text-ink hover:border-accent/30'
                      }`}>
                      {p.label}
                    </button>
                  ))}
                </div>
                <p className="mt-2 text-[11px] leading-relaxed text-muted">{preset.description}</p>
              </div>

              <div className="border-t border-line pt-3">
                <Select label="Location" options={(locations ?? []).map((l) => ({ value: l.id, label: `${l.name} · ${l.zone}` }))} value={locationId} onValueChange={setLocationId} />
              </div>

              <div className="space-y-4 border-t border-line pt-4">
                <Slider label="Rainfall intensity" value={inputs.rainfallMmHr} min={0} max={160} step={1} unit=" mm/hr" onChange={(v) => update({ rainfallMmHr: v })} description="mm per hour" />
                <Slider label="Rainfall duration" value={inputs.durationH} min={1} max={48} step={1} unit=" h" onChange={(v) => update({ durationH: v })} description="hours" />
                <Slider label="Soil saturation" value={inputs.soilSaturationPct} min={0} max={100} step={1} unit="%" onChange={(v) => update({ soilSaturationPct: v })} description="0 = dry" />
                <Slider label="Drainage efficiency" value={inputs.drainageEfficiencyPct} min={0} max={100} step={1} unit="%" onChange={(v) => update({ drainageEfficiencyPct: v })} description="0 = blocked" />
                <Slider label="River / water level" value={inputs.riverLevelPct} min={0} max={100} step={1} unit="%" onChange={(v) => update({ riverLevelPct: v })} description="relative level" />
              </div>

              <div className="flex gap-2 border-t border-line pt-4">
                <Button variant="primary" className="flex-1" icon={<Play size={14} />} loading={running} onClick={run}>Run Simulation</Button>
                <Button icon={<RotateCcw size={14} />} onClick={reset}>Reset</Button>
              </div>
            </div>
          </ChartCard>
        </div>

        {/* Results */}
        <div className="flex flex-col gap-4 xl:col-span-3">
          <AnimatePresence mode="wait">
            {!result ? (
              <motion.div key="empty" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <ChartCard title="Simulation Output" subtitle="Results appear here after you run a scenario" icon={<Gauge size={16} />} height={320}>
                  <StatePanel title="No simulation run yet" message="Adjust the sliders or choose a preset, then press Run Simulation to see an illustrative risk assessment." />
                  <div className="mt-4 grid grid-cols-3 gap-2">
                    {[
                      { icon: CloudRain, label: 'Rainfall' },
                      { icon: Droplets, label: 'Soil moisture' },
                      { icon: Wind, label: 'Drainage' },
                    ].map((x) => {
                      const Icon = x.icon
                      return <div key={x.label} className="rounded-xl border border-dashed border-line p-3 text-center"><Icon size={18} className="mx-auto text-muted" /><p className="mt-1.5 text-[10px] text-muted">{x.label}</p></div>
                    })}
                  </div>
                </ChartCard>
              </motion.div>
            ) : (
              <motion.div key="result" initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} className="flex flex-col gap-4">
                <ChartCard title="Simulation Output" subtitle={`${preset.label} · ${locationId.replace(/-/g, ' ')}`} icon={<Gauge size={16} />} height={0}
                  actions={
                    <>
                      <RiskBadge level={result.riskLevel} />
                      <Button size="sm" icon={<MapPin size={13} />} onClick={() => navigate('/map')}>View on map</Button>
                    </>
                  }>
                  <div className="mb-3 flex items-center gap-4 border-b border-line pb-3">
                    <RiskPrism riskIndex={result.riskIndex} color={RISK_COLORS[result.riskLevel]} />
                    <div className="min-w-0">
                      <p className="mono text-[9px] text-muted">Scenario prism / demo calc</p>
                      <p className="num mt-1 text-2xl leading-none font-bold text-ink">
                        {result.riskIndex}<span className="mono ml-1 text-[10px] font-normal text-muted">/ 100</span>
                      </p>
                      <p className="mono mt-2 text-[10px]" style={{ color: RISK_COLORS[result.riskLevel] }}>
                        {result.inundationSeverity} inundation · {result.affectedZones} zones
                      </p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
                    {[
                      { label: 'Risk index', value: `${result.riskIndex}`, unit: '/100', color: RISK_COLORS[result.riskLevel], icon: Gauge },
                      { label: 'Risk class', value: result.riskLevel, unit: '', color: RISK_COLORS[result.riskLevel], icon: Activity },
                      { label: 'Affected zones', value: `${result.affectedZones}`, unit: 'zones', color: '#F2A93B', icon: Waves },
                      { label: 'Inundation', value: result.inundationSeverity, unit: '', color: severityColor(result.inundationSeverity), icon: Droplets },
                      { label: 'Peak depth', value: `${result.peakDepthM}`, unit: 'm', color: '#6FD6C2', icon: BarChart3 },
                    ].map((s, i) => {
                      const Icon = s.icon
                      return (
                        <motion.div key={s.label} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
                          className="rounded-xl border border-line bg-surface/60 p-3">
                          <div className="flex items-center justify-between"><span className="text-[10px] font-semibold tracking-wider text-muted uppercase">{s.label}</span><Icon size={13} style={{ color: s.color }} /></div>
                          <p className="num mt-2 text-lg font-bold" style={{ color: s.color }}>{s.value} {s.unit ? <span className="text-[10px] font-normal text-muted">{s.unit}</span> : null}</p>
                        </motion.div>
                      )
                    })}
                  </div>
                  <div className="mt-3 flex flex-wrap items-center gap-2 rounded-lg border border-line bg-surface/50 px-3 py-2 text-[11px] text-muted">
                    <span>Estimated time to impact: <strong className="num text-ink">{result.durationToImpactH} h</strong></span>
                    <span className="text-line">·</span>
                    <span>Inputs: {result.inputs.rainfallMmHr} mm/hr for {result.inputs.durationH} h · soil {result.inputs.soilSaturationPct}% · drainage {result.inputs.drainageEfficiencyPct}%</span>
                  </div>
                </ChartCard>

                <ChartCard title="Risk Contribution Breakdown" subtitle="How the demo formula combines inputs" icon={<BarChart3 size={16} />} height={220} delay={0.08}>
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={breakdownData} layout="vertical" margin={{ top: 4, right: 16, left: 16, bottom: 0 }}>
                      <CartesianGrid stroke="var(--rw-border)" strokeDasharray="3 3" horizontal={false} />
                      <XAxis type="number" domain={[0, 100]} tickLine={false} axisLine={false} />
                      <YAxis type="category" dataKey="name" tickLine={false} axisLine={false} width={100} fontSize={10} />
                      <RTooltip contentStyle={tooltipStyle} />
                      <Bar dataKey="value" name="Contribution %" radius={[0, 4, 4, 0]} animationDuration={700}>
                        {breakdownData.map((_, i) => <Cell key={i} fill={['#6FD6C2', '#6FD6C2', '#F2A93B', '#B19BFA', '#69D2A0'][i % 5]} />)}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </ChartCard>
              </motion.div>
            )}
          </AnimatePresence>

          <ChartCard title="Scenario Comparison" subtitle="Last 5 runs (in-memory, resets on reload)" icon={<Activity size={16} />} height={0}
            actions={history.length > 0 ? <Button size="sm" variant="ghost" icon={<Trash2 size={13} />} onClick={() => { setHistory([]); toast.info('Comparison history cleared') }}>Clear</Button> : null}>
            <DataTable columns={historyColumns} rows={history} rowKey={(r, i) => `${r.label}-${i}`} emptyMessage="Run a simulation to build a comparison history." caption="Scenario comparison" />
          </ChartCard>
        </div>
      </div>
    </div>
  )
}
