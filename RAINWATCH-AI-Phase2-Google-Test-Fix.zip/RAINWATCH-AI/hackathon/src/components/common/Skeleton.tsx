import { AlertTriangle, Inbox, RefreshCw } from 'lucide-react'
import type { ReactNode } from 'react'
import { Button } from './Button'

export function Skeleton({ className = '' }: { className?: string }) {
  return <div className={`skeleton ${className}`} aria-hidden />
}

export function SkeletonCard({ lines = 3 }: { lines?: number }) {
  return (
    <div className="rounded-2xl border border-line bg-card p-[var(--rw-card-pad)]" aria-hidden>
      <div className="mb-4 flex items-center gap-3">
        <Skeleton className="h-9 w-9 rounded-xl" />
        <Skeleton className="h-4 w-32" />
      </div>
      <Skeleton className="h-7 w-24" />
      <div className="mt-4 space-y-2">
        {Array.from({ length: lines }).map((_, i) => (
          <Skeleton key={i} className={`h-3 ${i % 2 === 0 ? 'w-full' : 'w-4/5'}`} />
        ))}
      </div>
    </div>
  )
}

export function StatePanel({
  variant = 'empty',
  title,
  message,
  actionLabel,
  onAction,
  className = '',
}: {
  variant?: 'empty' | 'error'
  title: string
  message: string
  actionLabel?: string
  onAction?: () => void
  className?: string
}) {
  const Icon = variant === 'error' ? AlertTriangle : Inbox
  return (
    <div
      role={variant === 'error' ? 'alert' : 'status'}
      className={`flex flex-col items-center justify-center rounded-2xl border border-dashed border-line px-6 py-10 text-center ${className}`}
    >
      <span
        className={`mb-3 flex h-11 w-11 items-center justify-center rounded-xl border ${
          variant === 'error' ? 'border-critical/30 bg-critical/10 text-critical' : 'border-line bg-surface text-muted'
        }`}
      >
        <Icon size={20} aria-hidden />
      </span>
      <p className="text-sm font-semibold text-ink">{title}</p>
      <p className="mt-1 max-w-sm text-xs leading-relaxed text-muted">{message}</p>
      {actionLabel && onAction ? (
        <Button className="mt-4" size="sm" icon={<RefreshCw size={13} />} onClick={onAction}>
          {actionLabel}
        </Button>
      ) : null}
    </div>
  )
}

export function PageLoading({ label = 'Loading demo data…' }: { label?: string }) {
  return (
    <div className="flex items-center gap-3 text-sm text-muted" role="status">
      <span className="relative flex h-4 w-4">
        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-accent opacity-70" />
        <span className="relative inline-flex h-4 w-4 rounded-full bg-accent" />
      </span>
      {label}
    </div>
  )
}

export function EmptyHint({ children }: { children: ReactNode }) {
  return <p className="py-6 text-center text-xs text-muted">{children}</p>
}
