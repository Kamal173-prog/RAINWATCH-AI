"""Endpoint contract tests: every GET route, request validation,
invalid inputs, response structures and error/status codes.

These tests run against the production default (v3). Model-version
specific behaviour lives in test_model_selection.py; provenance
assertions live in test_provenance.py.
"""

import pytest

VALID_LOCATION = "old-town"
GANJAM_LOCATION = "brahmapur"
UNKNOWN_LOCATION = "not-a-place"

FORECAST_HOURS = (3, 6, 12, 24, 48, 72)


# ------------------------------------------------------------------
# Locations
# ------------------------------------------------------------------

def test_locations_list(v3_client):
    r = v3_client.get("/api/locations")
    assert r.status_code == 200
    locs = r.json()
    assert isinstance(locs, list) and len(locs) == 21
    ids = {loc["id"] for loc in locs}
    assert {"old-town", "patia", "brahmapur", "cuttack", "puri"} <= ids
    for loc in locs:
        assert {"id", "name", "zone", "lat", "lng", "population",
                "elevationM", "lowLyingPct", "drainageEfficiency",
                "riverProximity", "vulnerability"} <= set(loc)
        assert -90 <= loc["lat"] <= 90 and -180 <= loc["lng"] <= 180


# ------------------------------------------------------------------
# Weather
# ------------------------------------------------------------------

@pytest.mark.parametrize("hours", [1, 6, 24, 72])
def test_weather_history_ok(v3_client, hours):
    r = v3_client.get(f"/api/weather?locationId={VALID_LOCATION}&hours={hours}")
    assert r.status_code == 200
    rows = r.json()
    assert len(rows) == hours + 1  # past hours + current hour
    for row in rows:
        assert {"locationId", "timestamp", "temperatureC", "humidityPct",
                "windSpeedKmph", "windDirectionDeg", "pressureHpa",
                "visibilityKm", "cloudCoverPct", "rainfallMmHr"} <= set(row)
        assert row["locationId"] == VALID_LOCATION
        assert 0 <= row["humidityPct"] <= 100
        assert row["rainfallMmHr"] >= 0


@pytest.mark.parametrize("hours", [0, 73, -1, 100])
def test_weather_hours_out_of_range(v3_client, hours):
    r = v3_client.get(f"/api/weather?locationId={VALID_LOCATION}&hours={hours}")
    assert r.status_code == 422  # FastAPI Query(ge=1, le=72) validation


def test_weather_unknown_location(v3_client):
    r = v3_client.get(f"/api/weather?locationId={UNKNOWN_LOCATION}&hours=24")
    assert r.status_code == 404
    assert UNKNOWN_LOCATION in r.json()["detail"]


def test_weather_missing_location(v3_client):
    r = v3_client.get("/api/weather?hours=24")
    assert r.status_code == 422


def test_weather_current(v3_client):
    r = v3_client.get(f"/api/weather/current?locationId={VALID_LOCATION}")
    assert r.status_code == 200
    row = r.json()
    assert row["locationId"] == VALID_LOCATION
    assert isinstance(row["temperatureC"], float)
    # Current weather is the last row of the 6h history.
    hist = v3_client.get(f"/api/weather?locationId={VALID_LOCATION}&hours=6").json()
    assert row == hist[-1]


# ------------------------------------------------------------------
# Forecast
# ------------------------------------------------------------------

@pytest.mark.parametrize("hours", FORECAST_HOURS)
def test_forecast_ok(v3_client, hours):
    r = v3_client.get(f"/api/forecast?locationId={VALID_LOCATION}&hours={hours}")
    assert r.status_code == 200
    points = r.json()
    assert len(points) == hours
    for p in points:
        assert {"locationId", "timestamp", "rainfallMmHr", "accumulatedMm",
                "confidence", "classification", "source"} <= set(p)
        assert p["locationId"] == VALID_LOCATION
        assert p["rainfallMmHr"] >= 0
        assert p["accumulatedMm"] >= 0
        assert p["classification"] in (
            "Light", "Moderate", "Heavy", "Very Heavy", "Extremely Heavy")
        assert p["source"] in ("model", "demo")


def test_forecast_default_hours_is_24(v3_client):
    r = v3_client.get(f"/api/forecast?locationId={VALID_LOCATION}")
    assert r.status_code == 200
    assert len(r.json()) == 24


@pytest.mark.parametrize("hours", [1, 2, 5, 7, 25, 100, 0, -3])
def test_forecast_invalid_hours(v3_client, hours):
    r = v3_client.get(f"/api/forecast?locationId={VALID_LOCATION}&hours={hours}")
    assert r.status_code == 400
    assert "hours must be one of" in r.json()["detail"]


def test_forecast_non_integer_hours(v3_client):
    r = v3_client.get(f"/api/forecast?locationId={VALID_LOCATION}&hours=abc")
    assert r.status_code == 422


def test_forecast_unknown_location(v3_client):
    r = v3_client.get(f"/api/forecast?locationId={UNKNOWN_LOCATION}&hours=24")
    assert r.status_code == 404


def test_forecast_intensity_distribution(v3_client):
    r = v3_client.get(
        f"/api/forecast/intensity?locationId={VALID_LOCATION}&hours=24")
    assert r.status_code == 200
    slices = r.json()
    assert [s["label"] for s in slices] == [
        "Light", "Moderate", "Heavy", "Very Heavy", "Extremely Heavy"]
    assert sum(s["hours"] for s in slices) == 24
    for s in slices:
        assert isinstance(s["hours"], int) and s["hours"] >= 0
        assert s["color"].startswith("#")


def test_forecast_intensity_invalid_hours(v3_client):
    r = v3_client.get(
        f"/api/forecast/intensity?locationId={VALID_LOCATION}&hours=5")
    assert r.status_code == 400


# ------------------------------------------------------------------
# Flood risk
# ------------------------------------------------------------------

def test_risk_records_default(v3_client):
    r = v3_client.get(f"/api/risk/records?locationId={VALID_LOCATION}")
    assert r.status_code == 200
    recs = r.json()
    assert len(recs) == 25  # offsets 0..72 step 3
    for rec in recs:
        assert {"locationId", "timestamp", "riskIndex", "riskLevel",
                "populationAtRisk", "lowLyingPct", "drainageScore",
                "rainfallContribution", "terrainContribution",
                "riverContribution", "inundationDepthM", "areaInundatedHa",
                "source"} <= set(rec)
        assert 2 <= rec["riskIndex"] <= 99
        assert rec["riskLevel"] in (
            "Low", "Moderate", "High", "Very High", "Critical")
        assert rec["source"] in ("model", "demo")


@pytest.mark.parametrize("horizon", [6, 24, 72])
def test_risk_records_horizon(v3_client, horizon):
    r = v3_client.get(
        f"/api/risk/records?locationId={VALID_LOCATION}&horizonH={horizon}")
    assert r.status_code == 200
    assert len(r.json()) == horizon // 3 + 1


@pytest.mark.parametrize("horizon", [1, 12, 48, 100, 0])
def test_risk_records_bad_horizon(v3_client, horizon):
    r = v3_client.get(
        f"/api/risk/records?locationId={VALID_LOCATION}&horizonH={horizon}")
    assert r.status_code == 400


def test_risk_records_level_filter(v3_client):
    r = v3_client.get("/api/risk/records?level=High")
    assert r.status_code == 200
    recs = r.json()
    assert recs
    assert all(rec["riskLevel"] == "High" for rec in recs)


def test_risk_records_bad_level(v3_client):
    r = v3_client.get("/api/risk/records?level=Severe")
    assert r.status_code == 400


def test_risk_records_unknown_location(v3_client):
    r = v3_client.get(f"/api/risk/records?locationId={UNKNOWN_LOCATION}")
    assert r.status_code == 404


def test_risk_summary(v3_client):
    r = v3_client.get("/api/risk/summary?horizonH=24")
    assert r.status_code == 200
    body = r.json()
    assert {"overallIndex", "distribution", "worst", "vulnerable"} <= set(body)
    assert 0 <= body["overallIndex"] <= 100
    assert [d["level"] for d in body["distribution"]] == [
        "Low", "Moderate", "High", "Very High", "Critical"]
    assert sum(d["count"] for d in body["distribution"]) == len(
        v3_client.get("/api/risk/records?horizonH=24").json())
    assert all(rec["riskIndex"] >= 55 for rec in body["worst"])
    assert all(rec["riskIndex"] >= 60 for rec in body["vulnerable"])


def test_risk_summary_bad_horizon(v3_client):
    assert v3_client.get("/api/risk/summary?horizonH=12").status_code == 400


def test_risk_all(v3_client):
    r = v3_client.get("/api/risk/all")
    assert r.status_code == 200
    recs = r.json()
    assert len(recs) == 21 * 25  # 21 locations x offsets 0..72 step 3
    assert len({rec["locationId"] for rec in recs}) == 21


# ------------------------------------------------------------------
# Alerts
# ------------------------------------------------------------------

def test_alerts(v3_client):
    r = v3_client.get("/api/alerts")
    assert r.status_code == 200
    alerts = r.json()
    assert len(alerts) == 16
    for a in alerts:
        assert {"id", "severity", "category", "title", "locationId",
                "locationName", "timestamp", "description", "guidance",
                "status"} <= set(a)
        assert a["status"] == "active"
        assert a["severity"] in (
            "Information", "Advisory", "Watch", "Warning", "Critical")


@pytest.mark.parametrize("limit", [1, 5, 16])
def test_alerts_upcoming_limit(v3_client, limit):
    r = v3_client.get(f"/api/alerts/upcoming?limit={limit}")
    assert r.status_code == 200
    assert len(r.json()) == limit


def test_alerts_upcoming_limit_above_total_returns_all(v3_client):
    # Only 16 seed alerts exist; limit=20 returns all 16, not 20.
    r = v3_client.get("/api/alerts/upcoming?limit=20")
    assert r.status_code == 200
    assert len(r.json()) == 16


@pytest.mark.parametrize("limit", [0, 21, -1])
def test_alerts_upcoming_bad_limit(v3_client, limit):
    assert v3_client.get(f"/api/alerts/upcoming?limit={limit}").status_code == 422


def test_alerts_upcoming_severity_order(v3_client):
    alerts = v3_client.get("/api/alerts/upcoming?limit=5").json()
    order = {"Information": 0, "Advisory": 1, "Watch": 2, "Warning": 3, "Critical": 4}
    ranks = [order[a["severity"]] for a in alerts]
    assert ranks == sorted(ranks, reverse=True)


# ------------------------------------------------------------------
# Historical analysis
# ------------------------------------------------------------------

@pytest.mark.parametrize("days", [1, 30, 120, 365])
def test_history_daily_ok(v3_client, days):
    r = v3_client.get(
        f"/api/history/daily?locationId={VALID_LOCATION}&days={days}")
    assert r.status_code == 200
    rows = r.json()
    assert len(rows) == days
    for row in rows:
        assert {"date", "locationId", "rainfallMm", "peakHourMmHr",
                "riskIndex"} <= set(row)
        assert row["rainfallMm"] >= 0
    # Bhubaneswar-region rows come from the real archive anchored at
    # 2025-12-31, not from "today".
    assert rows[-1]["date"] == "2025-12-31"
    from datetime import date as _date
    dates = [_date.fromisoformat(row["date"]) for row in rows]
    assert all((dates[i + 1] - dates[i]).days == 1 for i in range(len(dates) - 1))


def test_history_daily_ganjam_uses_demo_window(v3_client):
    r = v3_client.get(
        f"/api/history/daily?locationId={GANJAM_LOCATION}&days=30")
    assert r.status_code == 200
    rows = r.json()
    assert len(rows) == 30
    # Demo window is anchored to today (UTC date on the server), unlike
    # the real archive. Allow a one-day tolerance for local/UTC drift.
    from datetime import date
    last = date.fromisoformat(rows[-1]["date"])
    assert abs((last - date.today()).days) <= 1
    assert rows[-1]["date"] != "2025-12-31"


@pytest.mark.parametrize("days", [0, 1826, -1])
def test_history_daily_bad_days(v3_client, days):
    r = v3_client.get(
        f"/api/history/daily?locationId={VALID_LOCATION}&days={days}")
    assert r.status_code == 422


def test_history_daily_unknown_location(v3_client):
    r = v3_client.get(
        f"/api/history/daily?locationId={UNKNOWN_LOCATION}&days=30")
    assert r.status_code == 404


def test_history_monthly(v3_client):
    r = v3_client.get(f"/api/history/monthly?locationId={VALID_LOCATION}")
    assert r.status_code == 200
    rows = r.json()
    assert len(rows) == 12
    for row in rows:
        assert {"month", "rainfallMm", "rainyDays", "peakMmHr",
                "avgRiskIndex"} <= set(row)
        assert row["rainfallMm"] >= 0
        assert 0 <= row["rainyDays"] <= 31


def test_history_annual(v3_client):
    r = v3_client.get("/api/history/annual")
    assert r.status_code == 200
    rows = r.json()
    assert [row["year"] for row in rows] == [2021, 2022, 2023, 2024, 2025]
    for row in rows:
        assert row["rainfallMm"] > 0
        assert row["heavyRainDays"] >= 0
        assert row["maxDailyMm"] > 0


def test_history_peaks(v3_client):
    r = v3_client.get("/api/history/peaks?limit=8")
    assert r.status_code == 200
    events = r.json()
    assert len(events) == 8
    assert all(e["dailyMm"] >= 45 for e in events)
    assert [e["dailyMm"] for e in events] == sorted(
        [e["dailyMm"] for e in events], reverse=True)


def test_history_peaks_location_filter(v3_client):
    r = v3_client.get(
        f"/api/history/peaks?locationId={VALID_LOCATION}&limit=3")
    assert r.status_code == 200
    assert len(r.json()) == 3
    assert all(e["locationId"] == VALID_LOCATION for e in r.json())


def test_history_comparison(v3_client):
    r = v3_client.get("/api/history/comparison?days=90")
    assert r.status_code == 200
    rows = r.json()
    assert len(rows) == 21
    assert [row["rainfallMm"] for row in rows] == sorted(
        [row["rainfallMm"] for row in rows], reverse=True)


# ------------------------------------------------------------------
# Map layers & region conditions
# ------------------------------------------------------------------

def test_map_layers(v3_client):
    r = v3_client.get("/api/map/layers")
    assert r.status_code == 200
    body = r.json()
    assert {"riskZones", "inundation", "stations", "population",
            "vulnerable"} <= set(body)
    assert len(body["riskZones"]) == 21
    assert len(body["stations"]) == 10
    assert len(body["population"]) == 2 * 7 * 8  # 2 regions x 7x8 grid
    assert len(body["vulnerable"]) == 12
    for zone in body["riskZones"]:
        assert len(zone["polygon"]) == 9
        assert all(len(pt) == 2 for pt in zone["polygon"])


def test_map_regions(v3_client):
    r = v3_client.get("/api/map/regions")
    assert r.status_code == 200
    rows = r.json()
    assert len(rows) == 21
    for row in rows:
        assert {"locationId", "name", "zone", "lat", "lng", "rainfallMmHr",
                "riskIndex", "riskLevel", "inundationDepthM",
                "populationAtRisk", "vulnerability", "lowLyingPct",
                "drainageEfficiency"} <= set(row)


# ------------------------------------------------------------------
# Data sources / overview
# ------------------------------------------------------------------

def test_data_sources(v3_client):
    from app.services import google_weather as gw
    gw.reset_state()  # Google state is process-global; start unconnected.
    r = v3_client.get("/api/data-sources")
    assert r.status_code == 200
    body = r.json()
    assert len(body["sources"]) == 8
    assert len(body["pipeline"]) == 6
    assert {s["status"] for s in body["sources"]} <= {
        "Live", "Demo Data", "Not Connected", "Awaiting Integration", "Archive", "Error"}
    by_id = {s["id"]: s for s in body["sources"]}
    assert by_id["history"]["name"] == "Historical Rainfall Records"
    # Integrity check 2026-11-24: the ERA5 archive is a static
    # historical dataset, never a "Live" external weather connection.
    history = by_id["history"]
    assert history["status"] == "Archive"
    assert history["kind"] == "Historical dataset"
    assert "no live updates" in history["cadence"]
    assert "not station measurements" in history["description"]
    # Google Weather: present, a Forecast feed, Not Connected with no key.
    google = by_id["google-weather"]
    assert google["name"] == "Google Weather API"
    assert google["kind"] == "Forecast feed"
    assert google["status"] == "Not Connected"
    assert google["icon"] == "cloud"
    # Every source carries the four-way kind taxonomy, and no row may
    # claim a live external connection of any kind.
    kinds = {s["kind"] for s in body["sources"]}
    assert kinds <= {"Historical dataset", "Real-time observation",
                     "Forecast feed", "Static dataset"}
    assert len([s for s in body["sources"]
                if s["kind"] == "Historical dataset"]) == 1
    assert all(s["status"] != "Live" for s in body["sources"])
    # Real-time observations: the category exists, but zero live feeds.
    obs = [s for s in body["sources"]
           if s["kind"] == "Real-time observation"]
    assert len(obs) == 3  # satellite, radar, stations
    assert all(s["status"] != "Live" for s in obs)
    # Forecast feeds: NWP (awaiting integration) + Google Weather (no key).
    feeds = [s for s in body["sources"] if s["kind"] == "Forecast feed"]
    assert len(feeds) == 2
    assert by_id["nwp"]["status"] == "Awaiting Integration"


def test_overview(v3_client):
    r = v3_client.get(f"/api/overview?locationId={VALID_LOCATION}&alertCount=3")
    assert r.status_code == 200
    body = r.json()
    assert {"kpis", "sparkline", "weather", "forecast", "intensity",
            "riskDistribution", "vulnerable", "upcomingAlerts",
            "activity"} <= set(body)
    assert body["kpis"]["activeAlerts"] == 3
    assert len(body["sparkline"]) == 24
    assert len(body["forecast"]) == 24
    assert len(body["upcomingAlerts"]) == 4
    assert len(body["activity"]) == 6
    assert body["kpis"]["riskLevel"] in (
        "Low", "Moderate", "High", "Very High", "Critical")


def test_overview_unknown_location(v3_client):
    r = v3_client.get(f"/api/overview?locationId={UNKNOWN_LOCATION}")
    assert r.status_code == 404


def test_overview_negative_alert_count(v3_client):
    r = v3_client.get(f"/api/overview?locationId={VALID_LOCATION}&alertCount=-1")
    assert r.status_code == 422


# ------------------------------------------------------------------
# Demo refresh + routing errors
# ------------------------------------------------------------------

def test_demo_refresh_bumps_tick(v3_client, tick_guard):
    before = v3_client.get("/api/health").json()["demoTick"]
    r = v3_client.post("/api/demo/refresh")
    assert r.status_code == 200
    assert r.json()["tick"] == before + 1
    assert v3_client.get("/api/health").json()["demoTick"] == before + 1


def test_unknown_route_404(v3_client):
    assert v3_client.get("/api/nope").status_code == 404


def test_simulate_get_is_method_not_allowed(v3_client):
    assert v3_client.get("/api/simulate").status_code == 405
