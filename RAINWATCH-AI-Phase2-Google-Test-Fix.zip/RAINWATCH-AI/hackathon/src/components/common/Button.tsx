import { Loader2 } from 'lucide-react'
import type { ButtonHTMLAttributes, ReactNode } from 'react'

type Variant = 'primary' | 'secondary' | 'ghost' | 'outline' | 'danger'
type Size = 'sm' | 'md'

const VARIANTS: Record<Variant, string> = {
  primary:
    'bg-accent text-[var(--rw-on-accent)] font-bold border border-accent hover:brightness-110',
  secondary:
    'bg-surface text-ink border border-line hover:border-accent/70 hover:text-accent',
  ghost: 'text-muted hover:text-accent hover:bg-surface border border-transparent',
  outline: 'border border-line text-ink hover:border-accent hover:text-accent bg-transparent',
  danger: 'bg-critical/12 text-critical border border-critical/50 hover:bg-critical/22',
}

const SIZES: Record<Size, string> = {
  sm: 'h-8 px-3 text-[11px] mono gap-1.5',
  md: 'h-10 px-4 text-xs mono gap-2',
}

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant
  size?: Size
  loading?: boolean
  icon?: ReactNode
}

export function Button({
  variant = 'secondary',
  size = 'md',
  loading = false,
  icon,
  children,
  className = '',
  disabled,
  ...rest
}: ButtonProps) {
  return (
    <button
      type="button"
      disabled={disabled || loading}
      className={`btn-press cut-br inline-flex items-center justify-center whitespace-nowrap tracking-[0.06em] uppercase disabled:opacity-45 disabled:cursor-not-allowed ${VARIANTS[variant]} ${SIZES[size]} ${className}`}
      {...rest}
    >
      {loading ? (
        <Loader2 size={size === 'sm' ? 13 : 15} className="animate-spin" aria-hidden />
      ) : (
        icon
      )}
      {children}
    </button>
  )
}
