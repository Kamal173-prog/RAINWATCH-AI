"""Illustrative geospatial overlays — a faithful port of
``hackathon/src/data/mapLayersData.ts``.

Polygons, depths and densities are synthetic shapes generated around
known coordinates — they are NOT real flood boundaries.

The shared RNG is consumed in a fixed order (risk zones → inundation →
stations → population → vulnerable sites), matching the frontend, so
values stay stable for a given demo tick.
"""

import math
from datetime import datetime, timedelta, timezone

from .demo_state import get_demo_tick
from .locations import LOCATIONS, REGIONS, get_location
from .risk import compute_risk_record
from .rng import clamp, create_rng, hash_seed, imul, js_round

_cache = None


def _make_polygon(lat: float, lng: float, radius_deg: float, seed: str, points: int = 9):
    rng = create_rng(hash_seed(seed))
    ring = []
    for i in range(points):
        angle = (i / points) * math.pi * 2
        r = radius_deg * (0.62 + rng() * 0.72)
        ring.append([
            js_round(lat + math.sin(angle) * r, 5),
            js_round(lng + math.cos(angle) * r * 1.32, 5),
        ])
    return ring


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def get_map_layers() -> dict:
    global _cache
    tick = get_demo_tick()
    # Cache key includes the model flag: risk zones embed model rainfall
    # (offset 6 h), so a version switch must not serve stale layers.
    try:
        from app.model_service import MODEL_VERSION_ENV

        model_flag = MODEL_VERSION_ENV
    except Exception:
        model_flag = "rainfall-xgb-v3"
    if _cache is not None and _cache["tick"] == tick and _cache.get("model_flag") == model_flag:
        return _cache["payload"]

    seed = (hash_seed("map-layers") ^ imul(tick + 1, 0x9E3779B1)) & 0xFFFFFFFF
    rng = create_rng(seed)

    # Risk zones — one per location, severity from the flood-risk model.
    risk_zones = []
    for loc in LOCATIONS:
        risk = compute_risk_record(loc["id"], 6, tick)
        risk_zones.append({
            "id": f"zone-{loc['id']}",
            "name": f"{loc['name']} sector",
            "level": risk["riskLevel"],
            "polygon": _make_polygon(
                loc["lat"], loc["lng"], 0.026 + loc["lowLyingPct"] / 5200, f"zone-{loc['id']}"
            ),
            "rainfallMmHr": js_round(risk["rainfallContribution"] * 0.9 + rng() * 4, 1),
        })

    # Inundation extents — synthetic ponding cells near low-lying zones.
    inundation = []
    for loc in [l for l in LOCATIONS if l["lowLyingPct"] >= 40]:
        depth = js_round((loc["lowLyingPct"] / 100) * (0.5 + rng() * 1.9), 2)
        lat_j = loc["lat"] + (rng() - 0.5) * 0.012
        lng_j = loc["lng"] + (rng() - 0.5) * 0.012
        confidence = int(js_round(58 + rng() * 34, 0))
        inundation.append({
            "id": f"inund-{loc['id']}",
            "name": f"{loc['name']} ponding cell",
            "polygon": _make_polygon(lat_j, lng_j, 0.014 + depth * 0.008, f"inund-{loc['id']}", 8),
            "depthM": depth,
            "confidencePct": confidence,
        })

    # Automatic weather stations — 5 per region, 10 total.
    station_locs = [l for l in LOCATIONS if l.get("regionId") != "ganjam"][:5] + \
                   [l for l in LOCATIONS if l.get("regionId") == "ganjam"][:5]
    statuses = ["online", "online", "online", "maintenance", "offline"]
    stations = []
    for i, loc in enumerate(station_locs):
        if i % 5 == 3:
            status = statuses[3]
        elif i % 7 == 6:
            status = statuses[4]
        else:
            status = statuses[i % 3]
        lat_j = loc["lat"] + (rng() - 0.5) * 0.01
        lng_j = loc["lng"] + (rng() - 0.5) * 0.01
        rainfall = js_round(rng() * 46, 1)
        minutes_ago = rng() * 12 if status == "online" else rng() * 240
        stations.append({
            "id": f"st-{loc['id']}",
            "name": f"{loc['name']} AWS",
            "lat": js_round(lat_j, 5),
            "lng": js_round(lng_j, 5),
            "rainfallMmHr": rainfall,
            "status": status,
            "lastUpdate": _iso(datetime.now(timezone.utc) - timedelta(minutes=minutes_ago)),
        })

    # Population density cells across both demonstration regions.
    population = []
    rows, cols = 7, 8
    for region in REGIONS:
        south, west, north, east = region["bbox"]
        for r in range(rows):
            for c in range(cols):
                lat = south + ((r + 0.5) / rows) * (north - south)
                lng = west + ((c + 0.5) / cols) * (east - west)
                d_lat = (lat - region["center"][0]) / ((north - south) / 2)
                d_lng = (lng - region["center"][1]) / ((east - west) / 2)
                dist = math.sqrt(d_lat * d_lat + d_lng * d_lng)
                density = int(js_round(
                    max(350, (9800 * math.exp(-dist * 1.45) + 420) * (0.7 + rng() * 0.75)), 0
                ))
                population.append({
                    "id": f"pop-{region['id']}-{r}-{c}",
                    "lat": js_round(lat, 5),
                    "lng": js_round(lng, 5),
                    "densityPerKm2": density,
                    "label": f"{'G' if region['id'] == 'ganjam' else 'B'}{chr(65 + c)}{r + 1}",
                })

    # Vulnerable sites shown as special markers.
    vulnerable_defs = [
        ("v1", "SCB Medical Campus (demo)", "Hospital", "old-town"),
        ("v2", "Municipal High School (demo)", "School", "nayapalli"),
        ("v3", "Canal Road Slum Cluster (demo)", "Slum Area", "old-town"),
        ("v4", "Railway Underpass (demo)", "Subway / Underpass", "saheed-nagar"),
        ("v5", "Senior Care Home (demo)", "Old-age Home", "sishupalgarh"),
        ("v6", "Industrial Estate School (demo)", "School", "mancheswar"),
        ("v7", "Storm-drain Outfall Zone (demo)", "Slum Area", "rasulgarh"),
        ("v8", "Hill-slope Settlement (demo)", "Slum Area", "khandagiri"),
        ("v9", "Brahmapur City Hospital (demo)", "Hospital", "brahmapur"),
        ("v10", "Gopalpur Fishing Settlement (demo)", "Slum Area", "gopalpur"),
        ("v11", "Chhatrapur Underpass (demo)", "Subway / Underpass", "chhatrapur"),
        ("v12", "Coastal School (demo)", "Slum Area", "patrapur"),
    ]
    vulnerable = []
    for vid, name, vtype, loc_id in vulnerable_defs:
        loc = get_location(loc_id)
        lat_j = loc["lat"] + (rng() - 0.5) * 0.016
        lng_j = loc["lng"] + (rng() - 0.5) * 0.016
        vulnerable.append({
            "id": vid,
            "name": name,
            "lat": js_round(lat_j, 5),
            "lng": js_round(lng_j, 5),
            "type": vtype,
            "vulnerability": loc["vulnerability"],
        })

    payload = {
        "riskZones": risk_zones,
        "inundation": inundation,
        "stations": stations,
        "population": population,
        "vulnerable": vulnerable,
    }
    _cache = {"tick": tick, "model_flag": model_flag, "payload": payload}
    return payload


def get_region_conditions() -> list:
    """Per-location snapshot used by both maps (rainfall, risk, inundation)."""
    from .risk import compute_risk_record
    from .weather import get_current_rainfall

    out = []
    for loc in LOCATIONS:
        risk = compute_risk_record(loc["id"], 6)
        out.append({
            "locationId": loc["id"],
            "name": loc["name"],
            "zone": loc["zone"],
            "lat": loc["lat"],
            "lng": loc["lng"],
            "rainfallMmHr": get_current_rainfall(loc["id"]),
            "riskIndex": risk["riskIndex"],
            "riskLevel": risk["riskLevel"],
            "inundationDepthM": risk["inundationDepthM"],
            "populationAtRisk": risk["populationAtRisk"],
            "vulnerability": loc["vulnerability"],
            "lowLyingPct": loc["lowLyingPct"],
            "drainageEfficiency": loc["drainageEfficiency"],
        })
    return out
