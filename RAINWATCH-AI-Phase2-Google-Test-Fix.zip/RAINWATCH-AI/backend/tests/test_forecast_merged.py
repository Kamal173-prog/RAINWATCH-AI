"""Tests for the merged forecast (GET /api/forecast/merged).

Source priority: MODEL > GOOGLE WEATHER > UNAVAILABLE. Synthetic demo
values must never appear in a merged response.

All Google HTTP traffic is mocked with httpx.MockTransport. Fixtures
are built relative to the RAINWATCH base hour (hour_aligned_now), in
two variants:
- UTC-aligned: Google intervals on the UTC hour grid (like the mock
  server's fixture).
- 30-min-offset: Google intervals on the local-hour grid (IST :30 UTC),
  as the real API returns for Asia/Kolkata.
Both must match every RAINWATCH hour (containment, with the 60-minute
nearest-start fallback for the last hour).
No live calls, no real key anywhere.
"""

from datetime import timedelta

import httpx
import pytest

from app.core import config
from app.engine import rainfall as rainfall_engine
from app.services import google_weather as gw

TEST_KEY = "test-demo-key"
# Google fixture indices with rain (qpf 1.4 mm). With the UTC-aligned
# fixture, RAINWATCH hour h maps to Google point h, so indices 7-8 put
# rain on RAINWATCH hours 7-8 — the first Google hours of an Old Town
# forecast (hours 1-6 are model).
RAIN_HOURS = (7, 8)


def _iso(dt):
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def make_google_hour(start, rain=False, no_precipitation=False):
    """One ForecastHour in Google's documented shape, interval [start, start+1h).

    Every hour carries a precipitation object (qpf 0.0 when dry), as the
    real API does — only ``no_precipitation=True`` omits it, which must
    make the hour UNAVAILABLE, never 0.
    """
    hour = {
        "interval": {
            "startTime": _iso(start),
            "endTime": _iso(start + timedelta(hours=1)),
        },
        "temperature": {"degrees": 28.0, "unit": "CELSIUS"},
        "relativeHumidity": 72,
        "weatherCondition": {
            "type": "LIGHT_RAIN" if rain else "PARTLY_CLOUDY",
            "description": {"text": "Light rain" if rain else "Partly cloudy"},
        },
        "wind": {
            "direction": {"degrees": 120, "cardinal": "ESE"},
            "speed": {"value": 11.0, "unit": "KILOMETERS_PER_HOUR"},
        },
    }
    if no_precipitation:
        return hour
    hour["precipitation"] = {
        "probability": {"percent": 65 if rain else 10, "type": "RAIN" if rain else "NONE"},
        "qpf": {"quantity": 1.4 if rain else 0.0, "unit": "MILLIMETERS"},
    }
    return hour


def google_fixture(offset_minutes=0, missing_qpf_index=None, n=24):
    """Google fixture anchored to the RAINWATCH base hour.

    offset_minutes=0: UTC-aligned intervals starting at the base hour.
    offset_minutes=30: local-hour-grid intervals starting at base+0:30
    (25 points so the last RAINWATCH hour is covered).
    missing_qpf_index: Google point index whose precipitation is absent
    (that RAINWATCH hour must become UNAVAILABLE, never 0).
    """
    base = rainfall_engine.hour_aligned_now() + timedelta(minutes=offset_minutes)
    count = n + 1 if offset_minutes else n
    hours = []
    for i in range(count):
        start = base + timedelta(hours=i)
        if i == missing_qpf_index:
            hours.append(make_google_hour(start, no_precipitation=True))
        else:
            hours.append(make_google_hour(start, rain=(i in RAIN_HOURS)))
    return {"forecastHours": hours, "timeZone": {"id": "Asia/Kolkata"}}


class CallCounter:
    def __init__(self):
        self.count = 0


def success_transport(counter, **fixture_kwargs):
    def handler(request: httpx.Request) -> httpx.Response:
        counter.count += 1
        assert request.url.params.get("key") == TEST_KEY
        return httpx.Response(200, json=google_fixture(**fixture_kwargs))
    return httpx.MockTransport(handler)


def error_transport(counter, status):
    def handler(request: httpx.Request) -> httpx.Response:
        counter.count += 1
        return httpx.Response(status, json={
            "error": {"code": status, "message": "mock error", "status": "MOCK"}})
    return httpx.MockTransport(handler)


@pytest.fixture(autouse=True)
def _reset_google(monkeypatch):
    gw.reset_state()
    gw.set_transport(None)
    monkeypatch.delenv("GOOGLE_WEATHER_API_KEY", raising=False)
    monkeypatch.delenv("GOOGLE_WEATHER_MONTHLY_CAP", raising=False)
    yield
    gw.reset_state()
    gw.set_transport(None)


@pytest.fixture
def keyed(monkeypatch):
    # Set BOTH the env var and the import-time config snapshot: the
    # service reads env first and falls back to config, so setting
    # only the env var would still leave a stale config value in play
    # if the fixture order ever changed.
    monkeypatch.setenv("GOOGLE_WEATHER_API_KEY", TEST_KEY)
    monkeypatch.setattr(config, "GOOGLE_WEATHER_API_KEY", TEST_KEY)
    return TEST_KEY


def _sources(points):
    counts = {}
    for p in points:
        counts[p["source"]] = counts.get(p["source"], 0) + 1
    return counts


def _assert_no_demo(body):
    assert all(p["source"] in {"model", "google_weather", "unavailable"}
               for p in body["points"]), body["points"]


# ------------------------------------------------------------------
# Happy path — UTC-aligned fixture
# ------------------------------------------------------------------

def test_merged_old_town_6_model_18_google(v33_client, keyed):
    counter = CallCounter()
    gw.set_transport(success_transport(counter))
    r = v33_client.get("/api/forecast/merged?locationId=old-town&hours=24")
    assert r.status_code == 200
    body = r.json()
    assert body["locationId"] == "old-town"
    assert body["hours"] == 24
    assert len(body["points"]) == 24
    assert _sources(body["points"]) == {"model": 6, "google_weather": 18}
    _assert_no_demo(body)
    assert body["meta"]["model"]["model_version"] == "rainfall-xgb-v3.3"
    assert body["meta"]["model"]["modelHours"] == 6
    assert body["meta"]["google"]["status"] == "ok"
    assert body["meta"]["google"]["reason"] is None
    assert body["meta"]["google"]["recordsRetrieved"] == 24
    assert body["meta"]["google"]["cached"] is False
    assert body["meta"]["sources"] == {"model": 6, "google_weather": 18, "unavailable": 0}
    assert counter.count == 1  # exactly one Google call for the range


def test_merged_brahmapur_all_google(v33_client, keyed):
    counter = CallCounter()
    gw.set_transport(success_transport(counter))
    r = v33_client.get("/api/forecast/merged?locationId=brahmapur&hours=24")
    assert r.status_code == 200
    body = r.json()
    assert _sources(body["points"]) == {"google_weather": 24}
    _assert_no_demo(body)
    assert body["meta"]["model"]["modelHours"] == 0
    assert body["meta"]["model"]["model_version"] is None
    assert body["meta"]["google"]["status"] == "ok"


def test_merged_cuttack_and_puri_model_plus_google(v33_client, keyed):
    counter = CallCounter()
    gw.set_transport(success_transport(counter))
    for location_id in ("cuttack", "puri"):
        r = v33_client.get(f"/api/forecast/merged?locationId={location_id}&hours=24")
        assert r.status_code == 200, location_id
        body = r.json()
        # Actual source availability, not assumed: both share the
        # Bhubaneswar grid cell, so they get the same 6 model hours.
        assert _sources(body["points"]) == {"model": 6, "google_weather": 18}, location_id
        _assert_no_demo(body)


def test_merged_model_points_byte_identical(v33_client, keyed):
    counter = CallCounter()
    gw.set_transport(success_transport(counter))
    base = v33_client.get("/api/forecast?locationId=old-town&hours=24").json()
    merged = v33_client.get("/api/forecast/merged?locationId=old-town&hours=24").json()
    base_model = [p for p in base if p["source"] == "model"]
    merged_model = [p for p in merged["points"] if p["source"] == "model"]
    assert len(base_model) == len(merged_model) == 6
    for b, m in zip(base_model, merged_model):
        assert m == {**b, "valueKind": "model_rate_mm_hr"}, (b, m)
        assert m["model"]["expected_mm"] == b["model"]["expected_mm"]
        assert m["model_version"] == "rainfall-xgb-v3.3"


def test_merged_value_kinds_and_google_metadata(v33_client, keyed):
    counter = CallCounter()
    gw.set_transport(success_transport(counter))
    body = v33_client.get("/api/forecast/merged?locationId=old-town&hours=24").json()
    for p in body["points"]:
        if p["source"] == "model":
            assert p["valueKind"] == "model_rate_mm_hr"
            assert p["confidence"] is not None
        elif p["source"] == "google_weather":
            assert p["valueKind"] == "google_qpf_mm"
            # Google's probability is NOT confidence.
            assert p["confidence"] is None
            assert p["precipitationProbabilityPct"] is not None
            assert p["temperatureC"] is not None
            assert p["condition"] is not None
            assert p["googleTimestamp"] is not None
            assert p["googleTimestamp"].endswith("Z")
    # RAINWATCH hour 7 maps to Google fixture index 7 (rain, qpf 1.4).
    hour7 = body["points"][6]
    assert hour7["source"] == "google_weather"
    assert hour7["rainfallMmHr"] == 1.4
    assert hour7["classification"] == "Light"
    assert hour7["precipitationProbabilityPct"] == 65
    assert hour7["precipitationType"] == "RAIN"


def test_merged_accumulated_continues_then_nulls_on_gap(v33_client, keyed):
    counter = CallCounter()
    # Google point index 10 has no precipitation -> RAINWATCH hour 10
    # (UTC fixture: hour h maps to Google point h) is UNAVAILABLE;
    # accumulated is null from hour 10 on, even though later Google
    # hours have values again.
    gw.set_transport(success_transport(counter, missing_qpf_index=10))
    body = v33_client.get("/api/forecast/merged?locationId=old-town&hours=24").json()
    points = body["points"]
    assert _sources(points)["unavailable"] == 1
    assert _sources(points)["google_weather"] == 17
    assert points[9]["source"] == "unavailable"
    assert points[9]["rainfallMmHr"] is None
    assert points[9]["accumulatedMm"] is None
    assert points[9]["confidence"] is None
    assert points[9]["classification"] is None
    assert points[9]["valueKind"] is None
    # Hours 1-9 accumulate model rates + Google QPF; hour 10+ unknown.
    assert all(p["accumulatedMm"] is not None for p in points[:9])
    assert all(p["accumulatedMm"] is None for p in points[9:])
    # But later Google values are still shown (only the total is unknown).
    assert points[10]["source"] == "google_weather"
    assert points[10]["rainfallMmHr"] == 0.0
    # Model hours match the base series exactly.
    base = v33_client.get("/api/forecast?locationId=old-town&hours=24").json()
    for b, m in zip(base[:6], points[:6]):
        assert m["accumulatedMm"] == b["accumulatedMm"]
    # Google hours continue the running total: model sum + QPF so far.
    model_sum = sum(p["rainfallMmHr"] for p in points[:6])
    # RAINWATCH hours 7 and 8 carry rain (fixture indices 7-8, qpf 1.4).
    assert points[6]["accumulatedMm"] == round(model_sum + 1.4, 1)
    assert points[8]["accumulatedMm"] == round(model_sum + 2.8, 1)


def test_merged_local_hour_grid_fixture(v33_client, keyed):
    """30-min-offset (IST local-hour) Google intervals still match."""
    counter = CallCounter()
    gw.set_transport(success_transport(counter, offset_minutes=30))
    r = v33_client.get("/api/forecast/merged?locationId=old-town&hours=24")
    assert r.status_code == 200
    body = r.json()
    assert _sources(body["points"]) == {"model": 6, "google_weather": 18}
    _assert_no_demo(body)
    assert body["meta"]["google"]["status"] == "ok"


def test_merged_google_not_called_when_all_model(v33_client, keyed):
    counter = CallCounter()
    gw.set_transport(success_transport(counter))
    r = v33_client.get("/api/forecast/merged?locationId=old-town&hours=3")
    assert r.status_code == 200
    body = r.json()
    assert _sources(body["points"]) == {"model": 3}
    assert body["meta"]["google"]["status"] == "not_needed"
    assert body["meta"]["google"]["recordsRetrieved"] == 0
    assert counter.count == 0


def test_merged_hours_6_all_model_no_google(v33_client, keyed):
    counter = CallCounter()
    gw.set_transport(success_transport(counter))
    r = v33_client.get("/api/forecast/merged?locationId=old-town&hours=6")
    assert r.status_code == 200
    assert _sources(r.json()["points"]) == {"model": 6}
    assert r.json()["meta"]["google"]["status"] == "not_needed"
    assert counter.count == 0


# ------------------------------------------------------------------
# Google failure modes -> UNAVAILABLE, never demo, model intact
# ------------------------------------------------------------------

def test_merged_no_key_unavailable(v33_client):
    counter = CallCounter()
    gw.set_transport(success_transport(counter))
    r = v33_client.get("/api/forecast/merged?locationId=old-town&hours=24")
    assert r.status_code == 200
    body = r.json()
    assert _sources(body["points"]) == {"model": 6, "unavailable": 18}
    _assert_no_demo(body)
    assert body["meta"]["google"]["status"] == "not_configured"
    assert body["meta"]["google"]["reason"] is not None
    assert body["meta"]["google"]["recordsRetrieved"] == 0
    assert counter.count == 0  # no Google call is attempted without a key
    for p in body["points"][6:]:
        assert p["rainfallMmHr"] is None
        assert p["accumulatedMm"] is None
        assert p["confidence"] is None
        assert p["classification"] is None
        assert p["valueKind"] is None


def test_merged_no_key_brahmapur_all_unavailable(v33_client):
    r = v33_client.get("/api/forecast/merged?locationId=brahmapur&hours=24")
    assert r.status_code == 200
    body = r.json()
    assert _sources(body["points"]) == {"unavailable": 24}
    _assert_no_demo(body)
    assert body["meta"]["google"]["status"] == "not_configured"


def test_merged_invalid_key_401(v33_client, keyed):
    counter = CallCounter()
    gw.set_transport(error_transport(counter, 401))
    r = v33_client.get("/api/forecast/merged?locationId=old-town&hours=24")
    assert r.status_code == 200
    body = r.json()
    assert _sources(body["points"]) == {"model": 6, "unavailable": 18}
    _assert_no_demo(body)
    assert body["meta"]["google"]["status"] == "error"
    assert "401" in (body["meta"]["google"]["reason"] or "")


def test_merged_google_timeout(v33_client, keyed):
    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectTimeout("timed out", request=request)
    gw.set_transport(httpx.MockTransport(handler))
    r = v33_client.get("/api/forecast/merged?locationId=old-town&hours=24")
    assert r.status_code == 200
    body = r.json()
    assert _sources(body["points"]) == {"model": 6, "unavailable": 18}
    _assert_no_demo(body)
    assert body["meta"]["google"]["status"] == "error"
    assert "timed out" in (body["meta"]["google"]["reason"] or "")


def test_merged_google_429(v33_client, keyed):
    counter = CallCounter()
    gw.set_transport(error_transport(counter, 429))
    r = v33_client.get("/api/forecast/merged?locationId=old-town&hours=24")
    assert r.status_code == 200
    body = r.json()
    assert _sources(body["points"]) == {"model": 6, "unavailable": 18}
    _assert_no_demo(body)
    assert body["meta"]["google"]["status"] == "error"
    assert "429" in (body["meta"]["google"]["reason"] or "")


# ------------------------------------------------------------------
# Existing endpoints unchanged
# ------------------------------------------------------------------

def test_forecast_endpoint_still_model_plus_demo(v33_client, keyed):
    counter = CallCounter()
    gw.set_transport(success_transport(counter))
    points = v33_client.get("/api/forecast?locationId=old-town&hours=24").json()
    assert _sources(points) == {"model": 6, "demo": 18}
    # The merged endpoint did not consume the Google call either.
    assert counter.count == 0


def test_forecast_intensity_unchanged(v33_client):
    from app.engine import rainfall as rainfall_engine

    expected = rainfall_engine.get_intensity_distribution("old-town", 24)
    r = v33_client.get("/api/forecast/intensity?locationId=old-town&hours=24")
    assert r.status_code == 200
    assert r.json() == expected
    assert sum(d["hours"] for d in r.json()) == 24


def test_merged_404_and_400(v33_client, keyed):
    r = v33_client.get("/api/forecast/merged?locationId=nowhere&hours=24")
    assert r.status_code == 404
    r = v33_client.get("/api/forecast/merged?locationId=old-town&hours=7")
    assert r.status_code == 400
