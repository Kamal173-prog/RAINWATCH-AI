"""Core rainfall series engine — a faithful port of
``hackathon/src/data/rainfallData.ts``.

Generates one deterministic hourly series per location per demo tick
covering -72h … +72h around the current hour. Every other module
(weather, flood risk, forecast, map) derives from this, so the whole
dashboard stays internally consistent.
"""

import math
from datetime import datetime, timedelta, timezone

from .demo_state import get_demo_tick
from .locations import get_location, is_ganjam
from .rng import RAINFALL_BANDS, clamp, classify_rainfall, create_rng, hash_seed, imul, js_round

# Model integration (Stage 4). Imported lazily inside functions to avoid
# a hard dependency: if the model is unavailable the demo engine is used.
MODEL_HOURS = 6  # the XGBoost model predicts hours 1..6 only


def _model_rates_for(location_id: str) -> dict | None:
    """Hourly model rainfall rates (mm/hr) for hours 1..6, or None.

    Only Bhubaneswar-region locations: the model is trained on the
    Bhubaneswar ERA5 grid cell. Ganjam locations always use the demo
    engine (their archive is not fetched yet).
    """
    if is_ganjam(location_id):
        return None
    try:
        from app.model_service import get_model_hourly_rates

        return get_model_hourly_rates()
    except Exception:
        return None

PAST_HOURS = 72
FUTURE_HOURS = 72
PAST = 24 * 3  # 72 — index offset so offset 0 sits at index 72

_cache: dict = {}


def _gaussian(x: float, mu: float, sigma: float) -> float:
    d = (x - mu) / sigma
    return math.exp(-0.5 * d * d)


def get_rainfall_series(location_id: str) -> dict:
    tick = get_demo_tick()
    key = f"{location_id}:{tick}"
    hit = _cache.get(key)
    if hit is not None and hit["tick"] == tick:
        return hit["series"]

    loc = get_location(location_id)
    seed = (hash_seed(location_id) ^ imul(tick + 1, 0x9E3779B1)) & 0xFFFFFFFF
    rng = create_rng(seed)

    # Per-location storm exposure: coastal / low-lying zones amplify.
    exposure = clamp(0.72 + loc["lowLyingPct"] / 240 + loc["riverProximity"] / 420, 0.6, 1.55)

    # Two synoptic events: one that just passed, one inbound.
    past_peak = -44 + rng() * 12
    past_amp = 24 + rng() * 46
    past_sigma = 8 + rng() * 6

    next_peak = 9 + rng() * 18
    next_amp = 34 + rng() * 74
    next_sigma = 6 + rng() * 7

    phase1 = rng() * math.pi * 2
    phase2 = rng() * math.pi * 2
    phase3 = rng() * math.pi * 2
    micro = 0.35 + rng() * 0.8

    offsets = []
    mm_hr = []
    for h in range(-PAST, FUTURE_HOURS + 1):
        ambient = micro * (0.6 + 0.45 * math.sin(h / 5.5 + phase1) + 0.3 * math.sin(h / 13 + phase2))
        showers = 1.5 * max(0, math.sin(h / 3.1 + phase3)) ** 2
        past = past_amp * _gaussian(h, past_peak, past_sigma)
        nxt = next_amp * _gaussian(h, next_peak, next_sigma)
        raw = (max(0, ambient) + showers + past + nxt) * exposure
        offsets.append(h)
        mm_hr.append(js_round(clamp(raw, 0, 185), 1))

    series = {"offsets": offsets, "mmHr": mm_hr}
    _cache[key] = {"tick": tick, "series": series}
    return series


def offset_index(offset: int) -> int:
    return offset + PAST


def rainfall_at(location_id: str, offset: int) -> float:
    series = get_rainfall_series(location_id)
    i = offset_index(offset)
    return series["mmHr"][i] if 0 <= i < len(series["mmHr"]) else 0


def hour_aligned_now() -> datetime:
    """Current hour, minutes/seconds zeroed (UTC, ISO output)."""
    now = datetime.now(timezone.utc)
    return now.replace(minute=0, second=0, microsecond=0)


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


# ------------------------------------------------------------------
# Forecast
# ------------------------------------------------------------------

_forecast_cache: dict = {}


def get_forecast_series(location_id: str) -> list:
    tick = get_demo_tick()
    # Cache key includes the model flag: switching MODEL_VERSION must
    # not serve stale points labelled with the previous version
    # (regression: ENGINE-2026-11-24-01).
    try:
        from app.model_service import MODEL_VERSION_ENV

        model_flag = MODEL_VERSION_ENV
    except Exception:
        model_flag = "rainfall-xgb-v3"
    key = f"{location_id}:{tick}:{model_flag}"
    cached = _forecast_cache.get(key)
    if cached is not None:
        return cached

    series = get_rainfall_series(location_id)
    base_hour = hour_aligned_now()
    model_rates = _model_rates_for(location_id)
    model_version = None
    model_detail = None
    if model_rates is not None:
        try:
            from app.model_service import get_model_detail, model_version as _mv

            model_version = _mv()
            model_detail = get_model_detail()
        except Exception:
            model_version = None
            model_detail = None

    points = []
    accumulated = 0.0
    for i in range(offset_index(1), offset_index(FUTURE_HOURS) + 1):
        offset = series["offsets"][i] if 0 <= i < len(series["offsets"]) else 0
        # Hours 1..6 come from the trained XGBoost model (Bhubaneswar
        # region only); hours 7+ come from the demo engine. Each point is
        # labelled so the frontend can show a Model vs Demo badge.
        if model_rates is not None and 1 <= offset <= MODEL_HOURS:
            mm = model_rates[offset]
            source = "model"
            # Indicative confidence from the model's test MAE, per horizon.
            try:
                from app.model_service import model_confidence

                horizon = 1 if offset == 1 else (3 if offset <= 3 else 6)
                confidence = model_confidence(horizon)
            except Exception:
                confidence = 85
        else:
            mm = series["mmHr"][i] if 0 <= i < len(series["mmHr"]) else 0
            source = "demo"
            confidence = int(js_round(clamp(94 - abs(offset) * 0.55 - (5 if mm > 40 else 0), 52, 96), 0))
        accumulated += mm
        ts = base_hour + timedelta(hours=offset)
        point = {
            "locationId": location_id,
            "timestamp": _iso(ts),
            "rainfallMmHr": mm,
            "accumulatedMm": js_round(accumulated, 1),
            "confidence": confidence,
            "classification": classify_rainfall(mm),
            "source": source,
        }
        if source == "model" and model_version:
            point["model_version"] = model_version
        if source == "model" and model_detail:
            # v2 two-stage detail: expected accumulations, P90 upper bound,
            # calibrated heavy-event probabilities, and the risk tier.
            point["model"] = {
                "expected_mm": model_detail["expected_mm"],
                "upper_bound_p90_mm": model_detail["upper_bound_p90_mm"],
                "heavy_rain_probability": model_detail["heavy_rain_probability"],
                "heavy_risk_tier": model_detail["heavy_risk_tier"],
                "model_version": model_version,
            }
        points.append(point)

    _forecast_cache[key] = points
    return points


def get_forecast(location_id: str, hours: int) -> list:
    return get_forecast_series(location_id)[:hours]


def get_intensity_distribution(location_id: str, hours: int) -> list:
    points = get_forecast(location_id, hours)
    return [
        {
            "label": band["label"],
            "hours": len([p for p in points if p["classification"] == band["label"]]),
            "color": band["color"],
        }
        for band in RAINFALL_BANDS
    ]
