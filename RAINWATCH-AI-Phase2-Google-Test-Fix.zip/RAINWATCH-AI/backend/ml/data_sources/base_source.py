"""Base class for RAINWATCH AI data sources (v3.2).

Every data source connector must implement this interface. The contract is:

- ``fetch`` downloads raw data for a date range and a bounding box into
  ``data/raw/<source>/``. It must be idempotent (re-running it skips
  files that already exist and are valid).
- ``process`` converts raw files into a clean, UTC-standardised hourly
  (or 30-minute) table in ``data/processed/<source>/`` and writes a
  machine-readable manifest.
- ``manifest`` records source name, product, version, retrieval time,
  spatial/temporal resolution, units, licence, access restrictions,
  geographic coverage and missing-data percentage.

Design rules (from the v3.2 brief):
- No hardcoded credentials. Credentials come from environment variables.
- Retry with exponential backoff; respect rate limits; support partial
  download recovery and missing-file detection.
- Structured logging (one line per action, with source + timestamp).
- Never fabricate data. If a source is inaccessible, the connector
  reports the blocker and returns an empty result — it never invents
  values.

Leakage rule: every feature produced from a source must record its
``available_at`` timestamp — the earliest time the observation was
actually available to a forecaster. A feature whose ``available_at`` is
later than the forecast issue time ``t`` must be rejected by the
feature-availability check in ``ml/preprocessing/temporal_alignment.py``.
"""

from __future__ import annotations

import json
import logging
import os
import time
from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

import requests

# Project root (backend/) — resolved from this file's location.
BACKEND_DIR = Path(__file__).resolve().parent.parent.parent
DATA_DIR = BACKEND_DIR / "data"

log = logging.getLogger(__name__)


@dataclass
class SourceManifest:
    """Machine-readable metadata for one downloaded/processed dataset."""

    source_name: str
    product_name: str
    product_version: str
    retrieval_timestamp_utc: str
    observation_start_utc: str
    observation_end_utc: str
    spatial_resolution: str
    temporal_resolution: str
    units: dict[str, str] = field(default_factory=dict)
    license: str = ""
    access_restrictions: str = ""
    geographic_coverage: str = ""
    missing_data_pct: float = 0.0
    n_records: int = 0
    n_files: int = 0
    processing_version: str = "1.0"
    notes: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def write(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            json.dump(self.to_dict(), f, indent=2, sort_keys=True)
        log.info("manifest written: %s", path)


def utcnow_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def retry_with_backoff(
    fn,
    *,
    max_retries: int = 5,
    base_delay_s: float = 30.0,
    max_delay_s: float = 300.0,
    retry_on_status: tuple[int, ...] = (429, 500, 502, 503, 504),
    description: str = "request",
):
    """Call ``fn`` with exponential backoff on HTTP 429 / 5xx and on
    transient network errors. Raises the last exception after the final
    attempt. Returns whatever ``fn`` returns."""
    last_exc: Optional[Exception] = None
    for attempt in range(1, max_retries + 1):
        try:
            return fn()
        except requests.HTTPError as e:
            status = e.response.status_code if e.response is not None else None
            if status in retry_on_status and attempt < max_retries:
                delay = min(base_delay_s * (2 ** (attempt - 1)), max_delay_s)
                log.warning(
                    "%s failed (HTTP %s), retry %d/%d after %.0fs",
                    description, status, attempt, max_retries, delay,
                )
                time.sleep(delay)
                last_exc = e
                continue
            raise
        except (requests.ConnectionError, requests.Timeout) as e:
            if attempt < max_retries:
                delay = min(base_delay_s * (2 ** (attempt - 1)), max_delay_s)
                log.warning(
                    "%s failed (%s), retry %d/%d after %.0fs",
                    description, type(e).__name__, attempt, max_retries, delay,
                )
                time.sleep(delay)
                last_exc = e
                continue
            raise
    if last_exc is not None:
        raise last_exc


class BaseDataSource(ABC):
    """Abstract base class for a RAINWATCH AI data source.

    Subclasses declare their identity (``SOURCE_NAME``, ``PRODUCT_NAME``,
    ``PRODUCT_VERSION``), their raw/processed directories, and implement
    ``fetch`` and ``process``. Credential handling is the subclass's job,
    but it must read credentials from environment variables only — never
    from hardcoded values and never from a committed file.
    """

    SOURCE_NAME: str = "base"
    PRODUCT_NAME: str = "base"
    PRODUCT_VERSION: str = ""
    # Availability lag: how long after the observation time the product
    # is actually available to a forecaster (e.g. "PT2H" for a 2-hour
    # latency). Used by the feature-availability check.
    AVAILABILITY_LAG: str = "PT0H"
    LICENSE: str = ""
    ACCESS_RESTRICTIONS: str = ""

    def __init__(self, backend_dir: Path | None = None):
        self.backend_dir = Path(backend_dir) if backend_dir else BACKEND_DIR
        self.raw_dir = self.backend_dir / "data" / "raw" / self.SOURCE_NAME
        self.processed_dir = self.backend_dir / "data" / "processed" / self.SOURCE_NAME
        self.raw_dir.mkdir(parents=True, exist_ok=True)
        self.processed_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Identity / access
    # ------------------------------------------------------------------
    @property
    def name(self) -> str:
        return self.SOURCE_NAME

    @abstractmethod
    def check_access(self) -> tuple[bool, str]:
        """Return (accessible, message). ``accessible`` is True only if
        this process can actually retrieve data right now (credentials
        present, endpoint reachable). The message states the blocker when
        access is not available (e.g. which env var or registration is
        needed). Must never raise for a missing credential — report it."""
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Fetch / process
    # ------------------------------------------------------------------
    @abstractmethod
    def fetch(
        self,
        start: str,
        end: str,
        bbox: Optional[tuple[float, float, float, float]] = None,
    ) -> list[Path]:
        """Download raw data for the inclusive date range ``start``..``end``
        (ISO dates, UTC) and optional bounding box (min_lon, min_lat,
        max_lon, max_lat). Returns the list of raw files written (existing
        valid files are skipped, not re-downloaded). Raises on a hard
        failure after retries; returns [] when access is blocked."""
        raise NotImplementedError

    @abstractmethod
    def process(self, raw_files: list[Path]) -> Path:
        """Convert raw files into a clean processed table and write it plus
        a manifest into ``data/processed/<source>/``. Returns the processed
        file path. Must apply the QC checks in
        ``ml/preprocessing/quality_control.py`` and standardise timestamps
        to UTC."""
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def manifest_path(self, stem: str) -> Path:
        return self.processed_dir / f"{stem}_manifest.json"

    def write_manifest(self, stem: str, manifest: SourceManifest) -> Path:
        path = self.manifest_path(stem)
        manifest.write(path)
        return path

    @staticmethod
    def env_or_none(name: str) -> Optional[str]:
        """Read an env var; return None (not an empty string) when unset.
        Credentials must never be logged."""
        v = os.environ.get(name)
        return v if v else None
