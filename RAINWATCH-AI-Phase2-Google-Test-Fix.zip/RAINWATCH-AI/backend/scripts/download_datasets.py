"""CLI: download a RAINWATCH AI data source (v3.2).

Usage:
    python scripts/download_datasets.py --source ifs --model ecmwf_ifs025 --start 2021-01-01 --end 2025-12-31
    python scripts/download_datasets.py --source ifs --model gfs_global --start 2021-03-23 --end 2025-12-31
    python scripts/download_datasets.py --source insat --product 3RIMG_L2B_HEM --start 2021-07-01 --end 2021-07-02

Sources that need credentials (INSAT, IMD, MSWEP, GSMaP, ERA5-Land)
report their blocker and exit without downloading anything. They never
fabricate data.
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger("download_datasets")


def main() -> None:
    ap = argparse.ArgumentParser(description="Download a RAINWATCH AI data source")
    ap.add_argument("--source", required=True,
                    choices=["ifs", "insat", "imd_stations", "mswep", "gsmap", "era5_land"])
    ap.add_argument("--model", default="ecmwf_ifs025", help="IFS model (ecmwf_ifs025 | gfs_global)")
    ap.add_argument("--product", default="3RIMG_L2B_HEM", help="INSAT product id")
    ap.add_argument("--start", required=True, help="Start date (ISO, e.g. 2021-01-01)")
    ap.add_argument("--end", required=True, help="End date (ISO, e.g. 2025-12-31)")
    ap.add_argument("--process", action="store_true", help="Process raw files after download")
    args = ap.parse_args()

    if args.source == "ifs":
        from ml.data_sources.ifs_source import IFSSource
        src = IFSSource(model=args.model)
    elif args.source == "insat":
        from ml.data_sources.insat_source import INSATSource
        src = INSATSource(product=args.product)
    elif args.source == "imd_stations":
        from ml.data_sources.imd_source import IMDStationSource
        src = IMDStationSource()
    elif args.source == "mswep":
        from ml.data_sources.mswep_source import MSWEPSource
        src = MSWEPSource()
    elif args.source == "gsmap":
        from ml.data_sources.gsmap_source import GSMaPSource
        src = GSMaPSource()
    elif args.source == "era5_land":
        from ml.data_sources.era5_land_source import ERA5LandSource
        src = ERA5LandSource()
    else:
        raise SystemExit(f"unknown source {args.source}")

    ok, msg = src.check_access()
    log.info("access: %s — %s", "OK" if ok else "BLOCKED", msg)
    if not ok:
        print(f"BLOCKED: {msg}")
        return
    files = src.fetch(args.start, args.end)
    print(f"fetched {len(files)} raw file(s)")
    for f in files:
        print(f"  {f}")
    if args.process and files:
        out = src.process(files)
        print(f"processed: {out}")


if __name__ == "__main__":
    main()
