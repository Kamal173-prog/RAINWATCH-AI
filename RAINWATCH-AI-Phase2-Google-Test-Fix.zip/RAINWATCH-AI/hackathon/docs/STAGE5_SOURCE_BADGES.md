# RAINWATCH AI — Stage 5: Frontend Model vs Demo Badges

Date: 2026-11-24. Scope: the existing Forecast and Flood Intelligence
views only. No redesign, no backend change, no model change, no
production-config change. Production remains on `rainfall-xgb-v3`.

## 1. What changed

Every forecast point and risk record now shows a provenance badge:

| Badge | Meaning | Colour |
|---|---|---|
| MODEL | Produced by the trained ML ensemble | Green (`success`) |
| DEMO | Produced by the deterministic demo engine | Accent (existing `DemoBadge`) |
| UNKNOWN | No provenance metadata was received | Muted grey |

Badges appear in three places per view:
- **Page header** — a summary of the kinds present in the loaded data
  (`SourceMixBadge`): MODEL + DEMO for a mixed view, a single badge
  when the view is uniform, UNKNOWN when provenance is missing.
- **Data tables** — a `Source` column on every row.
- **Risk detail card** — the badge sits next to the risk level of the
  selected record.

The header warning text and the footer/disclaimer text are now
source-aware (see §4). CSV exports gained a trailing `Source` column
so provenance travels with exported data.

## 2. How source identification works

Single rule, enforced in one place (`hackathon/src/utils/source.ts`):

- `resolveSource(value)` returns `'model'` **only** when
  `value.source === 'model'`, `'demo'` only when
  `value.source === 'demo'`, and `'unknown'` for anything else
  (missing, null, or an unrecognised string).
- `model_version` is **never** used to decide the badge. A value
  carrying `model_version: rainfall-xgb-v3.3` but no `source` is
  UNKNOWN, not MODEL. The version is shown only as a tooltip on the
  MODEL badge.
- `summarizeSources(items)` counts the three kinds for the header.

Provenance has exactly two origins, both reliable:
1. **Backend response metadata.** `/api/forecast` labels each point
   (`source: "model"` for hours 1–6, Bhubaneswar region; `"demo"` for
   hours 7+ and for all Ganjam locations) and `/api/risk/*` labels each
   record (`"model"` for offsets 0/3/6 h, Bhubaneswar region; `"demo"`
   otherwise). Model values also carry `model_version` and a `model`
   detail object; demo values carry neither.
2. **The local demo fallback.** When the API is unreachable or
   `VITE_API_URL` is unset, `dataService` generates the values itself.
   Those are DEMO by construction, and `viaApi` stamps
   `source: "demo"` onto them (see §3). The stamp is never applied to
   API responses.

## 3. Files changed

| File | Change |
|---|---|
| `hackathon/src/types/index.ts` | `SourcedValue` (`source?`, `model_version?`, `model?`) + `ModelDetail`; `ForecastPoint` and `FloodRiskRecord` extend it. All fields optional — the API contract is unchanged. |
| `hackathon/src/utils/source.ts` | **New.** `resolveSource`, `summarizeSources`, `isMixedSources`, `DataSourceKind`. |
| `hackathon/src/components/common/Badge.tsx` | `SourceBadge` (MODEL/DEMO/UNKNOWN, same visual language as the existing `DemoBadge`) and `SourceMixBadge` (header summary). |
| `hackathon/src/services/dataService.ts` | `viaApi` gained an optional `{ stampDemoSource }`; enabled only for `fetchForecast`, `fetchRiskRecords`, `fetchRiskSummary`, `fetchAllRiskRecords`. The stamp adds `source: "demo"` to fallback records (and one level deep into summary payloads). API responses are never stamped or overwritten. |
| `hackathon/src/pages/RainfallForecast.tsx` | Header meta (mix badge + source-aware warning), dynamic subtitle and footer note, `Source` table column, `Source` CSV column, "Mean confidence" label with a source-aware note. |
| `hackathon/src/pages/FloodIntelligence.tsx` | Header meta (mix badge + source-aware warning), dynamic disclaimer, `Source` table column, badge on the risk-detail card, `Source` CSV column. |
| `hackathon/src/components/layout/AppShell.tsx` | One-line global footer text fix (no layout change): the old text said *all* values are simulated DEMO DATA, which became false once model values are served. It now reads "values labelled DEMO are simulated samples; values labelled MODEL come from the trained ML ensemble and are an early-warning signal, not a confirmed forecast." |
| `hackathon/docs/STAGE5_SOURCE_BADGES.md` | This document. |

Nothing else was touched. No other page, component, route, style, or
interaction changed. The static `DemoBadge` in the two page headers
was replaced by the dynamic mix badge because a blanket "DEMO DATA"
label is no longer true once model values are served; other pages
keep their existing static badges (out of scope).

## 4. What the UI says in each state

**Forecast page**
- Mixed (Bhubaneswar, API up): subtitle "Mixed ML-model and demo
  forecast values — every row is labelled with its source." Warning:
  "Model + demo values — see per-row badges". Footer: MODEL values are
  from the trained ensemble (version named, e.g. `rainfall-xgb-v3`),
  DEMO values are illustrative samples.
- All model: "ML-model forecast from the trained rainfall ensemble
  (Bhubaneswar region)." Warning: "ML model — early-warning signal,
  not a confirmed forecast".
- All demo (API down / Ganjam): the original subtitle, warning
  ("Simulated QPF — not an operational forecast") and footer
  ("DEMO DATA — All forecast values are generated locally…").
- Unknown provenance: warning "Some values have unknown provenance —
  not verified model output"; footer notes UNKNOWN values are not
  verified model output.

**Flood Intelligence page**
- Mixed: warning "Model + demo records — see per-row badges".
  Disclaimer: MODEL records use ML-ensemble rainfall; the risk index
  itself is still a susceptibility index, not a validated prediction.
- All model: "ML-model rainfall · susceptibility index, not a
  validated prediction".
- All demo: the original disclaimer ("Every risk score … is an
  illustrative demo calculation…").
- Unknown: warning "Some records have unknown provenance".

## 5. Tests (2026-11-24)

1. **Actual v3 model response** — `curl` against the live production
   API (port 8000): forecast for `patia` 24 h = 6 model (hours 1–6,
   `model_version: rainfall-xgb-v3`, full `model` detail) + 18 demo;
   `brahmapur` (Ganjam) = 24/24 demo; risk records for `patia` =
   3 model (offsets 0/3/6) + 6 demo. PASS.
2. **v3.3 when explicitly selected** — second uvicorn on port 8001
   with shell env `MODEL_VERSION=rainfall-xgb-v3.3` only (no `.env`
   change, production untouched): the API returns 6 model points with
   `model_version: rainfall-xgb-v3.3` + 18 demo; demo points carry no
   `model_version`. **First UI attempt FAILED for a test-harness
   reason, not a product bug:** the backend's CORS allow-list
   (`backend/app/core/config.py`, default) covers only
   `http://localhost:5173` and `http://127.0.0.1:5173`, so the
   browser fetch from the :5174 dev origin was blocked and `viaApi`
   correctly fell back to labelled DEMO (24 DEMO, all-demo footer) —
   the fallback doing exactly what it should. Re-tested by serving
   the frontend from the :5173 origin pointed at :8001: header MODEL
   + DEMO, table 6 MODEL + 18 DEMO, MODEL badge tooltip
   "ML model rainfall-xgb-v3.3", footer names `rainfall-xgb-v3.3`.
   PASS (on re-test). No backend code was changed for this; the
   CORS allow-list is production config and was left alone.
3. **Demo fallback** — dev server pointed at a dead API
   (`http://localhost:9999`): header shows a single DEMO badge with
   the all-demo warning, table 24/24 DEMO, all-demo footer. PASS
   (DOM counts + screenshots).
4. **Mixed-source views** — the default Bhubaneswar forecast and risk
   views are mixed (see test 1): forecast header MODEL + DEMO, table
   6 MODEL + 18 DEMO; risk header MODEL + DEMO, table 3 MODEL + 6
   DEMO. PASS (DOM counts + screenshots).
5. **Missing / unknown source metadata** — mock proxy on port 8002
   strips `source`, `model_version` and `model` from all responses
   (test-only, `/tmp/mock_strip_source.mjs`, not in the repo): header
   UNKNOWN badges, table 24/24 UNKNOWN, no MODEL badge anywhere,
   footer notes UNKNOWN values are not verified model output. Unit
   check of `resolveSource` (9 cases, incl. `{model_version}` with
   no `source` → unknown, and case-sensitive `"MODEL"` → unknown):
   all pass. PASS.
6. **Existing frontend functionality** — `tsc -b` clean, `vite build`
   succeeds (3,064 modules, dist written, rebuilt after the footer
   fix), CSV export starts a download
   (`rainwatch-forecast-old-town-24h.csv`), no layout breakage
   observed in the screenshots. PASS.

Test method note: the cloud browser cannot reach this VM's localhost
(its localhost is a different machine), so the visual checks were done
with the Chromium already on this VM (Playwright, `~/.cache/
ms-playwright/chromium-1255`) against the dev servers, with DOM badge
counts read alongside each screenshot. Screenshots:
`workspace/stage5-screenshots/` (10 files, `*-top.png` + `*-table.png`
per state). One probe quirk: the DOM counter double-counts a
single-kind header badge (the `SourceMixBadge` wrapper span's text
matches too), so a uniform header reads 2 instead of 1 — the
screenshots confirm one badge is actually rendered.

Environment note: `node_modules` shipped Windows native binaries
(`typescript-win32-x64`, rolldown `win32-x64-msvc`), so `tsc` and
`vite build` failed until the Linux bindings were installed with
`npm install --no-save --no-package-lock` (5 packages added;
`package.json` / `package-lock.json` hashes unchanged). If the
frontend is developed on Windows and run here, that reinstall is
needed again after any fresh `node_modules` copy.

## 6. Limitations and unresolved issues

- **Aggregates have no badge.** The intensity-distribution pie, the
  risk-distribution pie, the KPI strips and the comparison chart mix
  model and demo values; only the header summary and the per-row
  badges label provenance. The Overview, Live Weather, maps, alerts,
  history and simulator pages are out of scope and still carry their
  static DEMO labels (correct for those pages today, since the
  backend serves them demo values only — but they will need the same
  treatment if they ever serve model values).
- **The risk index is never a model prediction**, even on MODEL
  records: only the rainfall input comes from the ML ensemble. The
  disclaimer says this; the MODEL badge must not be read as
  "validated flood prediction".
- **UNKNOWN is a display state, not a diagnosis.** It means the
  response carried no `source` field. It does not say whether the
  value is model or demo.
- **The v3.3 test server (port 8001), the mock server (port 8002)
  and the four dev servers (5173–5176) were stopped after testing**;
  only the production API on port 8000 remains running, serving
  `rainfall-xgb-v3`. Nothing was deployed: the production build output
  in `dist/` is a local build artifact (rebuilt after the footer fix),
  and the running production API on port 8000 still serves
  `rainfall-xgb-v3`.
- **Stage 6 was not started**, per Kam's instruction.
- **CORS note for future test setups:** the backend's CORS
  allow-list defaults to `http://localhost:5173` and
  `http://127.0.0.1:5173` only. A dev server on any other port
  silently falls back to labelled DEMO in the UI — which is the
  correct degradation, but it means a different model version can
  only be UI-tested from the :5173 origin (or with `CORS_ORIGINS`
  set, which is a production-config change and needs Kam's go).
