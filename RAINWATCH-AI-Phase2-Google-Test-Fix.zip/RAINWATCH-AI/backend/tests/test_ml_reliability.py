"""ML reliability tests: artifact integrity, prediction validation,
reproducibility, missing/invalid-feature handling, and classifier vs
regression output handling.

These tests never modify frozen artifacts or thresholds and never touch
the reserved 2026 evaluation data. They read the manifest and the
artifacts, and run inference on the real archive tail.
"""

import hashlib
import json
import math
import os

import pytest

BACKEND = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FROZEN = os.path.join(BACKEND, "models", "rainfall_xgb_v3_3", "frozen")
MANIFEST = os.path.join(FROZEN, "RELEASE_MANIFEST.json")


# ------------------------------------------------------------------
# Artifact integrity
# ------------------------------------------------------------------

def test_v33_manifest_hashes_all_match():
    """All 15 frozen v3.3 files match the release manifest (SHA-256 +
    size). This is the same check run during the demo verification."""
    manifest = json.load(open(MANIFEST))
    assert manifest["model_version"] == "rainfall-xgb-v3.3"
    assert manifest["production_model"].startswith("rainfall-xgb-v3")
    assert len(manifest["files"]) == 15
    for name, rec in manifest["files"].items():
        path = os.path.join(FROZEN, name)
        assert os.path.exists(path), name
        data = open(path, "rb").read()
        assert hashlib.sha256(data).hexdigest() == rec["sha256"], name
        assert len(data) == rec["bytes"], name


def test_v33_manifest_records_threshold_selection():
    manifest = json.load(open(MANIFEST))
    record = manifest["threshold_selection"]
    assert record["data"].startswith("pooled out-of-sample 2024")
    # The manifest must state explicitly that 2026 was NOT used.
    assert record["2026_use"].startswith("NONE.")
    assert "2026 was not used" in record["2026_use"]
    assert record["rules"]["watch"].startswith("maximize F2")
    assert record["rules"]["warning"].startswith("maximize F1")


def test_all_versions_have_required_artifact_files():
    required = ["ensemble_weights.json", "platt.json", "thresholds.json",
                "feature_schema.json"]
    for version_dir in ("rainfall_xgb_v3", "rainfall_xgb_v3_1",
                        "rainfall_xgb_v3_2"):
        for name in required:
            assert os.path.exists(
                os.path.join(BACKEND, "models", version_dir, name)), (
                version_dir, name)
    # v3.3 frozen has its own copies plus the optimized thresholds.
    for name in required + ["thresholds_optimized.json"]:
        assert os.path.exists(os.path.join(FROZEN, name)), name


def test_v33_thresholds_are_ordered_and_bounded():
    thr = json.load(open(os.path.join(FROZEN, "thresholds_optimized.json")))
    for event in ("y_3h_ge_10mm", "y_6h_ge_10mm", "y_3h_ge_5mm"):
        assert event in thr
        assert 0.0 < thr[event]["elevated"] < thr[event]["high"] < 1.0
    # The freeze record thresholds.json must still exist unchanged
    # (hash check above covers its content).


# ------------------------------------------------------------------
# Prediction validation
# ------------------------------------------------------------------

@pytest.fixture(scope="module")
def hourly():
    import sys
    sys.path.insert(0, os.path.join(BACKEND, "ml"))
    import features as feat
    return feat.load_hourly(
        os.path.join(BACKEND, "data", "processed", "bhubaneswar_weather.csv"))


@pytest.fixture(scope="module")
def forecaster_v3():
    from ml.predict import RainfallForecaster
    return RainfallForecaster()


def test_predict_output_shape_and_ranges(forecaster_v3, hourly):
    out = forecaster_v3.predict_with_provenance(hourly)
    assert out["source"] == "model"
    assert out["model_version"] == "rainfall-xgb-v3"
    assert out["scope"].startswith("Bhubaneswar grid cell only")
    assert out["model_input_as_of"].startswith("2025-12-31T23:00:00")
    assert set(out["expected_mm"]) == {"1h", "3h", "6h"}
    assert set(out["upper_bound_p90_mm"]) == {"3h", "6h"}
    assert set(out["heavy_rain_probability"]) == {
        "3h_ge_10mm", "6h_ge_10mm", "3h_ge_5mm"}
    for v in list(out["expected_mm"].values()) + list(out["upper_bound_p90_mm"].values()):
        assert isinstance(v, float) and math.isfinite(v) and v >= 0
    for v in out["heavy_rain_probability"].values():
        assert 0.0 <= v <= 1.0
    assert out["heavy_risk_tier"] in ("low", "moderate", "elevated", "high")
    assert out["thresholds_source"] == "thresholds.json"


def test_predict_is_reproducible(forecaster_v3, hourly):
    """Same input, same output — twice in a row, including the tier."""
    first = forecaster_v3.predict_with_provenance(hourly)
    second = forecaster_v3.predict_with_provenance(hourly)
    assert first["expected_mm"] == second["expected_mm"]
    assert first["upper_bound_p90_mm"] == second["upper_bound_p90_mm"]
    assert first["heavy_rain_probability"] == second["heavy_rain_probability"]
    assert first["heavy_risk_tier"] == second["heavy_risk_tier"]


def test_tier_is_consistent_with_thresholds(forecaster_v3, hourly):
    """Recompute the tier from the probabilities and the thresholds and
    require it to match — the tier must never disagree with its own
    decision rule."""
    probs = forecaster_v3.heavy_rain_probability(hourly)
    t = forecaster_v3.thresholds
    tier = forecaster_v3.heavy_risk_tier(hourly)

    def _thr(event, key):
        v = t[event]
        return v[key] if isinstance(v, dict) else v

    if (probs["3h_ge_10mm"] >= _thr("y_3h_ge_10mm", "high")
            or probs["6h_ge_10mm"] >= _thr("y_6h_ge_10mm", "high")):
        assert tier == "high"
    elif (probs["3h_ge_10mm"] >= _thr("y_3h_ge_10mm", "elevated")
          or probs["6h_ge_10mm"] >= _thr("y_6h_ge_10mm", "elevated")
          or probs["3h_ge_5mm"] >= _thr("y_3h_ge_5mm", "elevated")):
        assert tier == "elevated"
    else:
        assert tier in ("low", "moderate")


def test_shared_regressors_across_versions(forecaster_v3, hourly):
    """v3, v3.2 and v3.3 share the v3 regressors: the amount forecast
    (expected_mm) must be identical across versions for the same input.
    Only the classifiers differ."""
    from ml.predict import RainfallForecaster

    v32 = RainfallForecaster(
        model_dir=os.path.join(BACKEND, "models", "rainfall_xgb_v3_2"))
    v33 = RainfallForecaster(model_dir=FROZEN)
    a = forecaster_v3.predict(hourly)
    b = v32.predict(hourly)
    c = v33.predict(hourly)
    assert a == b == c
    assert (forecaster_v3.upper_bound_p90(hourly)
            == v32.upper_bound_p90(hourly) == v33.upper_bound_p90(hourly))


def test_hourly_rates_are_sane(v3_client):
    """The API's derived per-hour rates (hours 1..6) are non-negative
    and consistent with the model's 1h/3h/6h accumulations."""
    from app import model_service as ms

    rates = ms.get_model_hourly_rates()
    assert set(rates) == {1, 2, 3, 4, 5, 6}
    assert all(isinstance(v, float) and v >= 0 for v in rates.values())
    # hours 2-3 share a rate, hours 4-6 share a rate (derivation rule).
    assert rates[2] == rates[3]
    assert rates[4] == rates[5] == rates[6]


# ------------------------------------------------------------------
# Missing / invalid features
# ------------------------------------------------------------------

def test_features_at_requires_73_rows(forecaster_v3, hourly):
    with pytest.raises(ValueError, match="at least 73"):
        forecaster_v3._features_at(hourly.iloc[:50])


def test_predict_with_nan_features_returns_finite(forecaster_v3, hourly):
    """Models handle NaN natively (XGBoost/LightGBM/HGB). A frame with
    heavy missingness in the last 72 h must still produce finite,
    non-negative predictions — never a crash or NaN output."""
    import numpy as np
    import pandas as pd

    frame = hourly.copy()
    # Blank out precipitation for the last 72 h (worst realistic gap).
    frame.loc[frame.index[-72:], "precipitation_mm"] = np.nan
    out = forecaster_v3.predict_with_provenance(frame)
    for v in list(out["expected_mm"].values()) + list(out["upper_bound_p90_mm"].values()):
        assert math.isfinite(v) and v >= 0
    for v in out["heavy_rain_probability"].values():
        assert 0.0 <= v <= 1.0


def test_v33_predict_with_gfs_unavailable_returns_finite(hourly):
    """v3.3's GFS features are optional: with the GFS files unreachable,
    the features fall back to NaN and inference still returns finite
    values (never a crash)."""
    import ml.predict as predict_mod
    from ml.predict import RainfallForecaster

    monkey_csv = os.path.join(BACKEND, "data", "processed", "ifs",
                              "definitely-not-there.csv")
    original = predict_mod.GFS_PROCESSED_CSV
    predict_mod.GFS_PROCESSED_CSV = monkey_csv
    try:
        fc = RainfallForecaster(model_dir=FROZEN)
        out = fc.predict_with_provenance(hourly)
    finally:
        predict_mod.GFS_PROCESSED_CSV = original
    for v in list(out["expected_mm"].values()) + list(out["upper_bound_p90_mm"].values()):
        assert math.isfinite(v) and v >= 0
    for v in out["heavy_rain_probability"].values():
        assert 0.0 <= v <= 1.0
