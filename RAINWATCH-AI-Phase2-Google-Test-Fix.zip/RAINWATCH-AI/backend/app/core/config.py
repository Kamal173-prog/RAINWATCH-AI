"""Configuration — reads ``.env`` (see ``.env.example``).

Open-Meteo is free and keyless, and the historical CSVs ship in
``backend/data/``. The Google Weather API is the exception: it needs
``GOOGLE_WEATHER_API_KEY`` (a Maps Demo Key for hackathon prototyping,
or a standard key). Without it the Google endpoint answers 503 and
RAINWATCH keeps working without Google.
"""

import os

from dotenv import load_dotenv

load_dotenv()

PORT = int(os.environ.get("PORT", "8000"))
HOST = os.environ.get("HOST", "0.0.0.0")

_cors = os.environ.get("CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173")
CORS_ORIGINS = [o.strip() for o in _cors.split(",") if o.strip()]

DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///./rainwatch.db")

BHUBANESWAR_CSV = os.environ.get("BHUBANESWAR_CSV", "")

# Google Weather API key (Google Maps Platform Weather API).
# Maps Demo Key for hackathon prototyping, or a standard key.
# Empty = Google Weather is not configured; GET /api/weather/google
# answers 503 and RAINWATCH works without it. Never commit a real key:
# put it in backend/.env only, never in .env.example, git, or the frontend.
GOOGLE_WEATHER_API_KEY = os.environ.get("GOOGLE_WEATHER_API_KEY", "")

# Process-local monthly cap on Google Weather API calls (the real
# control is the Cloud Console quota / budget alert). 0 or invalid
# values fall back to the service default (5000).
GOOGLE_WEATHER_MONTHLY_CAP = os.environ.get("GOOGLE_WEATHER_MONTHLY_CAP", "")
