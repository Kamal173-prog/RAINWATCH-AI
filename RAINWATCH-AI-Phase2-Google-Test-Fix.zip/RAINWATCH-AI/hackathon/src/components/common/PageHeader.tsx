import { motion } from 'framer-motion'
import type { ReactNode } from 'react'

export function PageHeader({
  title,
  subtitle,
  children,
  meta,
}: {
  title: string
  subtitle?: string
  children?: ReactNode
  meta?: ReactNode
}) {
  return (
    <motion.header
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.36, ease: [0.16, 1, 0.3, 1] }}
      className="relative mb-5 flex flex-col gap-4 border-b border-line pb-4 xl:flex-row xl:items-end xl:justify-between"
    >
      <span className="absolute -bottom-px left-0 h-px w-24 bg-accent" aria-hidden />
      <div className="min-w-0">
        <div className="mono mb-2 flex flex-wrap items-center gap-2 text-[10px] text-muted">{meta}</div>
        <h1 className="max-w-4xl text-2xl leading-[1.05] font-bold tracking-[-0.045em] text-ink sm:text-[32px]">
          {title}
        </h1>
        {subtitle ? <p className="mt-2 max-w-3xl text-[13px] leading-relaxed text-muted">{subtitle}</p> : null}
      </div>
      {children ? <div className="flex shrink-0 flex-wrap items-center gap-2">{children}</div> : null}
    </motion.header>
  )
}

export function SectionTitle({
  children,
  hint,
  action,
}: {
  children: ReactNode
  hint?: string
  action?: ReactNode
}) {
  return (
    <div className="mb-3 flex flex-wrap items-center justify-between gap-2 border-l-2 border-accent pl-3">
      <div className="flex flex-wrap items-baseline gap-2">
        <h2 className="text-xs font-bold tracking-[0.04em] text-ink uppercase">{children}</h2>
        {hint ? <span className="mono text-[10px] text-muted">{hint}</span> : null}
      </div>
      {action}
    </div>
  )
}
