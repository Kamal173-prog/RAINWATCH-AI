import { motion } from 'framer-motion'
import { BarChart3, Download, Gauge, Info, RotateCcw, Waves } from 'lucide-react'
import { useMemo, useState } from 'react'
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip as RTooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { toast } from 'sonner'
import { Badge, RainBadge, SourceBadge, SourceMixBadge } from '../components/common/Badge'
import { Button } from '../components/common/Button'
import { ChartCard } from '../components/common/ChartCard'
import { DataTable, type Column } from '../components/common/DataTable'
import { InfoTip } from '../components/common/InfoTip'
import { PageHeader } from '../components/common/PageHeader'
import { SegmentedControl } from '../components/common/SegmentedControl'
import { Select } from '../components/common/Select'
import { SkeletonCard, StatePanel } from '../components/common/Skeleton'
import { useSelectedLocation } from '../context/LocationContext'
import { useSettings } from '../context/SettingsContext'
import { useAsyncData } from '../hooks/useAsyncData'
import { TIMEFRAME_OPTIONS, timeframeHours } from '../data/settingsData'
import { demoApi, type GoogleForecastPoint } from '../services/dataService'
import type { MergedForecastPoint } from '../types'
import { MODEL_CELL_NOTE, GOOGLE_WEATHER_NOTE, MERGED_TABLE_NOTE, UNAVAILABLE_NOTE, resolveSource, summarizeSources } from '../utils/source'
import { downloadCsv } from '../utils/csv'
import { formatTime, RAINFALL_BANDS, rainfallColor } from '../utils/colors'

const tooltipStyle = {
  background: 'var(--rw-card)', border: '1px solid var(--rw-border)', borderRadius: 12,
  color: 'var(--rw-ink)', fontSize: 12, boxShadow: '0 20px 50px -25px rgba(0,0,0,0.9)',
}

type Metric = 'rate' | 'accumulated' | 'confidence'

/** Bars tooltip: shows the value with its per-row unit and source. */
function BarsTooltip(props: { active?: boolean; payload?: Array<{ payload?: Record<string, unknown> }>; label?: string }) {
  const { active, payload, label } = props
  if (!active || !payload || payload.length === 0) return null
  const d = (payload[0]?.payload ?? {}) as { value?: number | null; source?: string }
  const sourceLabel =
    d.source === 'model' ? 'MODEL'
    : d.source === 'google_weather' ? 'GOOGLE WEATHER'
    : d.source === 'unavailable' ? 'UNAVAILABLE'
    : 'UNKNOWN'
  return (
    <div className="rounded-xl px-3 py-2 text-xs" style={tooltipStyle}>
      <p className="font-semibold">{label}</p>
      <p>{d.value != null ? `${d.value} ${d.source === 'google_weather' ? 'mm in hour' : 'mm/hr'}` : 'No value'}</p>
      <p className="text-muted">{sourceLabel}</p>
    </div>
  )
}

export function RainfallForecast() {
  const { locationId, setLocationId } = useSelectedLocation()
  const { settings, update } = useSettings()
  const [timeframe, setTimeframe] = useState<string>(settings.defaultTimeframe)
  const [metric, setMetric] = useState<Metric>('rate')
  const [showPeakLines, setShowPeakLines] = useState(true)

  const hours = timeframeHours(timeframe)
  const { data: locations } = useAsyncData(() => demoApi.listLocations(), [])
  // Merged forecast — source priority MODEL > GOOGLE WEATHER >
  // UNAVAILABLE. Depends on [locationId, hours] only, NOT on the demo
  // `version`: the merged series has no demo values, so a demo refresh
  // must not refetch it or burn Google quota. The fetch THROWS when
  // the backend is down, so the page shows its error panel — never
  // demo values.
  const { data: merged, loading, error, reload } = useAsyncData(
    () => demoApi.fetchMergedForecast(locationId, hours),
    [locationId, hours],
  )
  const forecast = merged?.points ?? null
  const googleMeta = merged?.meta.google
  // Regional comparison — merged series for the 3 sample locations,
  // same endpoint, so it carries the same source priority.
  const { data: comparison } = useAsyncData(
    async () => {
      const locs = ['old-town', 'patia', 'nayapalli', 'cuttack'].filter((id) => id !== locationId).slice(0, 3)
      const sets = await Promise.all(locs.map((id) => demoApi.fetchMergedForecast(id, hours)))
      return locs.map((id, i) => ({ id, points: sets[i].points }))
    },
    [locationId, hours],
  )

  // Google Weather — independent external forecast. Depends on
  // [locationId, hours] only, NOT on the demo `version`, so a demo
  // refresh never burns Google quota. Never falls back to demo data:
  // an unavailable Google section renders as unavailable.
  const { data: googleResult, loading: googleLoading } = useAsyncData(
    () => demoApi.fetchGoogleForecast(locationId, hours),
    [locationId, hours],
  )
  const googlePayload = googleResult?.available ? googleResult.payload : null
  const googleReason = googleResult && !googleResult.available ? googleResult.reason : null

  // Merged series, split by source for the charts. The model rate
  // (mm/hr) and Google QPF (mm in hour) are different quantities —
  // they are drawn as separate series and never averaged.
  const chartData = useMemo(() => (forecast ?? []).map((p, i) => ({
    time: formatTime(p.timestamp),
    value: p.rainfallMmHr,
    modelRate: p.source === 'model' ? p.rainfallMmHr : null,
    googleQpf: p.source === 'google_weather' ? p.rainfallMmHr : null,
    accumulated: p.accumulatedMm,
    confidence: p.source === 'model' ? p.confidence : null,
    source: resolveSource(p),
    color: p.rainfallMmHr != null ? rainfallColor(p.rainfallMmHr) : '#8B9996',
    index: i,
  })), [forecast])

  // Regional mean over valued points only — an unavailable hour
  // contributes nothing (never a fabricated 0); null when no sample
  // location has a value for that hour.
  const comparisonData = useMemo(() => (forecast ?? []).map((p, i) => {
    const vals = (comparison ?? [])
      .map((s) => s.points[i]?.rainfallMmHr)
      .filter((v): v is number => v != null)
    return {
      time: formatTime(p.timestamp),
      selected: p.rainfallMmHr,
      region: vals.length ? Math.round((vals.reduce((sum, v) => sum + v, 0) / vals.length) * 10) / 10 : null,
    }
  }), [forecast, comparison])

  // Intensity distribution, computed client-side from the merged
  // points (count by classification). Unavailable rows have no
  // classification and are excluded.
  const distribution = useMemo(() => RAINFALL_BANDS.map((b) => ({
    label: b.label,
    hours: (forecast ?? []).filter((p) => p.classification === b.label).length,
    color: b.color,
  })), [forecast])

  // Summary strip — over merged points that have a value only.
  // Peak and total are unknown (shown as —) when no valued hour
  // exists; mean confidence is computed over MODEL points only.
  const valued = (forecast ?? []).filter((p) => p.rainfallMmHr != null)
  const peak = valued.reduce<MergedForecastPoint | undefined>(
    (best, p) => ((p.rainfallMmHr ?? 0) > (best?.rainfallMmHr ?? -1) ? p : best), valued[0])
  const total = forecast?.[forecast.length - 1]?.accumulatedMm ?? null
  const modelPoints = (forecast ?? []).filter((p) => p.source === 'model')
  const meanConfidence = modelPoints.length
    ? Math.round(modelPoints.reduce((s, p) => s + (p.confidence ?? 0), 0) / modelPoints.length)
    : null

  // Provenance comes only from the per-point `source` metadata the
  // backend returns. Never from the model version.
  const sourceCounts = useMemo(() => summarizeSources(forecast ?? []), [forecast])
  const hasModel = sourceCounts.model > 0
  const hasGoogle = sourceCounts.googleWeather > 0
  const hasUnavailable = sourceCounts.unavailable > 0
  const modelVersions = useMemo(
    () => [...new Set((forecast ?? []).filter((p) => p.source === 'model').map((p) => p.model_version).filter(Boolean))],
    [forecast],
  )
  const subtitle =
    hasModel && hasGoogle
      ? 'ML-model forecast for the first hours, Google Weather for the rest — every row is labelled with its source.'
      : hasModel && hasUnavailable
        ? 'ML-model forecast where available; hours Google Weather could not provide are UNAVAILABLE.'
        : hasGoogle
          ? 'Google Weather forecast — the RAINWATCH model has no coverage for this location.'
          : hasUnavailable
            ? 'No forecast values available for this location right now.'
            : 'Loading forecast…'
  const sourceWarning =
    hasModel && hasGoogle
      ? 'MODEL + GOOGLE WEATHER — merged forecast'
      : hasModel && hasUnavailable
        ? 'MODEL + UNAVAILABLE — no Google values'
        : hasGoogle
          ? 'GOOGLE WEATHER only'
          : hasUnavailable
            ? 'UNAVAILABLE — no forecast values'
            : 'Merged forecast'
  const googleStatusNote =
    googleMeta?.status === 'not_configured'
      ? 'Google Weather is not configured — hours without model coverage show UNAVAILABLE.'
      : googleMeta?.status === 'error'
        ? `Google Weather could not be reached${googleMeta.reason ? ` (${googleMeta.reason})` : ''} — hours without model coverage show UNAVAILABLE.`
        : null

  const exportCsv = () => {
    downloadCsv(`rainwatch-forecast-${locationId}-${timeframe}`,
      ['Timestamp', 'Rainfall value', 'Value kind', 'Accumulated (mm)', 'Classification', 'Confidence (%)', 'Precipitation probability (%)', 'Source'],
      (forecast ?? []).map((p) => [p.timestamp, p.rainfallMmHr ?? '', p.valueKind ?? '', p.accumulatedMm ?? '', p.classification ?? '', p.confidence ?? '', p.precipitationProbabilityPct ?? '', resolveSource(p)]))
    toast.success('Forecast exported as CSV', { description: `${forecast?.length ?? 0} hourly records.` })
  }

  const exportGoogleCsv = () => {
    if (!googlePayload) return
    downloadCsv(`rainwatch-google-weather-${locationId}-${timeframe}`,
      ['Timestamp', 'Precipitation (mm in hour)', 'Probability (%)', 'Temperature (°C)', 'Condition', 'Source'],
      googlePayload.hours.map((p) => [p.timestamp, p.precipitationMm ?? '', p.precipitationProbabilityPct ?? '', p.temperatureC, p.conditionText ?? p.condition ?? '', resolveSource(p)]))
    toast.success('Google Weather exported as CSV', { description: `${googlePayload.hours.length} hourly records.` })
  }

  const reset = () => {
    setTimeframe(settings.defaultTimeframe)
    setMetric('rate')
    setShowPeakLines(true)
    toast.info('Forecast filters reset')
  }

  const tableColumns: Column<MergedForecastPoint>[] = [
    { key: 'time', header: 'Hour', render: (p) => <span className="num text-ink">{formatTime(p.timestamp)}</span> },
    {
      key: 'rate', header: 'Rainfall', render: (p) => (
        <span className="flex flex-col">
          <span className="num font-semibold" style={{ color: p.rainfallMmHr != null ? rainfallColor(p.rainfallMmHr) : 'var(--rw-muted)' }}>{p.rainfallMmHr ?? '—'}</span>
          <span className="text-[10px] text-muted">{p.valueKind === 'model_rate_mm_hr' ? 'mm/hr' : p.valueKind === 'google_qpf_mm' ? 'mm in hour' : ''}</span>
        </span>
      ),
    },
    { key: 'class', header: 'Classification', render: (p) => (p.classification ? <RainBadge label={p.classification} /> : <span className="text-muted">—</span>) },
    { key: 'acc', header: 'Accumulated (mm)', render: (p) => <span className="num">{p.accumulatedMm ?? '—'}</span>, secondary: true },
    { key: 'conf', header: 'Confidence', render: (p) => <span className="num">{p.confidence != null ? `${p.confidence}%` : '—'}</span>, secondary: true },
    { key: 'source', header: 'Source', render: (p) => <SourceBadge source={resolveSource(p)} modelVersion={p.model_version} /> },
  ]

  // Google Weather table — a separate table, never merged into the
  // RAINWATCH table above. Every row is GOOGLE WEATHER by construction.
  const googleColumns: Column<GoogleForecastPoint>[] = [
    { key: 'time', header: 'Hour', render: (p) => <span className="num text-ink">{formatTime(p.timestamp)}</span> },
    { key: 'precip', header: 'Precipitation (mm in hour)', render: (p) => <span className="num font-semibold">{p.precipitationMm ?? '—'}</span> },
    { key: 'prob', header: 'Probability (%)', render: (p) => <span className="num">{p.precipitationProbabilityPct ?? '—'}</span> },
    { key: 'temp', header: 'Temperature (°C)', render: (p) => <span className="num">{p.temperatureC}</span> },
    { key: 'cond', header: 'Condition', render: (p) => <span className="text-ink">{p.conditionText ?? p.condition ?? '—'}</span> },
    { key: 'source', header: 'Source', render: (p) => <SourceBadge source={resolveSource(p)} /> },
  ]

  const metricKey = metric === 'rate' ? 'rate' : metric === 'accumulated' ? 'accumulated' : 'confidence'
  const metricLabel = metric === 'rate' ? 'Rainfall — model rate vs Google QPF' : metric === 'accumulated' ? 'Accumulated (mm)' : 'Confidence (%)'
  const metricColor = metric === 'rate' ? 'var(--rw-accent)' : metric === 'accumulated' ? 'var(--rw-accent-2)' : '#B19BFA'

  return (
    <div className="section-gap flex flex-col">
      <PageHeader
        title="Rainfall Forecast"
        subtitle={subtitle}
        meta={<><SourceMixBadge counts={sourceCounts} /><Badge tone="warning">{sourceWarning}</Badge></>}
      >
        <Button icon={<Download size={14} />} onClick={exportCsv}>Export CSV</Button>
        <Button icon={<RotateCcw size={14} />} onClick={reset}>Reset filters</Button>
      </PageHeader>

      {/* Single-cell origin — shown whenever MODEL values are on screen. */}
      {hasModel ? (
        <p className="rounded-xl border border-line bg-surface/60 px-4 py-2.5 text-[11px] leading-relaxed text-muted">
          <strong className="text-ink">Single grid cell: </strong>
          {MODEL_CELL_NOTE}
        </p>
      ) : null}

      {/* Google status — shown when Google could not serve the hours
          the model does not cover, so the UNAVAILABLE rows are explained. */}
      {googleStatusNote ? (
        <p className="rounded-xl border border-warning/25 bg-warning/8 px-4 py-2.5 text-[11px] leading-relaxed text-warning">
          {googleStatusNote}
        </p>
      ) : null}

      {/* Controls */}
      <div className="flex flex-col gap-3 rounded-2xl border border-line bg-card p-[var(--rw-card-pad)]">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex flex-col gap-1.5">
            <span className="text-[11px] font-semibold tracking-wider text-muted uppercase">Forecast horizon</span>
            <SegmentedControl
              ariaLabel="Forecast timeframe" size="sm"
              value={timeframe}
              onChange={(v) => { setTimeframe(v); update({ defaultTimeframe: v as typeof settings.defaultTimeframe }) }}
              options={TIMEFRAME_OPTIONS.map((t) => ({ value: t.id as string, label: t.id.toUpperCase() }))}
            />
          </div>
          <Select label="Location" options={(locations ?? []).map((l) => ({ value: l.id, label: `${l.name} · ${l.zone}` }))} value={locationId} onValueChange={setLocationId} compact className="min-w-[200px] flex-1" />
          <Select label="Chart metric" options={[
            { value: 'rate', label: 'Rainfall rate (mm/hr)' },
            { value: 'accumulated', label: 'Accumulated (mm)' },
            { value: 'confidence', label: 'Confidence (%)' },
          ]} value={metric} onValueChange={(v) => setMetric(v as Metric)} compact className="w-[190px]" />
          <Button variant={showPeakLines ? 'secondary' : 'ghost'} size="sm" onClick={() => setShowPeakLines((v) => !v)}>
            {showPeakLines ? 'Hide' : 'Show'} intensity guides
          </Button>
        </div>
        <p className="flex items-center gap-1.5 text-[11px] text-muted"><Info size={12} /> Forecast horizon: {TIMEFRAME_OPTIONS.find((t) => t.id === timeframe)?.label} · {hours} hourly steps.</p>
      </div>

      {error ? <StatePanel variant="error" title="Forecast unavailable" message={error} actionLabel="Retry" onAction={reload} /> : null}

      {/* Summary strip */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {loading ? Array.from({ length: 4 }).map((_, i) => <SkeletonCard key={i} lines={1} />) : (
          <>
            {[
              { label: 'Peak rainfall', value: peak ? `${peak.rainfallMmHr} mm/hr` : '—', color: '#F2A93B', icon: Waves },
              { label: 'Total accumulation', value: total != null ? `${total} mm` : '—', color: '#6FD6C2', icon: BarChart3 },
              { label: 'Peak at', value: peak ? formatTime(peak.timestamp) : '—', color: '#6FD6C2', icon: Gauge },
              { label: 'Mean confidence', value: meanConfidence != null ? `${meanConfidence}%` : '—', color: '#B19BFA', icon: Info },
            ].map((s, i) => {
              const Icon = s.icon
              return (
                <motion.div key={s.label} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                  className="rounded-2xl border border-line bg-card p-[var(--rw-card-pad)]">
                  <div className="flex items-center justify-between"><span className="text-[10px] font-semibold tracking-wider text-muted uppercase">{s.label}</span><Icon size={14} style={{ color: s.color }} /></div>
                  <p className="num mt-2 text-lg font-bold text-ink">{s.value}</p>
                </motion.div>
              )
            })}
          </>
        )}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <ChartCard title="Rainfall Intensity Timeline" subtitle={`${metricLabel} · ${TIMEFRAME_OPTIONS.find((t) => t.id === timeframe)?.label}`} icon={<Waves size={16} />} height={300} loading={loading} delay={0.02}>
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
              <defs><linearGradient id="fcFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={metricColor} stopOpacity={0.45} /><stop offset="100%" stopColor={metricColor} stopOpacity={0.02} /></linearGradient></defs>
              <CartesianGrid stroke="var(--rw-border)" strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="time" tickLine={false} axisLine={false} interval={Math.max(1, Math.floor(chartData.length / 8))} />
              <YAxis tickLine={false} axisLine={false} width={46} />
              <RTooltip contentStyle={tooltipStyle} />
              {metric === 'rate' ? (
                <>
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                  {/* Two separate series — model rate and Google QPF are
                      different quantities, drawn together only for visual
                      comparison, never averaged. Gaps are UNAVAILABLE hours. */}
                  <Area type="monotone" dataKey="modelRate" name="RAINWATCH model (mm/hr)" stroke={metricColor} strokeWidth={2.2} fill="url(#fcFill)" dot={false} connectNulls={false} animationDuration={800} />
                  <Line type="monotone" dataKey="googleQpf" name="Google Weather QPF (mm in hour)" stroke="#7FB3D5" strokeWidth={2} strokeDasharray="5 4" dot={false} connectNulls={false} animationDuration={800} />
                </>
              ) : (
                <Area type="monotone" dataKey={metricKey} name={metricLabel} stroke={metricColor} strokeWidth={2.2} fill="url(#fcFill)" dot={false} connectNulls={false} animationDuration={800} />
              )}
            </AreaChart>
          </ResponsiveContainer>
          {metric === 'rate' ? (
            <p className="mt-2 text-[11px] leading-relaxed text-muted">
              The solid line is the RAINWATCH model rate (mm/hr); the dashed line is Google&apos;s hourly QPF (mm that fell in the hour). Different quantities, shown together only for visual comparison — never averaged. Gaps are hours with no forecast value.
            </p>
          ) : null}
        </ChartCard>

        <ChartCard title="Hourly Rainfall Bars" subtitle="Bars coloured by intensity classification" icon={<BarChart3 size={16} />} height={300} loading={loading} delay={0.06}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
              <CartesianGrid stroke="var(--rw-border)" strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="time" tickLine={false} axisLine={false} interval={Math.max(1, Math.floor(chartData.length / 8))} />
              <YAxis tickLine={false} axisLine={false} width={46} />
              <RTooltip content={<BarsTooltip />} />
              <Bar dataKey="value" name="Rainfall" radius={[3, 3, 0, 0]} animationDuration={800}>
                {chartData.map((d, i) => <Cell key={i} fill={d.color} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Accumulated Rainfall" subtitle="Running total over the forecast horizon" icon={<BarChart3 size={16} />} height={300} loading={loading} delay={0.1}>
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
              <CartesianGrid stroke="var(--rw-border)" strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="time" tickLine={false} axisLine={false} interval={Math.max(1, Math.floor(chartData.length / 8))} />
              <YAxis tickLine={false} axisLine={false} width={46} />
              <RTooltip contentStyle={tooltipStyle} />
              <Area type="monotone" dataKey="accumulated" name="Accumulated mm" stroke="var(--rw-accent-2)" strokeWidth={2} fill="var(--rw-accent-2)" fillOpacity={0.2} dot={false} connectNulls={false} animationDuration={800} />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Forecast Comparison" subtitle="Selected location vs regional mean (3 sample locations)" icon={<Info size={16} />} height={300} loading={loading} delay={0.14}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={comparisonData} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
              <CartesianGrid stroke="var(--rw-border)" strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="time" tickLine={false} axisLine={false} interval={Math.max(1, Math.floor(comparisonData.length / 8))} />
              <YAxis tickLine={false} axisLine={false} width={46} />
              <RTooltip contentStyle={tooltipStyle} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Line type="monotone" dataKey="selected" name="Selected region" stroke="var(--rw-accent)" strokeWidth={2} dot={false} connectNulls={false} animationDuration={800} />
              <Line type="monotone" dataKey="region" name="Regional mean" stroke="#F2A93B" strokeWidth={2} strokeDasharray="5 4" dot={false} connectNulls={false} animationDuration={800} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Intensity distribution + bands */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <ChartCard title="Intensity Distribution" subtitle="Forecast hours by class" icon={<BarChart3 size={16} />} height={260} loading={loading} delay={0.02}>
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={distribution.filter((d) => d.hours > 0)} dataKey="hours" nameKey="label" cx="50%" cy="50%" innerRadius={42} outerRadius={70} paddingAngle={3} stroke="none" animationDuration={800}>
                {distribution.filter((d) => d.hours > 0).map((d) => <Cell key={d.label} fill={d.color} />)}
              </Pie>
              <RTooltip contentStyle={tooltipStyle} />
              <Legend wrapperStyle={{ fontSize: 10 }} />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Intensity Classification" subtitle="Illustrative IMD-style thresholds" icon={<Info size={16} />} height={260} delay={0.06}
          footer={<span className="flex items-center gap-1"><InfoTip text="Thresholds are illustrative categories used for UI demonstration only." /> Hover the info icon for details.</span>}>
          <div className="space-y-1.5">
            {RAINFALL_BANDS.map((b) => (
              <div key={b.label} className="flex items-center justify-between gap-2 rounded-lg border border-line bg-surface/60 px-3 py-1.5">
                <span className="flex items-center gap-2"><span className="h-2.5 w-2.5 rounded-full" style={{ background: b.color }} /><span className="text-xs font-medium text-ink">{b.label}</span></span>
                <span className="num text-[11px] text-muted">{b.range}</span>
              </div>
            ))}
          </div>
        </ChartCard>

        <ChartCard title="Peak & Confidence" subtitle="About this forecast" icon={<Gauge size={16} />} height={260} delay={0.1}>
          <div className="space-y-3">
            <div className="rounded-xl border border-warning/30 bg-warning/8 p-3">
              <p className="text-[10px] font-semibold tracking-wider text-warning uppercase">Peak intensity window</p>
              <p className="num mt-1 text-lg font-bold text-ink">{peak ? `${peak.rainfallMmHr} mm/hr` : '—'}</p>
              <p className="text-[11px] text-muted">{peak ? `${peak.classification ?? '—'} · ${formatTime(peak.timestamp)}` : '—'}</p>
            </div>
            <div className="rounded-xl border border-line bg-surface/60 p-3">
              <p className="text-[10px] font-semibold tracking-wider text-muted uppercase">Mean confidence</p>
              <p className="num mt-1 text-lg font-bold text-ink">{meanConfidence != null ? `${meanConfidence}%` : '—'}</p>
              <p className="text-[11px] text-muted">Mean confidence is computed over MODEL hours only. Google Weather precipitation probabilities are not confidence and are never mixed in.</p>
            </div>
          </div>
        </ChartCard>
      </div>

      {/* Table */}
      <ChartCard title="Forecast Data Table" subtitle={`${forecast?.length ?? 0} hourly records · ${TIMEFRAME_OPTIONS.find((t) => t.id === timeframe)?.label}`} icon={<BarChart3 size={16} />}
        actions={<Button size="sm" icon={<Download size={13} />} onClick={exportCsv}>Export CSV</Button>}
        loading={loading} empty={(forecast?.length ?? 0) === 0}>
        <p className="mb-3 rounded-xl border border-line bg-surface/60 px-4 py-2.5 text-[11px] leading-relaxed text-muted">
          {MERGED_TABLE_NOTE}
        </p>
        <DataTable columns={tableColumns} rows={forecast ?? []} rowKey={(p) => p.timestamp} maxHeight={420} caption="Hourly rainfall forecast" />
      </ChartCard>

      {/* Google Weather — separate section, never merged into the
          RAINWATCH table above. Google values are an external
          forecast, not RAINWATCH predictions. */}
      <ChartCard
        title="Google Weather"
        subtitle={googlePayload
          ? `${googlePayload.hours.length} hourly records · retrieved ${formatTime(googlePayload.retrievedAt)}${googlePayload.meta.cached ? ' · cached' : ''}`
          : 'External forecast'}
        icon={<BarChart3 size={16} />}
        actions={googlePayload ? <Button size="sm" icon={<Download size={13} />} onClick={exportGoogleCsv}>Export Google CSV</Button> : undefined}
        loading={googleLoading}
        empty={false}
      >
        {googlePayload ? (
          <>
            <p className="mb-3 rounded-xl border border-line bg-surface/60 px-4 py-2.5 text-[11px] leading-relaxed text-muted">
              <strong className="text-ink">External forecast: </strong>
              {GOOGLE_WEATHER_NOTE}
            </p>
            <DataTable columns={googleColumns} rows={googlePayload.hours} rowKey={(p) => p.timestamp} maxHeight={420} caption="Google Weather hourly forecast" />
          </>
        ) : (
          <p className="rounded-xl border border-warning/25 bg-warning/8 px-4 py-2.5 text-[11px] leading-relaxed text-warning">
            Google Weather unavailable — {googleReason ?? 'unknown reason'}. The RAINWATCH forecast above is unaffected.
          </p>
        )}
      </ChartCard>

      <p className="rounded-xl border border-warning/25 bg-warning/8 px-4 py-2.5 text-[11px] leading-relaxed text-warning">
        {MERGED_TABLE_NOTE}{' '}
        {hasModel ? (
          <>
            MODEL values are produced by the trained rainfall ensemble
            {modelVersions.length ? ` (${modelVersions.join(', ')})` : ''} for the Bhubaneswar grid cell — the same
            single cell's forecast is applied to every Bhubaneswar-region location, including Cuttack and Puri; it
            is not a separate per-city forecast. An early-warning signal, not a confirmed forecast.
          </>
        ) : null}{' '}
        GOOGLE WEATHER values are an external forecast from Google — not a RAINWATCH ML prediction, and their
        accuracy has not been validated against RAINWATCH. {UNAVAILABLE_NOTE}
      </p>
    </div>
  )
}
