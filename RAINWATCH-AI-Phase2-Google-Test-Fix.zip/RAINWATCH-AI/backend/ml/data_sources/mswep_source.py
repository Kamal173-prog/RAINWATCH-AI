"""MSWEP V3 precipitation (v3.2, Source C).

Organisation: GloH2O (https://www.gloh2o.org/).
Product: MSWEP V3 — Multi-Source Weighted-Ensemble Precipitation.
- Hourly, 0.1 deg (~11 km), 1979–present, ~2 h latency.
- Machine-learning merge of gauges, satellites and reanalysis.
- Variants: Past (gauge-corrected) and Past_nogauge (no gauge input).
  Use Past_nogauge when comparing against independent rain gauges.
- Licence: CC BY-NC 4.0 (academic research / non-profit / personal).

Access: **request required.** Submit a request at
https://www.gloh2o.org/mswep — GloH2O emails download instructions
(a shared Google Drive folder, downloaded with rclone). There is no
public keyless download URL.

This connector implements the structure: the expected file layout, the
rclone download helper, and the access check. It does NOT fabricate
MSWEP data. ``fetch`` returns [] with a clear blocker message until
Kam submits the request and provides the shared-drive link.

Reference: Wang et al. (2026), arXiv:2602.01436 — "MSWEP V3: Machine
learning-powered global precipitation estimates at 0.1° hourly
resolution (1979–present)".
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from .base_source import BaseDataSource

log = logging.getLogger(__name__)

PORTAL_URL = "https://www.gloh2o.org/mswep"
VARIANTS = ("Past", "Past_nogauge")


class MSWEPSource(BaseDataSource):
    """MSWEP V3 hourly precipitation."""

    SOURCE_NAME = "mswep"
    PRODUCT_NAME = "MSWEP V3"
    PRODUCT_VERSION = "V3 (2026)"
    AVAILABILITY_LAG = "PT2H"  # near real-time, ~2 h latency
    LICENSE = "CC BY-NC 4.0"
    ACCESS_RESTRICTIONS = (
        "Request required at https://www.gloh2o.org/mswep — GloH2O "
        "emails a shared Google Drive folder link. Download with rclone. "
        "No public keyless download URL exists."
    )

    def __init__(self, backend_dir: Path | None = None, variant: str = "Past"):
        super().__init__(backend_dir)
        if variant not in VARIANTS:
            raise ValueError(f"unknown MSWEP variant {variant!r}; choose from {VARIANTS}")
        self.variant = variant

    def check_access(self) -> tuple[bool, str]:
        drive_link = self.env_or_none("MSWEP_DRIVE_LINK")
        if not drive_link:
            return False, (
                "MSWEP access not configured. Submit a request at "
                "https://www.gloh2o.org/mswep and set MSWEP_DRIVE_LINK "
                "to the shared Google Drive folder URL from the reply email."
            )
        return True, "MSWEP_DRIVE_LINK present"

    def fetch(
        self,
        start: str,
        end: str,
        bbox: Optional[tuple[float, float, float, float]] = None,
    ) -> list[Path]:
        ok, msg = self.check_access()
        if not ok:
            log.error("MSWEP fetch blocked: %s", msg)
            return []
        raise NotImplementedError(
            "MSWEP fetch is not implemented: the shared-drive layout "
            "must be confirmed from the actual GloH2O reply email before "
            "writing the rclone download. Do not fabricate MSWEP data."
        )

    def process(self, raw_files: list[Path]) -> Path:
        raise NotImplementedError(
            "MSWEP processing is not implemented: no MSWEP files have "
            "been obtained. Implement once the first file is available "
            "and its format is inspected."
        )
