"""Fetch thermodynamic variables for Bhubaneswar and upwind spatial grids.

Fetches 2021-2025 hourly ERA5 data from the Open-Meteo archive API with
polite rate-limit protection:
- 4 seconds between requests.
- Automatic exponential backoff on HTTP 429 (up to 5 retries, doubling
  the wait each time).
- If a grid is still rate-limited after retries, it is logged and the
  script proceeds with whatever grids succeeded (never blocks the pipeline).

Grids
-----
1. Bhubaneswar (20.281195, 85.843376) — thermodynamic columns merged into
   ``data/processed/bhubaneswar_weather.csv``:
   cape, wind_direction_10m, dew_point_2m, surface_pressure.
2. Puri Coast (19.81, 85.83) and Offshore Bay of Bengal (19.50, 86.30) —
   saved to ``data/processed/upwind_spatial.csv``:
   precipitation, pressure_msl, cape, wind_speed_10m, wind_direction_10m,
   relative_humidity_2m.

Usage:  python ml/fetch_spatial.py
"""

import json
import os
import sys
import time
import urllib.error
import urllib.request

import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
BACKEND = os.path.dirname(HERE)
PROCESSED_BHUB = os.path.join(BACKEND, "data", "processed", "bhubaneswar_weather.csv")
SPATIAL_CSV = os.path.join(BACKEND, "data", "processed", "upwind_spatial.csv")
RAW_DIR = os.path.join(BACKEND, "data", "raw")

BASE_URL = "https://archive-api.open-meteo.com/v1/archive"
DATES = "start_date=2021-01-01&end_date=2025-12-31"
TIMEZONE = "timezone=Asia%2FKolkata"

# Polite rate-limit handling.
SLEEP_BETWEEN_S = 4
MAX_RETRIES = 5
INITIAL_BACKOFF_S = 30

GRIDS = [
    {
        "name": "bhubaneswar_thermo",
        "lat": 20.281195,
        "lon": 85.843376,
        "hourly": "cape,wind_direction_10m,dew_point_2m,surface_pressure",
        "rename": {
            "cape": "cape_jkg",
            "wind_direction_10m": "wind_direction_deg",
            "dew_point_2m": "dew_point_2m_c",
            "surface_pressure": "surface_pressure_hpa",
        },
    },
    {
        "name": "puri_coast",
        "lat": 19.81,
        "lon": 85.83,
        "hourly": "precipitation,pressure_msl,cape,wind_speed_10m,wind_direction_10m,relative_humidity_2m",
        "rename": {
            "precipitation": "coast_precip_mm",
            "pressure_msl": "coast_pressure_hpa",
            "cape": "coast_cape_jkg",
            "wind_speed_10m": "coast_wind_speed_kmh",
            "wind_direction_10m": "coast_wind_direction_deg",
            "relative_humidity_2m": "coast_humidity_pct",
        },
    },
    {
        "name": "offshore_bay",
        "lat": 19.50,
        "lon": 86.30,
        "hourly": "precipitation,pressure_msl,cape,wind_speed_10m,wind_direction_10m,relative_humidity_2m",
        "rename": {
            "precipitation": "bay_precip_mm",
            "pressure_msl": "bay_pressure_hpa",
            "cape": "bay_cape_jkg",
            "wind_speed_10m": "bay_wind_speed_kmh",
            "wind_direction_10m": "bay_wind_direction_deg",
            "relative_humidity_2m": "bay_humidity_pct",
        },
    },
]


def fetch_with_backoff(url: str, name: str):
    """Fetch a URL with exponential backoff on HTTP 429. Returns the parsed JSON or None."""
    backoff = INITIAL_BACKOFF_S
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "RAINWATCH-AI/1.0"})
            with urllib.request.urlopen(req, timeout=180) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            if e.code == 429 and attempt < MAX_RETRIES:
                print(f"  [{name}] HTTP 429 (attempt {attempt}/{MAX_RETRIES}); "
                      f"backing off {backoff}s...")
                time.sleep(backoff)
                backoff *= 2
                continue
            print(f"  [{name}] HTTP {e.code} after {attempt} attempt(s); giving up on this grid.")
            return None
        except Exception as e:  # timeout, DNS, connection errors
            print(f"  [{name}] {type(e).__name__}: {e}; giving up on this grid.")
            return None
    print(f"  [{name}] rate-limited after {MAX_RETRIES} retries; giving up on this grid.")
    return None


def hourly_to_df(payload: dict, rename: dict) -> pd.DataFrame:
    hourly = payload.get("hourly", {})
    times = hourly.get("time", [])
    if not times:
        return pd.DataFrame()
    cols = {"timestamp": pd.to_datetime(times)}
    for src, dst in rename.items():
        if src in hourly:
            cols[dst] = hourly[src]
        else:
            print(f"    WARNING: {src} not in response; skipping.")
    return pd.DataFrame(cols)


def main():
    results = {}
    for i, grid in enumerate(GRIDS):
        if i > 0:
            print(f"Sleeping {SLEEP_BETWEEN_S}s before the next request (polite rate-limit)...")
            time.sleep(SLEEP_BETWEEN_S)
        url = (f"{BASE_URL}?latitude={grid['lat']}&longitude={grid['lon']}"
               f"&{DATES}&hourly={grid['hourly']}&{TIMEZONE}")
        print(f"Fetching {grid['name']} ({grid['lat']}, {grid['lon']})...")
        payload = fetch_with_backoff(url, grid["name"])
        if payload is None:
            print(f"  -> {grid['name']} FAILED (rate-limited or error). Continuing with the rest.")
            continue
        # Save raw for provenance.
        raw_path = os.path.join(RAW_DIR, f"{grid['name']}_raw.json")
        with open(raw_path, "w") as f:
            json.dump(payload, f)
        df = hourly_to_df(payload, grid["rename"])
        print(f"  -> {len(df)} rows, {len(df.columns) - 1} new columns. Raw saved to {raw_path}")
        results[grid["name"]] = df

    # --- Merge Bhubaneswar thermodynamic columns into the processed CSV ---
    if "bhubaneswar_thermo" in results:
        base = pd.read_csv(PROCESSED_BHUB, parse_dates=["timestamp"])
        merged = base.merge(results["bhubaneswar_thermo"], on="timestamp", how="left", validate="one_to_one")
        if len(merged) != len(base):
            print(f"ERROR: Bhubaneswar row count changed after merge ({len(base)} -> {len(merged)}). Aborting merge.")
        else:
            missing = merged[list(results["bhubaneswar_thermo"].columns[1:])].isna().sum()
            if missing.any():
                print(f"WARNING: missing values in new Bhubaneswar columns:\n{missing[missing > 0]}")
            merged.to_csv(PROCESSED_BHUB, index=False)
            print(f"Merged thermodynamic columns into {PROCESSED_BHUB} ({len(merged.columns)} columns).")

    # --- Save upwind grids to a single spatial CSV ---
    upwind = []
    for name in ("puri_coast", "offshore_bay"):
        if name in results:
            upwind.append(results[name])
    if upwind:
        spatial = upwind[0]
        for other in upwind[1:]:
            spatial = spatial.merge(other, on="timestamp", how="outer", validate="one_to_one")
        spatial = spatial.sort_values("timestamp").reset_index(drop=True)
        spatial.to_csv(SPATIAL_CSV, index=False)
        print(f"Saved upwind spatial grids to {SPATIAL_CSV} ({len(spatial)} rows, {len(spatial.columns)} columns).")
    else:
        print("No upwind grids succeeded; upwind_spatial.csv not written.")

    succeeded = sorted(results)
    print(f"\nDone. Succeeded: {succeeded if succeeded else 'NONE — proceeding with existing data only'}.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
