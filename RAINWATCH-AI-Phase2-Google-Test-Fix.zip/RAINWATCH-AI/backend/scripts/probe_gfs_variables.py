"""Probe the Open-Meteo Historical Forecast API (GFS) for new variables.

Tests which candidate variables the gfs_global model actually returns
for Bhubaneswar, over a short monsoon window (2024-07-01..03), and
reports the non-null fraction of each. Unknown variables make the API
return an error for the whole request, so variables are probed in
small batches.

Usage:
    cd backend && .venv/bin/python scripts/probe_gfs_variables.py
"""

from __future__ import annotations

import sys
import time

import requests

BASE = "https://historical-forecast-api.open-meteo.com/v1/forecast"
LAT, LON = 20.281195, 85.843376
START, END = "2024-07-01", "2024-07-03"

BATCHES = {
    "pressure_levels": [
        "temperature_850hPa", "relative_humidity_850hPa",
        "wind_speed_850hPa", "wind_direction_850hPa",
        "temperature_700hPa", "relative_humidity_700hPa",
        "wind_speed_700hPa", "wind_direction_700hPa",
    ],
    "vertical_and_water": [
        "vertical_velocity_850hPa", "vertical_velocity_700hPa",
        "precipitable_water", "convective_inhibition",
    ],
    "surface_extras": [
        "dew_point_2m", "wind_gusts_10m", "cloud_cover_low",
        "cloud_cover_mid", "cloud_cover_high", "snowfall",
        "surface_pressure", "pressure_msl",
    ],
    "more_levels": [
        "temperature_925hPa", "relative_humidity_925hPa",
        "wind_speed_925hPa", "wind_direction_925hPa",
        "geopotential_height_850hPa", "geopotential_height_500hPa",
        "temperature_500hPa", "relative_humidity_500hPa",
    ],
}


def probe(name: str, variables: list[str]) -> None:
    params = {
        "latitude": LAT, "longitude": LON,
        "start_date": START, "end_date": END,
        "hourly": ",".join(variables),
        "models": "gfs_global",
        "timezone": "UTC",
    }
    try:
        r = requests.get(BASE, params=params, timeout=60)
    except Exception as exc:  # noqa: BLE001
        print(f"[{name}] request failed: {exc}")
        return
    if r.status_code != 200:
        print(f"[{name}] HTTP {r.status_code}: {r.text[:200]}")
        return
    hourly = r.json().get("hourly", {})
    times = hourly.get("time", [])
    print(f"[{name}] OK, {len(times)} hours")
    for v in variables:
        vals = hourly.get(v)
        if vals is None:
            print(f"  {v}: NOT RETURNED")
            continue
        nonnull = sum(1 for x in vals if x is not None)
        print(f"  {v}: {nonnull}/{len(vals)} non-null"
              + (f"  e.g. {vals[0]}" if nonnull else ""))


def main() -> None:
    for name, variables in BATCHES.items():
        probe(name, variables)
        time.sleep(2)


if __name__ == "__main__":
    main()
