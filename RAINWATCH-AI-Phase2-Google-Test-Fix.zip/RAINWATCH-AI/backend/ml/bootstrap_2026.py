"""Paired block bootstrap of the 2026 PR-AUC gaps (v3.3 vs each earlier
version), 7-day blocks, 1,000 resamples. Answers whether the frozen
v3.3's 2026 wins are distinguishable from noise on one year of data.
"""

import json
import logging
import os
import sys

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import evaluate_2026 as ev  # noqa: E402
from v33_common import platt_apply  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger("bootstrap_2026")

BACKEND = ev.BACKEND
TARGETS = ev.TARGETS
FAMILIES = ev.FAMILIES


def score_version(name, model_dir, table_path, schema_path, target):
    feats = json.load(open(schema_path))["features"]
    weights = {ev._norm_key(k): v for k, v in
               json.load(open(os.path.join(model_dir, "ensemble_weights.json"))).items()}
    platt = json.load(open(os.path.join(model_dir, "platt.json")))
    df = pd.read_csv(table_path, parse_dates=["timestamp"])
    d26 = df[df["timestamp"].dt.year == 2026].reset_index(drop=True)
    sub = d26.dropna(subset=[target]).reset_index(drop=True)
    y = sub[target].to_numpy().astype(int)
    X = sub[feats].to_numpy(dtype=float)
    ens = np.zeros(len(y))
    for fam in FAMILIES:
        w = float(weights[target][fam])
        if w == 0:
            continue
        ens += w * ev._predict(ev._load_member(model_dir, target, fam), X)
    pl = platt[target]
    return y, platt_apply(ens, float(pl["w"]), float(pl["b"]))


def block_bootstrap(y, p_a, p_b, n_boot=1000, block_h=168, seed=42):
    rng = np.random.default_rng(seed)
    n = len(y)
    starts = np.arange(0, n, block_h)
    diffs = []
    for _ in range(n_boot):
        idx = np.concatenate([np.arange(s, min(s + block_h, n))
                              for s in rng.choice(starts, size=len(starts), replace=True)])
        if y[idx].sum() == 0:
            continue
        diffs.append(average_precision_score(y[idx], p_a[idx])
                     - average_precision_score(y[idx], p_b[idx]))
    diffs = np.array(diffs)
    return {"mean_diff": round(float(diffs.mean()), 4),
            "ci_95": [round(float(np.percentile(diffs, 2.5)), 4),
                      round(float(np.percentile(diffs, 97.5)), 4)],
            "p_diff_gt_0": round(float((diffs > 0).mean()), 3),
            "n_boot": int(len(diffs))}


def main() -> None:
    versions = {
        "v3": (os.path.join(BACKEND, "models", "rainfall_xgb_v3"),
               os.path.join(BACKEND, "data", "model_ready", "bhubaneswar_features_2026.csv"),
               os.path.join(BACKEND, "models", "rainfall_xgb_v3", "feature_schema.json")),
        "v3.1": (os.path.join(BACKEND, "models", "rainfall_xgb_v3_1"),
                 os.path.join(BACKEND, "data", "model_ready", "bhubaneswar_features_2026.csv"),
                 os.path.join(BACKEND, "models", "rainfall_xgb_v3_1", "feature_schema.json")),
        "v3.2": (os.path.join(BACKEND, "models", "rainfall_xgb_v3_2"),
                 os.path.join(BACKEND, "data", "model_ready", "bhubaneswar_features_v32.csv"),
                 os.path.join(BACKEND, "models", "rainfall_xgb_v3_2", "feature_schema.json")),
        "v3.3-frozen": (os.path.join(BACKEND, "models", "rainfall_xgb_v3_3", "frozen"),
                        os.path.join(BACKEND, "data", "model_ready", "bhubaneswar_features_v33.csv"),
                        os.path.join(BACKEND, "models", "rainfall_xgb_v3_3", "frozen", "feature_schema.json")),
    }
    out = {}
    for target in TARGETS:
        probs = {}
        y = None
        for name, (md, tp, sp) in versions.items():
            yy, pp = score_version(name, md, tp, sp, target)
            probs[name] = pp
            y = yy
        out[target] = {}
        for other in ("v3", "v3.1", "v3.2"):
            r = block_bootstrap(y, probs["v3.3-frozen"], probs[other])
            out[target][f"v3.3_minus_{other}"] = r
            log.info("%s v3.3-%s: mean %+0.4f 95%% CI [%+0.4f, %+0.4f] P(>0)=%.3f",
                     target, other, r["mean_diff"], r["ci_95"][0], r["ci_95"][1],
                     r["p_diff_gt_0"])
    json.dump(out, open(os.path.join(BACKEND, "models", "rainfall_xgb_v3_3",
                                     "bootstrap_2026.json"), "w"), indent=2)
    log.info("saved bootstrap_2026.json")


if __name__ == "__main__":
    main()
