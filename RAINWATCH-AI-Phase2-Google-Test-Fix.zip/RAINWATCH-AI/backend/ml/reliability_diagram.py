"""Render reliability diagrams as a self-contained HTML file (inline SVG).

Reads threshold_work/calibration.json (10-bin reliability tables on
pooled out-of-sample 2024+2025 probabilities) and writes
docs/V33_CALIBRATION_DIAGRAM.html: one diagram per event, v3 / v3.2 /
v3.3 overlaid against the perfect-calibration diagonal. No external
dependencies (no matplotlib in the venv).
"""

import json
import os

BACKEND = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORK = os.path.join(BACKEND, "models", "rainfall_xgb_v3_3", "threshold_work")

COLORS = {"v3": "#313552", "v3.2": "#00A896", "v3.3": "#E4572E"}
LABELS = {"y_3h_ge_10mm": "3 h >= 10 mm", "y_6h_ge_10mm": "6 h >= 10 mm",
          "y_3h_ge_5mm": "3 h >= 5 mm"}


def _svg(event: str, calib: dict) -> str:
    W, H, PAD = 460, 380, 46
    def x(v): return PAD + v * (W - 2 * PAD)
    def y(v): return H - PAD - v * (H - 2 * PAD)
    parts = [f'<svg viewBox="0 0 {W} {H}" width="460" height="380" '
             f'xmlns="http://www.w3.org/2000/svg" role="img" '
             f'aria-label="Reliability diagram {LABELS[event]}">']
    parts.append(f'<rect x="0" y="0" width="{W}" height="{H}" fill="white"/>')
    # Gridlines + axes.
    for g in (0, 0.2, 0.4, 0.6, 0.8, 1.0):
        parts.append(f'<line x1="{x(g):.1f}" y1="{y(0):.1f}" x2="{x(g):.1f}" '
                     f'y2="{y(1):.1f}" stroke="#eee"/>')
        parts.append(f'<line x1="{x(0):.1f}" y1="{y(g):.1f}" x2="{x(1):.1f}" '
                     f'y2="{y(g):.1f}" stroke="#eee"/>')
        parts.append(f'<text x="{x(g):.1f}" y="{H - 28}" font-size="11" '
                     f'text-anchor="middle" fill="#666">{g:.1f}</text>')
        parts.append(f'<text x="{PAD - 8}" y="{y(g) + 4:.1f}" font-size="11" '
                     f'text-anchor="end" fill="#666">{g:.1f}</text>')
    # Perfect-calibration diagonal.
    parts.append(f'<line x1="{x(0):.1f}" y1="{y(0):.1f}" x2="{x(1):.1f}" '
                 f'y2="{y(1):.1f}" stroke="#999" stroke-dasharray="5,4"/>')
    # One polyline + markers per version.
    for version, color in COLORS.items():
        pts = []
        for b in calib[event][version]["bins"]:
            if b["n"] == 0 or b["mean_predicted"] is None:
                continue
            pts.append((b["mean_predicted"], b["observed_rate"]))
        poly = " ".join(f"{x(px):.1f},{y(py):.1f}" for px, py in pts)
        parts.append(f'<polyline points="{poly}" fill="none" stroke="{color}" '
                     f'stroke-width="2"/>')
        for px, py in pts:
            parts.append(f'<circle cx="{x(px):.1f}" cy="{y(py):.1f}" r="4" '
                         f'fill="{color}"/>')
    parts.append(f'<text x="{W // 2}" y="{H - 8}" font-size="12" '
                 f'text-anchor="middle" fill="#333">mean predicted probability</text>')
    parts.append(f'<text x="14" y="{H // 2}" font-size="12" text-anchor="middle" '
                 f'fill="#333" transform="rotate(-90 14 {H // 2})">observed rate</text>')
    parts.append(f'<text x="{W // 2}" y="20" font-size="13" font-weight="bold" '
                 f'text-anchor="middle" fill="#222">{LABELS[event]} — pooled 2024+2025</text>')
    parts.append('</svg>')
    return "".join(parts)


def main() -> None:
    calib = json.load(open(os.path.join(WORK, "calibration.json")))
    cards = []
    for event in LABELS:
        rows = []
        for version in ("v3", "v3.2", "v3.3"):
            c = calib[event][version]
            rows.append(f"<p><b style='color:{COLORS[version]}'>{version}</b> — "
                        f"Brier {c['brier']:.4f}, ECE {c['ece']:.4f}</p>")
        cards.append(f"<div>{_svg(event, calib)}{''.join(rows)}</div>")
    legend = ("<p>Diagonal = perfect calibration. Points below the diagonal "
              "mean the model over-predicts in that bin; above means it "
              "under-predicts. Bins are equal-width 0.1 slices of predicted "
              "probability on pooled out-of-sample 2024+2025 data "
              "(train-only models for 2024, deployed artifacts for 2025). "
              "2026 was not used.</p>")
    html = ("<!DOCTYPE html><html><head><meta charset='utf-8'>"
            "<title>RAINWATCH AI v3.3 — Reliability diagrams</title></head>"
            "<body style='font-family:sans-serif;max-width:1000px;margin:auto'>"
            "<h1>RAINWATCH AI — Reliability diagrams (pooled 2024+2025)</h1>"
            + legend + "".join(cards) + "</body></html>")
    out = os.path.join(BACKEND, "docs", "V33_CALIBRATION_DIAGRAM.html")
    with open(out, "w") as f:
        f.write(html)
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
