"""Google Weather API service — independent external forecast source.

Uses the Google Maps Platform Weather API (hourly forecast) as a
third, clearly separated data source alongside the RAINWATCH ML model
and the demo engine. Google values are NEVER relabelled as MODEL and
never replace model points; they are served only through
``GET /api/weather/google`` and, merged with the model where the model
has no coverage, through ``GET /api/forecast/merged`` — always with
``source: "google_weather"`` on every point.

Verified against Google's official documentation (2026-11-24):
- Hourly forecast: ``GET https://weather.googleapis.com/v1/forecast/hours:lookup``
- API key as a ``key`` query parameter; ``unitsSystem=METRIC``.
- ``qpf.quantity`` is the liquid-water equivalent (mm) that fell
  during that hour — comparable to, but NOT the same quantity as, the
  RAINWATCH model's hourly rates. The UI must keep the two series
  separate (see the GOOGLE_WEATHER_NOTE in the frontend).

Honesty / independence rules:
- No key configured -> ``GoogleWeatherNotConfigured`` (the endpoint
  answers 503). Google errors / timeouts / quota -> ``GoogleWeatherError``
  (the endpoint answers 502). Nothing is ever fabricated.
- This module is imported lazily by ``main.py`` and ``datasources.py``
  so a missing key or a Google outage can never break /api/forecast,
  /api/health, or any other route.
- The Maps Demo Key (prototyping, no billing) and a standard key are
  both just ``GOOGLE_WEATHER_API_KEY`` here; the code does not care
  which one it is.
"""

import logging
import os
import threading
import time
from datetime import datetime, timezone
from typing import Any, Optional

import httpx
from pydantic import BaseModel, Field, ValidationError

from app.core import config
from app.engine import locations as locations_engine

logger = logging.getLogger("rainwatch.google_weather")

GOOGLE_HOURLY_URL = "https://weather.googleapis.com/v1/forecast/hours:lookup"
SOURCE = "google_weather"

CACHE_TTL_SECONDS = 1800  # 30 minutes. Google's own refresh cadence
# was not published in the docs; 30 min is a safe, documented choice.
# The Maps Platform terms should be checked for caching rules before
# relying on a longer TTL in any production use.
CONNECT_TIMEOUT_SECONDS = 5.0
READ_TIMEOUT_SECONDS = 10.0
MAX_PAGE_SIZE = 24

# Monthly call cap (process-local, approximate — the real control is
# the Cloud Console quota / budget alert). Configurable via env.
DEFAULT_MONTHLY_CALL_CAP = 5000


# ------------------------------------------------------------------
# Errors — the endpoint maps these to HTTP statuses; nothing escapes.
# ------------------------------------------------------------------

class GoogleWeatherNotConfigured(Exception):
    """No GOOGLE_WEATHER_API_KEY is configured."""


class GoogleWeatherError(Exception):
    """Google call failed (HTTP error, timeout, quota, cap)."""

    def __init__(self, reason: str):
        super().__init__(reason)
        self.reason = reason


# ------------------------------------------------------------------
# Pydantic validation of Google's payload (field names from the
# official reference, read 2026-11-24). Unknown extra fields are
# ignored; missing optional fields become None, never fabricated.
# ------------------------------------------------------------------

class _Probability(BaseModel):
    percent: Optional[int] = Field(default=None, ge=0, le=100)
    type: Optional[str] = None


class _Quantity(BaseModel):
    quantity: Optional[float] = Field(default=None, ge=0)
    unit: Optional[str] = None


class _Precipitation(BaseModel):
    probability: Optional[_Probability] = None
    qpf: Optional[_Quantity] = None
    # snowQpf is snow amount, not liquid equivalent — ignored for rainfall.


class _Temperature(BaseModel):
    degrees: float
    unit: Optional[str] = None


class _WindSpeed(BaseModel):
    value: Optional[float] = None
    unit: Optional[str] = None


class _WindDirection(BaseModel):
    degrees: Optional[float] = None
    cardinal: Optional[str] = None


class _Wind(BaseModel):
    direction: Optional[_WindDirection] = None
    speed: Optional[_WindSpeed] = None
    gust: Optional[_WindSpeed] = None


class _ConditionDescription(BaseModel):
    text: Optional[str] = None
    languageCode: Optional[str] = None


class _WeatherCondition(BaseModel):
    iconBaseUri: Optional[str] = None
    description: Optional[_ConditionDescription] = None
    type: Optional[str] = None


class _Interval(BaseModel):
    startTime: str
    endTime: Optional[str] = None


class _ForecastHour(BaseModel):
    interval: _Interval
    temperature: _Temperature
    relativeHumidity: Optional[int] = Field(default=None, ge=0, le=100)
    precipitation: Optional[_Precipitation] = None
    wind: Optional[_Wind] = None
    weatherCondition: Optional[_WeatherCondition] = None
    # thunderstormProbability, airPressure, visibility, cloudCover,
    # isDaytime etc. are present in the API but not mapped here.


class _TimeZone(BaseModel):
    id: Optional[str] = None


class _HourlyResponse(BaseModel):
    forecastHours: list[_ForecastHour] = Field(default_factory=list)
    timeZone: Optional[_TimeZone] = None
    nextPageToken: Optional[str] = None


# ------------------------------------------------------------------
# Module state (process-local). Reset via reset_state() in tests.
# ------------------------------------------------------------------

_cache: dict[tuple[str, int], dict[str, Any]] = {}
_last_success_at: Optional[str] = None
_last_error: Optional[str] = None
_records_retrieved: int = 0
_calls_made: int = 0
_monthly_calls: int = 0
_monthly_window: str = ""
_inflight_lock = threading.Lock()
_transport: Optional[httpx.BaseTransport] = None  # test-only injection


def set_transport(transport: Optional[httpx.BaseTransport]) -> None:
    """Test-only: inject an httpx transport (MockTransport)."""
    global _transport
    _transport = transport


def reset_state() -> None:
    """Test-only: clear cache, counters and error state."""
    global _last_success_at, _last_error, _records_retrieved
    global _calls_made, _monthly_calls, _monthly_window
    _cache.clear()
    _last_success_at = None
    _last_error = None
    _records_retrieved = 0
    _calls_made = 0
    _monthly_calls = 0
    _monthly_window = ""


def _api_key() -> str:
    # os.environ first so tests (and a reloaded .env) take effect
    # without an import-time snapshot; config is the import-time value.
    return os.environ.get("GOOGLE_WEATHER_API_KEY", "") or config.GOOGLE_WEATHER_API_KEY


def _monthly_cap() -> int:
    try:
        return int(os.environ.get("GOOGLE_WEATHER_MONTHLY_CAP", "") or DEFAULT_MONTHLY_CALL_CAP)
    except ValueError:
        return DEFAULT_MONTHLY_CALL_CAP


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def get_status() -> dict:
    """Connection state for the Data Sources page.

    "Live" only after a verified successful call within the cache TTL.
    No key -> "Not Connected". Key present but the last call failed ->
    "Error". A stale success (older than the TTL, no error) is
    "Not Connected" — the last-retrieval time is still reported, so a
    reader can see it worked before.
    """
    if not _api_key():
        return {
            "status": "Not Connected",
            "lastRetrievedAt": _last_success_at,
            "recordsRetrieved": _records_retrieved,
            "error": None,
        }
    if _last_error:
        return {
            "status": "Error",
            "lastRetrievedAt": _last_success_at,
            "recordsRetrieved": _records_retrieved,
            "error": _last_error,
        }
    if _last_success_at:
        try:
            last = datetime.strptime(_last_success_at, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
            age = (datetime.now(timezone.utc) - last).total_seconds()
            if age <= CACHE_TTL_SECONDS:
                return {
                    "status": "Live",
                    "lastRetrievedAt": _last_success_at,
                    "recordsRetrieved": _records_retrieved,
                    "error": None,
                }
        except ValueError:
            pass
    return {
        "status": "Not Connected",
        "lastRetrievedAt": _last_success_at,
        "recordsRetrieved": _records_retrieved,
        "error": None,
    }


def _map_hour(hour: _ForecastHour) -> Optional[dict]:
    """Map one validated ForecastHour to the internal point shape.

    Returns None (with a warning) when the point is unusable — e.g.
    temperature in non-metric units. Optional fields whose units are
    not the expected metric units are dropped (None), never converted
    or invented.
    """
    temp = hour.temperature
    if temp.unit is not None and temp.unit != "CELSIUS":
        logger.warning("Google hour %s: non-metric temperature unit %r — point dropped",
                       hour.interval.startTime, temp.unit)
        return None

    precip = hour.precipitation
    precip_mm: Optional[float] = None
    precip_pct: Optional[int] = None
    precip_type: Optional[str] = None
    if precip is not None:
        if precip.qpf is not None:
            if precip.qpf.unit is not None and precip.qpf.unit != "MILLIMETERS":
                logger.warning("Google hour %s: unexpected qpf unit %r — precipitation dropped",
                               hour.interval.startTime, precip.qpf.unit)
            else:
                precip_mm = precip.qpf.quantity
        if precip.probability is not None:
            precip_pct = precip.probability.percent
            precip_type = precip.probability.type

    wind_speed: Optional[float] = None
    wind_dir: Optional[float] = None
    if hour.wind is not None:
        if hour.wind.speed is not None:
            if hour.wind.speed.unit is not None and hour.wind.speed.unit != "KILOMETERS_PER_HOUR":
                logger.warning("Google hour %s: unexpected wind unit %r — wind dropped",
                               hour.interval.startTime, hour.wind.speed.unit)
            else:
                wind_speed = hour.wind.speed.value
        if hour.wind.direction is not None:
            wind_dir = hour.wind.direction.degrees

    cond = hour.weatherCondition
    return {
        "timestamp": hour.interval.startTime,
        # Interval end (additive, 2026-11-25): the merged forecast
        # matches RAINWATCH hours against Google's [startTime, endTime)
        # intervals, so the end is needed alongside the start.
        "endTime": hour.interval.endTime,
        "precipitationMm": precip_mm,
        "precipitationProbabilityPct": precip_pct,
        "precipitationType": precip_type,
        "temperatureC": temp.degrees,
        "relativeHumidityPct": hour.relativeHumidity,
        "windSpeedKmh": wind_speed,
        "windDirectionDeg": wind_dir,
        "condition": cond.type if cond else None,
        "conditionText": cond.description.text if cond and cond.description else None,
        "source": SOURCE,
    }


def _call_google(lat: float, lng: float, hours: int) -> tuple[list[dict], Optional[str]]:
    """Call the Google hourly forecast, following pagination.

    Returns (mapped points, timeZone id). Raises GoogleWeatherError on
    any failure. Each paginated HTTP call is a separate billable event
    and increments the call counters.
    """
    global _calls_made, _monthly_calls, _monthly_window
    key = _api_key()
    if not key:
        raise GoogleWeatherNotConfigured("Google Weather API key not configured")

    window = datetime.now(timezone.utc).strftime("%Y-%m")
    if _monthly_window != window:
        _monthly_window = window
        _monthly_calls = 0
    if _monthly_calls >= _monthly_cap():
        raise GoogleWeatherError(
            f"Google Weather monthly call cap reached ({_monthly_cap()} calls)")

    points: list[dict] = []
    time_zone: Optional[str] = None
    page_token: Optional[str] = None
    timeout = httpx.Timeout(READ_TIMEOUT_SECONDS, connect=CONNECT_TIMEOUT_SECONDS)
    try:
        with httpx.Client(timeout=timeout, transport=_transport) as client:
            while len(points) < hours:
                params: dict[str, Any] = {
                    "key": key,
                    "location.latitude": lat,
                    "location.longitude": lng,
                    "unitsSystem": "METRIC",
                    "hours": hours,
                    "pageSize": min(MAX_PAGE_SIZE, hours),
                }
                if page_token:
                    params["pageToken"] = page_token
                _calls_made += 1
                _monthly_calls += 1
                resp = client.get(GOOGLE_HOURLY_URL, params=params)
                if resp.status_code in (401, 403):
                    raise GoogleWeatherError(
                        f"Google Weather API rejected the key (HTTP {resp.status_code}) — "
                        "check the key, that the Weather API is enabled, and billing")
                if resp.status_code == 429:
                    raise GoogleWeatherError(
                        "Google Weather API quota exhausted (HTTP 429)")
                if resp.status_code != 200:
                    raise GoogleWeatherError(
                        f"Google Weather API returned HTTP {resp.status_code}")
                try:
                    payload = _HourlyResponse.model_validate(resp.json())
                except ValidationError as exc:
                    raise GoogleWeatherError(
                        f"Google Weather API returned an unexpected payload: {exc}") from exc
                if payload.timeZone and payload.timeZone.id:
                    time_zone = payload.timeZone.id
                for hour in payload.forecastHours:
                    mapped = _map_hour(hour)
                    if mapped is not None:
                        points.append(mapped)
                page_token = payload.nextPageToken
                if not page_token:
                    break
    except GoogleWeatherError:
        raise
    except httpx.TimeoutException as exc:
        raise GoogleWeatherError(f"Google Weather API timed out: {exc}") from exc
    except httpx.HTTPError as exc:
        raise GoogleWeatherError(f"Google Weather API request failed: {exc}") from exc
    return points[:hours], time_zone


def get_google_forecast(location_id: str, hours: int) -> dict:
    """Fetch the Google hourly forecast for a location.

    Returns the endpoint payload. Raises GoogleWeatherNotConfigured
    when no key is set and GoogleWeatherError on any Google failure.
    Results are cached 30 minutes per (locationId, hours); concurrent
    calls for the same key serialise on a lock and the second caller
    then hits the cache, so one logical fetch costs one Google call.
    """
    global _last_success_at, _last_error, _records_retrieved
    loc = locations_engine.get_location(location_id)
    cache_key = (location_id, hours)
    cached = _cache.get(cache_key)
    if cached is not None:
        age = time.monotonic() - cached["fetched_monotonic"]
        if age <= CACHE_TTL_SECONDS:
            out = dict(cached["payload"])
            out["meta"] = {**cached["payload"]["meta"], "cached": True}
            return out

    with _inflight_lock:
        # Re-check after acquiring the lock: a concurrent caller may
        # have populated the cache while we waited.
        cached = _cache.get(cache_key)
        if cached is not None:
            age = time.monotonic() - cached["fetched_monotonic"]
            if age <= CACHE_TTL_SECONDS:
                out = dict(cached["payload"])
                out["meta"] = {**cached["payload"]["meta"], "cached": True}
                return out
        try:
            points, time_zone = _call_google(float(loc["lat"]), float(loc["lng"]), hours)
        except Exception as exc:
            _last_error = str(exc)
            raise
        retrieved_at = _now_iso()
        _last_success_at = retrieved_at
        _last_error = None
        _records_retrieved = len(points)
        payload: dict[str, Any] = {
            "locationId": location_id,
            "location": {"name": loc["name"], "lat": loc["lat"], "lng": loc["lng"]},
            "timeZone": time_zone,
            "retrievedAt": retrieved_at,
            "source": SOURCE,
            "hours": points,
            "meta": {
                "cached": False,
                "callsMade": _calls_made,
                "lastSuccessAt": _last_success_at,
                "lastError": None,
            },
        }
        _cache[cache_key] = {"payload": payload, "fetched_monotonic": time.monotonic()}
        return payload
