import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react'
import { DEFAULT_LOCATION_ID, LOCATIONS } from '../data/locationsData'
import { useLocalStorage } from '../hooks/useLocalStorage'

interface LocationContextValue {
  locationId: string
  setLocationId: (id: string) => void
}

const LocationContext = createContext<LocationContextValue | null>(null)
const STORAGE_KEY = 'rainwatch.location'

export function LocationProvider({ children }: { children: ReactNode }) {
  const [locationId, setStored] = useLocalStorage<string>(STORAGE_KEY, DEFAULT_LOCATION_ID)
  const valid = LOCATIONS.some((l) => l.id === locationId) ? locationId : DEFAULT_LOCATION_ID
  const [session, setSession] = useState(valid)

  const active = LOCATIONS.some((l) => l.id === session) ? session : valid

  const setLocationId = useCallback(
    (id: string) => {
      if (!LOCATIONS.some((l) => l.id === id)) return
      setSession(id)
      setStored(id)
    },
    [setStored],
  )

  const value = useMemo(() => ({ locationId: active, setLocationId }), [active, setLocationId])

  return <LocationContext.Provider value={value}>{children}</LocationContext.Provider>
}

export function useSelectedLocation(): LocationContextValue {
  const ctx = useContext(LocationContext)
  if (!ctx) throw new Error('useSelectedLocation must be used inside <LocationProvider>')
  return ctx
}
