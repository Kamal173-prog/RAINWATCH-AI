"""Integration probe: visit every frontend route against the live demo
API (v3.3 on :8001, vite on :5173) and record render status, console
errors, failed requests, and MODEL/DEMO/UNKNOWN badge counts.

Test tooling only (not part of the shipped app). Screenshots go to
~/workspace/integration-screenshots/.
"""

import json
import os
import re
import sys

from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:5173"
OUT = os.path.expanduser("~/workspace/integration-screenshots")
CHROME = "/home/hatch/.cache/ms-playwright/chromium-1255/chrome-linux64/chrome"

ROUTES = [
    ("/", "landing"),
    ("/overview", "overview"),
    ("/live-weather", "live-weather"),
    ("/forecast", "forecast"),
    ("/flood-intelligence", "flood-intelligence"),
    ("/map", "map"),
    ("/simulator", "simulator"),
    ("/alerts", "alerts"),
    ("/historical", "historical"),
    ("/data-sources", "data-sources"),
    ("/settings", "settings"),
    ("/definitely-not-a-route", "not-found"),
]


def count_badges(page):
    text = page.locator("body").inner_text()
    return {
        "MODEL": len(re.findall(r"\bMODEL\b", text)),
        "DEMO": len(re.findall(r"\bDEMO\b", text)),
        "UNKNOWN": len(re.findall(r"\bUNKNOWN\b", text)),
    }


def main():
    os.makedirs(OUT, exist_ok=True)
    results = {}
    with sync_playwright() as pw:
        browser = pw.chromium.launch(executable_path=CHROME)
        page = browser.new_page(viewport={"width": 1440, "height": 900})
        errors, failed_reqs = [], []

        def on_console(msg):
            if msg.type == "error":
                errors.append(msg.text)

        def on_response(resp):
            if resp.status >= 400:
                failed_reqs.append(f"{resp.status} {resp.url}")

        page.on("console", on_console)
        page.on("response", on_response)

        for route, name in ROUTES:
            errors.clear()
            failed_reqs.clear()
            try:
                page.goto(f"{BASE}{route}", wait_until="networkidle")
            except Exception as exc:  # noqa: BLE001
                results[name] = {"route": route, "goto_error": str(exc)}
                continue
            page.wait_for_timeout(8000)  # charts animate in
            body_text = page.locator("body").inner_text()
            results[name] = {
                "route": route,
                "title": page.title(),
                "body_chars": len(body_text),
                "blank": len(body_text.strip()) < 200,
                "badges": count_badges(page),
                "console_errors": list(errors),
                "failed_requests": list(failed_reqs),
                "has_model_version_text": bool(
                    re.search(r"rainfall-xgb-v3(\.3|\.2)?", body_text)),
                "version_strings": sorted(set(
                    re.findall(r"rainfall-xgb-v3(?:\.\d)?", body_text))),
                "csv_buttons": page.locator(
                    "button:has-text('CSV'), button:has-text('Export')"
                ).count(),
            }
            page.screenshot(path=f"{OUT}/{name}.png", full_page=True)
        browser.close()

    print(json.dumps(results, indent=2))
    with open(f"{OUT}/probe_results.json", "w") as f:
        json.dump(results, f, indent=2)


if __name__ == "__main__":
    main()
