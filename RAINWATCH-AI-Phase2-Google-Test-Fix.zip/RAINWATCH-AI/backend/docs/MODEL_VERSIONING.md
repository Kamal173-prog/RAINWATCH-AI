# RAINWATCH AI — Model Versioning

## The rule

One model serves at a time, selected by the `MODEL_VERSION`
environment variable at backend startup. The served label always
comes from the actually-loaded forecaster, never from the flag. A
load failure falls back to v3 and reports v3.

## Versions

| Version | Status | Model dir | What it is |
|---|---|---|---|
| `rainfall-xgb-v3` | **Production default and rollback** | `models/rainfall_xgb_v3/` | Three-family ensemble (XGBoost + LightGBM + HistGradientBoosting), 41 features after permutation-importance pruning. Bhubaneswar ERA5 grid cell only. |
| `rainfall-xgb-v3.2` | **Benchmark** (flag-gated, never production) | `models/rainfall_xgb_v3_2/` | v3 ensemble + 12 GFS features (53 total). Integrated behind the flag in Phase 11. |
| `rainfall-xgb-v3.3` | **Primary hackathon demo model** (flag-gated, never production) | `models/rainfall_xgb_v3_3/frozen/` | 94 features, base 3-family ensemble frozen. Threshold-optimized on pooled 2024+2025. **Frozen — do not modify, retrain, or regenerate.** |
| `rainfall-xgb-v3.1` | Evaluated, NOT deployed | — | Precision-focused classifier upgrade; failed its primary objective (3h ≥ 10 mm PR-AUC 0.157 vs v3 0.168). Do not use. |

v1/v2 (single-XGB) live in `models/rainfall_xgb/` and are superseded.

## Shared regressors

The regressors are **shared across v3/v3.2/v3.3** (always loaded from
v3; `reg_6h` weights xgb 0.5 / lgbm 0.5 / hgb 0.0). Versions differ
only in their classifiers. Consequences:

- Expected rainfall amounts (`expected_mm`, P90 bounds) are identical
  across versions for the same input.
- Only heavy-rain probabilities (`heavy_rain_probability`) and risk
  tiers differ between versions.
- Daily-total validation (MAE/RMSE/correlation) is therefore the same
  for all three versions; the IMD daily validation report's regression
  numbers apply to the shared regressor, not to any one version.

## Operating thresholds

Saved per version, never tuned at runtime. v3.3's live thresholds
are in `models/rainfall_xgb_v3_3/frozen/thresholds_optimized.json`
(hashed in the release manifest):

| Event | v3.3 Watch | v3.3 Warning |
|---|---|---|
| 3h ≥ 10 mm | 0.070 | 0.125 |
| 6h ≥ 10 mm | 0.085 | 0.185 |
| 3h ≥ 5 mm | 0.125 | 0.225 |

Selected on pooled out-of-sample 2024+2025 only. **2026 was never
used for selection and the thresholds were never re-scored on 2026.**
Do not re-freeze or re-tune on 2026 results. v3/v3.2 thresholds live
in their own `thresholds.json`.

## Frozen artifacts and the release manifest

v3.3's 15 files are frozen under
`models/rainfall_xgb_v3_3/frozen/` with a release manifest
(`RELEASE_MANIFEST.json`, model_version `rainfall-xgb-v3.3`,
production_model `rainfall-xgb-v3`). To re-verify, hash every file in
`models/rainfall_xgb_v3_3/frozen/` and compare SHA-256 and byte size
against `RELEASE_MANIFEST.json` (each entry is a dict with `sha256`
and `bytes` keys). The pytest suite also asserts the manifest
(`test_model_selection.py`).

Verified 15/15 matching on 2026-11-24 (three times, including after
all demo and engineering work). Never overwrite, retrain,
modify, or regenerate these files. Never silently fall back to v3
while displaying a v3.3 label: if v3.3 cannot load, the service
reports the actual active model (v3) in `/api/health`.

## How to select a version

```bash
# production (default; .env has no MODEL_VERSION)
.venv/bin/python -m uvicorn app.main:app --port 8000

# demo (v3.3)
MODEL_VERSION=rainfall-xgb-v3.3 .venv/bin/python -m uvicorn app.main:app --port 8001

# benchmark (v3.2)
MODEL_VERSION=rainfall-xgb-v3.2 .venv/bin/python -m uvicorn app.main:app --port 8002
```

Verify with `/api/health` — it reports the actually-loaded
`model_version` and `loaded: true`. An invalid value (e.g.
`rainfall-xgb-v9.9`) serves and reports v3.

## The production bar (not met for v3.3)

v3.3 must **not** become the production default. The bar is a
validated improvement on 3h ≥ 10 mm, and v3.3 does not clear it:
matched-precision 3h ≥ 10 mm Warning, v3.3 loses to v3.2 (a ranking
gap, not a threshold gap). It wins 6h ≥ 10 mm and ties 3h ≥ 5 mm.
The next step for 3h ≥ 10 mm is better input data (GPM IMERG needs a
free Earthdata account), not more tuning. See `MODEL_REPORT.md`
§§11–14 and `V33_*` docs for the full comparison.

## What not to do

- Do not start v3.4, retrain, or modify frozen artifacts or
  thresholds.
- Do not tune against the reserved 2026 evaluation period.
- Do not change `MODEL_VERSION` in `.env` for the demo — pass it as a
  shell variable to the demo server only, so production stays on v3.
- Do not present v3.3 as production. The demo config is a flag-gated
  instance; production is v3 on :8000.
