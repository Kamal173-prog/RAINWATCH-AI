/**
 * Data-source provenance (Stage 5, extended for Google Weather and
 * the merged forecast).
 *
 * The backend labels every forecast point and risk record with
 * `source: "model" | "demo"` (see backend/app/engine/rainfall.py and
 * risk.py), every Google Weather point with
 * `source: "google_weather"` (see backend/app/services/google_weather.py),
 * and every hour neither the model nor Google could provide with
 * `source: "unavailable"` (see backend/app/engine/merged_forecast.py).
 * The local demo fallback in dataService stamps `source: "demo"` onto
 * values it generates. This module is the ONLY place that interprets
 * that field, so the MODEL / GOOGLE WEATHER / DEMO / UNAVAILABLE
 * decision can never drift between views.
 *
 * Rules:
 * - MODEL only when `source` is exactly "model". Nothing else —
 *   not `model_version`, not the location, not whether the API
 *   answered — may promote a value to MODEL.
 * - GOOGLE WEATHER only when `source` is exactly "google_weather".
 *   Google values are an external forecast, never a RAINWATCH
 *   ML prediction.
 * - DEMO when `source` is exactly "demo".
 * - UNAVAILABLE when `source` is exactly "unavailable": no value
 *   exists for that hour — never fabricated, never substituted.
 * - UNKNOWN for anything else (missing, null, or an unrecognised
 *   string). Unknown values are rendered with a neutral badge and
 *   are never presented as ML predictions.
 */

export type DataSourceKind = 'model' | 'google_weather' | 'demo' | 'unavailable' | 'unknown'

export interface SourcedLike {
  source?: unknown
}

export function resolveSource(value: SourcedLike | null | undefined): DataSourceKind {
  if (!value || typeof value !== 'object') return 'unknown'
  if (value.source === 'model') return 'model'
  if (value.source === 'google_weather') return 'google_weather'
  if (value.source === 'demo') return 'demo'
  if (value.source === 'unavailable') return 'unavailable'
  return 'unknown'
}

export interface SourceCounts {
  model: number
  googleWeather: number
  demo: number
  unavailable: number
  unknown: number
  total: number
}

export function summarizeSources(items: readonly (SourcedLike | null | undefined)[]): SourceCounts {
  const counts: SourceCounts = { model: 0, googleWeather: 0, demo: 0, unavailable: 0, unknown: 0, total: items.length }
  for (const item of items) {
    // The wire value is 'google_weather'; the counts key is camelCase.
    const kind = resolveSource(item)
    if (kind === 'google_weather') counts.googleWeather += 1
    else counts[kind] += 1
  }
  return counts
}

/** True when the view contains at least one value of each kind. */
export function isMixedSources(counts: SourceCounts): boolean {
  const kinds = [counts.model, counts.googleWeather, counts.demo, counts.unavailable, counts.unknown].filter((n) => n > 0).length
  return kinds > 1
}

/**
 * Single-cell origin of every MODEL value. The ML ensemble predicts
 * for ONE ERA5 grid cell (Bhubaneswar, 20.281195°N 85.843376°E); the
 * backend serves that cell's forecast to all 14 Bhubaneswar-region
 * locations, including Cuttack and Puri. There are no separate
 * per-city models. Any page that shows MODEL values states this
 * next to them, using these exact strings so the wording cannot
 * drift between views.
 */
export const MODEL_GRID_CELL = 'Bhubaneswar grid cell (20.28°N, 85.84°E)'
export const MODEL_CELL_NOTE =
  'MODEL values are the forecast for the single Bhubaneswar grid cell (20.28°N, 85.84°E), applied to every Bhubaneswar-region location — including Cuttack and Puri. They are not separate per-city forecasts.'

/**
 * Google Weather origin note. Google's qpf is the mm that fell during
 * that hour; RAINWATCH model points are hourly rates derived from
 * 1h/3h/6h accumulations. The two series are comparable as "mm in the
 * hour" but are NOT the same quantity — the merged Forecast table keeps
 * them labelled per row (MODEL rate vs GOOGLE WEATHER QPF) and never
 * averages them. Google's accuracy has not been validated against
 * RAINWATCH, and Google values are never included in RAINWATCH model
 * performance metrics.
 */
export const GOOGLE_WEATHER_NOTE =
  'GOOGLE WEATHER values are Google\u2019s hourly forecast (QPF, mm in the hour) for this location\u2019s coordinates — an external forecast, not a RAINWATCH ML prediction. Its accuracy has not been validated against RAINWATCH.'

/**
 * Merged Forecast table note. Source priority is MODEL > GOOGLE WEATHER
 * > UNAVAILABLE: hours the trained ensemble covers show MODEL rates
 * (mm/hr); hours it does not cover show genuine Google QPF (mm in the
 * hour); hours neither can provide show UNAVAILABLE, never a
 * fabricated value. Accumulated is the running total of the displayed
 * per-hour values and is unknown (shown as —) from the first
 * unavailable hour on. Confidence is a model-only figure — Google's
 * precipitation probability is shown separately and is not confidence.
 */
export const MERGED_TABLE_NOTE =
  'Source priority: MODEL, then GOOGLE WEATHER, then UNAVAILABLE. MODEL rows are the trained ensemble\u2019s hourly rate (mm/hr); GOOGLE WEATHER rows are Google\u2019s QPF (mm in the hour) — a different quantity, never averaged with model values. Accumulated is the running total of the displayed per-hour values and is unknown from the first unavailable hour on.'

/** Shown wherever an hour has no forecast value from any source. */
export const UNAVAILABLE_NOTE =
  'UNAVAILABLE means neither the RAINWATCH model nor Google Weather could provide a value for that hour. No value is shown, and none is substituted.'
