"""Data sources & pipeline — a port of ``hackathon/src/data/dataSourcesData.ts``.

These describe the types of data sources the production platform is
designed to ingest. The historical archive is now genuinely served by
this backend from the Open-Meteo ERA5 CSV for Bhubaneswar-region
locations (see history.py); the rest remain as designed.

``kind`` is the coarse taxonomy shown on the Data Sources page so a
reader can tell the four things apart at a glance:

- "Historical dataset" — a static archive served as-is (ERA5 2021–2025).
  It is not a live feed and contains no real-time observations.
- "Real-time observation" — a live satellite / radar / station feed.
  None is connected today; the weather shown elsewhere is demo-generated.
- "Forecast feed" — an external NWP feed. None is connected; the
  forecasts shown are the ML ensemble's output, served by this backend's
  own API.
- "Static dataset" — terrain / infrastructure reference data.

``status`` is the connection state. "Archive" means served from a
static historical archive — deliberately not "Live", so the ERA5
archive is never misread as a live external weather connection.
"""

DATA_SOURCES = [
    {
        "id": "satellite",
        "kind": "Real-time observation",
        "name": "Satellite Rainfall Data",
        "category": "Space-based observation",
        "description": "Polar and geostationary microwave/IR precipitation estimates (e.g. GPM-style products) providing wide-area rainfall coverage including over oceans and sparse regions.",
        "intendedUse": "Spatial rainfall field forcing for nowcasting and bias-adjustment of radar estimates.",
        "status": "Awaiting Integration",
        "cadence": "~30 min revisit (target)",
        "icon": "satellite",
    },
    {
        "id": "radar",
        "kind": "Real-time observation",
        "name": "Weather Radar Data",
        "category": "Remote sensing",
        "description": "Doppler radar reflectivity and derived QPE mosaics offering high-resolution rainfall intensity at 5–10 minute update cycles.",
        "intendedUse": "Short-term nowcasting, cell tracking, and intensity classification for early warnings.",
        "status": "Not Connected",
        "cadence": "~5 min (target)",
        "icon": "radar",
    },
    {
        "id": "stations",
        "kind": "Real-time observation",
        "name": "Ground Weather Stations",
        "category": "In-situ observation",
        "description": "Automatic weather and rain-gauge stations providing point observations of rainfall, temperature, wind, pressure and humidity.",
        "intendedUse": "Ground-truth calibration, threshold verification and operational alerts.",
        "status": "Demo Data",
        "cadence": "~10 min (target)",
        "icon": "station",
    },
    {
        "id": "nwp",
        "kind": "Forecast feed",
        "name": "Numerical Weather Prediction",
        "category": "Model output",
        "description": "Deterministic and ensemble NWP forecasts supplying quantitative precipitation forecasts out to 72 hours and beyond.",
        "intendedUse": "Driving the rainfall forecast timelines and scenario ensembles.",
        "status": "Awaiting Integration",
        "cadence": "~6 h cycles (target)",
        "icon": "model",
    },
    {
        "id": "dem",
        "kind": "Static dataset",
        "name": "Digital Elevation Models",
        "category": "Terrain",
        "description": "High-resolution DEMs (1–10 m class) describing slope, aspect, flow accumulation and depression storage.",
        "intendedUse": "Inundation extent derivation, flow routing and low-lying area identification.",
        "status": "Demo Data",
        "cadence": "Static (target)",
        "icon": "terrain",
    },
    {
        "id": "drainage",
        "kind": "Static dataset",
        "name": "Drainage and Terrain Data",
        "category": "Urban infrastructure",
        "description": "Storm-water network geometry, outfall capacities, culvert/underpass locations and canal command areas.",
        "intendedUse": "Drainage stress scoring, ponding hotspots and infrastructure vulnerability.",
        "status": "Not Connected",
        "cadence": "Static / periodic (target)",
        "icon": "drainage",
    },
    {
        "id": "history",
        "kind": "Historical dataset",
        "name": "Historical Rainfall Records",
        "category": "Archive",
        "description": "Open-Meteo ERA5 archive, hourly 2021–2025 for Bhubaneswar, served by this backend for Bhubaneswar-region locations; Ganjam locations use the demo generator until their archive is fetched. ERA5 reanalysis, not station measurements.",
        "intendedUse": "Historical analysis, threshold tuning and event comparison.",
        "status": "Archive",
        "cadence": "Static archive — no live updates",
        "icon": "archive",
    },
    {
        # Google Weather API — the only external forecast feed that can
        # go "Live". Its status is computed at request time in
        # get_data_sources() from the service state; it is never
        # "Live" on assumption. Static fields only here.
        "id": "google-weather",
        "kind": "Forecast feed",
        "name": "Google Weather API",
        "category": "External forecast",
        "description": "Google Maps Platform Weather API hourly forecast (up to 240 hours, METRIC units) for each location's coordinates. An independent external forecast shown for comparison with the ML ensemble — especially where the model has no coverage (hours 7–72 and Ganjam locations). Never presented as a RAINWATCH ML prediction.",
        "intendedUse": "Independent external forecast for comparison with the ML ensemble; the only real (non-demo) series where the model has no coverage.",
        "status": "Not Connected",
        "cadence": "On demand, 30 min cache",
        "icon": "cloud",
    },
]

PIPELINE_NODES = [
    {"id": "sat", "label": "Satellite Data", "detail": "Wide-area rainfall estimates"},
    {"id": "radar", "label": "Weather Radar", "detail": "High-res nowcast mosaics"},
    {"id": "obs", "label": "Ground Observations", "detail": "Stations & gauges"},
    {"id": "fc", "label": "Forecast Inputs", "detail": "NWP & blended QPF"},
    {"id": "risk", "label": "Risk Assessment", "detail": "Terrain + drainage model"},
    {"id": "dash", "label": "Early Warning Dashboard", "detail": "RAINWATCH AI"},
]


def get_data_sources() -> dict:
    sources = [dict(s) for s in DATA_SOURCES]
    # Google Weather status is computed live from the service state:
    # "Live" only after a verified successful call within the TTL,
    # "Not Connected" with no key, "Error" when the last call failed.
    # A failure here must never break the endpoint — fall back to the
    # static "Not Connected" entry.
    for entry in sources:
        if entry["id"] != "google-weather":
            continue
        try:
            from app.services import google_weather as google_service
            state = google_service.get_status()
        except Exception:  # noqa: BLE001 - Google must never break this endpoint
            state = {"status": "Not Connected", "lastRetrievedAt": None,
                     "recordsRetrieved": None, "error": None}
        entry["status"] = state["status"]
        entry["lastRetrievedAt"] = state["lastRetrievedAt"]
        entry["recordsRetrieved"] = state["recordsRetrieved"]
        entry["error"] = state["error"]
    return {"sources": sources, "pipeline": PIPELINE_NODES}
