# Verification report — RAINWATCH-AI-Phase2-Google-Test-Fix.zip

Built 2026-11-26 from the latest source (no source, model, threshold,
dataset or configuration file was modified while packaging). This package
is the Phase2-Windows-Fix package plus the Google Weather test-isolation
fix in three test files only — no other project file differs from the
Windows-Fix package.

## Pre-packaging checks (live project, before the ZIP was built)

| Check | Result |
|---|---|
| Backend pytest (full suite) | **245 passed, 0 failed** (190 pre-satellite + 28 satellite service + 17 satellite endpoint tests + 10 Windows-filename regression tests; Google 21 and merged-forecast 17 included) |
| Backend pytest with a key present (simulates `.env` holding a real Google key) | **245 passed, 0 failed** — the test-isolation fix verified both ways |
| The 4 previously failing no-key tests (with a key present) | **4 passed** (`test_service_no_key_raises_not_configured`, `test_endpoint_no_key_503`, `test_merged_no_key_unavailable`, `test_merged_no_key_brahmapur_all_unavailable`) |
| Frontend `tsc -b` | Clean |
| Frontend `vite build` | Passes (3.00 s) |
| Frozen v3.3 SHA-256 | **15/15 match** `backend/models/rainfall_xgb_v3_3/frozen/RELEASE_MANIFEST.json` |
| Satellite endpoints (live smoke check, real endpoints, no mocks, no credentials on this VM) | `/api/satellite/status` → 200 Not Configured; latitude 100 → 422; rainfall → 503 "Earthdata credentials not configured"; unknown region → 400 |
| Windows filename fix (mocked tests) | The exact failing GranuleUR `GPM_3IMERGHHE.07:3B-HHR-E...HDF5` sanitizes to a filename with no Windows-invalid characters, still parses (V07C, 03:00, 30 min); download writes the sanitized name with the original ID in metadata/sidecar; second call reuses the cache; legacy colon-named files are reused and migrated in place |
| Google test-isolation fix (root cause, reproduced before fixing) | `app.core.config` snapshots `GOOGLE_WEATHER_API_KEY` at import; the service falls back to that snapshot, so `monkeypatch.delenv` alone did not unconfigure it when `.env` held a real key. Reproduced with a fake key in the environment: the 4 no-key tests failed (real Google calls attempted / mock transport key assertion tripped). Fixed in test files only: conftest autouse fixture clears env var + config snapshot and resets service state/transport; `keyed` fixtures set both places to `test-demo-key` |
| Secrets scan | No `.env` file in the package; only `.env.example` files ship (Google key and Earthdata password are placeholders, username empty); no virtualenvs, no `node_modules`, no `__pycache__`, no `.pytest_cache` |
| Required files present | `backend/tests/conftest.py` (with `_no_google_key_by_default`), `backend/tests/test_google_weather.py`, `backend/tests/test_forecast_merged.py` (both with `keyed` setting env + config), `backend/app/services/satellite_rainfall.py` (with `_sanitize_cache_filename`), `backend/tests/test_satellite_rainfall.py` (38 tests incl. 10 filename regressions), `backend/tests/test_satellite_endpoints.py`, `backend/verify_satellite_live.py`, `backend/docs/SATELLITE_IMERG_PHASE2.md`, updated `backend/requirements.txt` (earthaccess==1.0.0, h5py==3.16.0) |
| Diff vs previous package (Phase2-Windows-Fix) | Only the 3 test files differ; file sets are identical |
| NASA live verification | **PASSED on Kam's Windows machine 2026-11-26** (`verify_satellite_live.py`, exit 0): real V07C granule downloaded, extraction VALID_ZERO 0.0 mm/hr at 2026-11-25T19:30:00Z (2026-11-26T01:00:00+05:30 IST), grid cell 20.25/85.849998, sanitized cache filename, second request reused the same granule, retrieval timestamp identical |
| NASA live verification — second run | **PASSED on Kam's Windows machine 2026-11-26** (`verify_satellite_live.py`, exit 0). Script: `backend/verify_satellite_live.py`. Observation UTC 2026-11-25T20:30:00Z, IST 2026-11-26T02:00:00+05:30. Satellite: NASA GPM IMERG Early Run V07C. Status VALID_ZERO — a valid observation of zero rainfall, not missing data and not synthetic demo data. Rainfall rate 0.0 mm/hr, accumulation 0.0 mm. Grid cell lat 20.25, lon ~85.85, ~1.99 km from Old Town. Granule filename sanitization successful; second request reused the same cached granule; retrieval timestamp unchanged between requests |

## Fresh-extraction checks (run on a clean extraction of this ZIP)

| Check | Result |
|---|---|
| ZIP integrity (`unzip -t`) | Clean — no errors in compressed data; 595 entries |
| Extracted file count / size | 528 files, 233 MB |
| Frozen v3.3 SHA-256 (extracted copy) | **15/15 match** |
| Fresh venv install (`pip install -r requirements.txt` + `requirements-test.txt`, `cp .env.example .env`) | Exit 0, no manual edits |
| Extracted-copy pytest (no key) | Not run separately — the with-key run below is the stricter case; the live-project suite was verified both ways before packaging |
| Extracted-copy pytest (fake key present — proves the isolation fix ships) | **245 passed, 0 failed, 0 skipped** (junit XML); the 4 previously failing no-key tests pass in the extracted copy with a key present |
| Extracted-copy `tsc -b` + `vite build` | Both pass (npm install exit 0, tsc clean, build 2.11 s) |
| Live demo server from extracted copy (:8001, production default v3) | Health loaded:true; merged Old Town 6 MODEL + 18 UNAVAILABLE (Google not configured); old `/api/forecast` unchanged 6 MODEL + 18 DEMO |
| Extracted-copy satellite endpoints (no creds) | Status 200 Not Configured; rainfall 503 "Earthdata credentials not configured"; unknown region 400 |

## Known issues found during packaging

1. **A second virtualenv hides in the project** — `backend/.venv-audit/`
   (~550 MB) is not caught by a plain `.venv/` exclusion. The exclusion
   used here is `.venv*/`, so no virtualenv ships in this ZIP. Final
   staging: 525 files / 233 MB, file-for-file identical to the
   Phase2-Windows-Fix package except the three test-isolation files.
2. **`npm run build` fails on the `tsc` step in this environment** because the
   `node_modules/.bin` shim lost its exec bit (a known, pre-existing quirk,
   also noted in the audit). The direct commands
   `node node_modules/typescript/bin/tsc -b` and
   `node node_modules/vite/bin/vite.js build` pass. The README documents this.

## What is NOT verified by this package

- The backend's live Google call with a real key is unverified
  (no key ships by design). The satellite integration, by contrast, is
  live-verified — see the NASA row in the pre-packaging table above.
