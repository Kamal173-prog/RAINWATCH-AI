"""JAXA GSMaP V8 precipitation (v3.2, Source D).

Organisation: JAXA. Dataset: ``JAXA/GPM_L3/GSMaP/v8/operational``.
- Hourly, 0.1 deg (~11 km), 2000–present.
- Bands: ``hourlyPrecipRate`` (raw) and ``hourlyPrecipRateGC``
  (gauge-adjusted). Compare both; keep them separate from IMERG.
- GSMaP is a satellite product, not an independent ground-truth
  observation. Do not treat it as ground truth.

Access routes:
1. Google Earth Engine (no separate registration beyond a Google
   account + Earth Engine signup):
   https://developers.google.com/earth-engine/datasets/catalog/JAXA_GPM_L3_GSMaP_v8_operational
   Requires the ``earthengine-api`` Python package and an authenticated
   Earth Engine account.
2. JAXA G-Portal / FTP (free JAXA registration):
   https://sharaku.eorc.jaxa.jp/GSMaP/ and https://gportal.jaxa.jp/gpr/

This connector implements the structure and the Earth Engine access
check. It does NOT fabricate GSMaP data. ``fetch`` returns [] with a
clear blocker message until Earth Engine (or JAXA FTP) credentials are
available.

Reference: Kubota et al. (2020), "Global Satellite Mapping of
Precipitation (GSMaP) products in the GPM era", doi:10.1007/978-3-030-24568-9_20.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from .base_source import BaseDataSource

log = logging.getLogger(__name__)

GEE_DATASET = "JAXA/GPM_L3/GSMaP/v8/operational"
BANDS = ("hourlyPrecipRate", "hourlyPrecipRateGC")


class GSMaPSource(BaseDataSource):
    """JAXA GSMaP V8 hourly precipitation."""

    SOURCE_NAME = "gsmap"
    PRODUCT_NAME = "GSMaP V8 operational"
    PRODUCT_VERSION = "v8 (product version 5)"
    AVAILABILITY_LAG = "PT4H"  # NRT ~4 h; MVK (final) ~3 days
    LICENSE = "JAXA — acknowledgement required"
    ACCESS_RESTRICTIONS = (
        "Google Earth Engine: free Google account + Earth Engine signup, "
        "earthengine-api package, authenticated project. "
        "Or JAXA G-Portal FTP (free JAXA registration)."
    )

    def __init__(self, backend_dir: Path | None = None, band: str = "hourlyPrecipRateGC"):
        super().__init__(backend_dir)
        if band not in BANDS:
            raise ValueError(f"unknown GSMaP band {band!r}; choose from {BANDS}")
        self.band = band

    def check_access(self) -> tuple[bool, str]:
        try:
            import ee  # noqa: F401
        except ImportError:
            return False, (
                "earthengine-api not installed (pip install earthengine-api) "
                "and no Earth Engine account is configured. Sign up at "
                "https://earthengine.google.com/ and authenticate with "
                "`earthengine authenticate`. Alternatively use JAXA G-Portal FTP."
            )
        return True, "earthengine-api installed (account auth not yet verified)"

    def fetch(
        self,
        start: str,
        end: str,
        bbox: Optional[tuple[float, float, float, float]] = None,
    ) -> list[Path]:
        ok, msg = self.check_access()
        if not ok:
            log.error("GSMaP fetch blocked: %s", msg)
            return []
        raise NotImplementedError(
            "GSMaP fetch is not implemented: Earth Engine authentication "
            "must be completed first (earthengine authenticate), then "
            "implement the point extraction with ee.ImageCollection. "
            "Do not fabricate GSMaP data."
        )

    def process(self, raw_files: list[Path]) -> Path:
        raise NotImplementedError(
            "GSMaP processing is not implemented: no GSMaP files have "
            "been obtained. Implement once the first file is available "
            "and its format is inspected."
        )
