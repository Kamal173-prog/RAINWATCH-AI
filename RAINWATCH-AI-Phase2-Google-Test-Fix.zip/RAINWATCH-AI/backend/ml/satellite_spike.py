"""Phase 0 spike: download one real GPM IMERG Early Run granule and extract
the precipitation value for Old Town, Bhubaneswar (20.2662, 85.8418).

VERIFIED DIMENSION ORDER (2026-11-26, from a real V07C granule):
the precipitation array is ordered (time, longitude, latitude) — shape
(1, 3600, 1800) — NOT (time, lat, lon). The script reads DimensionNames
from the file's own metadata and refuses to extract if the order differs,
so this class of bug cannot silently return a wrong value again.

Credentials come from backend/.env (EARTHDATA_USERNAME, EARTHDATA_PASSWORD)
— never hardcoded here, never committed. Earthdata account setup:
https://urs.earthdata.nasa.gov/users/new (free), then authorise the
"NASA GESDISC DATA ARCHIVE" application on first use.

Extra dependencies (NOT in requirements.txt — the shipped backend does not
import them; install only for this spike):
    pip install earthaccess h5py

Run from the backend directory:
    python -u ml/satellite_spike.py
On Windows PowerShell, from the backend folder:
    .\\.venv\\Scripts\\python.exe -u ml\\satellite_spike.py

Writes the downloaded granule to backend/data/satellite/ (created if needed).
Prints: granule found, download path + size, HDF5 metadata, nearest grid
cell + distance, precipitation rate (mm/hr), 30-min accumulation (mm),
granule timestamp (UTC + IST), product version and filename, and whether the
value is real data, zero, or missing (_FillValue / NaN / invalid).
Never fabricates a value: if authentication, download or extraction fails,
it exits non-zero.
"""
import math
import os
import re
import sys
from datetime import datetime, timedelta, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
BACKEND_DIR = os.path.dirname(HERE)
OUT = os.path.join(BACKEND_DIR, "data", "satellite")
os.makedirs(OUT, exist_ok=True)

ENV_PATH = os.path.join(BACKEND_DIR, ".env")

# Old Town, Bhubaneswar
TARGET_LAT = 20.2662
TARGET_LON = 85.8418
# Verified dimension order of Grid/precipitation in GPM_3IMERGHHE V07C.
EXPECTED_DIMS = ("time", "lon", "lat")
# Grid/time is seconds since 1980-01-06T00:00:00Z.
TIME_EPOCH = datetime(1980, 1, 6, tzinfo=timezone.utc)
IST_OFFSET = timedelta(hours=5, minutes=30)


def load_env(path):
    creds = {}
    if not os.path.exists(path):
        return creds
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            creds[k.strip()] = v.strip().strip('"').strip("'")
    return creds


def haversine_km(lat1, lon1, lat2, lon2):
    """Great-circle distance between two points, in kilometres."""
    r = 6371.0088
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def is_fill_value(val, fill):
    """True when a value equals the _FillValue.

    The file stores precipitation as float32 while _FillValue may be
    stored as float64, so -9999.9 reads back as -9999.900390625 in the
    array. An exact == comparison would miss it. A 1e-3 tolerance is
    safe: real rain rates are >= 0 and never sit near -9999.9.
    """
    return abs(val - fill) <= 1e-3


def decode_dims(raw):
    """DimensionNames as a tuple of plain strings, whatever h5py returns."""
    if raw is None:
        return ()
    if isinstance(raw, (bytes, str)):
        text = raw.decode("utf-8", "replace") if isinstance(raw, bytes) else raw
        return tuple(s.strip() for s in text.split(",") if s.strip())
    out = []
    for d in raw:
        if isinstance(d, bytes):
            out.append(d.decode("utf-8", "replace"))
        else:
            out.append(str(d))
    return tuple(out)


def extract_old_town(path):
    """Extract the Old Town precipitation value from one real IMERG granule.

    Returns 0 on success (value real, zero, or missing — all reported),
    1 on a structural problem (wrong dimension order, bad shape, no
    _FillValue). Never invents a value.
    """
    import h5py
    import numpy as np

    fname = os.path.basename(path)
    print(f"file: {fname}")
    print(f"size bytes: {os.path.getsize(path)}")

    m = re.search(r"\.V(\d+[A-Z])\.HDF5$", fname, re.IGNORECASE)
    print(f"product version: V{m.group(1)}" if m else "product version: unknown (not in filename)")

    with h5py.File(path, "r") as f:
        ds = f["Grid/precipitation"]
        precip = ds[:]
        lat = f["Grid/lat"][:]
        lon = f["Grid/lon"][:]
        attrs = ds.attrs
        dim_names = decode_dims(attrs.get("DimensionNames"))
        units = attrs.get("Units", attrs.get("units", ""))
        if isinstance(units, bytes):
            units = units.decode("utf-8", "replace")
        fill_raw = attrs.get("_FillValue")
        if fill_raw is None:
            print("ERROR: _FillValue missing from Grid/precipitation attributes — refusing to extract.")
            return 1
        fill = float(fill_raw)

        print(f"precip shape: {precip.shape}  dims: {dim_names}  units: {units}")
        print(f"lat shape: {lat.shape}  lon shape: {lon.shape}")
        print(f"_FillValue: {fill}")
        print(f"lat range: {float(lat.min()):.4f} to {float(lat.max()):.4f}  "
              f"lon range: {float(lon.min()):.4f} to {float(lon.max()):.4f}")

        # 7. Validate the dimension order from the file's own metadata.
        if dim_names != EXPECTED_DIMS:
            print(f"ERROR: unexpected precipitation dimension order {dim_names}; "
                  f"expected {EXPECTED_DIMS}. Refusing to extract.")
            return 1
        if precip.ndim != 3 or precip.shape[0] < 1:
            print(f"ERROR: unexpected precipitation shape {precip.shape}; expected (time, lon, lat).")
            return 1
        if precip.shape[1] != len(lon) or precip.shape[2] != len(lat):
            print(f"ERROR: precip shape {precip.shape} is inconsistent with "
                  f"lon ({len(lon)}) and lat ({len(lat)}) lengths.")
            return 1

        # Granule timestamp from Grid/time (seconds since 1980-01-06Z).
        time_vals = np.atleast_1d(f["Grid/time"][:])
        ts_utc = TIME_EPOCH + timedelta(seconds=float(time_vals[0]))
        ts_ist = ts_utc + IST_OFFSET
        print(f"granule timestamp UTC: {ts_utc.strftime('%Y-%m-%dT%H:%M:%SZ')}")
        print(f"granule timestamp IST: {ts_ist.strftime('%Y-%m-%dT%H:%M:%S')} +05:30")

        # 3. Nearest latitude and longitude indices, independently.
        lat_idx = int(np.argmin(np.abs(lat - TARGET_LAT)))
        lon_idx = int(np.argmin(np.abs(lon - TARGET_LON)))
        cell_lat = float(lat[lat_idx])
        cell_lon = float(lon[lon_idx])
        dist_km = haversine_km(TARGET_LAT, TARGET_LON, cell_lat, cell_lon)

        print(f"target Old Town: lat={TARGET_LAT} lon={TARGET_LON}")
        print(f"nearest cell: lat={cell_lat:.4f} (index {lat_idx})  lon={cell_lon:.4f} (index {lon_idx})")
        print(f"distance target to cell: {dist_km:.2f} km")

        # 4. Dimension order is (time, lon, lat): index [time, lon, lat].
        val = float(precip[0, lon_idx, lat_idx])

        # 6. Missing vs zero vs invalid — never confuse them.
        if math.isnan(val) or is_fill_value(val, fill):
            print(f"precipitation rate: MISSING (value {val} == _FillValue {fill} or NaN) — not zero rainfall")
            print("30-min accumulation: MISSING")
            print("status: MISSING DATA at this cell/time")
        elif val < 0:
            print(f"precipitation rate: INVALID (value {val} mm/hr < 0 and not _FillValue) — not rainfall")
            print("30-min accumulation: INVALID")
            print("status: INVALID VALUE at this cell/time")
        else:
            print(f"precipitation rate: {val} mm/hr")
            print(f"30-min accumulation: {val * 0.5} mm")
            if val == 0.0:
                print("status: DRY — 0.0 mm/hr is real zero rainfall, not missing data")
            else:
                print("status: REAL VALUE extracted from the granule")
    return 0


def main():
    creds = load_env(ENV_PATH)
    user = creds.get("EARTHDATA_USERNAME")
    pw = creds.get("EARTHDATA_PASSWORD")
    if not user or not pw:
        print("ERROR: EARTHDATA_USERNAME / EARTHDATA_PASSWORD missing from backend/.env")
        return 1
    os.environ["EARTHDATA_USERNAME"] = user
    os.environ["EARTHDATA_PASSWORD"] = pw

    import earthaccess

    auth = earthaccess.login()
    print("earthdata login OK:", bool(auth))

    results = earthaccess.search_data(
        concept_id="C2723758340-GES_DISC",
        temporal=("2026-11-25T03:00:00Z", "2026-11-25T04:00:00Z"),
        bounding_box=(84.57, 19.13, 85.88, 20.46),
    )
    print(f"granules found: {len(results)}")
    if not results:
        print("ERROR: no granules in window")
        return 1
    g = results[0]
    print("native-id:", g["umm"]["GranuleUR"])
    print("concept-id:", g["meta"]["concept-id"])

    files = earthaccess.download(g, OUT)
    print("downloaded:", files)
    return extract_old_town(files[0])


if __name__ == "__main__":
    sys.exit(main())
