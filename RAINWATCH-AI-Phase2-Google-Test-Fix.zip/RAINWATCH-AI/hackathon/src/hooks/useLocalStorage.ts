import { useCallback, useEffect, useState } from 'react'

/** localStorage-backed state with JSON safety and SSR-safe init. */
export function useLocalStorage<T>(key: string, initialValue: T): [T, (value: T | ((prev: T) => T)) => void] {
  const [stored, setStored] = useState<T>(() => {
    if (typeof window === 'undefined') return initialValue
    try {
      const raw = window.localStorage.getItem(key)
      if (raw === null) return initialValue
      const parsed = JSON.parse(raw) as T
      const isObj = (v: unknown): v is Record<string, unknown> =>
        typeof v === 'object' && v !== null && !Array.isArray(v)
      if (isObj(initialValue) && isObj(parsed)) {
        return { ...initialValue, ...parsed } as T
      }
      return parsed
    } catch {
      return initialValue
    }
  })

  const setValue = useCallback(
    (value: T | ((prev: T) => T)) => {
      setStored((prev) => {
        const next = typeof value === 'function' ? (value as (p: T) => T)(prev) : value
        try {
          window.localStorage.setItem(key, JSON.stringify(next))
        } catch {
          /* quota / private mode — state still works in memory */
        }
        return next
      })
    },
    [key],
  )

  return [stored, setValue]
}

/** Cross-tab sync for persisted state (optional nicety). */
export function useStorageSync<T>(key: string, onChange: (value: T) => void) {
  useEffect(() => {
    const handler = (e: StorageEvent) => {
      if (e.key === key && e.newValue) {
        try {
          onChange(JSON.parse(e.newValue) as T)
        } catch {
          /* ignore malformed */
        }
      }
    }
    window.addEventListener('storage', handler)
    return () => window.removeEventListener('storage', handler)
  }, [key, onChange])
}
