import { motion } from 'framer-motion'
import {
  Activity,
  AlertTriangle,
  Download,
  Gauge,
  Info,
  Mountain,
  RefreshCw,
  ShieldAlert,
  Users,
  Waves,
} from 'lucide-react'
import { useMemo, useState } from 'react'
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ComposedChart,
  Legend,
  Line,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip as RTooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { toast } from 'sonner'
import { Badge, RiskBadge, SourceBadge, SourceMixBadge } from '../components/common/Badge'
import { Button } from '../components/common/Button'
import { ChartCard } from '../components/common/ChartCard'
import { DataTable, type Column } from '../components/common/DataTable'
import { Select } from '../components/common/Select'
import { PageHeader } from '../components/common/PageHeader'
import { SkeletonCard, StatePanel } from '../components/common/Skeleton'
import { useDemo } from '../context/DemoContext'
import { useSelectedLocation } from '../context/LocationContext'
import { useAsyncData } from '../hooks/useAsyncData'
import { demoApi } from '../services/dataService'
import type { FloodRiskRecord, RiskLevel } from '../types'
import { MODEL_CELL_NOTE, resolveSource, summarizeSources } from '../utils/source'
import { downloadCsv } from '../utils/csv'
import { formatCompact, formatNumber, formatTime, RISK_COLORS, RISK_HELP } from '../utils/colors'

const tooltipStyle = {
  background: 'var(--rw-card)', border: '1px solid var(--rw-border)', borderRadius: 12,
  color: 'var(--rw-ink)', fontSize: 12, boxShadow: '0 20px 50px -25px rgba(0,0,0,0.9)',
}

const RISK_LEVELS = ['Low', 'Moderate', 'High', 'Very High', 'Critical'] as const

export function FloodIntelligence() {
  const { locationId, setLocationId } = useSelectedLocation()
  const { version } = useDemo()
  const [riskFilter, setRiskFilter] = useState('all')
  const [horizon, setHorizon] = useState('24')
  const [selectedForDetail, setSelectedForDetail] = useState<string | null>(null)

  const horizonH = Number(horizon)

  const { data: locations } = useAsyncData(() => demoApi.listLocations(), [])
  const { data: summary, loading: summaryLoading, error, reload } = useAsyncData(
    () => demoApi.fetchRiskSummary(horizonH),
    [horizonH, version],
  )
  const { data: records, loading: recordsLoading } = useAsyncData(
    () => demoApi.fetchRiskRecords({
      locationId: locationId === 'all' ? undefined : locationId,
      level: riskFilter === 'all' ? undefined : (riskFilter as RiskLevel),
      horizonH,
    }),
    [locationId, riskFilter, horizonH, version],
  )
  const { data: allRecords } = useAsyncData(() => demoApi.fetchAllRiskRecords(), [version])
  const { data: conditions } = useAsyncData(() => demoApi.fetchRegionConditions(), [version])

  const worst = useMemo(() => {
    if (!records?.length) return null
    return records.reduce((best, r) => (r.riskIndex > best.riskIndex ? r : best), records[0])
  }, [records])

  const detailRecord = useMemo(() => {
    if (!records?.length) return null
    const id = selectedForDetail ?? worst?.locationId
    return records.find((r) => r.locationId === id) ?? worst
  }, [records, selectedForDetail, worst])

  const distributionData = (summary?.distribution ?? []).map((d) => ({ ...d, color: RISK_COLORS[d.level as RiskLevel] ?? '#6FD6C2' }))

  const byLocation = useMemo(() => {
    const map = new Map<string, FloodRiskRecord>()
    for (const r of records ?? []) {
      const prev = map.get(r.locationId)
      if (!prev || r.riskIndex > prev.riskIndex) map.set(r.locationId, r)
    }
    return [...map.values()].sort((a, b) => b.riskIndex - a.riskIndex).map((r) => ({
      id: r.locationId,
      name: locations?.find((l) => l.id === r.locationId)?.name ?? r.locationId,
      risk: r.riskIndex,
      level: r.riskLevel,
      color: RISK_COLORS[r.riskLevel],
    }))
  }, [records, locations])

  const vulnerabilityData = useMemo(() => {
    const locs = locations?.filter((l) => locationId === 'all' || l.id === locationId).slice(0, 10) ?? []
    return locs.map((l) => ({
      name: l.name,
      lowLying: l.lowLyingPct,
      drainage: l.drainageEfficiency,
      river: l.riverProximity,
    }))
  }, [locations, locationId])

  const rainfallRiskData = useMemo(() => {
    const filtered = (allRecords ?? []).filter((r) => locationId === 'all' || r.locationId === locationId)
    const buckets = new Map<string, { rain: number; risk: number; n: number }>()
    for (const r of filtered) {
      const key = formatTime(r.timestamp)
      const b = buckets.get(key) ?? { rain: 0, risk: 0, n: 0 }
      b.rain += r.rainfallContribution
      b.risk += r.riskIndex
      b.n += 1
      buckets.set(key, b)
    }
    return [...buckets.entries()].sort((a, b) => a[0].localeCompare(b[0])).slice(0, 24).map(([time, b]) => ({
      time,
      rainfall: Math.round(b.rain / b.n * 10) / 10,
      risk: Math.round(b.risk / b.n * 10) / 10,
    }))
  }, [allRecords, locationId])

  // Population is per location, but records are hourly rows per location —
  // summing across rows counts each location's population ~25x. Take the
  // peak population at risk per location, then sum across locations.
  const totalAffected = useMemo(() => {
    const peak = new Map<string, number>()
    for (const r of records ?? []) peak.set(r.locationId, Math.max(peak.get(r.locationId) ?? 0, r.populationAtRisk))
    return [...peak.values()].reduce((s, v) => s + v, 0)
  }, [records])
  const avgRisk = records?.length ? records.reduce((s, r) => s + r.riskIndex, 0) / records.length : 0

  // Stage 5 — provenance comes only from the per-record `source`
  // metadata the backend returns (or the "demo" stamp the data service
  // applies to locally generated fallback values). Never from the model
  // version.
  const sourceCounts = useMemo(() => summarizeSources(records ?? []), [records])
  const hasModel = sourceCounts.model > 0
  const hasDemo = sourceCounts.demo > 0
  const hasUnknown = sourceCounts.unknown > 0
  const riskWarning =
    hasModel && hasDemo
      ? 'Model + demo records — see per-row badges'
      : hasModel
        ? 'ML-model rainfall · susceptibility index, not a validated prediction'
        : hasUnknown
          ? 'Some records have unknown provenance'
          : 'Demo calculations — not validated predictions'

  const exportCsv = () => {
    downloadCsv(`rainwatch-flood-risk-${locationId}-${horizon}h`,
      ['Location ID', 'Timestamp', 'Risk Index', 'Risk Level', 'Population At Risk', 'Low-Lying %', 'Drainage Score', 'Rainfall Contribution %', 'Terrain Contribution %', 'River Contribution %', 'Inundation Depth (m)', 'Area Inundated (ha)', 'Source'],
      (records ?? []).map((r) => [r.locationId, r.timestamp, r.riskIndex, r.riskLevel, r.populationAtRisk, r.lowLyingPct, r.drainageScore, r.rainfallContribution, r.terrainContribution, r.riverContribution, r.inundationDepthM, r.areaInundatedHa, resolveSource(r)]))
    toast.success('Flood risk data exported as CSV', { description: `${records?.length ?? 0} records.` })
  }

  const tableColumns: Column<FloodRiskRecord>[] = [
    { key: 'loc', header: 'Location', render: (r) => <button type="button" onClick={() => setSelectedForDetail(r.locationId)} className="font-medium text-ink hover:text-accent">{locations?.find((l) => l.id === r.locationId)?.name ?? r.locationId}</button> },
    { key: 'time', header: 'Valid time', render: (r) => <span className="num text-muted">{formatTime(r.timestamp)}</span>, secondary: true },
    { key: 'risk', header: 'Risk index', render: (r) => <span className="num font-bold" style={{ color: RISK_COLORS[r.riskLevel] }}>{r.riskIndex}</span> },
    { key: 'level', header: 'Class', render: (r) => <RiskBadge level={r.riskLevel} /> },
    { key: 'pop', header: 'Population at risk', render: (r) => <span className="num">{formatCompact(r.populationAtRisk)}</span>, secondary: true },
    { key: 'low', header: 'Low-lying %', render: (r) => <span className="num">{r.lowLyingPct}%</span>, secondary: true },
    { key: 'drain', header: 'Drainage', render: (r) => <span className="num">{r.drainageScore}%</span>, secondary: true },
    { key: 'depth', header: 'Est. depth', render: (r) => <span className="num">{r.inundationDepthM} m</span>, secondary: true },
    { key: 'area', header: 'Area (ha)', render: (r) => <span className="num">{r.areaInundatedHa}</span>, secondary: true },
    { key: 'source', header: 'Source', render: (r) => <SourceBadge source={resolveSource(r)} modelVersion={r.model_version} /> },
  ]

  return (
    <div className="section-gap flex flex-col">
      <PageHeader
        title="Flood Intelligence"
        subtitle="Illustrative composite risk assessment combining rainfall, terrain, drainage and river-proximity factors."
        meta={<><SourceMixBadge counts={sourceCounts} /><Badge tone="warning">{riskWarning}</Badge></>}
      >
        <Button icon={<RefreshCw size={14} />} onClick={() => { reload(); toast.success('Risk assessment refreshed') }}>Refresh</Button>
      </PageHeader>

      {/* Disclaimer */}
      <div className="flex items-start gap-3 rounded-xl border border-warning/30 bg-warning/8 px-4 py-3">
        <AlertTriangle size={16} className="mt-0.5 shrink-0 text-warning" aria-hidden />
        <p className="text-[11px] leading-relaxed text-warning">
          <strong>Important:</strong>{' '}
          {hasModel ? (
            <>
              Records labelled MODEL use rainfall from the trained ML ensemble — {MODEL_CELL_NOTE} The risk index
              itself is still a susceptibility index, not a validated prediction.
              {hasDemo ? ' Records labelled DEMO are illustrative demo calculations produced by a simple deterministic formula in the browser.' : ''}
              {hasUnknown ? ' Records labelled UNKNOWN carry no provenance metadata.' : ''}
              {' '}Neither must be used for emergency decisions.
            </>
          ) : (
            <>
              Every risk score, population estimate and inundation depth on this page is an
              illustrative demo calculation produced by a simple deterministic formula in the browser. These values are
              NOT validated flood predictions and must not be used for emergency decisions.
              {hasUnknown ? ' Records labelled UNKNOWN carry no provenance metadata.' : ''}
            </>
          )}
        </p>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-end gap-3 rounded-2xl border border-line bg-card p-[var(--rw-card-pad)]">
        <Select label="Location" options={[{ value: 'all', label: 'All locations' }, ...(locations ?? []).map((l) => ({ value: l.id, label: l.name }))]} value={locationId} onValueChange={(v) => { setLocationId(v); setSelectedForDetail(null) }} compact className="min-w-[180px] flex-1" />
        <Select label="Risk category" options={[{ value: 'all', label: 'All categories' }, ...RISK_LEVELS.map((l) => ({ value: l, label: l }))]} value={riskFilter} onValueChange={setRiskFilter} compact className="w-[170px]" />
        <Select label="Time period" options={[{ value: '6', label: 'Next 6 hours' }, { value: '24', label: 'Next 24 hours' }, { value: '72', label: 'Next 72 hours' }]} value={horizon} onValueChange={setHorizon} compact className="w-[170px]" />
        <Button size="sm" variant="ghost" onClick={() => { setRiskFilter('all'); setHorizon('24'); toast.info('Flood filters reset') }}>Reset filters</Button>
      </div>

      {error ? <StatePanel variant="error" title="Risk data unavailable" message={error} actionLabel="Retry" onAction={reload} /> : null}

      {/* KPI strip */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {summaryLoading ? Array.from({ length: 4 }).map((_, i) => <SkeletonCard key={i} lines={1} />) : (
          <>
            {[
              { label: 'Overall flood risk index', value: formatNumber(summary?.overallIndex ?? 0, 1), unit: '/100', icon: Gauge, color: RISK_COLORS[((summary?.overallIndex ?? 0) < 25 ? 'Low' : (summary?.overallIndex ?? 0) < 45 ? 'Moderate' : (summary?.overallIndex ?? 0) < 65 ? 'High' : (summary?.overallIndex ?? 0) < 82 ? 'Very High' : 'Critical')] , footnote: <RiskBadge level={((summary?.overallIndex ?? 0) < 25 ? 'Low' : (summary?.overallIndex ?? 0) < 45 ? 'Moderate' : (summary?.overallIndex ?? 0) < 65 ? 'High' : (summary?.overallIndex ?? 0) < 82 ? 'Very High' : 'Critical') as RiskLevel} /> },
              { label: 'Vulnerable zones', value: String(summary?.vulnerable.length ?? 0), unit: 'zones', icon: ShieldAlert, color: '#F2A93B', footnote: <span className="text-[10px] text-muted">risk index &ge; 60</span> },
              { label: 'Population potentially affected', value: formatCompact(totalAffected), unit: 'people', icon: Users, color: '#6FD6C2', footnote: <span className="text-[10px] text-muted">peak per location · summed</span> },
              { label: 'Mean risk (filtered)', value: formatNumber(avgRisk, 1), unit: '/100', icon: Activity, color: '#6FD6C2', footnote: <span className="text-[10px] text-muted">{records?.length ?? 0} records</span> },
            ].map((s, i) => {
              const Icon = s.icon
              return (
                <motion.div key={s.label} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                  className="rounded-2xl border border-line bg-card p-[var(--rw-card-pad)]">
                  <div className="flex items-center justify-between"><span className="text-[10px] font-semibold tracking-wider text-muted uppercase">{s.label}</span><Icon size={15} style={{ color: s.color }} /></div>
                  <p className="num mt-2 text-xl font-bold text-ink" style={{ color: s.color }}>{s.value} <span className="text-xs font-normal text-muted">{s.unit}</span></p>
                  <div className="mt-1.5">{s.footnote}</div>
                </motion.div>
              )
            })}
          </>
        )}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <ChartCard title="Flood Risk Distribution" subtitle={`Sample records · next ${horizon}h`} icon={<ShieldAlert size={16} />} height={280} loading={recordsLoading} delay={0.02}>
          <div className="flex flex-col items-center gap-3 sm:flex-row">
            <div className="h-[200px] w-full sm:w-1/2">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={distributionData.filter((d) => d.count > 0)} dataKey="count" nameKey="level" cx="50%" cy="50%" innerRadius={48} outerRadius={74} paddingAngle={3} stroke="none" animationDuration={800}>
                    {distributionData.filter((d) => d.count > 0).map((d) => <Cell key={d.level} fill={d.color} />)}
                  </Pie>
                  <RTooltip contentStyle={tooltipStyle} />
                  <Legend wrapperStyle={{ fontSize: 10 }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex-1 space-y-1.5">
              {distributionData.map((d) => (
                <div key={d.level} className="flex items-center justify-between text-[11px]">
                  <span className="flex items-center gap-2 text-muted"><span className="h-2 w-2 rounded-full" style={{ background: d.color }} />{d.level}</span>
                  <span className="num font-semibold text-ink">{d.count}</span>
                </div>
              ))}
            </div>
          </div>
        </ChartCard>

        <ChartCard title="Risk by Location" subtitle="Worst risk index per location (filtered)" icon={<Gauge size={16} />} height={280} loading={recordsLoading} delay={0.06}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={byLocation} layout="vertical" margin={{ top: 4, right: 12, left: 28, bottom: 0 }}>
              <CartesianGrid stroke="var(--rw-border)" strokeDasharray="3 3" horizontal={false} />
              <XAxis type="number" domain={[0, 100]} tickLine={false} axisLine={false} />
              <YAxis type="category" dataKey="name" tickLine={false} axisLine={false} width={76} fontSize={10} />
              <RTooltip contentStyle={tooltipStyle} cursor={{ fill: 'var(--rw-accent)', fillOpacity: 0.06 }} />
              <Bar dataKey="risk" name="Risk index" radius={[0, 4, 4, 0]} animationDuration={800} onClick={(d: unknown) => { const row = d as { payload?: { id?: string } }; if (row?.payload?.id) setSelectedForDetail(row.payload.id) }}>
                {byLocation.map((d) => <Cell key={d.id} fill={d.color} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Vulnerability Comparison" subtitle="Low-lying area, drainage capacity and river proximity" icon={<Mountain size={16} />} height={280} loading={!locations} delay={0.1}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={vulnerabilityData} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
              <CartesianGrid stroke="var(--rw-border)" strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="name" tickLine={false} axisLine={false} fontSize={10} interval={0} angle={-25} textAnchor="end" height={52} />
              <YAxis tickLine={false} axisLine={false} width={44} domain={[0, 100]} />
              <RTooltip contentStyle={tooltipStyle} />
              <Legend wrapperStyle={{ fontSize: 10 }} />
              <Bar dataKey="lowLying" name="Low-lying %" fill="#F2A93B" radius={[3, 3, 0, 0]} animationDuration={700} />
              <Bar dataKey="drainage" name="Drainage score %" fill="#6FD6C2" radius={[3, 3, 0, 0]} animationDuration={700} />
              <Bar dataKey="river" name="River proximity %" fill="#B19BFA" radius={[3, 3, 0, 0]} animationDuration={700} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Rainfall vs Flood Risk" subtitle="Composite rainfall contribution and mean risk index" icon={<Activity size={16} />} height={280} loading={!allRecords} delay={0.14}>
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={rainfallRiskData} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
              <CartesianGrid stroke="var(--rw-border)" strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="time" tickLine={false} axisLine={false} fontSize={10} interval={3} />
              <YAxis tickLine={false} axisLine={false} width={44} />
              <RTooltip contentStyle={tooltipStyle} />
              <Legend wrapperStyle={{ fontSize: 10 }} />
              <Bar dataKey="rainfall" name="Rainfall contribution" fill="var(--rw-accent)" fillOpacity={0.55} radius={[3, 3, 0, 0]} animationDuration={700} />
              <Line type="monotone" dataKey="risk" name="Risk index" stroke="#F05A43" strokeWidth={2} dot={false} animationDuration={700} />
            </ComposedChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Explanation + indicators */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <ChartCard title="Risk Explanation" subtitle="Contributing factors to the displayed risk" icon={<Info size={16} />} height={280} delay={0.02} className="lg:col-span-2">
          {detailRecord ? (
            <div>
              <div className="mb-3 flex flex-wrap items-center gap-2">
                <span className="text-sm font-semibold text-ink">{locations?.find((l) => l.id === detailRecord.locationId)?.name ?? detailRecord.locationId}</span>
                <RiskBadge level={detailRecord.riskLevel} />
                <SourceBadge source={resolveSource(detailRecord)} modelVersion={detailRecord.model_version} />
                <span className="num text-xs text-muted">Index {detailRecord.riskIndex}/100 · {formatTime(detailRecord.timestamp)}</span>
              </div>
              <div className="space-y-3">
                {[
                  { label: 'Rainfall intensity contribution', value: detailRecord.rainfallContribution, color: '#6FD6C2' },
                  { label: 'Terrain / low-lying contribution', value: detailRecord.terrainContribution, color: '#F2A93B' },
                  { label: 'River proximity contribution', value: detailRecord.riverContribution, color: '#B19BFA' },
                ].map((f) => (
                  <div key={f.label}>
                    <div className="mb-1 flex justify-between text-[11px]"><span className="text-muted">{f.label}</span><span className="num font-semibold text-ink">{f.value}%</span></div>
                    <div className="h-2 w-full overflow-hidden rounded-full bg-surface"><motion.div initial={{ width: 0 }} animate={{ width: `${f.value}%` }} transition={{ duration: 0.7 }} className="h-full rounded-full" style={{ background: f.color }} /></div>
                  </div>
                ))}
              </div>
              <p className="mt-4 rounded-lg border border-line bg-surface/60 p-2.5 text-[11px] leading-relaxed text-muted">{RISK_HELP[detailRecord.riskLevel]}</p>
              <p className="mt-2 text-[10px] text-muted">Formula: rainfall + terrain + river factors − drainage relief, clamped to 0–100. Illustrative demo calculation.</p>
            </div>
          ) : <StatePanel title="No risk record" message="Adjust the filters to see risk factor details." />}
        </ChartCard>

        <ChartCard title="Terrain & Drainage Indicators" subtitle="Selected location" icon={<Waves size={16} />} height={280} delay={0.06}>
          {conditions ? (
            <div className="space-y-3">
              {(() => {
                const c = conditions.find((x) => x.locationId === (selectedForDetail ?? locationId)) ?? conditions[0]
                return (
                  <>
                    {[
                      { label: 'Low-lying area', value: c.lowLyingPct, unit: '%', color: '#F2A93B', icon: Mountain },
                      { label: 'Drainage efficiency', value: c.drainageEfficiency, unit: '%', color: '#6FD6C2', icon: Waves },
                      { label: 'River proximity', value: c.riskIndex, unit: '/100 (risk)', color: '#F05A43', icon: Activity },
                    ].map((s) => {
                      const Icon = s.icon
                      return (
                        <div key={s.label} className="flex items-center gap-3 rounded-xl border border-line bg-surface/60 p-2.5">
                          <span className="flex h-8 w-8 items-center justify-center rounded-lg" style={{ background: `${s.color}18`, color: s.color }}><Icon size={15} /></span>
                          <div className="min-w-0 flex-1">
                            <p className="text-[10px] text-muted">{s.label}</p>
                            <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-bg"><div className="h-full rounded-full" style={{ width: `${s.value}%`, background: s.color }} /></div>
                          </div>
                          <span className="num text-sm font-bold text-ink">{s.value}{s.unit}</span>
                        </div>
                      )
                    })}
                  </>
                )
              })()}
            </div>
          ) : <SkeletonCard lines={3} />}
        </ChartCard>
      </div>

      {/* Table */}
      <ChartCard title="Risk Records" subtitle={`${records?.length ?? 0} filtered records`} icon={<ShieldAlert size={16} />}
        actions={<Button size="sm" icon={<Download size={13} />} onClick={exportCsv}>Export CSV</Button>}
        loading={recordsLoading} empty={(records?.length ?? 0) === 0}>
        <DataTable columns={tableColumns} rows={records ?? []} rowKey={(r) => `${r.locationId}-${r.timestamp}`} onRowClick={(r) => setSelectedForDetail(r.locationId)} maxHeight={440} caption="Flood risk records" />
      </ChartCard>
    </div>
  )
}
