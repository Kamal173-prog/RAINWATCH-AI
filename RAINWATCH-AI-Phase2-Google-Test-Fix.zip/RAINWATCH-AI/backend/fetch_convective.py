"""Fetch convective/thermodynamic columns for Bhubaneswar and merge them
into the processed archive.

Attempts ONE request to the Open-Meteo archive API for the extra hourly
variables (showers, wind gusts, low/mid/high cloud cover, vapour pressure
deficit, total-column integrated water vapour). If the API returns HTTP 429
or the request times out, the script exits without blocking — the pipeline
proceeds on the existing processed dataset (features.py handles missing
convective columns gracefully).

Run:  python fetch_convective.py
"""

import json
import os
import sys
import urllib.request
import urllib.error

import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
PROCESSED_CSV = os.path.join(HERE, "data", "processed", "bhubaneswar_weather.csv")
RAW_JSON = os.path.join(HERE, "data", "raw", "bhubaneswar_convective_raw.json")

BASE_VARS = "temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m,pressure_msl,cloud_cover"
EXTRA_VARS = "showers,wind_gusts_10m,cloud_cover_low,cloud_cover_mid,cloud_cover_high,vapour_pressure_deficit,total_column_integrated_water_vapour"

URL = (
    "https://archive-api.open-meteo.com/v1/archive"
    "?latitude=20.281195&longitude=85.843376"
    "&start_date=2021-01-01&end_date=2025-12-31"
    f"&hourly={BASE_VARS},{EXTRA_VARS}"
    "&timezone=Asia%2FKolkata"
)

# Map Open-Meteo names -> our processed column names.
RENAME = {
    "showers": "showers_mm",
    "wind_gusts_10m": "wind_gusts_kmh",
    "cloud_cover_low": "cloud_cover_low_pct",
    "cloud_cover_mid": "cloud_cover_mid_pct",
    "cloud_cover_high": "cloud_cover_high_pct",
    "vapour_pressure_deficit": "vapour_pressure_deficit_hpa",
    "total_column_integrated_water_vapour": "tcwv_kg_m2",
}


def main():
    print("Fetching convective columns from Open-Meteo (single attempt)...")
    req = urllib.request.Request(URL, headers={"User-Agent": "RAINWATCH-AI/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        print(f"Open-Meteo returned HTTP {e.code}. Proceeding WITHOUT convective columns.")
        print("The pipeline will use the existing processed dataset.")
        return 0
    except Exception as e:  # timeout, DNS, connection errors
        print(f"Fetch failed ({type(e).__name__}: {e}). Proceeding WITHOUT convective columns.")
        return 0

    hourly = payload.get("hourly", {})
    times = hourly.get("time", [])
    if not times:
        print("No hourly data in response. Proceeding WITHOUT convective columns.")
        return 0

    # Save the raw response for provenance.
    with open(RAW_JSON, "w") as f:
        json.dump(payload, f)
    print(f"Saved raw response to {RAW_JSON}")

    # Build a DataFrame of just the NEW columns, keyed by timestamp.
    new_cols = {}
    for src, dst in RENAME.items():
        if src in hourly:
            new_cols[dst] = hourly[src]
        else:
            print(f"WARNING: {src} not in response; skipping.")
    extra = pd.DataFrame({"timestamp": pd.to_datetime(times), **new_cols})
    print(f"Fetched {len(extra)} rows x {len(new_cols)} new columns.")

    # Merge into the processed CSV on timestamp.
    base = pd.read_csv(PROCESSED_CSV, parse_dates=["timestamp"])
    print(f"Existing processed CSV: {len(base)} rows.")
    merged = base.merge(extra, on="timestamp", how="left", validate="one_to_one")
    if len(merged) != len(base):
        print(f"ERROR: row count changed after merge ({len(base)} -> {len(merged)}). Aborting.")
        return 1
    missing = merged[list(new_cols)].isna().sum()
    if missing.any():
        print(f"WARNING: missing values in new columns:\n{missing[missing > 0]}")
    merged.to_csv(PROCESSED_CSV, index=False)
    print(f"Merged. {PROCESSED_CSV} now has {len(merged.columns)} columns: {list(merged.columns)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
