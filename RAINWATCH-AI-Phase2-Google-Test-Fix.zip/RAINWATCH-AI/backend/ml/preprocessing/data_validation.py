"""Dataset validation for RAINWATCH AI multi-source data (v3.2).

Validates that a processed dataset meets the contract before it is used
for feature engineering or model training:
- Required columns present.
- Timestamps are UTC, monotonic, and gap-free (or gaps are documented).
- No negative rainfall.
- Units are as declared in the manifest.
- The spatial extraction method is recorded.

Raises ``ValueError`` with a clear message on a hard failure; returns a
list of warnings for soft issues.
"""

from __future__ import annotations

import pandas as pd

from .quality_control import check_values


def validate_processed_table(
    df: pd.DataFrame,
    required_columns: list[str],
    time_col: str = "timestamp",
    source: str = "frame",
) -> list[str]:
    """Validate a processed table. Returns a list of warning strings
    (empty = clean). Raises ValueError on a hard failure."""
    warnings: list[str] = []
    missing_cols = [c for c in required_columns if c not in df.columns]
    if missing_cols:
        raise ValueError(f"{source}: missing required columns: {missing_cols}")
    if len(df) == 0:
        raise ValueError(f"{source}: empty table")
    if time_col in df.columns:
        ts = pd.to_datetime(df[time_col], utc=True, errors="coerce")
        if ts.isna().any():
            raise ValueError(f"{source}: {int(ts.isna().sum())} unparseable timestamps")
        if not ts.is_monotonic_increasing:
            warnings.append(f"{source}: timestamps are not monotonic increasing")
        dup = ts.duplicated().sum()
        if dup:
            warnings.append(f"{source}: {int(dup)} duplicate timestamps")
    # Value checks (negative rainfall, out-of-range).
    _, report = check_values(df, source=source, time_col=time_col)
    if report.n_negative_rainfall:
        warnings.append(
            f"{source}: {report.n_negative_rainfall} negative rainfall values"
        )
    if report.n_out_of_range:
        warnings.append(
            f"{source}: {report.n_out_of_range} out-of-range values"
        )
    return warnings
