"""Reproduce rainfall-v3.2 (GFS variant) metrics from the saved artifacts.

Loads the deployed v3.2 classifier ensemble (models/rainfall_xgb_v3_2/)
and re-scores the 2025 benchmark and the fresh 2026 evaluation from the
frozen feature table (data/model_ready/bhubaneswar_features_v32.csv).
Reports PR-AUC, ROC-AUC, Brier, and the elevated/high operating points,
and compares them against the recorded numbers in evaluation.json.

This is the Phase 1 baseline for the v3.3 upgrade: every later claim of
improvement is measured against the numbers reproduced here, not against
the numbers remembered from the v3.2 report.

Usage:
    cd backend && .venv/bin/python ml/reproduce_v32.py
"""

from __future__ import annotations

import json
import os
import sys

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, brier_score_loss, roc_auc_score

HERE = os.path.dirname(os.path.abspath(__file__))
BACKEND = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, BACKEND)

from ml.predict import RainfallForecaster, _lookup, _sigmoid, _logit  # noqa: E402

V32_DIR = os.path.join(BACKEND, "models", "rainfall_xgb_v3_2")
TABLE = os.path.join(BACKEND, "data", "model_ready", "bhubaneswar_features_v32.csv")

TARGETS = ["y_3h_ge_10mm", "y_6h_ge_10mm", "y_3h_ge_5mm"]
KEYS = {"y_3h_ge_10mm": "3h_ge_10mm", "y_6h_ge_10mm": "6h_ge_10mm", "y_3h_ge_5mm": "3h_ge_5mm"}


def _probs(fc: RainfallForecaster, X: pd.DataFrame, target: str) -> np.ndarray:
    """Calibrated ensemble probabilities for one target, from feature rows.

    Batch-predicts per family member (seconds) instead of row-by-row.
    """
    import lightgbm as lgbm  # noqa: E402

    key = KEYS[target]
    members = fc.classifiers[key]
    w = _lookup(fc.weights, f"clf_{target}")
    raw = np.zeros(len(X))
    for fam, model in members.items():
        wf = w.get(fam, 0.0)
        if wf <= 0:
            continue
        if isinstance(model, lgbm.Booster):
            p = model.predict(X.to_numpy())
        else:
            p = model.predict_proba(X)[:, 1]
        raw += wf * np.asarray(p, dtype=float)
    platt = _lookup(fc.platt, target)
    # Vectorised Platt scaling (predict.py's _logit/_sigmoid are scalar-only).
    eps = 1e-6
    p = np.clip(raw, eps, 1 - eps)
    z = platt["w"] * np.log(p / (1 - p)) + platt["b"]
    return 1.0 / (1.0 + np.exp(-z))


def _levels(y: np.ndarray, p: np.ndarray, thresholds: dict) -> dict:
    out = {}
    for name in ("elevated", "high"):
        t = thresholds[name]
        pred = (p >= t).astype(int)
        tp = int(((pred == 1) & (y == 1)).sum())
        fp = int(((pred == 1) & (y == 0)).sum())
        fn = int(((pred == 0) & (y == 1)).sum())
        prec = tp / max(1, tp + fp)
        rec = tp / max(1, tp + fn)
        out[name] = {
            "threshold": t,
            "precision": round(prec, 4),
            "recall": round(rec, 4),
            "f1": round(2 * prec * rec / max(1e-9, prec + rec), 4),
            "tp": tp, "fp": fp, "fn": fn,
            "alerts_per_100h": round(100 * (tp + fp) / max(1, len(y)), 2),
        }
    return out


def main() -> None:
    fc = RainfallForecaster(model_dir=V32_DIR)
    print(f"loaded {fc.model_version}: {len(fc.features)} features")
    df = pd.read_csv(TABLE, parse_dates=["timestamp"])
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True).dt.tz_localize(None)
    with open(os.path.join(V32_DIR, "evaluation.json")) as f:
        recorded = json.load(f)

    for period, years in (("test_2025_benchmark", [2025]), ("fresh_2026", [2026])):
        sub = df[df["timestamp"].dt.year.isin(years)].reset_index(drop=True)
        print(f"\n=== {period}: n={len(sub)} ===")
        for target in TARGETS:
            X = sub[fc.features]
            y = sub[target].to_numpy().astype(int)
            p = _probs(fc, X, target)
            thresholds = _lookup(fc.thresholds, target)
            rep = {
                "pr_auc": round(float(average_precision_score(y, p)), 4),
                "roc_auc": round(float(roc_auc_score(y, p)), 4),
                "brier": round(float(brier_score_loss(y, p)), 4),
                "levels": _levels(y, p, thresholds),
            }
            rec = recorded["classifiers"][target][period]
            print(f"  {target}: PR-AUC {rep['pr_auc']} (recorded {rec['pr_auc']:.4f}) | "
                  f"ROC-AUC {rep['roc_auc']} (recorded {rec['roc_auc']:.4f}) | "
                  f"Brier {rep['brier']} (recorded {rec['brier']:.4f})")
            for lvl in ("elevated", "high"):
                r = rep["levels"][lvl]
                rr = rec["levels"][lvl]
                flag = "" if (abs(r["precision"] - rr["precision"]) < 0.005
                              and abs(r["recall"] - rr["recall"]) < 0.005) else "  <-- DIFFERS"
                print(f"    {lvl}: P {r['precision']} (rec {rr['precision']:.3f}) | "
                      f"R {r['recall']} (rec {rr['recall']:.3f}) | F1 {r['f1']} | "
                      f"TP {r['tp']} FP {r['fp']} FN {r['fn']}{flag}")


if __name__ == "__main__":
    main()
