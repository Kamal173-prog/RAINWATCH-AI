import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { BrandLogo } from '../components/common/BrandLogo'
import { Button } from '../components/common/Button'

export function NotFound() {
  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center px-4 text-center">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ type: 'spring', stiffness: 260, damping: 22 }}
      >
        <BrandLogo size={72} />
      </motion.div>
      <p className="num mt-6 text-5xl font-bold text-accent">404</p>
      <h1 className="mt-3 text-lg font-semibold text-ink">Sector not found</h1>
      <p className="mt-2 max-w-sm text-sm text-muted">
        The requested page does not exist in the RAINWATCH AI dashboard.
      </p>
      <div className="mt-6 flex flex-wrap justify-center gap-3">
        <Link to="/overview">
          <Button variant="primary">Back to overview</Button>
        </Link>
        <Link to="/">
          <Button variant="outline">Landing page</Button>
        </Link>
      </div>
    </div>
  )
}
