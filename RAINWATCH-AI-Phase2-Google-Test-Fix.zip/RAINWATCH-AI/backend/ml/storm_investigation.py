"""Storm-detection investigation: why does v3.3 catch fewer storms?

Uses ONLY the pooled out-of-sample 2024+2025 probabilities
(build_threshold_probs.py). 2026 is not used. The 2026 symptom
(v3.3 26/46 vs v3 35/46 at the saved thresholds) is the question, not
the evidence: the mechanism is diagnosed here on 2024+2025.

For every true storm (gap-merged runs of y=1, gap <= 6 h) and every
version (v3, v3.2, v3.3), records:
  * duration, peak hourly rain, peak 3 h total, month
  * max calibrated probability inside the detection window [s-2, e+2]
  * detected at the OLD thresholds (each version's shipped thresholds)
  * detected at the NEW optimized thresholds (thresholds_optimized.json)
Then classifies storms (caught by all / by v3 only / missed by all /
...) and measures, for v3.3, how many old-threshold misses the new
thresholds recover and at what false-alarm cost.

Output: threshold_work/storm_investigation.json
"""

import json
import logging
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v33_common import event_metrics  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger("storm_investigation")

BACKEND = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORK = os.path.join(BACKEND, "models", "rainfall_xgb_v3_3", "threshold_work")
TARGETS = ["y_3h_ge_10mm", "y_6h_ge_10mm", "y_3h_ge_5mm"]
VERSIONS = ("v3", "v3.2", "v3.3")
MODEL_DIRS = {
    "v3": os.path.join(BACKEND, "models", "rainfall_xgb_v3"),
    "v3.2": os.path.join(BACKEND, "models", "rainfall_xgb_v3_2"),
    "v3.3": os.path.join(BACKEND, "models", "rainfall_xgb_v3_3", "frozen"),
}


def _thresholds(path: str, target: str) -> dict:
    """Read {elevated, high} thresholds, unwrapping either format."""
    d = json.load(open(path))[target]
    out = {}
    for level in ("elevated", "high"):
        v = d[level]
        out[level] = float(v["threshold"]) if isinstance(v, dict) else float(v)
    return out


def _true_storms(y: np.ndarray) -> list[tuple[int, int]]:
    storms, start = [], None
    for i, v in enumerate(y):
        if v == 1 and start is None:
            start = i
        elif v == 0 and start is not None:
            storms.append((start, i - 1))
            start = None
    if start is not None:
        storms.append((start, len(y) - 1))
    merged: list[list[int]] = []
    for s, e in storms:
        if merged and s - merged[-1][1] - 1 <= 6:
            merged[-1][1] = e
        else:
            merged.append([s, e])
    return [(s, e) for s, e in merged]


def _pred_events(pred: np.ndarray) -> list[tuple[int, int]]:
    """STRICT contiguous predicted events (NO gap-merging).

    This matches v33_common.event_metrics exactly: a storm counts as
    detected when any strict predicted event STARTS within [s-2, e+2].
    Gap-merging the predicted blocks first would undercount detection
    (a merged block's start can fall before the window even when one of
    its constituent events starts inside it) and would make these rates
    incomparable with every storm-detection number reported before.
    """
    blocks, start = [], None
    for i, v in enumerate(pred):
        if v == 1 and start is None:
            start = i
        elif v == 0 and start is not None:
            blocks.append((start, i - 1))
            start = None
    if start is not None:
        blocks.append((start, len(pred) - 1))
    return blocks


def _detected(storm: tuple[int, int], events: list[tuple[int, int]]) -> bool:
    s, e = storm
    return any(s - 2 <= a <= e + 2 for a, _ in events)


def investigate(target: str) -> dict:
    # Rainfall amounts for storm characterization (ERA5 hourly weather CSV).
    feat = pd.read_csv(os.path.join(BACKEND, "data", "processed",
                                    "bhubaneswar_weather.csv"),
                       parse_dates=["timestamp"])
    feat = feat[feat["timestamp"].dt.year.isin([2024, 2025])].reset_index(drop=True)
    rain = feat["precipitation_mm"].to_numpy(dtype=float)
    rain3 = pd.Series(rain).rolling(3).sum().to_numpy()

    probs = {}
    for v in VERSIONS:
        df = pd.read_csv(os.path.join(WORK, f"probs_{v}_{target}.csv"),
                         parse_dates=["timestamp"])
        probs[v] = df.sort_values("timestamp").reset_index(drop=True)
    y = probs["v3"]["y"].to_numpy().astype(int)
    ts = probs["v3"]["timestamp"]
    # Sanity: all versions share timestamps and labels.
    for v in VERSIONS:
        assert (probs[v]["timestamp"] == ts).all(), f"{v} timestamps differ"
        assert (probs[v]["y"].to_numpy() == y).all(), f"{v} labels differ"

    storms = _true_storms(y)
    new_thr = json.load(open(os.path.join(WORK, "thresholds_optimized.json")))
    rows = []
    for (s, e) in storms:
        win_lo, win_hi = max(0, s - 2), min(len(y) - 1, e + 2)
        row = {
            "start": str(ts.iloc[s]), "end": str(ts.iloc[e]),
            "duration_h": int(e - s + 1),
            "peak_hourly_mm": float(np.nanmax(rain[s:e + 1])),
            "peak_3h_mm": float(np.nanmax(rain3[s:e + 1])),
            "month": int(ts.iloc[s].month), "year": int(ts.iloc[s].year),
        }
        for v in VERSIONS:
            p = probs[v]["p_cal"].to_numpy(dtype=float)
            old = _thresholds(os.path.join(MODEL_DIRS[v], "thresholds.json"), target)
            new = {"elevated": new_thr[v][target]["watch"]["threshold"],
                   "high": new_thr[v][target]["warning"]["threshold"]}
            row[f"max_p_{v}"] = float(np.max(p[win_lo:win_hi + 1]))
            for label, thr in (("old", old), ("new", new)):
                for level in ("elevated", "high"):
                    events = _pred_events((p >= thr[level]).astype(int))
                    row[f"{label}_{level}_detected_{v}"] = bool(_detected((s, e), events))
        rows.append(row)

    def _rate(rows, key):
        return sum(1 for r in rows if r[key]) / max(1, len(rows))

    # Old-threshold detection rates (reproduces the event_metrics rates).
    old_rates = {v: _rate(rows, f"old_elevated_detected_{v}") for v in VERSIONS}
    new_rates = {v: _rate(rows, f"new_elevated_detected_{v}") for v in VERSIONS}
    # Storms v3 catches at old Watch that v3.3 misses.
    v3_only = [r for r in rows if r["old_elevated_detected_v3"]
               and not r["old_elevated_detected_v3.3"]]
    v33_only = [r for r in rows if r["old_elevated_detected_v3.3"]
                and not r["old_elevated_detected_v3"]]
    missed_all = [r for r in rows if not r["old_elevated_detected_v3"]
                  and not r["old_elevated_detected_v3.2"]
                  and not r["old_elevated_detected_v3.3"]]
    # Recovery: v3.3 old-Watch misses recovered by the new Watch threshold.
    v33_missed_old = [r for r in rows if not r["old_elevated_detected_v3.3"]]
    recovered = [r for r in v33_missed_old if r["new_elevated_detected_v3.3"]]
    # False-alarm cost of the new thresholds (v3.3, pooled 2024+2025).
    p33 = probs["v3.3"]["p_cal"].to_numpy(dtype=float)
    old_t = _thresholds(os.path.join(MODEL_DIRS["v3.3"], "thresholds.json"), target)
    new_t = {"elevated": new_thr["v3.3"][target]["watch"]["threshold"],
             "high": new_thr["v3.3"][target]["warning"]["threshold"]}
    fa = {}
    for label, thr in (("old", old_t), ("new", new_t)):
        for level in ("elevated", "high"):
            from v33_common import hour_metrics as _hm
            m = {**_hm(y, p33, thr[level]),
                 **event_metrics(y, p33, thr[level], n_days=len(y) / 24.0)}
            fa[f"{label}_{level}"] = {
                "alerts_per_100h": m["alerts_per_100h"],
                "false_alarm_events_per_day": m["false_alarm_events_per_day"],
                "precision": m["precision"], "recall": m["recall"],
                "f1": m["f1"], "f2": m["f2"],
                "storm_detection_rate": m["storm_detection_rate"],
                "missed_storms": int(m["n_true_storms"] - m["detected_storms"]),
            }

    result = {
        "n_storms": len(storms),
        "old_watch_detection_rate": old_rates,
        "new_watch_detection_rate": new_rates,
        "storms_v3_only_old_watch": len(v3_only),
        "storms_v3.3_only_old_watch": len(v33_only),
        "storms_missed_by_all_old_watch": len(missed_all),
        "v3.3_old_watch_missed": len(v33_missed_old),
        "v3.3_recovered_by_new_watch": len(recovered),
        "recovery_rate": (len(recovered) / max(1, len(v33_missed_old))),
        "false_alarm_cost_v3.3": fa,
        "v3_only_storms": [
            {k: r[k] for k in ("start", "duration_h", "peak_hourly_mm",
                               "peak_3h_mm", "month", "year", "max_p_v3",
                               "max_p_v3.2", "max_p_v3.3",
                               "new_elevated_detected_v3.3")}
            for r in v3_only],
        "missed_by_all_storms": [
            {k: r[k] for k in ("start", "duration_h", "peak_hourly_mm",
                               "peak_3h_mm", "month", "year", "max_p_v3",
                               "max_p_v3.2", "max_p_v3.3")}
            for r in missed_all],
        "all_storms": rows,
    }
    log.info("%s: %d storms | old Watch detection v3 %.3f v3.2 %.3f v3.3 %.3f | "
             "new Watch v3.3 %.3f | v3-only %d | missed-by-all %d | "
             "v3.3 recovers %d/%d old misses",
             target, len(storms), old_rates["v3"], old_rates["v3.2"],
             old_rates["v3.3"], new_rates["v3.3"], len(v3_only),
             len(missed_all), len(recovered), len(v33_missed_old))
    return result


def main() -> None:
    out = {t: investigate(t) for t in TARGETS}
    json.dump(out, open(os.path.join(WORK, "storm_investigation.json"), "w"), indent=2)
    log.info("saved storm_investigation.json")


if __name__ == "__main__":
    main()
