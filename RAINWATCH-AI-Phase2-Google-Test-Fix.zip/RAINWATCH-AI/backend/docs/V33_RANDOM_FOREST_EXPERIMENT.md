# RAINWATCH AI — Random Forest Challenger Experiment (v3.3)

**Date:** 2026-11-23
**Status:** IN PROGRESS — tuning script written; heavy runs queued behind the
location experiment (shared 1.5-CPU machine).
**Rule:** Random Forest is added to the ensemble ONLY if it gives a
reproducible improvement over the existing three-family ensemble
(XGBoost + LightGBM + HistGradientBoosting). No production changes in
this experiment; 2026 evaluation data is never touched.

## 0. Prerequisite — corrected event-aware experiment (VERIFIED)

Before the RF work, the event-aware sample-weighting arm from the v3.3
variants phase was fixed and re-verified, because its first run was
invalid: the weights were computed but never passed to `fit`, so the
arm returned base-identical numbers.

**Fix** (`backend/ml/train_rainfall_v33.py`, `_train_arm` and `_refit_arm`):
the `eventaware` arm now joins the `cost3`/`cost5` sample-weight branch,
so `model.fit(X, y, sample_weight=sw)` receives the ±6 h ×2 weights.

**Verification, two ways:**
1. *Results level* — the re-run differs from base on all three targets
   (before the fix the results were bit-identical):
   - 3h ≥ 10 mm: PR-AUC 0.1661 (base 0.1687); F1-optimal threshold gives
     F1 0.250, precision 0.347, recall 0.195 — the highest-precision
     operating point of any arm.
   - 6h ≥ 10 mm: PR-AUC 0.2563 (base 0.2743); F1 0.328.
   - 3h ≥ 5 mm: PR-AUC 0.4084 (base 0.3915); F1 0.425.
2. *Mechanism level* — the same HistGradientBoosting model trained with
   vs without the event-aware weights produces different 2024
   probabilities: 1,382 of 26,209 training hours upweighted ×2, mean
   |Δp| = 0.065, max |Δp| = 0.753.

**Verdict on event-aware sampling:** it shifts the operating
characteristic toward precision (best F1 for 3h ≥ 10 mm) but does not
improve PR-AUC over base on any target. It is a threshold-shaping tool,
not a ranking improvement.

## 1. Why test Random Forest?

Random Forest was never used in any RAINWATCH version (v1–v3.2 all use
gradient boosting). It is a legitimate challenger because bagging
decorrelates errors differently from boosting: its trees are trained
independently on bootstrap samples, so its mistakes may be
complementary to the boosting families — exactly what an ensemble
wants. The question is whether that diversity buys anything on
chronological out-of-fold data and on the 2025 benchmark, or whether
RF is simply a weaker ranker on this data.

## 2. Method

**Feature set:** the pruned 94-feature v3.3 set (same as the variants
phase), so the comparison against the three-family base arm is
controlled — only the model family changes.

**Protocol (identical to the variants phase):** train 2021–2023,
ensemble weights / Platt calibration / F1–F2 thresholds learned on
2024 validation, refit on 2021–2024, evaluate ONCE on the 2025
benchmark. 2026 is untouched.

**Tuning (`backend/ml/rf_challenger.py --phase tune`):** chronological
only, no shuffling.
- Stage A (fold train 2021–22 → val 2023, 150 trees):
  max_depth {None, 12} × min_samples_leaf {1, 5} ×
  class_weight {None, balanced_subsample}.
- Stage B (winner refinements): n_estimators {150, 300} ×
  max_features {sqrt, 0.3} × sample_weight {None, event-aware ±6 h ×2}.
- Stage C: top-2 configs confirmed on the untouched folds val 2022
  (train 2021) and val 2024 (train 2021–23); winner by mean PR-AUC
  across 2022–2024.
- Light per-target check for 6h ≥ 10 mm and 3h ≥ 5 mm:
  class_weight × sample_weight only; adopted only if it beats the
  transferred config by > 0.01 PR-AUC on the 2023 fold.

**Out-of-fold probabilities (`--phase oof`):** RF OOF probs with the
winning config, expanding window (val 2022/2023/2024, 200 trees),
saved as `models/rainfall_xgb_v3_3/oof/oof_rf_y_*.csv` in the same
schema as the existing OOF files.

**2025 arms (`--phase eval`):**
- `three_family` — existing baseline, recomputed (must match
  `variants.json`).
- `rf_alone` — Random Forest alone (own Platt + thresholds).
- `xgb_rf` — two-family ensemble, weights learned on 2024.
- `four_family` — XGBoost + LightGBM + HistGB + RF, weights learned
  on 2024 (0.1 grid).
- `stacking` — logistic-regression meta-learner over the four
  families' OOF probabilities; Platt + thresholds from the 2024 OOF
  fold, meta-learner refit on all OOF for the 2025 application.

**Analysis (`--phase analysis`):**
- Metrics per arm/target: PR-AUC, ROC-AUC, Brier, precision, recall,
  F1, F2, F3, event-level recall, storm detection rate, median lead
  time, false alarms/hour and /event per day, ECE calibration error.
- Prediction diversity: Pearson correlation between families'
  2025 probabilities, disagreement rate, Jaccard of positive sets.
- Storm-miss analysis: storms (gap-merged ≤ 6 h) detected ONLY by
  RF-inclusive arms, with RF's max probability during those storms;
  storms missed by every arm.
- Uncertainty: paired chronological block bootstrap (7-day blocks,
  1,000 resamples) on PR-AUC differences vs the three-family
  baseline, plus a storm-event bootstrap on detection-rate
  differences.

## 3. Tuning results

Chronological tuning on 3h ≥ 10 mm, fold train 2021–22 → val 2023,
150 trees unless noted.

**Stage A** (depth × leaf × class_weight):
| depth | leaf | class_weight | val 2023 PR-AUC |
|---|---|---|---|
| None | 1 | None | 0.2308 |
| None | 1 | balanced_subsample | 0.1909 |
| None | 5 | None | 0.2338 |
| None | 5 | balanced_subsample | **0.2364** |
| 12 | 1 | None | 0.2174 |
| 12 | 1 | balanced_subsample | 0.2212 |
| 12 | 5 | None | 0.2363 |
| 12 | 5 | balanced_subsample | 0.2185 |

Winner: unlimited depth, leaf 5, balanced_subsample (0.2364).
Depth barely matters; leaf 5 beats leaf 1; class weighting helps
only with leaf 5.

**Stage B** (trees × max_features × sample weight, on the Stage-A
winner): 300 trees + sqrt + event-aware weights wins at **0.2608**
(150 trees + sqrt + event weights 0.2546; 300 trees + sqrt, no event
weights 0.2475; max_features 0.3 is clearly worse, 0.209–0.220).

**Stage C** (top-2 confirmed on the untouched val 2022 and val 2024
folds): winner is 300 trees, unlimited depth, leaf 5, sqrt,
balanced_subsample, event-aware weights, mean OOF PR-AUC **0.1701**
across 2022–2024 (vs the three-family ensemble's 0.1932 on the same
folds — RF alone is the weaker ranker overall, though it wins the
2023 fold).

**Per-target light check** (class_weight × sample_weight only):
- 6h ≥ 10 mm: transferred config kept (val 2023 0.4609; the best
  alternative, balanced_subsample without event weights, 0.4642, is
  within the 0.01 adoption margin).
- 3h ≥ 5 mm: adopted plain class weights, no event weighting
  (val 2023 0.4952 vs 0.4836 for the transferred config, +0.0116).

Full tuning record: `models/rainfall_xgb_v3_3/rf_tuning.json`.

## 4. Out-of-fold results

RF OOF PR-AUC, expanding window (200 trees), per fold:

| target | 2022 | 2023 | 2024 | mean | 3-family mean |
|---|---|---|---|---|---|
| 3h ≥ 10 mm | 0.1309 | 0.2565 | 0.1191 | 0.1688 | 0.1932 |
| 6h ≥ 10 mm | 0.3298 | 0.4571 | 0.2660 | 0.3510 | 0.3565 |
| 3h ≥ 5 mm | 0.3703 | 0.4958 | 0.3626 | 0.4096 | 0.4053 |

RF is competitive: slightly below the ensemble on 3h ≥ 10 mm,
about even on 6h ≥ 10 mm, slightly above on 3h ≥ 5 mm. 2023 is
RF's best year on all three targets; 2024 is the hard year for
every family. Files: `models/rainfall_xgb_v3_3/oof/oof_rf_y_*.csv`.

## 5. 2025 benchmark results

2025 PR-AUC (protocol: train 2021–23, weights/Platt/thresholds on
2024, refit 2021–24, evaluate once on 2025; the three-family arm
reproduces `variants.json` exactly, validating the pipeline):

| arm | 3h ≥ 10 mm | 6h ≥ 10 mm | 3h ≥ 5 mm |
|---|---|---|---|
| three_family (baseline) | 0.1687 | **0.2743** | 0.3915 |
| rf_alone | 0.1920 | 0.2563 | 0.3792 |
| xgb_rf | 0.1916 | 0.2571 | 0.3989 |
| four_family | **0.2011** | 0.2697 | 0.3868 |
| stacking (logreg, 4 families) | 0.1922 | 0.2606 | **0.4094** |

Weights learned on 2024 validation: four_family is RF-heavy
(3h ≥ 10 mm: xgb 0.0 / lgbm 0.1 / hgb 0.2 / rf 0.7; 6h ≥ 10 mm:
rf 0.7; 3h ≥ 5 mm: hgb 0.4 / rf 0.6). The 2024-OOF gate for
stacking passes for all three targets (stack 0.1100 / 0.2596 /
0.3698 vs fixed 0.1068 / 0.2565 / 0.3620) — unlike the earlier
v32+v33 stacking, which failed the OOF gate on all three.

F1 at F1-optimal thresholds (2025):
- 3h ≥ 10 mm: baseline F1 0.172 (P 0.116 / R 0.333) →
  four_family F1 **0.265** (P 0.313 / R 0.230), rf_alone 0.264.
  RF buys precision at the cost of recall.
- 6h ≥ 10 mm: baseline 0.320 → four_family 0.331 (best), rf_alone
  0.296.
- 3h ≥ 5 mm: baseline 0.409 → xgb_rf 0.434 (best), four_family
  0.432, stacking 0.424.

Context that matters: even the best v3.3 arm on 3h ≥ 10 mm
(four_family 0.2011) is still below the deployed v3.2's 0.2228 on
the same 2025 data. RF narrows the gap; it does not close it.

Full arm detail (weights, Platt params, thresholds, event-level
metrics, ECE): `models/rainfall_xgb_v3_3/rf_experiment.json`.

## 6. Diversity and storm-miss analysis

**Prediction diversity (2025 probabilities).** Pearson correlation
between families: RF vs XGB 0.82–0.88, RF vs LightGBM 0.84–0.87,
RF vs HistGB 0.83–0.90 — correlated but not identical (XGB vs
LightGBM is higher, 0.93–0.96). Jaccard of positive sets at a 0.5
threshold is very low for 3h ≥ 10 mm (RF vs XGB 0.042, vs LightGBM
0.037, vs HistGB 0.010): the families disagree sharply about
which hours are positives at that cut. For 6h ≥ 10 mm the overlap
is larger (RF vs XGB 0.32).

**Storm-miss analysis** (storms = gap-merged ≤ 6 h; detection at
the F1-optimal threshold):
- 3h ≥ 10 mm (33 storms): only-RF detects 1, only-four-family
  detects 1, missed by all 16. RF finds essentially no storm the
  ensemble misses.
- 6h ≥ 10 mm (51 storms): only-RF 1, only-four-family 4, missed
  by all 19.
- 3h ≥ 5 mm (89 storms): only-RF detects **14**, only-four-family
  3, missed by all 10. RF alone sees storms the ensemble misses —
  but the four-family ensemble inherits only 3 of those 14, so the
  diversity does not translate into ensemble gains.

**Calibration.** ECE is small for every arm (0.0023–0.0147); RF
arms are among the best calibrated (0.0025–0.0033), the worst is
the three-family 6h ≥ 10 mm arm (0.0147).

## 7. Uncertainty (bootstrap)

Paired chronological block bootstrap, 7-day blocks, 1,000
resamples, PR-AUC difference vs the three-family baseline:

| target | arm | mean diff | 95% CI | P(>0) |
|---|---|---|---|---|
| 3h ≥ 10 mm | rf_alone | +0.0265 | [−0.051, +0.131] | 0.69 |
| 3h ≥ 10 mm | four_family | +0.0330 | [−0.044, +0.126] | 0.77 |
| 3h ≥ 10 mm | stacking | +0.0234 | [−0.044, +0.105] | 0.72 |
| 6h ≥ 10 mm | four_family | −0.0043 | [−0.037, +0.028] | 0.40 |
| 3h ≥ 5 mm | xgb_rf | +0.0098 | [−0.033, +0.058] | 0.66 |
| 3h ≥ 5 mm | stacking | +0.0199 | [−0.025, +0.070] | 0.80 |

Every CI includes zero. The 3h ≥ 10 mm four-family gain leans
positive (P = 0.77) but is not reproducible by the pre-registered
standard on one year of data.

Storm-event bootstrap on detection rate at the F1 threshold makes
the operational cost explicit: for 3h ≥ 10 mm the RF arms detect
**significantly fewer** storms than the baseline (four_family
−0.212, CI [−0.364, −0.061], P = 0.004; rf_alone −0.243;
stacking −0.243). The PR-AUC gain comes with a recall cost at the
operating point. For 3h ≥ 5 mm, rf_alone leans positive on storm
detection (+0.080, CI includes zero, P = 0.93) while four_family
is significantly worse (−0.090, CI [−0.169, −0.011]).

## 8. Verdict

**Random Forest is NOT adopted.** Verdict recorded in
`rf_experiment.json`: `{3h ≥ 10 mm: False, 6h ≥ 10 mm: False,
3h ≥ 5 mm: False}`.

The evidence:
- The four-family ensemble beats the baseline on 2025 PR-AUC for
  3h ≥ 10 mm (+0.033) and lifts F1 from 0.172 to 0.265, but the
  block-bootstrap CI includes zero — the gain is not established
  as reproducible on one year of data.
- For 6h ≥ 10 mm no RF arm beats the baseline at all.
- For 3h ≥ 5 mm the stacking gain (+0.020) is also inside its CI.
- At the F1 operating point, RF arms detect significantly fewer
  3h ≥ 10 mm storms than the baseline — the precision gain is
  bought with recall the warning use-case cannot spare.
- RF alone does catch 14 storms the ensemble misses for
  3h ≥ 5 mm, but the ensemble inherits only 3 of them.

What would change the verdict: the reserved 2026 evaluation. If
the four-family 3h ≥ 10 mm gain (or the stacking 3h ≥ 5 mm gain)
reproduces on 2026, revisit. Until then the three-family
ensemble stands, and the RF experiment's artifacts
(`rf_tuning.json`, `oof/oof_rf_*.csv`, `rf_experiment.json`,
`rf_arm_probs_*.npz`) are kept as the record, not deployed.
