"""IFS / NWP features for RAINWATCH AI v3.2 (Source F).

Builds features from the ECMWF IFS (and GFS) historical-forecast data
in ``data/processed/ifs/``. All features are computed from values at
time ``t`` or earlier — zero future leakage.

Physical interpretation:
- ``ifs_precip``: the NWP model's own precipitation estimate for the
  hour. A second, independent precipitation estimate (the model
  forecast) alongside ERA5 reanalysis. If the NWP model "sees" rain
  that ERA5 smooths out, this adds signal.
- ``ifs_cape``: Convective Available Potential Energy from the NWP
  model. ERA5 via Open-Meteo returns CAPE as all nulls, so IFS is the
  only CAPE source in this project. High CAPE = unstable atmosphere =
  convective potential.
- ``ifs_cape_3h_max``: maximum CAPE over the past 3 h — convective
  instability building up.
- ``ifs_precip_3h_sum`` / ``ifs_precip_6h_sum``: NWP precipitation
  accumulated over the past 3 h / 6 h.
- ``ifs_cape_x_humidity``: CAPE weighted by humidity — instability
  only matters when moisture is present.
- ``ifs_precip_minus_era5``: NWP precip minus ERA5 precip (same hour).
  A positive value means the forecast model expects more rain than the
  reanalysis shows — a disagreement signal.
- ``ifs_rh_tendency``: 3 h change in relative humidity — moistening
  ahead of a rain event.

Availability: these are 0-hour-lead (analysis) forecast values, so they
are available at the valid time. If longer-lead forecasts are ever
added, record the run time and lead time and pass the availability
check.
"""

from __future__ import annotations

import pandas as pd


def build_ifs_features(
    ifs_df: pd.DataFrame,
    era5_precip: pd.Series | None = None,
) -> pd.DataFrame:
    """Build IFS features from a processed IFS frame (hourly UTC,
    columns as written by ``ifs_source.IFSSource.process``).
    ``era5_precip`` is the ERA5 hourly precipitation series (same index)
    used only for the disagreement feature. Returns a frame indexed by
    timestamp with the new feature columns."""
    df = ifs_df.copy()
    df = df.sort_values("timestamp").reset_index(drop=True)
    out = pd.DataFrame({"timestamp": df["timestamp"]})

    if "precipitation_mm" in df.columns:
        p = pd.to_numeric(df["precipitation_mm"], errors="coerce")
        out["ifs_precip"] = p
        out["ifs_precip_3h_sum"] = p.rolling(3, min_periods=3).sum()
        out["ifs_precip_6h_sum"] = p.rolling(6, min_periods=6).sum()
        out["ifs_precip_accel"] = (
            p.rolling(3, min_periods=3).sum()
            - p.rolling(3, min_periods=3).sum().shift(3)
        )
        if era5_precip is not None:
            era5 = pd.to_numeric(era5_precip, errors="coerce").reset_index(drop=True)
            out["ifs_precip_minus_era5"] = p - era5

    if "cape_jkg" in df.columns:
        cape = pd.to_numeric(df["cape_jkg"], errors="coerce")
        out["ifs_cape"] = cape
        out["ifs_cape_3h_max"] = cape.rolling(3, min_periods=3).max()
        out["ifs_cape_3h_change"] = cape - cape.shift(3)
        if "humidity_pct" in df.columns:
            hum = pd.to_numeric(df["humidity_pct"], errors="coerce")
            out["ifs_cape_x_humidity"] = cape * (hum / 100.0)
            out["ifs_rh_tendency_3h"] = hum - hum.shift(3)

    if "wind_speed_kmh" in df.columns and "wind_direction_deg" in df.columns:
        import numpy as np
        speed = pd.to_numeric(df["wind_speed_kmh"], errors="coerce")
        direction = pd.to_numeric(df["wind_direction_deg"], errors="coerce")
        dir_rad = np.radians(direction)
        # Meteorological convention: direction is where the wind comes FROM.
        out["ifs_wind_u"] = -speed * np.sin(dir_rad)
        out["ifs_wind_v"] = -speed * np.cos(dir_rad)

    return out
