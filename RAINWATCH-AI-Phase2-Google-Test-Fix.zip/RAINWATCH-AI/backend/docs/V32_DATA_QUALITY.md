# v3.2 Data Quality Report

Date: 2026-11-23. This document records the data-quality checks run on
every dataset acquired for v3.2, the issues found, and how they were
handled. Nothing was silently deleted or fabricated.

## 1. ERA5 2026 (fresh evaluation period)

- File: `data/processed/bhubaneswar_weather_2026.csv`
- Rows: 7,848 (2026-01-01 00:00 → 2026-11-23 23:00 UTC, hourly).
- Precipitation: 7,848/7,848 non-null (100%).
- Overall missing: 5.56% (same pattern as 2021–2025: CAPE all nulls,
  TCWV has gaps).
- No duplicate timestamps, no negative rainfall, no temporal gaps.
- **Verdict: clean. Usable as the fresh evaluation period.**

## 2. 2026 upwind spatial grids (Puri Coast + Offshore Bay)

- File: `data/processed/upwind_spatial_2026.csv`
- Rows: 7,848. Precipitation non-null: 7,848/7,848 for both grids.
- **Verdict: clean.**

## 3. GFS (Open-Meteo Historical Forecast API)

- Files: `data/raw/ifs/gfs_global_*.json` (5 chunks),
  `data/processed/ifs/gfs_global_processed.csv` (49,728 rows).
- Coverage: 2021-03-23 → 2026-11-23.
- Precipitation non-null: 49,383/49,728 (99.3%).
- **Gap found: 2022-11-29 20:00 → 2022-12-14 04:00 (~15 days, 345 hours
  missing).** This is a contiguous data gap in the Open-Meteo GFS
  archive, not scattered missing values. Rows in this period have NaN
  GFS features; XGBoost/LightGBM/HistGB handle NaN natively, so the
  rows are kept (not dropped) and the models learn to handle missing
  GFS data.
- QC: 0 negative rainfall, 29 out-of-range values (CAPE > 6000 J/kg in
  a few hours — flagged, not deleted; these are plausible extreme
  values in the GFS model, not errors).
- **Verdict: usable with the documented gap.**

## 4. ECMWF IFS (Open-Meteo Historical Forecast API)

- Files: `data/raw/ifs/ecmwf_ifs025_*.json` (7 chunks),
  `data/processed/ifs/ecmwf_ifs025_processed.csv` (51,672 rows).
- Coverage: **2024-02-02 → 2026-11-23 only.** All values are null for
  2021-01-01 → 2024-02-02 (the API returns timestamps but no data).
  First non-null: 2024-02-02T22:00. After that, one gap of 244 hours
  (~10 days) in 2024.
- Precipitation non-null: 23,838/51,672 (46.1%).
- QC: 0 negative rainfall, 222 out-of-range values (CAPE up to 8,820
  J/kg — flagged, not deleted).
- **Verdict: acquired but NOT usable for training** with the 2021–2023
  split. All 12 IFS features were dropped from the IFS variant. IFS
  can only be used if the training period is restricted to 2024+, which
  is too short for a robust model. Documented as a limitation.

## 5. Dataset comparison (ERA5 vs NWP)

Compared on overlapping periods, ERA5 as the reference (it is the
training target, not ground truth):

| Metric | ERA5 vs GFS (2021-03-23 → 2026-11-23, n=49,382) | ERA5 vs ECMWF IFS (2024-02-02 → 2026-11-23, n=24,359) |
|---|---|---|
| MAE (mm/hr) | 0.304 | 0.300 |
| RMSE (mm/hr) | 1.330 | 1.020 |
| Mean bias (mm/hr) | −0.080 | +0.002 |
| Pearson correlation | 0.145 | 0.601 |
| Spearman correlation | 0.396 | 0.588 |
| Wet-hour MAE (mm/hr) | 2.301 | 1.693 |
| Wet-hour bias (mm/hr) | −1.730 | −1.145 |
| Monsoon MAE (mm/hr) | 0.632 | 0.616 |
| Non-monsoon MAE (mm/hr) | 0.124 | 0.122 |
| 3h ≥ 5 mm: POD / FAR / CSI | 0.150 / 0.706 / 0.110 | 0.407 / 0.580 / 0.260 |
| 3h ≥ 10 mm: POD / FAR / CSI | 0.081 / 0.800 / 0.061 | 0.370 / 0.483 / 0.275 |

**Interpretation:**
- ECMWF IFS agrees with ERA5 much better than GFS does (Pearson 0.60
  vs 0.15; POD 0.37 vs 0.08 for heavy events). This is expected —
  ERA5 is produced by the IFS model, so IFS and ERA5 are not
  independent. The IFS–ERA5 agreement is partly model self-consistency,
  not independent evidence of predictive value.
- GFS disagrees with ERA5 substantially (Pearson 0.15) yet still
  improves the ML classifier (see V32_TECHNICAL.md). This is the key
  result: **a second, disagreeing precipitation estimate adds
  information the ERA5-only features do not capture.** The GFS model
  "sees" rain that ERA5 smooths out, and vice versa.
- Both NWP products underestimate wet-hour rainfall (negative bias
  −1.73 and −1.15 mm/hr on wet hours).

## 6. CAPE

- ERA5 CAPE: 0/51,672 non-null (all nulls, confirmed again for 2026).
- GFS CAPE: 49,728/49,728 non-null, mean 687 J/kg, max 3,940 J/kg.
- ECMWF IFS CAPE: 23,838/51,672 non-null, mean 1,546 J/kg, max 8,820 J/kg.
- **GFS CAPE on ERA5 3h ≥ 10 mm hours: mean 600 J/kg (n=669) vs
  non-heavy 688 J/kg (n=49,057).** CAPE is *lower* on heavy-rain hours.
  This is physically consistent: CAPE is consumed by convection, so by
  the time heavy rain falls, CAPE has already been depleted. The useful
  CAPE features are the 3 h maximum and the 3 h change (instability
  building up), not the concurrent value.

## 7. Quality-control rules applied

- Missing observations: counted and reported, never silently filled.
- Duplicated timestamps: dropped (keep first).
- Negative rainfall: flagged; none found in any acquired dataset.
- Extreme values: flagged (CAPE > 6000 J/kg), not deleted.
- Temporal gaps: documented (GFS 15-day gap Nov–Dec 2022; IFS 10-day
  gap in 2024; IFS entirely missing before 2024-02-02).
- Units: verified per source (mm, J/kg, hPa, km/h, degC, %).
- All QC runs are reproducible via `scripts/validate_datasets.py`.
