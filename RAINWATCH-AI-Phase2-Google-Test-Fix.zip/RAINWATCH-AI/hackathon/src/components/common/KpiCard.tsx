import { ArrowRight, ArrowUpRight, ArrowDownRight } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import type { ReactNode } from 'react'
import { useCountUp } from '../../hooks/useUi'
import { Card } from './Card'
import { InfoTip } from './InfoTip'
import { Skeleton } from './Skeleton'

export interface KpiCardProps {
  label: string
  value: number
  unit?: string
  decimals?: number
  icon: LucideIcon
  tooltip: string
  trend?: {
    value: number
    suffix?: string
    tone?: 'good' | 'bad' | 'neutral'
    label?: string
  }
  spark?: number[]
  loading?: boolean
  footnote?: ReactNode
  delay?: number
}

const TREND_TONE = {
  good: 'text-success',
  bad: 'text-critical',
  neutral: 'text-muted',
} as const

function Sparkline({ points }: { points: number[] }) {
  if (points.length < 2) return null
  const max = Math.max(...points, 1)
  const min = Math.min(...points, 0)
  const span = max - min || 1
  const w = 96
  const h = 30
  const coords = points.map((p, i) => {
    const x = (i / (points.length - 1)) * w
    const y = h - ((p - min) / span) * (h - 4) - 2
    return `${x.toFixed(1)},${y.toFixed(1)}`
  })

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-8 w-24 overflow-visible" preserveAspectRatio="none" aria-hidden>
      <polyline points={`0,${h} ${coords.join(' ')} ${w},${h}`} fill="var(--rw-accent)" opacity="0.1" stroke="none" />
      <polyline
        points={coords.join(' ')}
        fill="none"
        stroke="var(--rw-accent)"
        strokeWidth="1.6"
        strokeLinecap="square"
        vectorEffect="non-scaling-stroke"
      />
      <rect x={w - 2} y={Number(coords[coords.length - 1]?.split(',')[1] ?? h / 2) - 2} width="4" height="4" fill="var(--rw-accent)" />
    </svg>
  )
}

export function AnimatedValue({
  value,
  decimals = 1,
  className = '',
}: {
  value: number
  decimals?: number
  className?: string
}) {
  const shown = useCountUp(value, 950, decimals)
  const text = shown.toLocaleString('en-IN', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })
  return <span className={`num ${className}`}>{text}</span>
}

export function KpiCard({
  label,
  value,
  unit,
  decimals = 1,
  icon: Icon,
  tooltip,
  trend,
  spark,
  loading = false,
  footnote,
  delay = 0,
}: KpiCardProps) {
  const trendIcon = !trend || trend.value === 0 ? ArrowRight : trend.value > 0 ? ArrowUpRight : ArrowDownRight
  const TrendIcon = trendIcon

  return (
    <Card tilt hover delay={delay} className="overflow-hidden">
      <span className="absolute top-0 left-0 h-0.5 w-0 bg-accent transition-all duration-300 group-hover/card:w-full" aria-hidden />

      <div className="tilt-3d flex items-start justify-between gap-2">
        <div className="flex min-w-0 items-center gap-1.5">
          <p className="mono truncate text-[10px] font-semibold text-muted">{label}</p>
          <InfoTip text={tooltip} />
        </div>
        <span className="tilt-lift flex h-8 w-8 shrink-0 items-center justify-center border border-line bg-surface text-accent transition-colors duration-200 group-hover/card:border-accent">
          <Icon size={15} aria-hidden />
        </span>
      </div>

      <div className="tilt-3d mt-3 flex items-end justify-between gap-2">
        <div className="min-w-0">
          {loading ? (
            <Skeleton className="h-8 w-24" />
          ) : (
            <div className="flex items-baseline gap-1.5">
              <AnimatedValue value={value} decimals={decimals} className="text-[27px] leading-none font-bold text-ink" />
              {unit ? <span className="mono text-[10px] text-muted">{unit}</span> : null}
            </div>
          )}
          {footnote ? <div className="mt-2">{footnote}</div> : null}
        </div>
        {!loading && spark && spark.length > 1 ? (
          <div className="shrink-0 pb-0.5 opacity-90"><Sparkline points={spark} /></div>
        ) : null}
      </div>

      {trend ? (
        <div className="tilt-3d mono mt-3 flex items-center gap-1.5 border-t border-line pt-2 text-[10px]">
          <TrendIcon size={12} className={TREND_TONE[trend.tone ?? 'neutral']} aria-hidden />
          <span className={`font-semibold ${TREND_TONE[trend.tone ?? 'neutral']}`}>
            {trend.value > 0 ? '+' : ''}{trend.value}{trend.suffix ?? ''}
          </span>
          <span className="truncate text-muted">{trend.label ?? 'vs previous'}</span>
        </div>
      ) : null}
    </Card>
  )
}
