"""Tests for the Google Weather API integration.

All Google HTTP traffic is mocked with httpx.MockTransport. Fixtures
are built from the response shape in Google's official documentation
(hourly forecast guide + reference, read 2026-11-24) — no live calls,
no invented fields, no real key anywhere.
"""

import httpx
import pytest

from app.core import config
from app.services import google_weather as gw

TEST_KEY = "test-demo-key"


def make_hour(i, rain=False):
    """One ForecastHour in Google's documented shape."""
    hour = {
        "interval": {
            "startTime": f"2026-11-25T{i:02d}:00:00Z",
            "endTime": f"2026-11-25T{i + 1:02d}:00:00Z",
        },
        "temperature": {"degrees": 28.0 - i * 0.2, "unit": "CELSIUS"},
        "relativeHumidity": 70 + (i % 5),
        "weatherCondition": {
            "type": "LIGHT_RAIN" if rain else "PARTLY_CLOUDY",
            "description": {"text": "Light rain" if rain else "Partly cloudy"},
        },
        "wind": {
            "direction": {"degrees": 120, "cardinal": "ESE"},
            "speed": {"value": 11.0, "unit": "KILOMETERS_PER_HOUR"},
        },
    }
    if rain:
        hour["precipitation"] = {
            "probability": {"percent": 65, "type": "RAIN"},
            "qpf": {"quantity": 1.4, "unit": "MILLIMETERS"},
        }
    else:
        hour["precipitation"] = {
            "probability": {"percent": 10, "type": "NONE"},
            "qpf": {"quantity": 0.0, "unit": "MILLIMETERS"},
        }
    return hour


def google_payload(n=24, rain_hours=(5, 6)):
    return {
        "forecastHours": [
            make_hour(i, rain=(i in rain_hours)) for i in range(n)
        ],
        "timeZone": {"id": "Asia/Kolkata"},
    }


class CallCounter:
    def __init__(self):
        self.count = 0
        self.requests = []


def success_transport(counter, pages=None):
    """MockTransport returning the 24h fixture (or paginated pages).

    pages: list of (hours_list, next_page_token) tuples; when None,
    the whole fixture is returned in a single page.
    """
    def handler(request: httpx.Request) -> httpx.Response:
        counter.count += 1
        counter.requests.append(request)
        assert request.url.params.get("key") == TEST_KEY
        assert request.url.params.get("unitsSystem") == "METRIC"
        if pages is not None:
            token = request.url.params.get("pageToken")
            idx = 0 if token is None else int(token)
            hours_list, next_token = pages[idx]
            return httpx.Response(200, json={
                "forecastHours": hours_list,
                "timeZone": {"id": "Asia/Kolkata"},
                "nextPageToken": next_token,
            })
        return httpx.Response(200, json=google_payload())
    return httpx.MockTransport(handler)


def error_transport(counter, status):
    def handler(request: httpx.Request) -> httpx.Response:
        counter.count += 1
        return httpx.Response(status, json={
            "error": {"code": status, "message": "mock error", "status": "MOCK"}})
    return httpx.MockTransport(handler)


@pytest.fixture(autouse=True)
def _reset_google(monkeypatch):
    gw.reset_state()
    gw.set_transport(None)
    monkeypatch.delenv("GOOGLE_WEATHER_API_KEY", raising=False)
    monkeypatch.delenv("GOOGLE_WEATHER_MONTHLY_CAP", raising=False)
    yield
    gw.reset_state()
    gw.set_transport(None)


@pytest.fixture
def keyed(monkeypatch):
    # Set BOTH the env var and the import-time config snapshot: the
    # service reads env first and falls back to config, so setting
    # only the env var would still leave a stale config value in play
    # if the fixture order ever changed.
    monkeypatch.setenv("GOOGLE_WEATHER_API_KEY", TEST_KEY)
    monkeypatch.setattr(config, "GOOGLE_WEATHER_API_KEY", TEST_KEY)
    return TEST_KEY


# ------------------------------------------------------------------
# Service: parsing and mapping
# ------------------------------------------------------------------

def test_service_parses_24h_fixture(keyed):
    counter = CallCounter()
    gw.set_transport(success_transport(counter))
    payload = gw.get_google_forecast("old-town", 24)
    assert payload["locationId"] == "old-town"
    assert payload["location"]["name"] == "Old Town"
    assert payload["location"]["lat"] == 20.2662
    assert payload["location"]["lng"] == 85.8418
    assert payload["timeZone"] == "Asia/Kolkata"
    assert payload["source"] == "google_weather"
    assert payload["meta"]["cached"] is False
    assert payload["meta"]["callsMade"] == 1
    assert len(payload["hours"]) == 24
    assert all(p["source"] == "google_weather" for p in payload["hours"])
    assert payload["hours"][0]["timestamp"] == "2026-11-25T00:00:00Z"
    # endTime (added 2026-11-25 for the merged forecast's interval match).
    assert payload["hours"][0]["endTime"] == "2026-11-25T01:00:00Z"
    assert payload["hours"][0]["temperatureC"] == 28.0
    assert payload["hours"][0]["relativeHumidityPct"] == 70
    assert payload["hours"][0]["precipitationMm"] == 0.0
    assert payload["hours"][0]["precipitationProbabilityPct"] == 10
    assert payload["hours"][0]["windSpeedKmh"] == 11.0
    assert payload["hours"][0]["windDirectionDeg"] == 120
    assert payload["hours"][0]["condition"] == "PARTLY_CLOUDY"
    assert payload["hours"][0]["conditionText"] == "Partly cloudy"
    rainy = payload["hours"][5]
    assert rainy["precipitationMm"] == 1.4
    assert rainy["precipitationProbabilityPct"] == 65
    assert rainy["precipitationType"] == "RAIN"
    assert rainy["condition"] == "LIGHT_RAIN"


def test_service_missing_optional_fields(keyed):
    counter = CallCounter()
    sparse = {"forecastHours": [
        {"interval": {"startTime": "2026-11-25T00:00:00Z"},
         "temperature": {"degrees": 27.5, "unit": "CELSIUS"}},
        {"interval": {"startTime": "2026-11-25T01:00:00Z"},
         "temperature": {"degrees": 27.0},
         "precipitation": {"qpf": {"quantity": 0.5, "unit": "MILLIMETERS"}}},
    ], "timeZone": {"id": "Asia/Kolkata"}}
    gw.set_transport(httpx.MockTransport(
        lambda request: httpx.Response(200, json=sparse)))
    payload = gw.get_google_forecast("cuttack", 3)
    assert len(payload["hours"]) == 2
    first, second = payload["hours"]
    assert first["precipitationMm"] is None
    assert first["windSpeedKmh"] is None
    assert first["condition"] is None
    assert first["relativeHumidityPct"] is None
    assert second["precipitationMm"] == 0.5
    assert second["temperatureC"] == 27.0


def test_service_no_key_raises_not_configured():
    with pytest.raises(gw.GoogleWeatherNotConfigured):
        gw.get_google_forecast("old-town", 24)


def test_service_invalid_key(keyed):
    counter = CallCounter()
    gw.set_transport(error_transport(counter, 403))
    with pytest.raises(gw.GoogleWeatherError) as excinfo:
        gw.get_google_forecast("old-town", 24)
    assert "403" in excinfo.value.reason
    assert counter.count == 1
    status = gw.get_status()
    assert status["status"] == "Error"
    assert status["error"] is not None


def test_service_timeout(keyed):
    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectTimeout("timed out", request=request)
    gw.set_transport(httpx.MockTransport(handler))
    with pytest.raises(gw.GoogleWeatherError) as excinfo:
        gw.get_google_forecast("old-town", 24)
    assert "timed out" in excinfo.value.reason
    assert gw.get_status()["status"] == "Error"


def test_service_quota_429(keyed):
    counter = CallCounter()
    gw.set_transport(error_transport(counter, 429))
    with pytest.raises(gw.GoogleWeatherError) as excinfo:
        gw.get_google_forecast("old-town", 24)
    assert "429" in excinfo.value.reason
    assert gw.get_status()["error"] is not None


def test_service_5xx(keyed):
    counter = CallCounter()
    gw.set_transport(error_transport(counter, 500))
    with pytest.raises(gw.GoogleWeatherError):
        gw.get_google_forecast("old-town", 24)
    assert gw.get_status()["status"] == "Error"


def test_service_cache_hit_makes_no_second_call(keyed):
    counter = CallCounter()
    gw.set_transport(success_transport(counter))
    first = gw.get_google_forecast("old-town", 24)
    second = gw.get_google_forecast("old-town", 24)
    assert counter.count == 1
    assert second["meta"]["cached"] is True
    assert second["hours"] == first["hours"]
    assert second["retrievedAt"] == first["retrievedAt"]


def test_service_ttl_expiry_refetches(keyed, monkeypatch):
    counter = CallCounter()
    gw.set_transport(success_transport(counter))
    gw.get_google_forecast("old-town", 24)
    assert counter.count == 1
    monkeypatch.setattr(gw, "CACHE_TTL_SECONDS", 0)
    gw.get_google_forecast("old-town", 24)
    assert counter.count == 2


def test_service_monthly_cap(keyed, monkeypatch):
    counter = CallCounter()
    gw.set_transport(success_transport(counter))
    monkeypatch.setenv("GOOGLE_WEATHER_MONTHLY_CAP", "1")
    gw.get_google_forecast("old-town", 24)
    assert counter.count == 1
    with pytest.raises(gw.GoogleWeatherError) as excinfo:
        gw.get_google_forecast("brahmapur", 24)
    assert "cap" in excinfo.value.reason
    assert counter.count == 1  # no second HTTP call was made


def test_service_pagination_72h(keyed):
    counter = CallCounter()
    pages = [
        ([make_hour(i) for i in range(24)], "1"),
        ([make_hour(24 + i) for i in range(24)], "2"),
        ([make_hour(48 + i) for i in range(24)], None),
    ]
    gw.set_transport(success_transport(counter, pages=pages))
    payload = gw.get_google_forecast("old-town", 72)
    assert len(payload["hours"]) == 72
    assert counter.count == 3  # one billable event per page
    assert payload["meta"]["callsMade"] == 3


# ------------------------------------------------------------------
# Endpoint (TestClient)
# ------------------------------------------------------------------

def test_endpoint_success_old_town(client, keyed):
    counter = CallCounter()
    gw.set_transport(success_transport(counter))
    r = client.get("/api/weather/google?locationId=old-town&hours=24")
    assert r.status_code == 200
    body = r.json()
    assert body["source"] == "google_weather"
    assert body["locationId"] == "old-town"
    assert body["timeZone"] == "Asia/Kolkata"
    assert len(body["hours"]) == 24
    assert all(h["source"] == "google_weather" for h in body["hours"])
    assert body["meta"]["cached"] is False


def test_endpoint_locations(client, keyed):
    counter = CallCounter()
    gw.set_transport(success_transport(counter))
    for location_id, name in [
        ("brahmapur", "Brahmapur"), ("cuttack", "Cuttack"), ("puri", "Puri")]:
        r = client.get(f"/api/weather/google?locationId={location_id}&hours=24")
        assert r.status_code == 200, location_id
        assert r.json()["location"]["name"] == name
        assert r.json()["location"]["lat"] is not None


def test_endpoint_unknown_location(client, keyed):
    r = client.get("/api/weather/google?locationId=nowhere&hours=24")
    assert r.status_code == 404


def test_endpoint_bad_hours(client, keyed):
    r = client.get("/api/weather/google?locationId=old-town&hours=7")
    assert r.status_code == 400


def test_endpoint_no_key_503(client):
    r = client.get("/api/weather/google?locationId=old-town&hours=24")
    assert r.status_code == 503
    assert r.json()["detail"] == "Google Weather API key not configured"


def test_endpoint_google_down_forecast_still_works(client, keyed, v33_client):
    counter = CallCounter()
    gw.set_transport(error_transport(counter, 500))
    r = client.get("/api/weather/google?locationId=old-town&hours=24")
    assert r.status_code == 502
    # Independence: RAINWATCH v3.3 keeps working exactly as before.
    points = v33_client.get("/api/forecast?locationId=old-town&hours=24").json()
    sources = {p["source"] for p in points}
    assert sources == {"model", "demo"}
    assert len([p for p in points if p["source"] == "model"]) == 6
    assert len([p for p in points if p["source"] == "demo"]) == 18


def test_endpoint_pagination_72h(client, keyed):
    counter = CallCounter()
    pages = [
        ([make_hour(i) for i in range(24)], "1"),
        ([make_hour(24 + i) for i in range(24)], "2"),
        ([make_hour(48 + i) for i in range(24)], None),
    ]
    gw.set_transport(success_transport(counter, pages=pages))
    r = client.get("/api/weather/google?locationId=old-town&hours=72")
    assert r.status_code == 200
    assert len(r.json()["hours"]) == 72


# ------------------------------------------------------------------
# Source integrity
# ------------------------------------------------------------------

def test_forecast_never_contains_google_weather(v33_client):
    points = v33_client.get("/api/forecast?locationId=old-town&hours=24").json()
    assert {p["source"] for p in points} <= {"model", "demo"}


def test_data_sources_google_live_only_after_success(client, keyed):
    counter = CallCounter()
    gw.set_transport(success_transport(counter))
    # Before any call: Not Connected.
    body = client.get("/api/data-sources").json()
    google = [s for s in body["sources"] if s["id"] == "google-weather"][0]
    assert google["status"] == "Not Connected"
    assert google["kind"] == "Forecast feed"
    # After a verified successful call: Live, with live fields.
    client.get("/api/weather/google?locationId=old-town&hours=24")
    body = client.get("/api/data-sources").json()
    google = [s for s in body["sources"] if s["id"] == "google-weather"][0]
    assert google["status"] == "Live"
    assert google["lastRetrievedAt"] is not None
    assert google["recordsRetrieved"] == 24
    assert google["error"] is None


def test_data_sources_google_error_after_failure(client, keyed):
    counter = CallCounter()
    gw.set_transport(error_transport(counter, 500))
    client.get("/api/weather/google?locationId=old-town&hours=24")
    body = client.get("/api/data-sources").json()
    google = [s for s in body["sources"] if s["id"] == "google-weather"][0]
    assert google["status"] == "Error"
    assert google["error"] is not None
