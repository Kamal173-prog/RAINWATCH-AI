# RAINWATCH AI — Testing

How the project is tested, what is covered, and how to run it. All
numbers below are from runs on 2026-11-24 / 2026-11-25 on this
machine, not aspirations. Nothing here claims a test was run that
was not run.

## How to run

```bash
# Backend (from backend/)
.venv/bin/python -m pytest            # full suite, ~60 s
.venv/bin/python -m pytest -q -p no:warnings
.venv/bin/python -m pytest tests/test_model_selection.py -v   # one file

# Frontend typecheck + production build (from hackathon/)
npm install --no-save --no-package-lock   # once per fresh checkout on Linux; see note
node node_modules/typescript/bin/tsc -b
node node_modules/vite/bin/vite.js build
```

Test dependencies live in `backend/requirements-test.txt`
(pytest 9.2.0, httpx 0.28.1) and are installed in `backend/.venv`
only — the production venv is untouched. The research venv
`backend/.venv-audit` holds the audit/probe tooling (xarray,
scikit-learn, matplotlib, playwright, python-pptx).

## Backend suite — 190 passed, 0 failed

`backend/tests/` (run 2026-11-25: `190 passed in ~85s`). The suite
uses FastAPI `TestClient` with the model loaded once per session
(`conftest.py`); most of the time is model load, not test logic.

| File | What it covers |
|---|---|
| `test_health.py` | `/api/health` shape; `model.loaded`, `model_version`, `model_input_as_of` is ISO-8601; dataset block (name, range, records, loaded); invalid `MODEL_VERSION` falls back to v3 and reports v3 |
| `test_endpoints.py` | All 23 endpoints incl. `/api/weather/google` and the new `/api/forecast/merged`: status codes, response shapes, query validation, 404/422 behaviour, the 8 data sources (incl. the Historical Rainfall Records row reporting `Archive` with kind `Historical dataset` and cadence "Static archive — no live updates"; **no source may claim status `Live` except Google Weather API after a verified successful call, and zero real-time-observation feeds are live**), overview bundle, map layers/regions, demo refresh |
| `test_forecast_merged.py` | 17 tests, all against `httpx.MockTransport` (no live Google call): Old Town 6 model + 18 google_weather (UTC-aligned and 30-min-offset local-hour-grid fixtures), Brahmapur 24 google_weather, Cuttack/Puri 6 model + 18 google_weather (actual sources verified); model points byte-identical to `/api/forecast`; `valueKind` per row; Google metadata preserved (probability, temperature, condition, `googleTimestamp`); accumulated continues the running total and is null from the first unavailable hour on; no key → 6 model + 18 unavailable (`not_configured`); invalid key 401 → unavailable; timeout → unavailable; 429 → unavailable; Google never called when all hours are model (hours=3/6); `/api/forecast` still 6 model + 18 demo; `/api/forecast/intensity` unchanged; no `demo` source in any merged response; 404/400 |
| `test_google_weather.py` | 21 tests, all against `httpx.MockTransport` (no live Google call): service parse of the documented 24 h fixture (field mapping, units, timestamps, `endTime` on every point, `google_weather` on every point); missing optional fields (no precipitation → None, no crash); 401/403 → unavailable, no exception escapes; timeout → unavailable; 429 → unavailable with error recorded; 5xx → unavailable; cache hit (second call, same location/hours: zero HTTP requests); TTL expiry (refetch); monthly cap reached (no HTTP call); endpoint via TestClient (old-town 24 h returns `source: google_weather` + 24 records; brahmapur/cuttack/puri work; unknown location 404; hours=7 400; no key → 503; Google mocked down → 502 **and** `/api/forecast` still returns model/demo normally) |
| `test_simulator.py` | `POST /api/simulate`: valid presets, boundary inputs, invalid inputs (422), response structure (risk index, class, breakdown, peak depth); `/api/overview` simulator-adjacent fields |
| `test_provenance.py` | MODEL / DEMO / UNKNOWN labels: forecast points (6 model + 18 demo for a Bhubaneswar-region location, 24/24 demo for Ganjam), risk records (3 model + 6 demo per location, 42 model + 483 demo in `/api/risk/all`), missing `source` metadata → `unknown`, `model_version` never inferred from the version flag alone; **shared-cell regression: the six MODEL points are identical across Old Town, Patia, Cuttack and Puri (one Bhubaneswar grid cell), while DEMO points differ**; compiled `resolveSource` probe covers `"google_weather"` → `google_weather` and `model_version` alone never promotes; `/api/forecast` never leaks `google_weather` |
| `test_model_selection.py` | v3 production default, v3.3 via `MODEL_VERSION=rainfall-xgb-v3.3`, v3.2 via flag, invalid flag → v3, the actually-loaded version reported by `/api/health` and per-point `model_version`; cache-key regression (switching versions with warm caches cannot serve stale points under the old label); frozen v3.3 manifest hashes (15/15) |
| `test_ml_reliability.py` | Missing/invalid features, NaN-heavy inputs and a missing GFS CSV still yield finite outputs; `_features_at` raises below 73 rows; reproducibility (same input → same output); classifier vs regression output handling; artifact integrity |

Two product bugs were found by this suite and fixed (both
regression-tested):
1. `/api/health` `model_input_as_of` was space-separated, non-ISO
   (`ml/predict.py:460` now uses `pd.Timestamp(...).isoformat()`).
2. Forecast/risk/map response caches were keyed by demo tick only, so
   a version switch with warm caches could serve stale points labelled
   with the previous version. Caches are now keyed by
   `MODEL_VERSION_ENV` as well as demo tick.

### Endpoints the brief named that do not exist

`/api/simulations/run` and `/api/simulations/compare` do **not**
exist. The real surface is `POST /api/simulate` plus `GET
/api/overview`, and scenario comparison is client-side local state
(`Simulator.tsx` "Scenario comparison" history table). The suite
asserts this absence explicitly (`test_endpoints.py`). Adding the
endpoints is a product decision for Kam, not a test gap.

### Known non-failing warnings

- pandas `Series.dt.dayofyear` deprecation at `ml/features.py:298`
  (pinned pandas 3.1.1 still works).
- sklearn "fitted without feature names" warnings from
  HistGradientBoosting classifiers (cosmetic).

## Frontend verification (browser probes, not unit tests)

There is no frontend unit-test suite. Verification is done with
Playwright against the live dev server (Chromium cached at
`~/.cache/ms-playwright/chromium-1255/`). Scripts live in
`backend/ml/` (they are probes, not product code):

- `probe_all_pages.py` — all 12 routes render, none blank, zero
  failed API requests, UNKNOWN 0 on every page (run 2026-11-24
  against the v3.3 demo config).
- `probe_interactions.py` — runs the simulator in the UI (1 POST to
  `/api/simulate`, risk index shown), downloads the forecast CSV
  (24 rows, Source column, 6 model + 18 demo) and the historical CSV
  (92 rows after the date-range fix, Source column
  `era5-archive`).
- `probe_integrity_labels.py` — the 2026-11-24 integrity check's
  regression probe: Forecast for Cuttack and Puri (grid-cell note
  visible, MODEL badges present, badge tooltips name the grid cell),
  Flood Intelligence for Cuttack (disclaimer names the cell), Overview
  and Map (cell note present), Data Sources (all four kind chips,
  history card `Archive` never `Live`, "Live observation feeds" = 0).
  **6/6 checks passed** (2026-11-24, demo config). Screenshots in
  `~/workspace/integrity-screenshots/`. Note: Playwright's
  `inner_text()` applies CSS text-transform, so chips and summary
  labels read UPPERCASE there — the probe compares lower-cased, and
  checks the Archive badge as rendered ("ARCHIVE").
- `probe_google_weather.py` — two phases, no live Google call.
  **Phase A** (mocked Google success via `ml/mock_google_server.py`,
  backend on :8009): Forecast page shows the Google Weather section
  with 24 GOOGLE WEATHER rows, the Google CSV exports 24
  `google_weather` rows, the Data Sources card shows Live + a
  last-retrieval time, and the RAINWATCH table still shows 6 MODEL +
  18 DEMO. **Phase B** (real backend, no key): the page shows
  "Google Weather unavailable — key not configured", no fake Live
  anywhere, forecast still 6 MODEL + 18 DEMO. **PASS both phases**
  (2026-11-25). Screenshots in `~/workspace/google-probe-screenshots/`.
- `probe_forecast_merged.py` — two phases, no live Google call.
  **Phase A** (mocked Google success via `ml/mock_google_server.py`,
  backend on :8009, fixture anchored to the current UTC hour): the
  Forecast page's main table shows 6 MODEL + 18 GOOGLE WEATHER for
  Old Town, 24 GOOGLE WEATHER for Brahmapur, 6 MODEL + 18 GOOGLE
  WEATHER for Cuttack, with zero visible DEMO badges anywhere on the
  page; the main CSV has the new columns (Rainfall value, Value kind,
  Source) with 6 `model_rate_mm_hr` + 18 `google_qpf_mm` rows; mean
  confidence on the page (84%) equals the API's model-only mean; the
  separate Google comparison section is still present. **Phase B**
  (real backend on :8001, no key): Old Town shows 6 MODEL + 18
  UNAVAILABLE, zero visible DEMO badges, the Google-status line
  explains the UNAVAILABLE rows, and the CSV marks unavailable rows
  with empty values. Zero console errors in both phases. **PASS
  both phases** (2026-11-25). Screenshots in
  `~/workspace/merged-probe-screenshots/`.
- Ad-hoc DOM checks — chart sizes, badge text, health-dot title,
  CSV contents (see `KNOWN_LIMITATIONS.md` for the two chart bugs
  these caught).

Rules for probes: wait ~10 s after load before screenshotting
(Recharts mount animation); serve the frontend from `:5173` only
(backend CORS allow-list); expect OpenStreetMap tile loads to fail in
this sandbox (`ERR_TUNNEL_CONNECTION_FAILED` on tile fetches is
environmental, not an app bug — map overlays still render).

## Reliability measurements (2026-11-24)

| Check | Result |
|---|---|
| Cold start, fresh uvicorn → first `loaded:true` health | **10.3 s** |
| Warm latency p50 (20 runs each) | health 1 ms, forecast 2 ms, risk/all 18 ms, overview 4–5 ms, history/daily 9 ms |
| RSS | v3 169 MB, v3.3 185 MB (long-running); 312 MB right after cold start |
| CORS preflight | `:5173` → 200 with `Access-Control-Allow-Origin`; `:5174` → 400 (blocked); actual GET from `:5174` gets no ACAO header |
| Missing-CSV fallback (`BHUBANESWAR_CSV=/nonexistent.csv`) | health `dataset.loaded=false`, model still loads; `/api/history/daily` returns demo rows |
| Model input anchor | most recent archive timestamp `2025-12-31T23:00:00Z`; current output ~0 mm, tier "low" (dry December evening — correct, not a bug) |

## What is NOT tested

- No frontend unit tests (React Testing Library / Vitest). The
  resolver `src/utils/source.ts` was verified with a 9-case standalone
  node run (2026-11-24, Stage 5) plus the compiled-probe cases in
  `test_provenance.py` (2026-11-25), not a test runner.
- No end-to-end test that drives the demo config from a cold start
  (the probes assume servers are already running).
- No CI, no git repository — there is nothing to run tests on push.
- The reserved 2026 evaluation period (Jan–Nov, 7,771 rows) is never
  used by any test; do not add tests that read it.
