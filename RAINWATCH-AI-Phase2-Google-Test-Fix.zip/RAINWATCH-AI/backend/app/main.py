"""RAINWATCH AI — backend API (FastAPI).

Serves the React/TypeScript frontend in ``../hackathon``. Every route
mirrors one ``demoApi`` method in ``hackathon/src/services/dataService.ts``
so the frontend's types and pages work unchanged.

Data honesty:
- Historical endpoints use the REAL Open-Meteo ERA5 archive
  (``data/processed/bhubaneswar_weather.csv``, hourly 2021–2025) for
  Bhubaneswar-region locations.
- Ganjam / Brahmapur locations use the demo generator for history
  (their archive fetch was rate-limited by Open-Meteo).
- Forecast: hours 1-6 come from the trained ensemble model
  (``rainfall-xgb-v3``, spatial-thermodynamic ensemble: XGBoost +
  LightGBM + HistGradientBoosting, mean regressors + heavy-event
  classifiers + P90 quantile regressors, Bhubaneswar region only);
  hours 7+ use the deterministic demo engine. Each forecast point
  carries ``source`` and, for model points, a ``model`` object with
  expected_mm, upper_bound_p90_mm, heavy_rain_probability and
  heavy_risk_tier.
- Flood risk: a susceptibility index (not a validated prediction).
  Rainfall for offsets 0/3/6 h comes from the XGBoost model
  (Bhubaneswar region); the rest uses the demo series. Each record
  carries ``source``. ``inundationDepthM`` / ``areaInundatedHa`` are
  illustrative, derived from the index — not modelled depths.
- Weather / map / simulator values come from the deterministic demo
  engine — labelled DEMO in the UI, never presented as operational
  predictions.

Run:  uvicorn app.main:app --reload --port 8000
Docs:  http://localhost:8000/docs
"""

import os
import sys
from typing import Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

# Allow running as `uvicorn app.main:app` from backend/ and as a module.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.core import config  # noqa: E402
from app.engine import alerts as alerts_engine  # noqa: E402
from app.engine import datasources as datasources_engine  # noqa: E402
from app.engine import demo_state  # noqa: E402
from app.engine import history as history_engine  # noqa: E402
from app.engine import locations as locations_engine  # noqa: E402
from app.engine import maps as maps_engine  # noqa: E402
from app.engine import rainfall as rainfall_engine  # noqa: E402
from app.engine import risk as risk_engine  # noqa: E402
from app.engine import simulator as simulator_engine  # noqa: E402
from app.engine import weather as weather_engine  # noqa: E402
from app.model_service import get_model_status  # noqa: E402
from app.schemas import (  # noqa: E402
    SatelliteRainfallResponse,
    SatelliteRegionResponse,
    SatelliteStatusResponse,
    SimulatorInputs,
)

app = FastAPI(
    title="RAINWATCH AI API",
    description=(
        "Backend for the RAINWATCH AI flood early-warning dashboard. "
        "Historical data: Open-Meteo ERA5 archive 2021–2025 (Bhubaneswar). "
        "Forecast hours 1-6: trained ensemble model (rainfall-xgb-v3, spatial-thermodynamic: "
        "XGBoost + LightGBM + HistGradientBoosting, mean regressors + heavy-event classifiers + P90 quantile regressors, Bhubaneswar region). "
        "Forecast hours 7+, weather, map, simulator: deterministic demo engine (labelled DEMO). "
        "Flood risk is a susceptibility index, not a validated prediction."
    ),
    version="1.3.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=config.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(HTTPException)
async def _http_exception_handler(request, exc: HTTPException):
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.detail},
    )


def _require_location(location_id: str) -> None:
    if not locations_engine.is_known_location(location_id):
        raise HTTPException(status_code=404, detail=f"Unknown location: {location_id}")


# ------------------------------------------------------------------
# Health / meta
# ------------------------------------------------------------------

@app.get("/api/health")
def health():
    real = history_engine._load_real_daily()
    return {
        "status": "ok",
        "version": "1.3.0",
        "demoTick": demo_state.get_demo_tick(),
        "dataset": {
            "name": "Open-Meteo ERA5 archive (Bhubaneswar)",
            "range": "2021-01-01 to 2025-12-31",
            "records": 43824,
            "loaded": bool(real),
            "note": "ERA5 reanalysis, not station measurements. "
                    "Ganjam region uses the demo generator (archive fetch rate-limited).",
        },
        "model": get_model_status(),
    }


# ------------------------------------------------------------------
# Locations
# ------------------------------------------------------------------

@app.get("/api/locations")
def list_locations():
    return locations_engine.LOCATIONS


# ------------------------------------------------------------------
# Weather
# ------------------------------------------------------------------

@app.get("/api/weather")
def fetch_weather(
    locationId: str = Query(...),
    hours: int = Query(24, ge=1, le=72),
):
    _require_location(locationId)
    return weather_engine.get_weather_history(locationId, hours)


@app.get("/api/weather/current")
def fetch_current_weather(locationId: str = Query(...)):
    _require_location(locationId)
    return weather_engine.get_current_weather(locationId)


@app.get("/api/weather/google")
def fetch_google_weather(
    locationId: str = Query(...),
    hours: int = Query(24),
):
    """Google Weather API hourly forecast — independent external source.

    Returns Google's forecast for the location's coordinates with
    ``source: "google_weather"`` on every point. It never touches the
    RAINWATCH forecast endpoint and never returns model values.
    No key configured -> 503. Google error / timeout / quota -> 502.
    """
    _require_location(locationId)
    if hours not in FORECAST_HOURS:
        raise HTTPException(
            status_code=400,
            detail=f"hours must be one of {list(FORECAST_HOURS)}",
        )
    try:
        # Lazy import: a missing key or a Google outage must never
        # break the rest of the API at import time.
        from app.services import google_weather as google_service
    except Exception as exc:  # noqa: BLE001 - service must never break the API
        raise HTTPException(
            status_code=502,
            detail=f"Google Weather service unavailable: {exc}",
        )
    try:
        return google_service.get_google_forecast(locationId, hours)
    except google_service.GoogleWeatherNotConfigured as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except google_service.GoogleWeatherError as exc:
        raise HTTPException(status_code=502, detail=exc.reason)


# ------------------------------------------------------------------
# Forecast
# ------------------------------------------------------------------

FORECAST_HOURS = (3, 6, 12, 24, 48, 72)


@app.get("/api/forecast")
def fetch_forecast(
    locationId: str = Query(...),
    hours: int = Query(24),
):
    _require_location(locationId)
    if hours not in FORECAST_HOURS:
        raise HTTPException(
            status_code=400,
            detail=f"hours must be one of {list(FORECAST_HOURS)}",
        )
    return rainfall_engine.get_forecast(locationId, hours)


@app.get("/api/forecast/merged")
def fetch_merged_forecast(
    locationId: str = Query(...),
    hours: int = Query(24),
):
    """Merged forecast — source priority MODEL > GOOGLE WEATHER > UNAVAILABLE.

    The Forecast page's primary series. Model hours (1-6, Bhubaneswar
    region) are the trained ensemble, byte-identical to /api/forecast.
    Every other hour is a genuine Google Weather forecast where Google
    can provide one, else UNAVAILABLE. Synthetic demo values are never
    returned here. /api/forecast keeps its model+demo behaviour for
    every other consumer (simulator, risk, overview, map).
    Always 200 for a valid location+hours; 404 unknown location,
    400 bad hours. A Google failure degrades to UNAVAILABLE rows —
    it never fails this endpoint and never breaks the model path.
    """
    _require_location(locationId)
    if hours not in FORECAST_HOURS:
        raise HTTPException(
            status_code=400,
            detail=f"hours must be one of {list(FORECAST_HOURS)}",
        )
    from app.engine import merged_forecast as merged_engine

    return merged_engine.get_merged_forecast(locationId, hours)


@app.get("/api/forecast/intensity")
def fetch_intensity_distribution(
    locationId: str = Query(...),
    hours: int = Query(24),
):
    _require_location(locationId)
    if hours not in FORECAST_HOURS:
        raise HTTPException(
            status_code=400,
            detail=f"hours must be one of {list(FORECAST_HOURS)}",
        )
    return rainfall_engine.get_intensity_distribution(locationId, hours)


# ------------------------------------------------------------------
# Flood risk
# ------------------------------------------------------------------

@app.get("/api/risk/records")
def fetch_risk_records(
    locationId: str = Query(None),
    level: str = Query(None),
    horizonH: int = Query(72),
):
    if locationId:
        _require_location(locationId)
    if horizonH not in (6, 24, 72):
        raise HTTPException(status_code=400, detail="horizonH must be one of 6, 24, 72")
    if level and level not in ("Low", "Moderate", "High", "Very High", "Critical"):
        raise HTTPException(status_code=400, detail=f"Unknown risk level: {level}")
    return risk_engine.get_filtered_risk_records(
        location_id=locationId, level=level, horizon_h=horizonH
    )


@app.get("/api/risk/summary")
def fetch_risk_summary(horizonH: int = Query(24)):
    if horizonH not in (6, 24, 72):
        raise HTTPException(status_code=400, detail="horizonH must be one of 6, 24, 72")
    return {
        "overallIndex": risk_engine.get_overall_risk_index(horizonH),
        "distribution": risk_engine.get_risk_distribution(horizonH),
        "worst": risk_engine.get_vulnerable_zones(55),
        "vulnerable": risk_engine.get_vulnerable_zones(60),
    }


@app.get("/api/risk/all")
def fetch_all_risk_records():
    return risk_engine.get_all_risk_records()


# ------------------------------------------------------------------
# Alerts
# ------------------------------------------------------------------

@app.get("/api/alerts")
def fetch_alerts():
    return alerts_engine.get_alerts()


@app.get("/api/alerts/upcoming")
def fetch_upcoming_alerts(limit: int = Query(5, ge=1, le=20)):
    return alerts_engine.get_upcoming_alerts(limit)


# ------------------------------------------------------------------
# Historical analysis (real Open-Meteo data where available)
# ------------------------------------------------------------------

@app.get("/api/history/daily")
def fetch_daily_history(
    locationId: str = Query(...),
    days: int = Query(120, ge=1, le=1825),
):
    _require_location(locationId)
    return history_engine.get_daily_history(locationId, days)


@app.get("/api/history/monthly")
def fetch_monthly_history(locationId: str = Query(...)):
    _require_location(locationId)
    return history_engine.get_monthly_history(locationId)


@app.get("/api/history/annual")
def fetch_annual_history():
    return history_engine.get_annual_history()


@app.get("/api/history/peaks")
def fetch_peak_events(
    locationId: str = Query(None),
    limit: int = Query(8, ge=1, le=50),
):
    if locationId:
        _require_location(locationId)
    return history_engine.get_peak_events(location_id=locationId, limit=limit)


@app.get("/api/history/comparison")
def fetch_location_comparison(days: int = Query(90, ge=1, le=365)):
    return history_engine.get_location_comparison(days)


# ------------------------------------------------------------------
# Map layers & region conditions
# ------------------------------------------------------------------

@app.get("/api/map/layers")
def fetch_map_layers():
    return maps_engine.get_map_layers()


@app.get("/api/map/regions")
def fetch_region_conditions():
    return maps_engine.get_region_conditions()


# ------------------------------------------------------------------
# Data sources / pipeline
# ------------------------------------------------------------------

@app.get("/api/data-sources")
def fetch_data_sources():
    return datasources_engine.get_data_sources()


# ------------------------------------------------------------------
# Satellite rainfall (NASA GPM IMERG, Phase 2)
# ------------------------------------------------------------------
#
# Observed satellite rainfall — observations, never forecasts. Values
# are read from real IMERG Early Run granules by the Phase 1 service
# (app/services/satellite_rainfall.py); nothing is fabricated, and a
# cell with no usable value is reported MISSING/INVALID with null
# numerics, never zero-filled. Satellite values never enter the
# forecast, merged forecast, risk, or Data Sources computations.


def _satellite_service():
    """Lazy import of the satellite service (mirrors the Google endpoint).

    A missing service module or its dependencies must never break the
    rest of the API at import time.
    """
    try:
        from app.services import satellite_rainfall as satellite_service
    except Exception as exc:  # noqa: BLE001 - service must never break the API
        raise HTTPException(
            status_code=502,
            detail=f"Satellite service unavailable: {exc}",
        )
    return satellite_service


def _satellite_coverage_note(region_id: str, body: dict) -> str:
    """Honest coverage note for a region response, computed from the data.

    Compares the locations actually returned against every RAINWATCH
    location whose region is ``region_id``. The Bhubaneswar region
    bounding box excludes Cuttack and Puri, so region=bhubaneswar
    returns 12 of its 14 locations; Ganjam is complete at 7/7.
    """
    region_locations = [
        loc for loc in locations_engine.LOCATIONS
        if locations_engine.region_of(loc)["id"] == region_id
    ]
    total = len(region_locations)
    returned_coords = {
        (loc["location"]["latitude"], loc["location"]["longitude"])
        for loc in body["locations"]
    }
    missing = [
        loc["name"] for loc in region_locations
        if (float(loc["lat"]), float(loc["lng"])) not in returned_coords
    ]
    display = region_id.capitalize()
    if not missing:
        return f"All {total} {display} locations are inside the region bounding box."
    if len(missing) == 1:
        names = missing[0]
    elif len(missing) == 2:
        names = f"{missing[0]} and {missing[1]}"
    else:
        names = ", ".join(missing[:-1]) + f" and {missing[-1]}"
    return (f"{display} region returns {len(body['locations'])} of {total} "
            f"locations; {names} lie outside the region bounding box.")


@app.get("/api/satellite/status", response_model=SatelliteStatusResponse)
def fetch_satellite_status():
    """Satellite service status — always 200, even when not configured.

    "Not Configured" is a state to report, not a failure of this
    endpoint. "Ready" means credentials are present with no known
    failure; it does not claim a granule was ever retrieved.
    """
    service = _satellite_service()
    return service.get_satellite_status()


@app.get("/api/satellite/rainfall", response_model=SatelliteRainfallResponse)
def fetch_satellite_rainfall(
    latitude: float = Query(..., ge=-90, le=90),
    longitude: float = Query(..., ge=-180, le=180),
    observationTime: Optional[str] = Query(None),
):
    """Observed satellite rainfall for one latitude/longitude.

    An observation from the latest IMERG Early Run granule (or the
    granule whose interval contains ``observationTime`` when given) —
    never a forecast. Success is 200 including MISSING and INVALID
    statuses: the observation succeeded, the cell simply has no usable
    value, so the status field carries that. No key configured -> 503.
    NASA / search / download / extraction failure -> 502. Bad
    observationTime -> 400. Out-of-range coordinates -> 422.
    """
    service = _satellite_service()
    try:
        return service.get_rainfall_for_location(latitude, longitude, observationTime)
    except service.SatelliteNotConfigured as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except service.SatelliteError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/api/satellite/rainfall/region", response_model=SatelliteRegionResponse)
def fetch_satellite_region_rainfall(region: str = Query(...)):
    """Observed satellite rainfall for every RAINWATCH location in a region.

    ``region`` is a region id only ("bhubaneswar" / "ganjam"); one
    granule download is shared across the region's locations. This is
    an observation, never a forecast. Limitation, stated in the
    response's coverageNote as well: the Bhubaneswar region bounding
    box excludes Cuttack and Puri, so region=bhubaneswar returns 12 of
    its 14 locations; Ganjam is complete at 7/7. Unknown region -> 400.
    No key configured -> 503. NASA / service failure -> 502.
    """
    service = _satellite_service()
    try:
        body = service.get_rainfall_for_region(region)
    except service.SatelliteNotConfigured as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except service.SatelliteError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    body["coverageNote"] = _satellite_coverage_note(body["region"]["id"], body)
    return body


# ------------------------------------------------------------------
# Overview bundle
# ------------------------------------------------------------------

@app.get("/api/overview")
def fetch_overview(
    locationId: str = Query(...),
    alertCount: int = Query(0, ge=0),
):
    _require_location(locationId)
    return simulator_engine.get_overview(locationId, alertCount)


# ------------------------------------------------------------------
# What-if simulator
# ------------------------------------------------------------------

@app.post("/api/simulate")
def run_simulation(inputs: SimulatorInputs):
    _require_location(inputs.locationId)
    return simulator_engine.run_simulation(inputs.model_dump())


# ------------------------------------------------------------------
# Demo refresh (bumps the demo tick so every series regenerates)
# ------------------------------------------------------------------

@app.post("/api/demo/refresh")
def refresh_demo_data():
    return {"tick": demo_state.bump_demo_tick()}
