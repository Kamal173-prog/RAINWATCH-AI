import type { ReactNode } from 'react'
import { Card } from './Card'
import { InfoTip } from './InfoTip'
import { Skeleton, StatePanel } from './Skeleton'

export function ChartCard({
  title,
  subtitle,
  actions,
  icon,
  tooltip,
  height = 260,
  loading = false,
  empty = false,
  emptyMessage = 'No data available for the selected filters.',
  children,
  delay = 0,
  className = '',
  footer,
}: {
  title: ReactNode
  subtitle?: ReactNode
  actions?: ReactNode
  icon?: ReactNode
  tooltip?: string
  height?: number
  loading?: boolean
  empty?: boolean
  emptyMessage?: string
  children: ReactNode
  delay?: number
  className?: string
  footer?: ReactNode
}) {
  return (
    <Card delay={delay} className={`flex min-w-0 flex-col ${className}`}>
      <div className="mb-3 flex flex-wrap items-start justify-between gap-3 border-b border-line pb-3">
        <div className="flex min-w-0 items-start gap-3">
          {icon ? (
            <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center border border-line bg-surface text-accent">
              {icon}
            </span>
          ) : null}
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <h3 className="truncate text-sm font-semibold text-ink">{title}</h3>
              {tooltip ? <InfoTip text={tooltip} /> : null}
            </div>
            {subtitle ? <p className="mono mt-1 text-[10px] text-muted">{subtitle}</p> : null}
          </div>
        </div>
        {actions ? <div className="flex shrink-0 flex-wrap items-center gap-2">{actions}</div> : null}
      </div>

      <div className="min-w-0 flex-1" style={{ minHeight: height }}>
        {loading ? (
          <div className="flex flex-col gap-3 pt-2" aria-hidden>
            <Skeleton className="h-4 w-40" />
            <Skeleton className="w-full rounded-none" />
            <div className="flex gap-2">
              <Skeleton className="h-3 w-14" />
              <Skeleton className="h-3 w-14" />
              <Skeleton className="h-3 w-14" />
            </div>
          </div>
        ) : empty ? (
          <StatePanel title="No data" message={emptyMessage} className="h-full" />
        ) : (
          children
        )}
      </div>
      {footer ? <div className="mono mt-3 border-t border-line pt-3 text-[10px] text-muted">{footer}</div> : null}
    </Card>
  )
}
