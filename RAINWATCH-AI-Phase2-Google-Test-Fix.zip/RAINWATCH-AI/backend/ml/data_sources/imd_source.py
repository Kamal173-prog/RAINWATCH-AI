"""IMD AWS / ARG station observations (v3.2, Source B).

Access: **institutional approval required.** The India Meteorological
Department publishes an API catalogue at
https://api.imd.gov.in/public/api_reference.html and a self-service
portal at https://api.imd.gov.in/public/register.php, but access to
station data requires **IP whitelisting by IMD** (see
https://mausam.imd.gov.in/responsive/apis.php). Government registrants
must use a gov.in / nic.in address. There is no public keyless API that
returns the complete historical hourly AWS/ARG archive for 2021–2025.

Candidate stations (to verify once access exists — these are requested
locations, not confirmed station IDs):
- Bhubaneswar, Cuttack, Puri, Paradip, Khordha, Gopalpur.

This connector implements the structure: station registry, the API
client shape, and the access check. It does NOT fabricate station data.
``fetch`` returns [] with a clear blocker message until IMD grants
access. Ground observations, when obtained, are preserved as a separate
independent evaluation dataset (never merged into the training features
without a leakage review — station rainfall is an observation, not a
forecast, and its availability lag must be recorded).

Data portal for manual requests: https://dsp.imdpune.gov.in/
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from .base_source import BaseDataSource

log = logging.getLogger(__name__)

API_BASE = "https://api.imd.gov.in/api/v1/"
REGISTER_URL = "https://api.imd.gov.in/public/register.php"
DATA_PORTAL = "https://dsp.imdpune.gov.in/"

# Candidate stations — coordinates are the city locations; the actual
# IMD station ID and exact coordinates must be verified against the IMD
# station list once access is granted. Do not treat these as confirmed.
CANDIDATE_STATIONS = {
    "bhubaneswar": {"lat": 20.2961, "lon": 85.8245, "station_id": None},
    "cuttack": {"lat": 20.4625, "lon": 85.8830, "station_id": None},
    "puri": {"lat": 19.8135, "lon": 85.8312, "station_id": None},
    "paradip": {"lat": 20.3167, "lon": 86.6167, "station_id": None},
    "khordha": {"lat": 20.1833, "lon": 85.6167, "station_id": None},
    "gopalpur": {"lat": 19.2667, "lon": 84.9167, "station_id": None},
}


class IMDStationSource(BaseDataSource):
    """IMD AWS / ARG station observations."""

    SOURCE_NAME = "imd_stations"
    PRODUCT_NAME = "IMD AWS/ARG hourly observations"
    PRODUCT_VERSION = "IMD API v1"
    AVAILABILITY_LAG = "PT1H"
    LICENSE = "IMD — attribution required; terms per IMD data policy"
    ACCESS_RESTRICTIONS = (
        "IMD API access requires registration AND IP whitelisting by "
        "IMD (see https://mausam.imd.gov.in/responsive/apis.php). "
        "Historical hourly AWS archive is not publicly available via a "
        "keyless API. Manual data requests: https://dsp.imdpune.gov.in/"
    )

    def __init__(self, backend_dir: Path | None = None):
        super().__init__(backend_dir)
        self.stations = CANDIDATE_STATIONS

    def check_access(self) -> tuple[bool, str]:
        api_key = self.env_or_none("IMD_API_KEY")
        if not api_key:
            return False, (
                "IMD API access not configured. Register at "
                "https://api.imd.gov.in/public/register.php, request IP "
                "whitelisting from IMD, and set IMD_API_KEY. Historical "
                "hourly AWS data is not available via a public keyless API."
            )
        return True, "IMD_API_KEY present (IP whitelist not yet verified)"

    def fetch(
        self,
        start: str,
        end: str,
        bbox: Optional[tuple[float, float, float, float]] = None,
    ) -> list[Path]:
        ok, msg = self.check_access()
        if not ok:
            log.error("IMD station fetch blocked: %s", msg)
            return []
        raise NotImplementedError(
            "IMD station fetch is not implemented: the API endpoint "
            "shape and station IDs must be confirmed against the live "
            "IMD API reference once IP whitelisting is granted. "
            "Do not fabricate station observations."
        )

    def process(self, raw_files: list[Path]) -> Path:
        raise NotImplementedError(
            "IMD station processing is not implemented: no station data "
            "has been obtained. Implement once the first station file is "
            "available and its schema is inspected."
        )
