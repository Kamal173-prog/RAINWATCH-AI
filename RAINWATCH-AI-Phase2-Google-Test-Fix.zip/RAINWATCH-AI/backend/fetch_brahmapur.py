"""Fetch the Brahmapur / Ganjam Open-Meteo archive (same 2021-2025 hourly
variables as Bhubaneswar) and save it as ``data/brahmapur_weather.csv``.

Why a separate script: Open-Meteo rate-limited the second request
(HTTP 429) right after the Bhubaneswar download succeeded, so this was
not fetched during the build. Run it later — once the rate limit has
cleared (usually minutes) — then restart the backend and the Ganjam
locations will use real historical data too.

Usage:
    python fetch_brahmapur.py
"""

import csv
import json
import os
import urllib.request

URL = (
    "https://archive-api.open-meteo.com/v1/archive"
    "?latitude=19.3098&longitude=84.7972"
    "&start_date=2021-01-01&end_date=2025-12-31"
    "&hourly=temperature_2m,relative_humidity_2m,precipitation,"
    "wind_speed_10m,pressure_msl,cloud_cover"
    "&timezone=Asia%2FKolkata"
)

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_CSV = os.path.join(HERE, "data", "processed", "brahmapur_weather.csv")
OUT_JSON = os.path.join(HERE, "data", "raw", "brahmapur_weather_raw.json")


def main():
    req = urllib.request.Request(
        URL,
        headers={"User-Agent": "RAINWATCH-AI-Hackathon/1.0 (student project)"},
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            data = json.load(resp)
    except urllib.error.HTTPError as e:
        print(f"Open-Meteo returned HTTP {e.code}. Rate-limited — try again later.")
        raise SystemExit(1)

    hourly = data["hourly"]
    n = len(hourly["time"])
    print(f"records: {n} | {hourly['time'][0]} → {hourly['time'][-1]}")
    print(f"grid lat/lng: {data['latitude']}, {data['longitude']}")

    with open(OUT_JSON, "w") as f:
        json.dump(data, f)

    with open(OUT_CSV, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["timestamp", "temperature_c", "humidity_pct", "precipitation_mm",
                    "wind_speed_kmh", "pressure_hpa", "cloud_cover_pct"])
        for i in range(n):
            w.writerow([
                hourly["time"][i],
                hourly["temperature_2m"][i],
                hourly["relative_humidity_2m"][i],
                hourly["precipitation"][i],
                hourly["wind_speed_10m"][i],
                hourly["pressure_msl"][i],
                hourly["cloud_cover"][i],
            ])
    print(f"saved {OUT_CSV}")
    print("Restart the backend — Ganjam locations will now use real history.")


if __name__ == "__main__":
    main()
