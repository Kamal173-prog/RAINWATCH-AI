"""Tests for GET /api/health.

Covers: response shape, API version, dataset block (real ERA5 archive),
model status block (loaded, version, scope, horizons). The health
endpoint triggers the lazy model load on first call, so these tests also
exercise the load path.
"""

from conftest import VERSION_V3, set_model_version


def test_health_ok(v3_client):
    r = v3_client.get("/api/health")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "ok"
    assert body["version"] == "1.3.0"
    assert isinstance(body["demoTick"], int)


def test_health_dataset_block(v3_client):
    body = v3_client.get("/api/health").json()
    ds = body["dataset"]
    assert ds["name"] == "Open-Meteo ERA5 archive (Bhubaneswar)"
    assert ds["range"] == "2021-01-01 to 2025-12-31"
    assert ds["records"] == 43824
    assert ds["loaded"] is True
    assert "reanalysis" in ds["note"]
    assert "Ganjam" in ds["note"]


def test_health_model_block_v3(v3_client):
    body = v3_client.get("/api/health").json()
    model = body["model"]
    assert model["loaded"] is True
    assert model["model_version"] == VERSION_V3
    assert model["model"] == "xgboost+lightgbm+histgradientboosting"
    assert model["horizons_h"] == [1, 3, 6]
    # model_input_as_of must be strict ISO 8601 with a T separator
    # (a space-separated value was returned before the 2026-11-24 fix).
    from datetime import datetime
    ts = datetime.fromisoformat(
        model["model_input_as_of"].replace("Z", "+00:00"))
    assert ts.isoformat().startswith("2025-12-31T23:00:00")
    # Scope must state the Bhubaneswar-only limit, never state-wide.
    assert "Bhubaneswar grid cell only" in model["scope"]
    assert "not state-wide" in model["scope"]
    assert model["heavy_risk_tier"] in ("low", "moderate", "elevated", "high")


def test_health_model_note_states_demo_fallback(v3_client):
    body = v3_client.get("/api/health").json()
    note = body["model"]["note"]
    assert "hours 1-6" in note
    assert "Ganjam" in note
    assert "demo engine" in note


def test_health_is_stable_across_calls(v3_client):
    first = v3_client.get("/api/health").json()
    second = v3_client.get("/api/health").json()
    assert first == second
