"""Final acceptance: API prediction-workflow verification (read-only)."""
import json
import urllib.request


def get(port, path):
    with urllib.request.urlopen(f"http://127.0.0.1:{port}{path}", timeout=30) as r:
        return json.load(r)


def src_of(p):
    return p.get("source") or (p.get("metadata") or {}).get("source", "?")


def ver_of(p):
    return p.get("model_version") or (p.get("metadata") or {}).get("model_version")


# 1. Forecast old-town (Bhubaneswar region) on demo :8001
f = get(8001, "/api/forecast?locationId=old-town&hours=24")
pts = f if isinstance(f, list) else f.get("points", f.get("forecast", []))
srcs = {}
for p in pts:
    srcs[src_of(p)] = srcs.get(src_of(p), 0) + 1
print("forecast old-town :8001 points:", len(pts), "sources:", srcs)
model_pts = [p for p in pts if src_of(p) == "model"]
print("  model points:", len(model_pts))
if model_pts:
    print("  model_version on points:", sorted({ver_of(p) for p in model_pts}))
    print("  sample model point:", json.dumps(model_pts[0], default=str)[:400])
    print("  sample demo point:", json.dumps([p for p in pts if src_of(p) == "demo"][0], default=str)[:300])

# 2. Brahmapur all demo
fb = get(8001, "/api/forecast?locationId=brahmapur&hours=24")
pb = fb if isinstance(fb, list) else fb.get("points", fb.get("forecast", []))
sb = {}
for p in pb:
    sb[src_of(p)] = sb.get(src_of(p), 0) + 1
print("forecast brahmapur :8001 points:", len(pb), "sources:", sb)

# 3. Cuttack/Puri vs old-town model identity
def model_sig(pts_):
    return [(p.get("timestamp"), p.get("rainfallMmHr"), p.get("expected_mm")) for p in pts_ if src_of(p) == "model"]

base = model_sig(pts)
for loc in ("cuttack", "puri"):
    fl = get(8001, f"/api/forecast?locationId={loc}&hours=24")
    pl = fl if isinstance(fl, list) else fl.get("points", fl.get("forecast", []))
    ml = model_sig(pl)
    print(f"forecast {loc}: model points {len(ml)}, identical to old-town MODEL points: {ml == base}")

# 4. Risk records old-town
r = get(8001, "/api/risk/records?locationId=old-town&horizonH=72")
recs = r if isinstance(r, list) else r.get("records", r)
rs = {}
for x in recs:
    rs[src_of(x)] = rs.get(src_of(x), 0) + 1
print("risk/records old-town:", len(recs), "sources:", rs)
if recs:
    print("  sample risk record:", json.dumps(recs[0], default=str)[:400])

# 5. risk/all totals
ra = get(8001, "/api/risk/all")
allr = ra if isinstance(ra, list) else ra.get("records", ra)
ars = {}
for x in allr:
    ars[src_of(x)] = ars.get(src_of(x), 0) + 1
print("risk/all:", len(allr), "sources:", ars)

# 6. Data sources
ds = get(8001, "/api/data-sources")
print("data-sources:")
for s in ds["sources"]:
    print(f"  {s['id']:10s} kind={s['kind']:22s} status={s['status']}")

# 7. Production :8000 forecast (v3) - model_version check
f0 = get(8000, "/api/forecast?locationId=old-town&hours=24")
p0 = f0 if isinstance(f0, list) else f0.get("points", f0.get("forecast", []))
m0 = [p for p in p0 if src_of(p) == "model"]
print("forecast old-town :8000 (prod) model points:", len(m0), "| versions:", sorted({ver_of(p) for p in m0}))

# 8. Health payload model_input_as_of (ISO check; nested under model)
h = get(8001, "/api/health")
print("health :8001 model_input_as_of:", h["model"].get("model_input_as_of"))
print("health :8001 version:", h.get("version"), "| model:", h["model"]["model_version"])
h0 = get(8000, "/api/health")
print("health :8000 model_input_as_of:", h0["model"].get("model_input_as_of"))

# 9. Overview + map + history + alerts sanity
ov = get(8001, "/api/overview?locationId=old-town")
print("overview keys:", sorted(ov.keys())[:12])
mp = get(8001, "/api/map/layers")
print("map/layers keys:", sorted(mp.keys()) if isinstance(mp, dict) else f"list[{len(mp)}]")
hi = get(8001, "/api/history/daily?locationId=old-town")
print("history/daily rows:", len(hi) if isinstance(hi, list) else hi.keys())
al = get(8001, "/api/alerts/upcoming?limit=20")
print("alerts/upcoming:", len(al) if isinstance(al, list) else al.keys())
