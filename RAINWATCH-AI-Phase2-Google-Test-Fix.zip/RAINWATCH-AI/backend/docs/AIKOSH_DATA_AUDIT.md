# AIKosh and Government-Hosted Rainfall Datasets — Audit for RAINWATCH AI

**Date:** 2026-11-24
**Scope:** AIKosh (IndiaAI) + other government sources for rainfall observations usable
by RAINWATCH AI. No production, frontend, model, threshold or deployment changes
were made. Nothing in this audit touches the reserved 2026 evaluation period.

## 1. Bottom line

| Question | Answer |
|---|---|
| Does the reported **Odisha hourly telemetry rainfall dataset (2021–2025)** exist on AIKosh? | **Not found.** No hourly, telemetry, rain-gauge or AWS/ARG dataset covering Odisha 2021–2025 appears on AIKosh, data.gov.in listings, or the IMD open API. **Do not assume it exists or is accessible.** |
| Is there an "IMD Rainfall" dataset on AIKosh? | Not under that exact name (phrase search: 0 results). AIKosh hosts monthly **"Daily Rainfall data of [month year] from IMD (IMD GRID MODEL)"** files (2021 Jan–Dec, 2022 Jan–Sep) plus NRSC VIC-model equivalents — but **downloading them requires an AIKosh account** (sign-in gate verified 2026-11-24). |
| Best acquirable independent validation data right now | **IMD 0.25° daily gridded rainfall, 1901–2025** — downloaded, audited, and ready in `backend/data/research/`. Gauge-interpolated, so it is a legitimate independent check of daily totals. |
| Can it validate 3 h / 6 h labels? | **No.** Daily resolution cannot resolve 3 h or 6 h accumulations. Do not disaggregate daily totals into hourly labels. |
| Does it cover the reserved 2026 period? | **No — the file ends 2025-12-31.** It cannot validate 2026. (An earlier suggestion that it "includes 2026" was wrong.) |
| Hourly station data — any real lead? | **IMD AWS/ARG station data via `api.imd.gov.in`** (`/api/v1/aws_data`, Odisha state ID 10). Requires a free API key; historical depth unverified. This is the only live lead for genuine hourly station telemetry. |

**Recommendation:** use the IMD daily grid for independent **daily** validation of
v3/v3.2/v3.3 (daily aggregates only), following the validation design in §6.
For hourly ground truth, obtain an IMD API key and test the AWS/ARG endpoint's
historical depth — or register a free NASA Earthdata account for GPM IMERG
(satellite, 30-minute, the best hourly candidate identified in the v3.2 audit).
Do not pursue AIKosh further for rainfall until/unless an account is created:
its rainfall holdings are monthly slices of the same IMD grid product, behind
a sign-in gate.

## 2. What AIKosh actually holds (verified on the portal, 2026-11-24)

Portal: https://aikosh.indiaai.gov.in/home/datasets/all (16,263 items total).
Detail pages are viewable without sign-in; **clicking Download redirects to
https://aikosh.indiaai.gov.in/account/login** (Email OTP, Jan Parichay,
Meri Pehchaan, or Govt Parichay). Search is slow — results take ~5–10 s to
settle; an early "No Record(s) Found!" is a placeholder, not a result.

| Search term | Settled results |
|---|---|
| `rainfall` | 142 items |
| `IMD Rainfall` | **0** |
| `rain gauge` | **0** |
| `Odisha rainfall` | **0** |
| `telemetry` | 9 items, none rainfall |
| `hourly` | 97 items — IITM surface variables 2000–2018 only (see below) |
| `Bhubaneswar` | 5 items, none rainfall |
| `Cuttack` | 88 items, none rainfall |
| `Odisha` | 3,006 items (not paged through in full; first page is health/irrigation/JalJeevan) |

### 2.1 Monthly IMD GRID / NRSC VIC daily rainfall files

- Titles: "Daily Rainfall data of [month year] from India Meteorological
  Department (IMD GRID MODEL) Agency" and the matching "(NRSC VIC MODEL) Agency".
- Coverage found: 2021 Jan–Dec; 2022 Jan–Sep (Aug–Sep 2022 only in the NRSC VIC
  version in the pages scanned). All-India, daily, one month per file.
- Detail page opened (April 2021, IMD GRID):
  https://aikosh.indiaai.gov.in/home/datasets/details/daily_rainfall_data_from_india_meteorological_department_imd_grid_model_agency_during_april_2021.html
- Publisher: IndiaAI (uploaded by Sumit Kumar Jha). Licence: Open Government
  License, India. Visibility: Open. Downloads 29, views 154.
- Description (as shown): "Daily district-level rainfall data from IMD grid
  model and station-wise data from CWC, Gujarat WRD, and APWRIMS for April 2021",
  plus daily normal rainfall up to district level from IMD climatology.
- **Not stated on the page:** file format, station count, variable names,
  units (no "mm" stated), timestamp/timezone. Files & Versions showed no file
  list in the view seen. The "station-wise" claim in the description could not
  be verified without downloading (gated).
- Verdict: same underlying IMD grid product as §3, sliced monthly, with
  unverified station-wise extras, behind a sign-in gate. **Redundant for
  validation; only worth pursuing if the station-wise CWC component is needed
  and an account is created.**

### 2.2 District At a Glance 2025 — Odisha

- https://aikosh.indiaai.gov.in/home/datasets/details/district_at_a_glance_2025_odisha.html
- Author: Directorate of Economics and Statistics, Govt. of Odisha. Licence:
  Open Government License, India. Visibility: Open. File size 23.41 KB.
- 30 districts × 16 sectors, rainfall included — but rainfall reference year
  is **2023, annual only**. Not rainfall-only, not daily/hourly, not usable
  for model validation. Not downloaded.

### 2.3 IITM Surface Precipitation Rate (2000–2018)

- https://aikosh.indiaai.gov.in/home/datasets/details/surface_precipitation_rate_over_india_for_2000.html
- 3-hourly **forecasts** from the GFS T1534 model (~0.125°), archived by IITM
  Pune; units kg/m²/s; years 2000–2018 only. Access via THREDDS OPeNDAP
  (e.g. https://ardc.tropmet.res.in/thredds/dodsC/data/v10/gdas_2000_india_v10.nc.html).
- Verdict: model forecasts, not observations; ends 2018. **Not usable** for
  2021–2025 validation.

### 2.4 Cumulative rainfall (district-wise, by state and year)

- Arunachal Pradesh and Assam files (2020–2025) exist; **no Odisha cumulative
  rainfall title appeared** in the 142-item rainfall list. Weekly cumulative,
  district-wise, CSV (e.g. 27.49 KB for Arunachal 2024). Not relevant.

### 2.5 What was NOT searched exhaustively

Puri, Paradip, Brahmapur, Ganjam and Sambalpur were not individually searched
on AIKosh, and the 3,006-item "Odisha" list was not paged through in full.
Absence for those five names is established only within the 142-item
"rainfall" inventory, which contained none of them. The single-word `rainfall`
and `hourly` inventories are the stronger evidence for the headline verdicts.

## 3. IMD 0.25° daily gridded rainfall — downloaded and audited

### 3.1 Provenance

| Field | Value |
|---|---|
| Product | IMD daily gridded rainfall, 0.25° × 0.25°, Pai et al. (2014), MAUSAM 65(1), pp. 1–18 |
| File | `backend/data/research/raw/IMD_RF25_1901_2025_merged.nc` |
| Downloaded from | https://huggingface.co/datasets/parthawrk/as-dataset/resolve/main/Data/IMD/IMD_RF25_1901_2025_merged.nc |
| Repo | https://huggingface.co/datasets/parthawrk/as-dataset (public, not gated, CC BY 4.0; IMD acknowledgement requested) |
| Official product page | https://www.imdpune.gov.in/cmpg/Griddata/Rainfall_25_NetCDF.html (1901–2024, yearly NetCDF; the mirror extends to 2025) |
| Downloaded | 2026-11-24; size 365,296,737 bytes (matches the Hugging Face API listing) |
| SHA-256 | `d102d52e3edc7c8adeaf0fa4d4e63a2b4000a3a43c7be14bddf25d392ae564c5` |
| Format | NetCDF4 (HDF5), variable `RAINFALL`, units **mm** |
| Grid | 129 lat (6.5–38.5°N) × 135 lon (66.5–100°E), 0.25° steps |
| Time | 1901-01-01 to **2025-12-31**, 45,656 days, strictly daily, **no gaps, 0 duplicate timestamps** |
| Nature | Gauge-interpolated (Shepard) from IMD's rain-gauge network — a mirror of the same product also cites ~6,955 gauges (secondary source, not independently verified) |

Full manifest: `backend/data/research/SOURCES.md`.
Audit script: `backend/data/research/audit_imd_daily.py` (run with the separate
`backend/.venv-audit`; the production venv was not modified).
Processed artefacts: `processed/odisha_imd_daily_2021_2025.csv`,
`processed/odisha_imd_daily_2021_2025.nc` (Odisha bbox 17.75–22.75°N, 81.5–87.5°E),
`audit_imd_daily_summary.json`.

### 3.2 Quality audit — all-India window, 2021–2025

- 31,799,790 values; **22,735,605 NaN (71.5%)** — expected: the grid covers
  ocean and non-Indian land, which the land-only product leaves missing.
- **0 sentinel −999 values** in this mirror file (missing is encoded as NaN;
  the official binary product uses −999.0 — do not test for −999 in this file).
- **0 negative values.** Min 0.0 mm, max **979.1 mm/day** (all-India).
  278 values > 300 mm/day, 34 > 500 mm/day across five years of all-India data
  — plausible for extreme orographic events; no value is physically impossible.
- 68.9% of valid values are exactly 0.0 mm (dry days dominate, as expected).

### 3.3 Quality audit — six Odisha target cells, 2021–2025 (1,826 days each)

| Location | IMD grid cell | Dist. | Missing | Max daily (date) | Annual totals 2021–2025 (mm) | Days ≥10 mm | Days ≥50 mm | Longest dry spell |
|---|---|---|---|---|---|---|---|---|
| Bhubaneswar | 20.25°N, 85.75°E | 9.8 km | 0 | **337.0 mm (2021-09-13)** | 2415 / 1683 / 1541 / 1885 / 1521 | 264 | 33 | 98 d |
| Cuttack | 20.50°N, 86.00°E | 13.7 km | 0 | 168.1 mm (2021-09-13) | 1786 / 1559 / 1234 / 1609 / 1512 | 248 | 18 | 153 d |
| Puri | **nearest (19.75°N, 85.75°E) is ocean — 100% missing for all 125 years**; nearest land cell 20.00°N, 85.75°E used instead | 22.6 km | 0 (land cell) | 333.5 mm (2021-09-13) | 1541 / 1271 / 1065 / 1293 / 1387 | — | — | — |
| Paradip | 20.25°N, 86.50°E | 14.5 km | 0 | 214.7 mm (2021-09-13) | 2433 / 1530 / 1107 / 1388 / 1307 | 214 | 25 | 98 d |
| Brahmapur | 19.25°N, 84.75°E | 8.5 km | 0 | 129.3 mm (2021-11-13) | 1404 / 1190 / 1052 / 983 / 1141 | 155 | 28 | 94 d |
| Sambalpur | 21.50°N, 84.00°E | 4.7 km | 0 | 137.5 mm (2023-08-02) | 1162 / 1452 / 1788 / 1230 / 1554 | 216 | 25 | 148 d |

Notes:
- **Puri is the gap:** the IMD land grid has no data at the coastal cell
  nearest Puri. The substitute land cell 22.6 km inland is complete but is not
  Puri — any Puri validation must carry that caveat, or use station data.
- The 2021-09-13 maximum is shared by Bhubaneswar, Cuttack, Paradip and the
  Puri land cell — a coherent multi-cell extreme event, which is a good sign
  for the product's spatial consistency (not a single-cell artefact).
- Brahmapur/Ganjam is the driest of the six (annual mean ~1,154 mm), matching
  the known drier south-Odisha climatology.
- No station IDs, station coordinates, or relocation history exist in a
  gridded product — there is no station map to draw. Station identity is
  available only via the IMD API (§4.3) or the gated AIKosh monthly files (§2.1).

### 3.4 Consistency cross-check: IMD vs ERA5, Bhubaneswar daily, 2021–2025

- Pearson r = **0.498**; ERA5-minus-IMD mean bias **−0.2 mm/day**;
  IMD annual mean 1,809 mm vs ERA5 1,736 mm.
- This is a **consistency check, not validation**: ERA5 is reanalysis and the
  model was trained on ERA5-derived labels, so ERA5–model agreement partly
  measures self-consistency. The moderate daily correlation is expected —
  ERA5 smooths extremes (its Bhubaneswar daily totals never approach IMD's
  337 mm day) and the two products sit on different grids.

## 4. Other government sources checked

### 4.1 data.gov.in (OGD Platform India) — partially verified

- District-wise and sub-basin-wise **daily average rainfall, 2018–2025**,
  and subdivision monthly normals/actuals since 1901, exist as MoES resources
  (mirrored at https://dataful.in/collections/2310/; e.g. district dataset
  https://dataful.in/datasets/24558/).
- The district dataset's own description says values are "derived from
  hydrometeorological modeling and gridded observation systems (NRSC VIC Model
  and IMD Grid Model)" — **model + grid derived, not raw gauge readings**.
- Exact data.gov.in resource IDs/URLs and file sizes were **not retrieved**;
  API access requires a free API key. A Hugging Face derivative
  (judicialmind/BharatWater-Data, district daily parquet, 702 districts,
  2018-01-01 to 2026-05-04) is **gated** and CC BY-NC-SA 4.0.
- Verdict: secondary candidate only. Daily district averages add little over
  the IMD grid already downloaded, and they are not station observations.

### 4.2 Official IMD gridded pages — verified, partially

- https://www.imdpune.gov.in/cmpg/Griddata/Rainfall_25_NetCDF.html (fetched
  2026-11-24): 1901–2024, yearly NetCDF, 135 × 129 grid, mm, daily, missing
  −999.0, citation Pai et al. (2014). Page is publicly readable; **whether the
  per-year download links work with zero login was not directly verified**
  (no downloads attempted), and secondary sources say the newer
  mausam.imd.gov.in portal requires registration for gridded data. The HF
  mirror (§3) is the practical route and is already in hand.
- https://rcc.imdpune.gov.in/download.php — merged satellite (GPM) + gauge
  0.25° daily rainfall (real-time) and IMDAA downloads. Not pursued further;
  the GPM-merged product is a candidate for later satellite comparison.

### 4.3 IMD open API (`api.imd.gov.in`) — verified to need a key

- Reference: https://api.imd.gov.in/public/api_reference.html lists
  `/api/v1/districtrainfall` (district-wise rainfall) and
  `/api/v1/aws_data` (AWS/ARG station data; **Odisha state ID "10"**).
- Live probes 2026-11-24 (no key): both return `{"error":"API key missing"}`.
- **Historical depth is unverified** — the endpoints appear to serve
  current/recent values only. Verdict: the only live lead for genuine hourly
  station telemetry. Needs a free API key (Kam action) and a depth test.

### 4.4 IMDAA hourly reanalysis — verified, not independent

- `parthawrk/as-dataset`, `Data/IMDAA/RFT2m_Full/IMDAA_Merged/APCP-sfc/`:
  one file per year, 1979–2020, ~1.05–1.16 GB each. 12 km regional reanalysis,
  hourly, t2m + rainfall.
- Verdict: **reanalysis, not observations — not independent ground truth**
  for an ERA5-trained model. Cross-check only; not downloaded.

### 4.5 OSDMA / DoWR / OWMS — noted, not pursued

- OSDMA "Rainfall Climatology of Odisha (1993–2024)" (Oct 2025) notes the WINDS
  project (~400 AWS + ~6,600 ARG planned for Odisha) — future station source,
  not a downloadable dataset.
- DoWR Odisha publishes daily basin-rainfall PDFs; OWMS publishes district
  daily totals. Both are daily aggregates in non-machine-readable form with no
  hourly product found. Not pursued.

## 5. Suitability assessment

| Use case | Verdict |
|---|---|
| Independent validation of **daily** totals (v3 / v3.2 / v3.3 daily aggregates) | **Yes — strong.** Gauge-interpolated, independent of ERA5. 5 of 6 cells complete for 2021–2025; Puri via the 22.6 km land cell with a caveat. |
| Validation of **3 h / 6 h labels** (the model's actual targets) | **No.** Daily resolution cannot resolve 3 h or 6 h accumulations. Disaggregating daily totals into hourly labels would fabricate data. |
| Training targets | Daily targets only. A daily model is a different model, not the hourly forecaster. Do not mix daily targets into the hourly pipeline. |
| Geographic expansion (multi-location training) | **Partial.** Land cells only; coastal cells (Puri, Paradip) are offset inland; no station-level data. Pooling across the six cells is possible at daily resolution. |
| Satellite / gauge comparison | The IMD grid **is** the gauge reference (interpolated). Comparing it against GPM IMERG satellite estimates is a legitimate future step — IMERG needs a free Earthdata account. |
| Statewide accuracy claims | **Do not claim.** Six grid cells (one of them a 22.6 km substitute) do not support statewide accuracy. |
| 2026 validation | **Impossible from this file** — it ends 2025-12-31. The reserved 2026 period stays reserved; no IMD data can validate it until the 2026 release appears. |

## 6. Validation design (for when daily validation is run)

1. **Station-to-grid matching:** nearest land cell per target (§3.3 table);
   record grid distance in every result. Puri: use (20.0°N, 85.75°E) and label
   it as the substitute, 22.6 km inland.
2. **Time alignment — unresolved, must be confirmed first:** the file carries
   no timezone or day-boundary attribute. The IMD gridded product's documented
   convention is a 24 h accumulation ending 08:30 IST (03:00 UTC), but this was
   **not verified from the file** — confirm from Pai et al. (2014) or the
   imdpune page before aggregating model/ERA5 hours into daily labels.
   Do not assume a midnight-UTC or midnight-IST boundary.
3. **Independent holdouts:** hold out whole years (e.g. 2025) or whole cells
   (e.g. Sambalpur). Never random row splits — daily rain is autocorrelated.
4. **Metrics:** daily MAE/RMSE; Brier and PR-AUC for daily ≥ 10 mm and
   ≥ 50 mm events; reliability of the model's daily-aggregated probabilities;
   95% CIs via block bootstrap by monsoon season.
5. **Leakage prevention:** the model was trained on ERA5-derived labels, so
   IMD daily data is an independent *source* — but a validation is only honest
   if thresholds and model choices were not tuned on the same IMD years being
   scored. Score the frozen models as-is; **do not tune on IMD and then claim
   IMD validates the tuning. Do not touch reserved 2026.**
6. **Why ERA5 is not independent ground truth:** ERA5 is a reanalysis — a
   model that assimilates observations. A model trained on ERA5-derived labels
   and scored against ERA5 is partly scored against itself. IMD gauge data is
   independent because it comes from rain gauges through a different pipeline,
   not from the ERA5 assimilation system. (Both describe the same atmosphere,
   so correlation is expected; the test is whether the model beats ERA5's own
   agreement with IMD.)

## 7. What still needs Kam

- **AIKosh account** (Email OTP is the simplest route) — only if the monthly
  IMD GRID files' station-wise CWC component (§2.1) is wanted. Not needed for
  the daily validation already enabled by §3.
- **IMD API key** (free, api.imd.gov.in) — to test whether the AWS/ARG
  endpoint serves historical hourly station data for Odisha. The one real lead
  for hourly ground truth.
- **data.gov.in API key** (free) — only if district daily averages are wanted
  as a secondary check. Low priority.
- **NASA Earthdata account** (free) — for GPM IMERG, the best hourly satellite
  candidate for 3 h / 6 h-scale comparison. Already identified in the v3.2 audit.

## 8. Limitations and unverified items

- The reported Odisha hourly telemetry 2021–2025 dataset was not found on
  AIKosh, data.gov.in listings, or the IMD API. It may exist under a different
  name or on a portal not checked (e.g. MOSDAC/INSAT, IMD AWS portal) — but
  nothing in this audit supports assuming it exists.
- AIKosh: five city names (Puri, Paradip, Brahmapur, Ganjam, Sambalpur) were
  not individually searched and the 3,006-item "Odisha" list was not fully
  paged; absence is established within the rainfall/hourly inventories.
- AIKosh download gate: verified (sign-in required). File formats, units,
  station counts and timezones of the AIKosh monthly files are unverified.
- data.gov.in exact resource IDs/URLs not retrieved; IMD API historical depth
  not tested (needs a key).
- IMD daily file: day-boundary/timezone convention unverified from the file;
  gauge count (~6,955) is a secondary-source figure.
- No station coordinates exist in the gridded product; no station map was drawn.
