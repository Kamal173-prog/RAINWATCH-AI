"""CLI: inspect a RAINWATCH AI dataset (v3.2).

Usage:
    python scripts/inspect_datasets.py --source ifs --model ecmwf_ifs025
    python scripts/inspect_datasets.py --file data/processed/ifs/ecmwf_ifs025_processed.csv

Prints: row count, time range, columns, missing-data %, and the QC
summary. Never fabricates data — it only reads what is on disk.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd


def inspect_file(path: Path) -> None:
    print(f"=== {path} ===")
    if path.suffix == ".json":
        with open(path) as f:
            data = json.load(f)
        hourly = data.get("hourly", {})
        print(f"keys: {list(data.keys())}")
        print(f"hourly keys: {list(hourly.keys())}")
        times = hourly.get("time", [])
        print(f"rows: {len(times)}")
        if times:
            print(f"range: {times[0]} .. {times[-1]}")
        for k, v in hourly.items():
            if isinstance(v, list):
                nn = sum(1 for x in v if x is not None)
                print(f"  {k}: n={len(v)} non-null={nn}")
        return
    df = pd.read_csv(path, parse_dates=["timestamp"] if "timestamp" in pd.read_csv(path, nrows=0).columns else None)
    print(f"rows: {len(df)}, columns: {len(df.columns)}")
    print(f"columns: {list(df.columns)}")
    if "timestamp" in df.columns:
        ts = pd.to_datetime(df["timestamp"], utc=True)
        print(f"range: {ts.min()} .. {ts.max()}")
        expected = pd.date_range(ts.min(), ts.max(), freq="h", tz="UTC")
        print(f"expected hourly rows: {len(expected)}, missing: {len(expected) - len(df)}")
    print(f"missing % (overall): {df.isna().mean().mean() * 100:.2f}%")
    for c in df.columns:
        if c == "timestamp":
            continue
        miss = df[c].isna().mean() * 100
        if miss > 0:
            print(f"  {c}: missing {miss:.1f}%")


def main() -> None:
    ap = argparse.ArgumentParser(description="Inspect a RAINWATCH AI dataset")
    ap.add_argument("--file", type=str, help="Path to a processed CSV or raw JSON file")
    ap.add_argument("--source", type=str, help="Source name (e.g. ifs)")
    args = ap.parse_args()
    if args.file:
        inspect_file(Path(args.file))
        return
    if args.source:
        base = Path(__file__).resolve().parent.parent / "data" / "processed" / args.source
        files = sorted(base.glob("*.csv"))
        if not files:
            print(f"no processed files in {base}")
            return
        for f in files:
            inspect_file(f)
        return
    ap.print_help()


if __name__ == "__main__":
    main()
