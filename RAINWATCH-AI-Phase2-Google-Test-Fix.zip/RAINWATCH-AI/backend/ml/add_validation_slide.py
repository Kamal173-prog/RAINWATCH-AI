"""Add the IMD validation slide to the HACK-KALP deck (Wanda_Maximoff).

Inserts as slide 5 (number 04), renumbers References 04 -> 05.
Matches the deck tokens: bg F9F4E8, navy 14204C, teal 00A896, body 1D2738,
Calibri throughout. Run: .venv-audit/bin/python backend/ml/add_validation_slide.py
"""
import shutil

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt

DECK = "/home/hatch/workspace/user/files/Wanda_Maximoff_RAINWATCH_AI_HackKalp.pptx"
BACKUP = ("/home/hatch/workspace/goals/hack-kalp-2026-entry/hidden_files/"
          "Wanda_Maximoff_RAINWATCH_AI_HackKalp.backup-20261124.pptx")
CHART = "/home/hatch/workspace/backend/docs/imd_validation/scatter_daily_2025_wide.png"

NAVY = RGBColor(0x14, 0x20, 0x4C)
TEAL = RGBColor(0x00, 0xA8, 0x96)
BODY = RGBColor(0x1D, 0x27, 0x38)
CREAM = RGBColor(0xF9, 0xF4, 0xE8)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
GREY = RGBColor(0x66, 0x66, 0x66)
PAGENUM = RGBColor(0xD8, 0xD8, 0xD8)


def tb(slide, x, y, w, h, text, size, bold=False, color=BODY, align=PP_ALIGN.LEFT):
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = box.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = MSO_ANCHOR.TOP
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    lines = text.split("\n")
    for i, line in enumerate(lines):
        para = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        para.alignment = align
        para.line_spacing = 1.05
        run = para.add_run()
        run.text = line
        run.font.name = "Calibri"
        run.font.size = Pt(size)
        run.font.bold = bold
        run.font.color.rgb = color
    return box


def main():
    shutil.copy(DECK, BACKUP)
    prs = Presentation(DECK)
    assert len(prs.slides) == 5, f"expected 5 slides, found {len(prs.slides)}"
    blank = next(l for l in prs.slide_layouts if l.name == "BLANK")
    slide = prs.slides.add_slide(blank)
    # Move the new slide to index 4 (5th position, before References).
    sldIdLst = prs.slides._sldIdLst
    sldId = sldIdLst[-1]
    sldIdLst.remove(sldId)
    sldIdLst.insert(4, sldId)

    slide.background.fill.solid()
    slide.background.fill.fore_color.rgb = CREAM

    tb(slide, 17.25, 0.30, 2.45, 0.40, "Wanda_Maximoff", 18, True, NAVY)
    tb(slide, 4.67, 0.38, 11.5, 1.15, "IMD VALIDATION", 66, True, NAVY)
    tb(slide, 19.0, 10.82, 1.4, 0.40, "04", 18, False, PAGENUM)
    tb(slide, 1.42, 1.42, 17.58, 0.35,
       "VALIDATED AGAINST INDEPENDENT IMD DAILY GRIDDED RAINFALL — BHUBANESWAR, 2025",
       18, True, TEAL)

    findings = [
        (1.7, "1 · IT TRACKS REAL RAIN",
         "Daily totals vs independent IMD daily gridded rainfall, Bhubaneswar "
         "2025 (n = 365 days): correlation r = 0.58, MAE 4.09 mm — beats "
         "persistence (r = 0.37) and matches raw ERA5 (r = 0.54). "
         "P90 envelope covered 94% of days."),
        (7.5, "2 · ALERTS FIRE, AMOUNTS DON'T",
         "Watch alerts flagged all 9 observed days ≥ 50 mm across 2024–2025 — "
         "including 3 Jun 2024 (101.5 mm), which the amount forecast scored "
         "at just 5.5 mm. Early-warning signal, not an amount forecast; "
         "no lead-time claim."),
        (13.3, "3 · LIMITS, MEASURED",
         "Amount forecast never exceeded 30.8 mm in a day; monsoon totals ran "
         "~22% high; validation is Bhubaneswar-only. Every other location in "
         "the demo is labelled DEMO / synthetic — never presented as "
         "v3.3 predictions."),
    ]
    for x, head, body in findings:
        tb(slide, x, 2.00, 5.0, 0.62, head, 20, True, NAVY)
        tb(slide, x, 2.72, 5.0, 2.80, body, 17, False, BODY)

    # Metrics table (left) + scatter chart (right).
    tb(slide, 1.42, 5.85, 7.6, 0.30, "DAILY TOTALS, BHUBANESWAR 2025", 16, True, NAVY)
    rows = [
        ("Metric", "Model", "ERA5", "Persistence"),
        ("Daily MAE (mm)", "4.09", "4.00", "4.52"),
        ("Correlation r", "0.58", "0.54", "0.37"),
        ("Wet-day F1 (≥ 10 mm)", "0.53", "—", "—"),
        ("Watch: ≥ 50 mm days caught", "9 of 9 *", "—", "—"),
    ]
    table_shape = slide.shapes.add_table(
        len(rows), 4, Inches(1.42), Inches(6.20), Inches(7.6), Inches(2.10))
    table = table_shape.table
    widths = [3.0, 1.5, 1.5, 1.6]
    for j, w in enumerate(widths):
        table.columns[j].width = Inches(w)
    for i, row in enumerate(rows):
        table.rows[i].height = Inches(0.42)
        for j, val in enumerate(row):
            cell = table.cell(i, j)
            cell.margin_left = Inches(0.08)
            cell.margin_right = Inches(0.08)
            cell.margin_top = Inches(0.02)
            cell.margin_bottom = Inches(0.02)
            cell.vertical_anchor = MSO_ANCHOR.MIDDLE
            cell.fill.solid()
            cell.fill.fore_color.rgb = NAVY if i == 0 else WHITE
            tf = cell.text_frame
            tf.word_wrap = True
            para = tf.paragraphs[0]
            para.alignment = PP_ALIGN.LEFT if j == 0 else PP_ALIGN.CENTER
            run = para.add_run()
            run.text = val
            run.font.name = "Calibri"
            run.font.size = Pt(15)
            run.font.bold = (i == 0) or (j == 0)
            run.font.color.rgb = WHITE if i == 0 else BODY
    tb(slide, 1.42, 8.42, 7.6, 0.30, "* 2024–2025 combined; 2 of 2 in 2025.",
       13, False, GREY)
    slide.shapes.add_picture(CHART, Inches(9.60), Inches(5.85), width=Inches(8.98))

    tb(slide, 1.42, 10.15, 17.16, 0.50,
       "Source: IMD 0.25° daily gridded rainfall (Pai et al. 2014) — independent of ERA5. "
       "Bhubaneswar only; daily totals, not 3 h / 6 h accuracy. "
       "Amount forecasts compress extremes (max 30.8 mm/day in 2025).",
       13, False, GREY)

    # Renumber the References slide 04 -> 05.
    ref = prs.slides[5]
    changed = 0
    for shape in ref.shapes:
        if shape.has_text_frame and shape.text_frame.text.strip() == "04":
            for para in shape.text_frame.paragraphs:
                for run in para.runs:
                    if run.text == "04":
                        run.text = "05"
                        changed += 1
    assert changed >= 1, "references page number not found"
    prs.save(DECK)
    print(f"saved: {len(prs.slides)} slides; references renumbered ({changed} run)")
    print(f"backup: {BACKUP}")


if __name__ == "__main__":
    main()
