# IMD Daily Validation — RAINWATCH AI

**Date:** 2026-11-24
**Reference data:** IMD 0.25° daily gridded rainfall, 1901–2025 (Pai et al. 2014),
`backend/data/research/raw/IMD_RF25_1901_2025_merged.nc`
(SHA-256 `d102d52e…ae564c5`; audit: `backend/docs/AIKOSH_DATA_AUDIT.md`).
**Scripts:** `backend/ml/validate_imd_daily.py` (scoring, backend venv),
`backend/data/research/check_imd_alignment.py` (day-boundary check),
`backend/data/research/plot_imd_validation.py` (charts).
**Outputs:** `backend/data/research/processed/validate_imd_daily.csv` (731 daily rows),
`backend/docs/imd_validation/metrics.json`, charts in this directory.

## 1. Bottom line

The frozen models were scored against **independent IMD daily gridded
rainfall data they never saw in any form** — IMD 0.25° daily gridded rainfall
(Pai et al. 2014) at Bhubaneswar.
The model tracks real rain (daily-total correlation **r = 0.58** in the 2025
test year, MAE **4.09 mm**), beats a persistence baseline clearly, and matches
raw ERA5 — but it does **not** beat its own input data at daily scale, and its
amount forecast compresses extremes: it never forecast a daily total above
**30.8 mm** in 2025, so it cannot predict a ≥ 50 mm day by amount.
The **alert system is the stronger story**: every observed day ≥ 50 mm in
both years (9 of 9) raised a Watch in all three versions, and most raised a
Warning — including the 101.5 mm day of 3 Jun 2024, which the amount forecast
scored as 5.5 mm.

**Recommendation: include in the presentation as one validation slide**
("Validated against independent IMD daily gridded rainfall data"), with the slide-ready table
in §6 and the scatter chart. It strengthens credibility precisely because it
reports the misses too. Do **not** present daily numbers as the hourly 3 h/6 h
results, and do **not** claim statewide performance.

## 2. What was validated — and the scope decision

The frozen models (v3, v3.2, v3.3) predict at the **Bhubaneswar ERA5 grid
cell only** (lat 20.2812, lng 85.8434). There is no frozen-model prediction at
Cuttack, Paradip, Brahmapur, Sambalpur or Puri — the API serves synthetic demo
values there, and validating demo data against observations would be
meaningless. So:

- **Model-vs-IMD comparison: Bhubaneswar only** (all metrics in §4).
- **Other five locations: IMD observed context only** (§4.4) — annual totals,
  wet days, heavy days — showing real geographic variability (Sambalpur had 8
  heavy days in 2025 vs Bhubaneswar's 2), which is itself evidence that a
  Bhubaneswar-only model must not be presented as statewide.
- **Puri** uses the nearest land cell (20.0°N, 85.75°E), 22.6 km inland — a
  spatial approximation, not an exact match (its nearest cell is ocean and
  100% missing in the IMD grid).

A multi-location transfer test would be new research (new feature tables,
new upwind cells), not validation — out of scope before the finale.

## 3. Method

### 3.1 Dataset verification (Task 1)

- **Structure:** NetCDF4, variables TIME (45,656 days, 1901-01-01 → 2025-12-31,
  strictly daily, no gaps, 0 duplicate timestamps), LATITUDE 129 (6.5–38.5°N),
  LONGITUDE 135 (66.5–100°E), RAINFALL float32, **units mm**, 0.25° grid.
  No timezone attribute in the file.
- **Date convention — verified two ways.** Documentary: Pai et al. (2014) via
  two independent secondary sources — each daily value is the 24 h
  accumulation **ending 08:30 IST (03:00 UTC)** on the labelled date, i.e.
  the window [08:30 IST D−1, 08:30 IST D); the label is the gauge-reading
  date, not the date most rain fell. Empirical: correlating IMD daily totals
  with ERA5 hourly sums under every integer hour-shift of the day window
  (2021–2025, Bhubaneswar) peaks at a **10 h IST shift (r = 0.601**, flat top
  8–11 h, r 0.577–0.601), clearly above the IST-calendar-day alignment
  (r = 0.498) and the UTC-calendar-day alignment (r = 0.459). The documented
  08:30 IST boundary sits inside the empirical flat top; both midnight
  alignments are ruled out. (The peak at 10 h rather than 8.5 h is within
  noise — the 9 h vs 10 h difference is 0.006 — and is consistent with ERA5
  hourly values being hour-end labelled.)
- **Missing values:** the mirror file encodes missing as NaN (0 sentinel
  −999 values). All five target cells have **0 missing days in 2021–2025**;
  Puri's nearest cell is 100% missing for the full 125-year record (ocean).
  Zero negatives; max 979.1 mm/day all-India.
- **Construction:** the gridded product is interpolated from 6,955
  rain-gauge stations (Pai et al. 2014 abstract) — so this is a legitimate
  independent check, not station-level ground truth (see §8).

### 3.2 Daily forecast construction — no overlapping windows

Model tables are tz-naive **IST** wall-clock, matching the IMD window above.
For IMD day D, four **non-overlapping** 6 h forecasts are issued at
**09:00, 15:00, 21:00 IST on D−1 and 03:00 IST on D**. Each 6 h forecast
covers the 6 h after its issue time, so the four windows tile
[09:00 D−1, 09:00 D) IST — the true IMD window [08:30 D−1, 08:30 D) shifted
+30 min, because hourly tables cannot resolve 08:30 starts. This is a
documented approximation affecting at most one hourly value at each edge.

- **Daily total** = sum of the four 6 h regression predictions. The regressors
  are **shared across v3/v3.2/v3.3** (v3's `reg_6h`: XGBoost 0.5 + LightGBM
  0.5), so all three versions share one daily-total forecast — the daily
  totals cannot distinguish versions. Versions differ only in their
  classifiers.
- **Daily classifier signal** per version = max calibrated P(6 h ≥ 10 mm)
  over the same four issue times; 3 h signals use eight 3 h-spaced issues
  tiling the same window. "Any-fire" = the day's max probability clears the
  version's saved Watch (elevated) or Warning (high) threshold — i.e. the
  model raised an alert at least once during the day. v3.3 uses
  `thresholds_optimized.json`; v3/v3.2 use `thresholds.json`.

### 3.3 What F1 means here — two different classification decisions

A regression model has no F1 of its own. Every F1 in this report comes from
turning a forecast into a yes/no decision at a threshold, and the two F1
families below use **different decisions and different targets** — do not mix
them up.

- **F1 (regression daily total), §4.2.** The regression is thresholded at
  the same level T as the observation: **decision = forecast daily total
  ≥ T; target = observed IMD daily total ≥ T** (T = 10, 50, 100 mm).
  TP = days where both cross T; FP = forecast crosses but observed does not;
  FN = observed crosses but forecast does not. Precision = TP/(TP+FP),
  Recall = TP/(TP+FN), F1 = 2·P·R/(P+R). Example: at T = 50 mm the decision
  is exactly "did the predicted daily rainfall cross 50 mm" vs "did the
  observed daily rainfall cross 50 mm". (Code: `ml/validate_imd_daily.py`,
  `_prf` on `model_daily_mm >= thr` vs `imd_mm >= thr`.)
- **F1 (classifier any-fire), §4.3.** **Decision = the day's max calibrated
  P(6 h ≥ 10 mm) clears the version's saved Watch/Warning threshold** — i.e.
  the model raised an alert at least once during the day. **Target = observed
  IMD daily total ≥ 10 mm** (or ≥ 50 mm for the heavy-day rows). Note the
  asymmetry: the classifier's *native* event is a 6-hour accumulation
  ≥ 10 mm, but the evaluation target here is the *daily* total ≥ 10 mm —
  different events. This F1 measures "did an alert fire on a day that turned
  out wet", not "did the classifier predict its own 6 h event". The hourly
  PR-AUC/F1 numbers for the classifier's native events are in
  `MODEL_REPORT.md` §§11–13, not here.
- **Edge cases.** At T = 50 mm in 2025 the forecast never crossed the
  threshold (TP = 0, FP = 0, FN = 2): recall is 0 so F1 = 0.0, while
  precision is *undefined* (0/0) — the code records 0.0 by convention, not
  as a measured value. At T = 100 mm in 2025 there were no observed days at
  all, so F1 is undefined (shown as — in this report; `metrics.json` records
  a by-construction 0.0 placeholder for that row — do not quote it).
- **References:** ERA5 daily total summed over the same window (the input-data
  baseline — separates input error from model error) and persistence
  (yesterday's IMD total).
- **Years:** **2025 is primary** (365 days; test year for v3/v3.2, benchmark
  year for v3.3 — v3.3 was selected using 2025 PR-AUC, so its 2025 numbers
  carry a selection caveat). **2024 is supplementary** (366 days; validation
  year — weights, Platt and thresholds were fitted on 2024, so it is not
  independent). **2026 was never touched** (IMD file ends 2025-12-31; 2026 is
  reserved). Zero missing issue rows in either year.

## 4. Results — Bhubaneswar

### 4.1 Daily totals, 2025 (primary; n = 365)

Observed (IMD): total 1,521 mm, mean 4.17 mm/day, 56 days ≥ 10 mm,
2 days ≥ 50 mm, 0 days ≥ 100 mm, max **70.0 mm (30 Jul 2025)**.

| Forecast | MAE (mm) | RMSE (mm) | Bias (mm) | Pearson r | Spearman ρ | Wet-day MAE* |
|---|---|---|---|---|---|---|
| **Model daily total** (shared regressors) | **4.09** [3.02–5.32]† | 7.51 | +0.94 | 0.582 | 0.747 | 8.76 |
| ERA5 daily total (same window) | 4.00 | 8.32 | +0.51 | 0.543 | 0.787 | 9.63 |
| Persistence (yesterday's IMD) | 4.52 | 10.10 | 0.00 | 0.369 | 0.644 | 10.93 |

\* Wet day = observed ≥ 1 mm. † 95% CI, 7-day block bootstrap, 1,000 resamples.
Monsoon (JJAS) only: model MAE 8.47, r 0.390; ERA5 MAE 8.47, r 0.393 —
the monsoon is where most of the error lives.
**P90 envelope:** 94.0% of observed days fall inside the summed P90 upper
bound (mean P90 − observed = +6.9 mm) — the uncertainty envelope is honest
at daily scale.

Reading: the model beats persistence clearly and matches raw ERA5 on MAE,
with better RMSE and Pearson correlation — but it does **not** beat its own
input data on daily totals. At daily scale the model adds little over ERA5;
its value is in the hourly/heavy-event detection (§4.2–4.3), not in daily
amounts.

### 4.2 Events from the regression daily total, 2025

Decision and target (see §3.3): **forecast daily total ≥ T vs observed IMD
daily total ≥ T**, for T = 10, 50, 100 mm. This is a thresholded regression,
not a classifier — the "classification" is the threshold crossing.

| Threshold T | Precision | Recall | F1 | TP / FP / FN |
|---|---|---|---|---|
| ≥ 10 mm | 0.461 | 0.625 | **0.530** | 35 / 41 / 21 |
| ≥ 50 mm | 0.000* | 0.000 | **0.000** | 0 / 0 / 2 |
| ≥ 100 mm | — | — | — | no observed days in 2025 |

\* At ≥ 50 mm, precision is *undefined* (the forecast never crossed 50 mm,
so TP + FP = 0); F1 = 0.0 because recall is 0, not because precision was
measured as 0.

The model daily total **never reached 50 mm in 2025 (max forecast 30.8 mm)**,
so by amount it cannot detect a ≥ 50 mm day. This is regression compression
(ERA5 smoothing + mean regression), not a threshold problem. Monsoon totals
tell the other half of the story: IMD 1,116 mm vs model **1,367 mm (+22%)**
vs ERA5 1,244 mm (+11%) — the model over-forecasts monsoon totals while
under-forecasting the biggest single days. On dry days (226 observed in 2025)
it predicts exactly 0 mm only 13 times (mean +1.44 mm on dry days) — a small
drizzle bias.

### 4.3 Classifier daily signals, 2025

Decision and target (see §3.3): **decision = the day's max calibrated
P(6 h ≥ 10 mm) clears the version's saved Watch (elevated) or Warning (high)
threshold** — the model raised an alert at least once during the day.
**Target = observed IMD daily total ≥ 10 mm** (or ≥ 50 mm for the heavy-day
rows). The classifier's native event is 6 h ≥ 10 mm, not the daily total,
so this F1 measures alert-vs-wet-day agreement, not native-event accuracy.
Base rate for daily ≥ 10 mm is 56/365 = 0.153.

| Version | PR-AUC vs daily ≥ 10 mm | Watch any-fire (elevated) vs ≥ 10 mm | Warning any-fire (high) vs ≥ 10 mm |
|---|---|---|---|
| v3 | 0.402 | P 0.311 / R 0.929 / F1 0.466 | P 0.410 / R 0.446 / F1 0.427 |
| v3.2 | **0.488** | P 0.395 / R 0.875 / F1 **0.544** | P 0.404 / R 0.339 / F1 0.369 |
| v3.3 | 0.420 | P 0.385 / R 0.839 / F1 0.528 | P 0.373 / R 0.339 / F1 0.355 |

Watch fires on ~122–167 days a year (high recall, low precision — by design,
it is F2-tuned). At daily scale v3.2 leads on Watch F1, v3.3 is close behind,
v3 trails; the gaps are modest and the 2025 sample is small, so do not
over-claim version differences here.

**Heavy days (daily ≥ 50 mm, n = 2 in 2025):** every version's Watch caught
**both days** (recall 1.0, precision ~0.01–0.02 — the Watch fires often);
Warning caught 1 of 2 in each version. With n = 2 these are anecdotes, not
metrics — but the pattern repeats in 2024 (7 heavy days): Watch caught **7/7**
in all versions; Warning caught 4/7 (v3), 3/7 (v3.2), **6/7 (v3.3)**.

**Biggest days, what actually happened:**

| Date | IMD observed | Model daily total | ERA5 daily | Watch | Warning |
|---|---|---|---|---|---|
| 2024-06-03 | 101.5 mm | 5.5 mm | 21.7 mm | all three | v3.2, v3.3 |
| 2025-07-30 | 70.0 mm | 17.6 mm | 24.4 mm | all three | v3 |
| 2025-06-26 | 58.8 mm | 30.8 mm | 35.1 mm | all three | v3.2, v3.3 |

The amount forecast missed the biggest days badly — and the alert system
still fired. That is the honest early-warning story.

### 4.4 Supplementary year 2024 (validation year — not independent)

Model daily: MAE 5.32 (ERA5 5.18), RMSE 11.43 (ERA5 11.43), bias −0.26,
r 0.491 (ERA5 0.515). P90 coverage 0.926. Regression ≥ 10 mm F1 0.517;
≥ 50 mm F1 0.0 (0 TP, 1 FP, 7 FN — again, the amount forecast never reaches
50 mm). Classifier PR-AUC vs daily ≥ 10 mm: v3 0.483, v3.2 0.568,
v3.3 0.546. Watch F1: v3 0.466, v3.2 0.548, v3.3 0.554. Same patterns as
2025 — the conclusions do not depend on one year.

### 4.5 Per-location IMD observed context, 2025 (no model prediction here)

| Location | IMD cell | Annual total | Days ≥ 10 mm | Days ≥ 50 mm | Max day |
|---|---|---|---|---|---|
| Bhubaneswar | 20.25°N, 85.75°E (9.8 km) | 1,521 mm | 56 | 2 | 70.0 mm (30 Jul) |
| Cuttack | 20.50°N, 86.00°E (13.7 km) | 1,512 mm | 60 | 1 | 50.9 mm (29 Oct) |
| Paradip | 20.25°N, 86.50°E (14.5 km) | 1,307 mm | 41 | 3 | 62.7 mm (7 Oct) |
| Puri* | 20.00°N, 85.75°E (22.6 km inland) | 1,387 mm | 49 | 3 | 79.2 mm (15 Aug) |
| Brahmapur | 19.25°N, 84.75°E (8.5 km) | 1,141 mm | 36 | 2 | 64.5 mm (23 Mar) |
| Sambalpur | 21.50°N, 84.00°E (4.7 km) | 1,554 mm | 46 | **8** | 75.6 mm (6 Jul) |

\* Puri: nearest land cell, spatial approximation (see §2). All six cells
complete (0 missing days, 2021–2025). Sambalpur — 300 km inland, outside the
model's scope — had the most heavy days (8) in 2025. Geographic variability
is real; a Bhubaneswar-only model cannot be presented as statewide.

## 5. Charts

- `scatter_daily_2025.png` — observed vs forecast daily totals, 2025. The
  compression is visible: forecasts cap near 31 mm while observations reach
  70 mm; the wet bias on dry days is visible at observed = 0.
- `timeseries_daily_2025.png` — daily bars (IMD) vs model line, 2025; the two
  ≥ 50 mm days are marked.
- `locations_imd_2025.png` — annual totals and heavy days by cell (observed
  only).
- `events_daily_2025.png` — Watch/Warning F1 and recall vs daily ≥ 10 mm,
  per version.

## 6. Slide-ready table (Bhubaneswar, 2025 test year, n = 365 days)

| | Model | ERA5 (same window) | Persistence |
|---|---|---|---|
| Daily total MAE | 4.09 mm | 4.00 mm | 4.52 mm |
| Daily total correlation (r) | 0.58 | 0.54 | 0.37 |
| Wet-day detection F1 — forecast daily total ≥ 10 mm vs observed ≥ 10 mm | 0.53 | — | — |
| Watch (any-fire) caught wet days | 84–93% (v3.3–v3) | — | — |
| Watch caught heavy days (≥ 50 mm) | 2 of 2 | — | — |
| P90 envelope coverage | 94% | — | — |

Small print for the slide: *Validated against IMD 0.25° daily gridded
rainfall (Pai et al. 2014; gauge-interpolated product), an independent source the model never
trained on. Bhubaneswar only; daily totals, not 3 h/6 h accuracy. Amount
forecasts compress extremes (never forecast above 31 mm/day in 2025).*

## 7. Plain-language explanation (for judges)

> We checked our rainfall model against IMD's daily gridded rainfall
> product (0.25°, Pai et al. 2014), a completely independent source the model never trained on. Over the
> full year 2025 at Bhubaneswar, the model's daily rainfall totals were right
> to within about 4 mm on a typical day and moved in the same direction as
> the real rain about 58% of the time — clearly better than just guessing
> yesterday's rain, and as good as the raw satellite-era data it is built on.
> The honest limits: the model underestimates the biggest downpours (it never
> predicted a daily total above 31 mm, while the wettest real day was 70 mm),
> and it over-forecasts monsoon totals by about a fifth. But as an
> **early-warning system** it works: it raised a Watch alert on every single
> day that actually got 50 mm or more, in both 2025 and 2024 — including the
> 101 mm day in June 2024. So the right way to use it is as a warning signal,
> not as a precise rainfall-amount forecast — and right now it only covers
> Bhubaneswar, not the whole state.

## 8. Limitations — read before quoting any number

1. **Daily validation does not establish hourly, 3 h or 6 h accuracy.**
   The model's real targets are 3 h/6 h accumulations; this experiment only
   tests daily sums of 6 h forecasts. Hourly skill is a different claim and
   is evidenced by the 2025/2026 PR-AUC numbers, not by this experiment.
2. **IMD gridded rainfall is not station-level ground truth.** It is a
   0.25° interpolation of ~6,955 gauges (Pai et al. 2014). It smooths local
   extremes and sits ~10–14 km from each city (22.6 km for Puri's substitute
   cell). Agreement with IMD is agreement with an interpolation, not with a
   rain gauge at the location.
3. **2025 had only 2 days ≥ 50 mm** (2024: 7). Every ≥ 50 mm result here is
   small-sample evidence — the Watch's 9/9 record across two years is
   encouraging, not conclusive.
4. **2025 is not fully independent for v3.3** (it was the benchmark year in
   model selection). The 2024 supplementary year is not independent for any
   version. The independence here is in the *data source* (gridded IMD product vs ERA5),
   not in the time period.
5. **Day-boundary approximation:** the four 6 h windows tile
   [09:00 D−1, 09:00 D) IST, 30 minutes off the true IMD window
   [08:30 D−1, 08:30 D). Effect: at most one hourly value swapped at each
   edge of each day.
6. **Shared regressors:** daily-total results cannot distinguish v3, v3.2
   and v3.3. Only the classifier signals differ between versions.
7. **No statewide claim:** one grid cell (plus five observed-context cells)
   does not support statewide operational performance.

## 9. Three strongest judge-facing findings

1. **First validation against data the model never saw in any form.**
   IMD daily gridded totals are independent of ERA5; the model
   still tracks them (r = 0.58, MAE 4.09 mm, 2025 test year), beats
   persistence (r = 0.37), and its P90 uncertainty envelope covers 94% of
   observed days. This is the credibility anchor for the whole project.
2. **The alert system fires on the biggest days even when the amount
   forecast is far off.** Watch raised on 9/9 observed days ≥ 50 mm across
   2024–2025 in all three versions; Warning on most. The 101.5 mm day
   (3 Jun 2024) got a Warning from v3.2/v3.3 despite a 5.5 mm amount
   forecast. Early-warning signal, not amount forecast — and the numbers
   prove the distinction matters.
3. **The limits are measured, not hidden.** Amount forecasts cap near
   31 mm/day and cannot detect a ≥ 50 mm day by amount (F1 0.0 — recall 0,
   the amount forecast never crossed 50 mm); monsoon
   totals run +22% high; the model covers Bhubaneswar only while Sambalpur
   had 8 heavy days in 2025. Reporting this openly is itself a
   differentiator — most hackathon demos only show their best metric.

## 10. Reproducibility and production confirmation

- Reproduce: `.venv/bin/python ml/validate_imd_daily.py` (reads frozen
  artifacts + `data/research/processed/odisha_imd_daily_2021_2025.csv`;
  writes the daily frame and `metrics.json`). Charts:
  `.venv-audit/bin/python data/research/plot_imd_validation.py`. No model
  artifact, threshold, calibration, production file or frontend file was
  modified; no retraining; 2026 untouched.
- **Production confirmed on v3:** `/api/health` returned API 1.3.0 with
  `model_version: rainfall-xgb-v3` (verified live 2026-11-24; `.env` has no
  `MODEL_VERSION`). The server was not running when the check started
  (runtime restart); it was started, verified, and stopped.
- **v3.3 frozen artifacts unchanged:** all 15 files in
  `models/rainfall_xgb_v3_3/frozen/` match `RELEASE_MANIFEST.json` SHA-256
  hashes and sizes.
