import { useCountUp } from '../../hooks/useUi'

export function AnimatedNumber({
  value,
  decimals = 1,
  prefix = '',
  suffix = '',
  className = '',
  duration = 950,
}: {
  value: number
  decimals?: number
  prefix?: string
  suffix?: string
  className?: string
  duration?: number
}) {
  const shown = useCountUp(value, duration, decimals)
  const text = shown.toLocaleString('en-IN', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })
  return (
    <span className={`num ${className}`}>
      {prefix}
      {text}
      {suffix}
    </span>
  )
}
