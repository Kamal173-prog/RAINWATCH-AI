"""Flood-susceptibility index — a faithful port of
``hackathon/src/data/floodRiskData.ts``.

A transparent, deterministic formula combines rainfall, terrain,
drainage and river proximity into a 0–100 index. This is a
**susceptibility index for the UI — NOT a validated flood prediction.**

Honesty notes (do not remove):
- ``riskIndex`` is an illustrative composite, not a calibrated probability.
- ``inundationDepthM`` and ``areaInundatedHa`` are derived from the index
  by a formula, NOT modelled or measured depths/extents. Do not present
  them as real inundation.
- Rainfall for offsets 0 / 3 / 6 h comes from the trained XGBoost model
  (``rainfall-xgb-v1``, Bhubaneswar region only); offsets >= 9 h and all
  Ganjam locations use the demo series. Each record carries ``source``.
"""

from datetime import timedelta

from .demo_state import get_demo_tick
from .locations import LOCATIONS, get_location, is_ganjam
from .rainfall import get_rainfall_series, hour_aligned_now, offset_index, _iso
from .rng import RISK_LEVELS, clamp, classify_risk, create_rng, hash_seed, imul, js_round

# Re-export the horizon constants the frontend uses (3h steps, 72h).
RISK_STEPS_H = 3
RISK_HORIZON_H = 72

# Offsets (h) whose rainfall comes from the XGBoost model (Bhubaneswar
# region only). The model predicts hours 1..6; risk offsets are 3h steps,
# so offsets 0/3/6 map to the model's hour-1 / hours-2-3 / hours-4-6 rates.
MODEL_RISK_OFFSETS = {0: 1, 3: 2, 6: 4}


def _model_rainfall_at(location_id: str, offset_h: int) -> tuple[float, str | None] | tuple[None, None]:
    """Model rainfall rate (mm/hr) for a risk offset, or (None, None).

    Returns (rate, model_version) when the offset is within the model's
    6-hour window and the location is in the Bhubaneswar region.
    """
    if offset_h not in MODEL_RISK_OFFSETS or is_ganjam(location_id):
        return None, None
    try:
        from app.model_service import get_model_hourly_rates, model_version

        rates = get_model_hourly_rates()
        if rates is None:
            return None, None
        return rates[MODEL_RISK_OFFSETS[offset_h]], model_version()
    except Exception:
        return None, None

_cache = None


def compute_risk_record(location_id: str, offset_h: int, tick: int = None) -> dict:
    if tick is None:
        tick = get_demo_tick()
    loc = get_location(location_id)
    # Rainfall: XGBoost model for offsets 0/3/6 h (Bhubaneswar region),
    # demo series otherwise. The record is labelled with its source.
    model_mm, model_ver = _model_rainfall_at(location_id, offset_h)
    if model_mm is not None:
        mm = model_mm
        source = "model"
    else:
        series = get_rainfall_series(location_id)
        i = offset_index(offset_h)
        mm = series["mmHr"][i] if 0 <= i < len(series["mmHr"]) else 0
        source = "demo"
        model_ver = None

    seed = (hash_seed(location_id) ^ imul(tick + 3, 0xC2B2AE35) ^ offset_h) & 0xFFFFFFFF
    rng = create_rng(seed)

    wobble = (rng() - 0.5) * 6

    rainfall_contribution = clamp(mm * 1.35, 0, 46)
    terrain_contribution = clamp(
        loc["lowLyingPct"] * 0.3 + max(0, 46 - loc["elevationM"]) * 0.45, 0, 26
    )
    river_factor = clamp(
        loc["riverProximity"] * 0.22 * (0.72 + mm / 150 + (rng() * 0.18)), 0, 24
    )
    drainage_relief = (loc["drainageEfficiency"] / 100) * 16

    risk_index = js_round(
        clamp(rainfall_contribution + terrain_contribution + river_factor - drainage_relief + wobble, 2, 99), 1
    )
    risk_level = classify_risk(risk_index)

    total = rainfall_contribution + terrain_contribution + river_factor + 0.001
    population_at_risk = int(js_round(
        loc["population"] * clamp((risk_index / 100) * (loc["lowLyingPct"] / 100) * 2.6, 0.02, 0.88), 0
    ))
    inundation_depth_m = js_round(
        clamp((risk_index / 100) ** 1.7 * 1.9 * (0.6 + loc["lowLyingPct"] / 130), 0, 3.4), 2
    )
    area_inundated_ha = int(js_round(
        clamp((loc["lowLyingPct"] / 100) * 740 * (risk_index / 100), 4, 720), 0
    ))

    base = hour_aligned_now()
    record = {
        "locationId": location_id,
        "timestamp": _iso(base + timedelta(hours=offset_h)),
        "riskIndex": risk_index,
        "riskLevel": risk_level,
        "populationAtRisk": population_at_risk,
        "lowLyingPct": loc["lowLyingPct"],
        "drainageScore": loc["drainageEfficiency"],
        "rainfallContribution": js_round((rainfall_contribution / total) * 100, 1),
        "terrainContribution": js_round((terrain_contribution / total) * 100, 1),
        "riverContribution": js_round((river_factor / total) * 100, 1),
        "inundationDepthM": inundation_depth_m,
        "areaInundatedHa": area_inundated_ha,
        # Provenance: "model" when the rainfall came from the XGBoost
        # model (offsets 0/3/6 h, Bhubaneswar region), else "demo".
        # riskIndex is a susceptibility index, not a validated prediction;
        # inundationDepthM / areaInundatedHa are illustrative, derived
        # from the index — not modelled or measured depths.
        "source": source,
    }
    if source == "model" and model_ver:
        record["model_version"] = model_ver
    if source == "model":
        try:
            from app.model_service import get_model_detail

            detail = get_model_detail()
            if detail:
                record["model"] = {
                    "expected_mm": detail["expected_mm"],
                    "upper_bound_p90_mm": detail["upper_bound_p90_mm"],
                    "heavy_rain_probability": detail["heavy_rain_probability"],
                    "heavy_risk_tier": detail["heavy_risk_tier"],
                    "model_version": model_ver,
                }
        except Exception:
            pass
    return record


def get_all_risk_records() -> list:
    global _cache
    tick = get_demo_tick()
    # Cache key includes the model flag (same regression as rainfall.py:
    # a version switch must not serve stale records labelled with the
    # previous version).
    try:
        from app.model_service import MODEL_VERSION_ENV

        model_flag = MODEL_VERSION_ENV
    except Exception:
        model_flag = "rainfall-xgb-v3"
    if _cache is not None and _cache["tick"] == tick and _cache.get("model_flag") == model_flag:
        return _cache["records"]

    records = []
    for loc in LOCATIONS:
        for h in range(0, RISK_HORIZON_H + 1, RISK_STEPS_H):
            records.append(compute_risk_record(loc["id"], h, tick))
    _cache = {"tick": tick, "model_flag": model_flag, "records": records}
    return records


def get_filtered_risk_records(location_id=None, level=None, horizon_h=None) -> list:
    horizon = horizon_h if horizon_h is not None else 72
    base = hour_aligned_now()
    out = []
    for r in get_all_risk_records():
        # offset in hours from the hour-aligned now
        ts = r["timestamp"]
        # timestamps are ISO with Z; parse back to a datetime
        from datetime import datetime, timezone
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        offset = (dt - base).total_seconds() / 3600
        if offset > horizon:
            continue
        if location_id and r["locationId"] != location_id:
            continue
        if level and r["riskLevel"] != level:
            continue
        out.append(r)
    return out


def get_worst_risk_per_location(horizon_h: int = 72) -> list:
    worst = {}
    for r in get_filtered_risk_records(horizon_h=horizon_h):
        prev = worst.get(r["locationId"])
        if prev is None or r["riskIndex"] > prev["riskIndex"]:
            worst[r["locationId"]] = r
    return sorted(worst.values(), key=lambda r: r["riskIndex"], reverse=True)


def get_overall_risk_index(horizon_h: int = 24) -> float:
    records = get_filtered_risk_records(horizon_h=horizon_h)
    if not records:
        return 0
    return js_round(sum(r["riskIndex"] for r in records) / len(records), 1)


def get_risk_distribution(horizon_h: int = 24) -> list:
    records = get_filtered_risk_records(horizon_h=horizon_h)
    return [
        {"level": level, "count": len([r for r in records if r["riskLevel"] == level])}
        for level in RISK_LEVELS
    ]


def get_vulnerable_zones(threshold: int = 60) -> list:
    return [r for r in get_worst_risk_per_location(72) if r["riskIndex"] >= threshold]
