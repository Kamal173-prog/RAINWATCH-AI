# RAINWATCH AI — Backend API

FastAPI backend for the RAINWATCH AI flood early-warning dashboard
(`../hackathon`, React 19 + Vite + TypeScript). Every route mirrors one
`demoApi` method in `hackathon/src/services/dataService.ts`, so the
frontend's types and pages work unchanged against the API.

## Data — what is real and what is demo

| Endpoint group | Source |
|---|---|
| Historical (daily / monthly / annual / peaks / comparison) | **Real** — Open-Meteo ERA5 archive, hourly 2021-01-01 → 2025-12-31 for Bhubaneswar (`data/processed/bhubaneswar_weather.csv`, 43,824 records, fetched 23 Nov 2026). Applies to Bhubaneswar-region locations; daily totals are scaled by the frontend's per-location exposure factor. |
| Historical for Ganjam / Brahmapur locations | Demo generator (the archive fetch was rate-limited by Open-Meteo, HTTP 429, twice on 23 Nov 2026). Run `python fetch_brahmapur.py` later, then restart — Ganjam will switch to real data automatically. |
| Forecast (hours 1–6, Bhubaneswar region) | **Trained ensemble model** (`rainfall-xgb-v3`, XGBoost + LightGBM + HistGradientBoosting). Each point carries `source: "model"` + `model_version` + a `model` object with `expected_mm`, `upper_bound_p90_mm`, `heavy_rain_probability` and `heavy_risk_tier`. The `model` object also carries dual `decision_thresholds` (`elevated` / `high` per event). Model input is the last available observations (2025-12-31T23:00Z) — there is no live feed. |
| Forecast (hours 7+, and all Ganjam locations) | Deterministic demo engine, on `/api/forecast` only. Each point carries `source: "demo"`. |
| Merged forecast (`/api/forecast/merged`, used by the Forecast page) | **Source priority MODEL → GOOGLE WEATHER → UNAVAILABLE.** MODEL hours are byte-identical to `/api/forecast`; every other hour is a genuine Google Weather forecast (QPF, mm in the hour) where Google can provide one, else UNAVAILABLE with null values — synthetic DEMO values are never returned here. Each point carries `source` + `valueKind` (`model_rate_mm_hr` / `google_qpf_mm`). Google's hourly intervals are local-hour aligned, so matching is by interval containment, not equal timestamps. Google's precipitation probability is carried separately and is never confidence. |
| Flood risk | **Susceptibility index** (not a validated prediction). Rainfall for offsets 0/3/6 h comes from the XGBoost model (Bhubaneswar region); the rest uses the demo series. Each record carries `source` + `model_version` when model. `inundationDepthM` / `areaInundatedHa` are illustrative, derived from the index — not modelled depths. |
| Weather / map / simulator / overview | Deterministic demo engine, ported line-for-line from the frontend's `src/data/*` modules (same seeded LCG, same formulas). Labelled **DEMO** in the UI — never presented as operational predictions. |

## Machine learning — rainfall forecaster (Stage 2, done)

A genuine trained model, not a demo formula. XGBoost regression, one booster per horizon (1 h / 3 h / 6 h accumulation), trained on the Bhubaneswar ERA5 archive with a chronological split (train 2021–2023, validation 2024, test 2025). Full report: `docs/MODEL_REPORT.md`.

- **Amounts:** beats persistence and climatology on MAE/RMSE at every horizon (1 h: 0.240/0.794; 3 h: 0.653/1.753; 6 h: 1.198/2.878 mm on the 2025 test set).
- **Events (v3, spatial-thermodynamic ensemble):** PR-AUC improved for all three events vs v2 — 3 h ≥ 10 mm 0.168 (v2: 0.101), 6 h ≥ 10 mm 0.207 (v2: 0.178), 3 h ≥ 5 mm 0.323 (v2: 0.290). Dual thresholds: 3 h ≥ 10 mm elevated (Watch) Precision 0.15 / Recall 0.30 / F1 0.198 (caught 26/87, same recall as v2 but precision 0.09 → 0.15); high (Warning) Precision 0.16 / Recall 0.22 / F1 0.185 (caught 19/87). 6 h ≥ 10 mm elevated catches 222/258 (Recall 0.86, Precision 0.11); high catches 75/258 (Recall 0.29, Precision 0.19). 3 h ≥ 5 mm elevated Precision 0.23 / Recall 0.71 / F1 0.341 (caught 224/317); high Precision 0.29 / Recall 0.43 / F1 0.347 (caught 137/317). Precision is still low in absolute terms — a "high" tier is an early-warning signal, not a confirmed forecast. P90 upper-bound coverage: 3 h 0.938, 6 h 0.932 (target 0.90).
- **Regression (v3, mixed):** 1 h MAE 0.209 / RMSE 0.748 (better than v2's 0.224/0.762); 3 h MAE 0.631 / RMSE 1.676 (v2: 0.622/1.699 — MAE slightly worse, RMSE slightly better); 6 h MAE 1.211 / RMSE 2.862 (v2: 1.172/2.823 — slightly worse). v3 used fixed hyperparameters for the ensemble members while v2 tuned its single XGBoost; per-family tuning is the next step for regression.
- **CAPE not used:** Open-Meteo returned `cape` as all nulls for all three grid cells. v3 uses surface-based instability proxies (dew-point depression, moisture flux, onshore flux, theta_e) instead. See `data/README.md`.
- **Files:** `ml/fetch_spatial.py` (upwind grid fetcher), `ml/features.py` (feature engineering, 62 features, 41 kept after pruning), `ml/train_rainfall.py` (v3 ensemble training), `ml/train_rainfall_v2.py` (v2 script, preserved), `ml/predict.py` (v3 ensemble inference), `models/rainfall_xgb_v3/` (ensemble members + `ensemble_weights.json` + `thresholds.json` + `platt.json` + `evaluation.json`).
- **Integration (Stage 4, done):** the model is loaded once at startup (`app/model_service.py`) and serves forecast hours 1–6 for Bhubaneswar-region locations, plus the rainfall input to risk records at offsets 0/3/6 h. Every model-backed value carries `source: "model"` + `model_version` + a `model` object (expected_mm, P90, probabilities, tier, dual thresholds); everything else carries `source: "demo"`. If the model fails to load, the API falls back to demo and keeps working. `/api/health` reports model status.
- **Data layout:** `data/raw/` (as-downloaded), `data/processed/` (cleaned tables the API reads), `data/model_ready/` (feature tables). Inventory: `data/README.md`.

Reproduce: `.venv/bin/python ml/train_rainfall.py --n-configs 16` (seeded; reproduces the reported metrics).

Notes on honesty: the Open-Meteo values are ERA5 **reanalysis** (modelled,
~31 km grid; the API snapped Bhubaneswar to lat 20.2812, lng 85.8434),
not direct station measurements. Flood depths and risk indices are the
frontend's illustrative teaching model, not a validated prediction.

## Quick start

```bash
cd backend
python3 -m venv .venv && source .venv/bin/activate   # or use your own venv
pip install -r requirements.txt
cp .env.example .env        # optional — defaults work as-is
uvicorn app.main:app --reload --port 8000
```

API docs: http://localhost:8000/docs
Health:    http://localhost:8000/api/health

## Run frontend + backend together

Terminal 1 (backend):
```bash
cd backend && uvicorn app.main:app --reload --port 8000
```

Terminal 2 (frontend):
```bash
cd hackathon && npm run dev
```

The frontend reads `VITE_API_URL` from `hackathon/.env`
(`http://localhost:8000`). When it is set, `demoApi` calls the backend
and falls back to local demo data if the backend is unreachable — so the
dashboard works with or without the server running.

## Endpoints

| Method | Path | Mirrors |
|---|---|---|
| GET | `/api/health` | — |
| GET | `/api/locations` | `listLocations` |
| GET | `/api/weather?locationId&hours` | `fetchWeather` |
| GET | `/api/weather/current?locationId` | `fetchCurrentWeather` |
| GET | `/api/weather/google?locationId&hours` (3/6/12/24/48/72) | `fetchGoogleForecast` |
| GET | `/api/forecast?locationId&hours` (3/6/12/24/48/72) | `fetchForecast` |
| GET | `/api/forecast/merged?locationId&hours` (3/6/12/24/48/72) | `fetchMergedForecast` |
| GET | `/api/forecast/intensity?locationId&hours` | `fetchIntensityDistribution` |
| GET | `/api/risk/records?locationId&level&horizonH` | `fetchRiskRecords` |
| GET | `/api/risk/summary?horizonH` | `fetchRiskSummary` |
| GET | `/api/risk/all` | `fetchAllRiskRecords` |
| GET | `/api/alerts` | `fetchAlerts` |
| GET | `/api/alerts/upcoming?limit` | `fetchUpcomingAlerts` |
| GET | `/api/history/daily?locationId&days` | `fetchDailyHistory` |
| GET | `/api/history/monthly?locationId` | `fetchMonthlyHistory` |
| GET | `/api/history/annual` | `fetchAnnualHistory` |
| GET | `/api/history/peaks?locationId&limit` | `fetchPeakEvents` |
| GET | `/api/history/comparison?days` | `fetchLocationComparison` |
| GET | `/api/map/layers` | `fetchMapLayers` |
| GET | `/api/map/regions` | `fetchRegionConditions` |
| GET | `/api/data-sources` | `fetchDataSources` |
| GET | `/api/overview?locationId&alertCount` | `fetchOverview` |
| POST | `/api/simulate` | `runSimulation` |
| POST | `/api/demo/refresh` | `refreshDemoData` |

Errors are JSON: `{"detail": "..."}` with 400 (bad hours / horizon /
level) or 404 (unknown location).

## Configuration (`.env`)

| Variable | Default | Notes |
|---|---|---|
| `PORT` / `HOST` | `8000` / `0.0.0.0` | API listen address |
| `CORS_ORIGINS` | `http://localhost:5173,http://127.0.0.1:5173` | Vite dev server |
| `DATABASE_URL` | `sqlite:///./rainwatch.db` | Zero-setup default. For PostgreSQL + PostGIS (per the project spec), set e.g. `postgresql+psycopg2://user:pass@localhost:5432/rainwatch`. The API is stateless today — the DB is reserved for future persistence (alert ack state, cached forecasts). |
| `BHUBANESWAR_CSV` | `data/processed/bhubaneswar_weather.csv` | Override the archive path |
| `GOOGLE_WEATHER_API_KEY` | *(empty)* | Google Maps Platform Weather API key. Optional: without it `/api/weather/google` answers 503 and the merged forecast fills non-model hours with UNAVAILABLE instead of Google values. Maps Demo Key works for prototyping (no billing); a standard key needs a billing account. Never commit a real key — put it in `backend/.env` only. |
| `GOOGLE_WEATHER_MONTHLY_CAP` | `5000` | Optional process-local cap on Google Weather calls per month. |

Open-Meteo is free and keyless. Google Weather is the only keyed service, and it is optional — RAINWATCH works without it.

## Project layout

```
backend/
  data/                     real Open-Meteo archive (CSV + raw JSON)
  app/
    main.py                 FastAPI app, CORS, routes, error handling
    schemas.py              Pydantic models (mirror src/types/index.ts)
    core/config.py          .env settings
    engine/                 data engine (ported from hackathon/src/data/*)
      rng.py                seeded LCG + classify helpers
      demo_state.py         demo tick
      locations.py          21 locations + 2 regions
      rainfall.py           hourly series, forecast, intensity
      weather.py            weather history / current / KPIs
      risk.py               flood-risk records + summaries
      history.py            real-CSV + demo historical analysis
      alerts.py             16 seed alerts
      maps.py               map layers + region conditions
      datasources.py        data sources + pipeline
      simulator.py          what-if simulator + overview bundle
  fetch_brahmapur.py        fetch the Ganjam archive when rate limit clears
  requirements.txt  .env.example  .gitignore  README.md
```
