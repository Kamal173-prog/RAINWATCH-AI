import { BrowserRouter, Route, Routes } from 'react-router-dom'
import { MotionConfig } from 'framer-motion'
import { Toaster } from 'sonner'
import { AppShell } from './components/layout/AppShell'
import { AlertsProvider } from './context/AlertsContext'
import { DemoProvider } from './context/DemoContext'
import { LocationProvider } from './context/LocationContext'
import { SettingsProvider, useSettings } from './context/SettingsContext'
import { Alerts } from './pages/Alerts'
import { DataSources } from './pages/DataSources'
import { FloodIntelligence } from './pages/FloodIntelligence'
import { HistoricalAnalysis } from './pages/HistoricalAnalysis'
import { InundationMap } from './pages/InundationMap'
import { LiveWeather } from './pages/LiveWeather'
import { Landing } from './pages/Landing'
import { NotFound } from './pages/NotFound'
import { Overview } from './pages/Overview'
import { RainfallForecast } from './pages/RainfallForecast'
import { Settings } from './pages/Settings'
import { Simulator } from './pages/Simulator'

function AppToaster() {
  const { settings } = useSettings()
  return (
    <Toaster
      position="bottom-right"
      toastOptions={{
        style: {
          background: 'var(--rw-card)',
          color: 'var(--rw-ink)',
          border: '1px solid var(--rw-border)',
          borderRadius: '14px',
          fontSize: '13px',
          fontFamily: 'Inter, sans-serif',
          boxShadow: '0 30px 70px -35px rgba(0,0,0,0.9)',
        },
      }}
      theme={settings.theme}
      richColors
      closeButton
    />
  )
}

export default function App() {
  return (
    <MotionConfig reducedMotion="user">
      <BrowserRouter>
        <SettingsProvider>
          <LocationProvider>
            <AlertsProvider>
              <DemoProvider>
                <Routes>
                  <Route path="/" element={<Landing />} />
                  <Route element={<AppShell />}>
                    <Route path="/overview" element={<Overview />} />
                    <Route path="/live-weather" element={<LiveWeather />} />
                    <Route path="/forecast" element={<RainfallForecast />} />
                    <Route path="/flood-intelligence" element={<FloodIntelligence />} />
                    <Route path="/map" element={<InundationMap />} />
                    <Route path="/simulator" element={<Simulator />} />
                    <Route path="/alerts" element={<Alerts />} />
                    <Route path="/historical" element={<HistoricalAnalysis />} />
                    <Route path="/data-sources" element={<DataSources />} />
                    <Route path="/settings" element={<Settings />} />
                    <Route path="*" element={<NotFound />} />
                  </Route>
                </Routes>
                <AppToaster />
              </DemoProvider>
            </AlertsProvider>
          </LocationProvider>
        </SettingsProvider>
      </BrowserRouter>
    </MotionConfig>
  )
}
