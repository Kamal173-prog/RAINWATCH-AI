"""What-if simulator + overview bundle — a port of the simulator in
``hackathon/src/services/dataService.ts`` (``runSimulation`` and
``fetchOverview``).

The simulator is a deterministic, fully server-side scenario
calculation. It is an educational demo formula — explicitly NOT an AI
model — matching the frontend's local maths so results agree.
"""

from datetime import datetime, timedelta, timezone

from .alerts import get_upcoming_alerts
from .demo_state import get_demo_tick
from .locations import LOCATIONS, get_location
from .rainfall import get_forecast, get_intensity_distribution
from .risk import (
    get_overall_risk_index,
    get_risk_distribution,
    get_vulnerable_zones,
)
from .rng import clamp, classify_risk, create_rng, hash_seed, js_round
from .weather import (
    get_accumulated_rainfall,
    get_current_rainfall,
    get_current_weather,
    get_max_forecast,
    get_rainfall_delta,
    get_rainfall_sparkline,
)


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


# ------------------------------------------------------------------
# Simulator
# ------------------------------------------------------------------

def run_simulation(inputs: dict) -> dict:
    location_id = inputs["locationId"]
    rainfall = inputs["rainfallMmHr"]
    duration_h = inputs["durationH"]
    soil = inputs["soilSaturationPct"]
    drainage = inputs["drainageEfficiencyPct"]
    river = inputs["riverLevelPct"]

    seed_src = f"{location_id}|{rainfall}|{duration_h}|{soil}|{drainage}|{river}"
    rng = create_rng(hash_seed(seed_src))
    loc = get_location(location_id)

    rain_load = clamp((rainfall / 120) * 42, 0, 44)
    duration_load = clamp((duration_h / 48) * 16, 0, 16)
    soil_load = clamp((soil / 100) * 18, 0, 18)
    river_load = clamp((river / 100) * 16, 0, 16)
    terrain_load = clamp((loc["lowLyingPct"] / 100) * 14, 0, 14)
    drainage_relief = clamp((drainage / 100) * 26, 0, 26)

    risk_index = js_round(
        clamp(rain_load + duration_load + soil_load + river_load + terrain_load - drainage_relief + rng() * 3, 1, 99), 1
    )

    denom = risk_index + drainage_relief
    breakdown = [
        {"factor": "Rainfall intensity", "contribution": js_round((rain_load / denom) * 100, 1)},
        {"factor": "Storm duration", "contribution": js_round((duration_load / denom) * 100, 1)},
        {"factor": "Soil saturation", "contribution": js_round((soil_load / denom) * 100, 1)},
        {"factor": "River / water level", "contribution": js_round((river_load / denom) * 100, 1)},
        {"factor": "Terrain & drainage", "contribution": js_round(((terrain_load + 4) / denom) * 100, 1)},
    ]

    affected_zones = int(js_round(clamp((risk_index / 100) * 14 * (loc["lowLyingPct"] / 60), 0, 14), 0))
    peak_depth_m = js_round(clamp((risk_index / 100) ** 1.6 * 2.4, 0, 3.6), 2)
    if risk_index < 20:
        severity = "None"
    elif risk_index < 40:
        severity = "Minor"
    elif risk_index < 60:
        severity = "Moderate"
    elif risk_index < 80:
        severity = "Severe"
    else:
        severity = "Extreme"

    duration_to_impact_h = js_round(
        clamp(
            (1.2 if soil > 70 else 2.6) + (100 - drainage) / 45 + 60 / max(8, rainfall),
            0.5, 12,
        ), 1
    )

    return {
        "riskIndex": risk_index,
        "riskLevel": classify_risk(risk_index),
        "affectedZones": affected_zones,
        "inundationSeverity": severity,
        "peakDepthM": peak_depth_m,
        "durationToImpactH": duration_to_impact_h,
        "breakdown": breakdown,
        "inputs": inputs,
    }


# ------------------------------------------------------------------
# Overview bundle
# ------------------------------------------------------------------

_ACTIVITY = [
    ("Radar mosaic ingested for {loc} sector", "info"),
    ("Drainage model re-ran for 12 sample zones", "ok"),
    ("Risk index recalculated — composite factors updated", "warn"),
    ("Sample station telemetry validated", "ok"),
    ("Inundation extent regenerated from demo terrain", "crit"),
    ("Forecast confidence band narrowed for next 6 h", "info"),
    ("Vulnerability registry refreshed (demo records)", "warn"),
]


def get_overview(location_id: str, alert_count: int) -> dict:
    worst = get_vulnerable_zones(55)
    rng = create_rng(hash_seed(f"activity-{location_id}"))

    activity = []
    for i, (text, tone) in enumerate(_ACTIVITY[:6]):
        activity.append({
            "id": f"act-{i}",
            "time": _iso(datetime.now(timezone.utc) - timedelta(minutes=(i * 17 + rng() * 12))),
            "text": text.format(loc=location_id),
            "tone": tone,
        })

    acc24 = get_accumulated_rainfall(location_id, 24)
    acc48 = get_accumulated_rainfall(location_id, 48)
    prior24 = acc48 - acc24
    accumulated_trend = js_round(((acc24 - prior24) / max(1, prior24)) * 100, 1)
    overall = get_overall_risk_index(24)

    return {
        "kpis": {
            "currentRainfall": get_current_rainfall(location_id),
            "rainfallDelta": get_rainfall_delta(location_id),
            "accumulated24h": acc24,
            "accumulatedTrend": accumulated_trend,
            "maxForecast": get_max_forecast(location_id),
            "floodRiskIndex": overall,
            "riskLevel": classify_risk(overall),
            "vulnerableZones": len(worst),
            "activeAlerts": alert_count,
        },
        "sparkline": get_rainfall_sparkline(location_id, 24),
        "weather": get_current_weather(location_id),
        "forecast": get_forecast(location_id, 24),
        "intensity": get_intensity_distribution(location_id, 24),
        "riskDistribution": get_risk_distribution(24),
        "vulnerable": [
            {
                "name": next((l["name"] for l in LOCATIONS if l["id"] == r["locationId"]), r["locationId"]),
                "riskIndex": r["riskIndex"],
                "level": r["riskLevel"],
                "populationAtRisk": r["populationAtRisk"],
            }
            for r in worst[:6]
        ],
        "upcomingAlerts": get_upcoming_alerts(4),
        "activity": activity,
    }
