import { useEffect, useRef, useState } from 'react'
import { useReducedMotion } from 'framer-motion'

/**
 * Animated number counter used by KPI cards.
 * Respects the user's reduced-motion preference by snapping instantly.
 */
export function useCountUp(target: number, duration = 950, decimals = 1): number {
  const reduce = useReducedMotion()
  const [display, setDisplay] = useState(target)
  const displayRef = useRef(target)

  useEffect(() => {
    if (reduce) {
      displayRef.current = target
      setDisplay(target)
      return
    }

    const from = displayRef.current
    if (Math.abs(from - target) < 1e-6) {
      setDisplay(target)
      return
    }

    const start = performance.now()
    let raf = 0

    const step = (now: number) => {
      const p = Math.min(1, (now - start) / duration)
      const eased = 1 - Math.pow(1 - p, 3)
      const value = from + (target - from) * eased
      displayRef.current = value
      setDisplay(value)
      if (p < 1) raf = requestAnimationFrame(step)
      else {
        displayRef.current = target
        setDisplay(target)
      }
    }

    raf = requestAnimationFrame(step)
    return () => cancelAnimationFrame(raf)
  }, [target, duration, reduce])

  const f = 10 ** decimals
  return Math.round(display * f) / f
}

/** Live dashboard clock (1 Hz). */
export function useLiveClock(): Date {
  const [now, setNow] = useState(() => new Date())
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 1000)
    return () => window.clearInterval(id)
  }, [])
  return now
}

/** Applies document-level theme / accent / density attributes. */
export function useDocumentTheme(
  theme: string,
  accent: string,
  accent2: string,
  onLight: string,
  onLightSecondary: string,
  density: string,
) {
  useEffect(() => {
    const root = document.documentElement
    const isLight = theme === 'light'
    const primary = isLight ? onLight : accent
    const secondary = isLight ? onLightSecondary : accent2
    root.dataset.theme = theme
    root.dataset.density = density
    root.style.setProperty('--rw-accent', primary)
    root.style.setProperty('--rw-accent-2', secondary)
    root.style.setProperty(
      '--rw-glow',
      `color-mix(in srgb, ${primary} 16%, transparent)`,
    )
  }, [theme, accent, accent2, onLight, onLightSecondary, density])
}
