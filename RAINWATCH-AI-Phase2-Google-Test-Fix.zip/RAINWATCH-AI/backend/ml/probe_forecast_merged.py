"""Playwright probe for the merged forecast (MODEL > GOOGLE WEATHER > UNAVAILABLE).

Two phases, run against live servers started by this script:
  Phase A — MOCKED Google success: the backend runs with an httpx
    MockTransport (see ml/mock_google_server.py, fixture anchored to
    the current UTC hour) returning the documented 24h fixture. The
    Forecast page's main table must show 6 MODEL + 18 GOOGLE WEATHER
    for Old Town, 24 GOOGLE WEATHER for Brahmapur, 6 MODEL + 18 GOOGLE
    WEATHER for Cuttack — ZERO DEMO badges anywhere on the page. The
    main CSV must carry correct Source + Value kind columns. Mean
    confidence must be computed over MODEL hours only. The separate
    Google comparison section must still be present.
  Phase B — NO KEY: the real backend with no key configured. The
    Forecast page must show 6 MODEL + 18 UNAVAILABLE for Old Town,
    zero DEMO, zero fabricated values; the main CSV must mark
    unavailable rows with empty values.

No live Google call is made in either phase (no real key exists).
Exits non-zero on any failure. Screenshots to
~/workspace/merged-probe-screenshots/.
"""

import csv
import json
import os
import re
import subprocess
import sys
import time
import urllib.request
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

BACKEND = Path.home() / "workspace" / "backend"
HACKATHON = Path.home() / "workspace" / "hackathon"
VENV_PY = BACKEND / ".venv" / "bin" / "python"
OUT = Path.home() / "workspace" / "merged-probe-screenshots"
OUT.mkdir(parents=True, exist_ok=True)
CHROME = "/home/hatch/.cache/ms-playwright/chromium-1255/chrome-linux64/chrome"
results: dict = {}

EXPECTED_CSV_HEADER = [
    "Timestamp", "Rainfall value", "Value kind", "Accumulated (mm)",
    "Classification", "Confidence (%)", "Precipitation probability (%)", "Source",
]


def wait_up(url, timeout=60):
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=5) as r:
                if r.status == 200:
                    return True
        except Exception:
            time.sleep(1)
    return False


def start_backend_mock(port):
    env = {"MODEL_VERSION": "rainfall-xgb-v3.3"}
    full_env = dict(os.environ, **env)
    full_env.pop("GOOGLE_WEATHER_API_KEY", None)
    return subprocess.Popen(
        [str(VENV_PY), "ml/mock_google_server.py", str(port)],
        cwd=BACKEND, env=full_env,
        stdout=open(OUT / "mock-backend.log", "w"),
        stderr=subprocess.STDOUT)


def start_backend_real(port):
    full_env = dict(os.environ)
    full_env.pop("GOOGLE_WEATHER_API_KEY", None)
    full_env["MODEL_VERSION"] = "rainfall-xgb-v3.3"
    return subprocess.Popen(
        [str(VENV_PY), "-m", "uvicorn", "app.main:app",
         "--host", "127.0.0.1", "--port", str(port)],
        cwd=BACKEND, env=full_env,
        stdout=open(OUT / "real-backend.log", "w"),
        stderr=subprocess.STDOUT)


def start_vite(api_base):
    full_env = dict(os.environ, VITE_API_URL=api_base)
    return subprocess.Popen(
        ["node", "node_modules/vite/bin/vite.js", "--port", "5173"],
        cwd=HACKATHON, env=full_env,
        stdout=open(OUT / "vite.log", "w"),
        stderr=subprocess.STDOUT)


def stop(proc):
    if proc and proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()


def main_table_counts(page):
    """Source badges in the main Forecast Data Table (first <table>)."""
    tables = page.locator("table")
    assert tables.count() >= 1, "no tables on the Forecast page"
    rows = tables.nth(0).locator("tbody tr")
    counts = Counter()
    for i in range(rows.count()):
        cells = rows.nth(i).locator("td")
        if cells.count():
            counts[cells.nth(cells.count() - 1).inner_text().strip().upper()] += 1
    return dict(counts)


def demo_badge_count(page):
    """VISIBLE DemoBadge elements on the page (exact text DEMO / DEMO DATA).

    The app shell also renders DemoBadges in the Topbar (hidden below
    the 2xl breakpoint) and global "Demo Mode" / "values labelled
    DEMO" prose on every page — that is shell chrome for the whole
    app, whose other pages still show DEMO values, and is out of
    scope for this page. Only badges actually visible on the Forecast
    page count here.
    """
    loc = page.locator("text=/^DEMO( DATA)?$/")
    return sum(1 for i in range(loc.count()) if loc.nth(i).is_visible())


def set_location(page, name):
    """The location picker is a native <select>; options are 'Name · Zone'."""
    sel = page.locator("select").first
    options = sel.locator("option").all_inner_texts()
    match = [o for o in options if o == name or o.startswith(name + " ")]
    assert match, f"no location option for {name}: {options}"
    sel.select_option(label=match[0])
    page.wait_for_timeout(8000)  # refetch + charts animate in


def export_main_csv(page, filename):
    with page.expect_download() as dl:
        page.get_by_text("Export CSV").first.click()
    dl.value.save_as(str(OUT / filename))
    # downloadCsv prepends a UTF-8 BOM — read with utf-8-sig so the
    # first header cell is "Timestamp", not "\ufeffTimestamp".
    with open(OUT / filename, newline="", encoding="utf-8-sig") as f:
        rows = list(csv.reader(f))
    return rows


def mean_confidence_on_page(page):
    # The card label is CSS-uppercased, so inner_text() returns
    # "MEAN CONFIDENCE" — match case-insensitively (same trap as the
    # earlier integrity probe's chip-text checks).
    body = page.locator("body").inner_text()
    m = re.search(r"mean confidence\s*\n\s*(\S+)", body, re.IGNORECASE)
    assert m, "Mean confidence card not found"
    return m.group(1)


def merged_api_mean_confidence(api_base, location_id="old-town"):
    with urllib.request.urlopen(
            f"{api_base}/api/forecast/merged?locationId={location_id}&hours=24",
            timeout=15) as r:
        body = json.loads(r.read())
    confs = [p["confidence"] for p in body["points"]
             if p["source"] == "model" and p["confidence"] is not None]
    assert confs, "no model points from the API"
    return f"{round(sum(confs) / len(confs))}%"


def run_phase_a():
    """Mocked Google success."""
    from playwright.sync_api import sync_playwright
    backend = start_backend_mock(8009)
    vite = None
    try:
        assert wait_up("http://127.0.0.1:8009/api/health"), "mock backend did not start"
        vite = start_vite("http://localhost:8009")
        assert wait_up("http://127.0.0.1:5173/"), "vite did not start"
        with sync_playwright() as p:
            b = p.chromium.launch(executable_path=CHROME)
            page = b.new_page(viewport={"width": 1440, "height": 900})
            errors = []
            page.on("console", lambda m: errors.append(m.text)
                    if m.type == "error" and "ERR_TUNNEL_CONNECTION_FAILED" not in m.text and "503" not in m.text else None)
            page.on("requestfailed", lambda r: errors.append(r.url)
                    if "tile.openstreetmap" not in r.url and "fonts.g" not in r.url and "weather/google" not in r.url else None)
            page.goto("http://localhost:5173/forecast", wait_until="networkidle")
            page.wait_for_timeout(8000)
            body = page.locator("body").inner_text()
            results["phase_a"] = {
                "old_town_table": main_table_counts(page),
                "demo_badges": demo_badge_count(page),
                "google_section_present": "Google Weather" in body,
                "google_csv_button": page.get_by_text("Export Google CSV").count(),
                "merged_note_present": "Source priority: MODEL, then GOOGLE WEATHER, then UNAVAILABLE" in body,
            }
            page.screenshot(path=str(OUT / "forecast-merged-old-town.png"), full_page=True)
            # Main CSV export
            rows = export_main_csv(page, "forecast-merged-old-town.csv")
            header, data = rows[0], rows[1:]
            by_source = Counter(r[7] for r in data)
            by_kind = Counter(r[2] for r in data)
            results["phase_a"]["main_csv"] = {
                "header_ok": header == EXPECTED_CSV_HEADER,
                "rows": len(data),
                "by_source": dict(by_source),
                "by_kind": dict(by_kind),
            }
            # Mean confidence: page value must equal the API's
            # model-only mean (Google probabilities never mixed in).
            results["phase_a"]["mean_confidence"] = {
                "page": mean_confidence_on_page(page),
                "api_model_only": merged_api_mean_confidence("http://localhost:8009"),
            }
            # Brahmapur — no model coverage: 24 GOOGLE WEATHER.
            set_location(page, "Brahmapur")
            results["phase_a"]["brahmapur_table"] = main_table_counts(page)
            results["phase_a"]["brahmapur_demo_badges"] = demo_badge_count(page)
            page.screenshot(path=str(OUT / "forecast-merged-brahmapur.png"), full_page=True)
            # Cuttack — shares the Bhubaneswar grid cell: 6 MODEL + 18 GOOGLE.
            set_location(page, "Cuttack")
            results["phase_a"]["cuttack_table"] = main_table_counts(page)
            page.screenshot(path=str(OUT / "forecast-merged-cuttack.png"), full_page=True)
            results["phase_a"]["console_errors"] = errors
            b.close()
    finally:
        stop(vite)
        stop(backend)


def run_phase_b():
    """No key configured."""
    from playwright.sync_api import sync_playwright
    backend = start_backend_real(8001)
    vite = None
    try:
        assert wait_up("http://127.0.0.1:8001/api/health"), "real backend did not start"
        vite = start_vite("http://localhost:8001")
        assert wait_up("http://127.0.0.1:5173/"), "vite did not start"
        with sync_playwright() as p:
            b = p.chromium.launch(executable_path=CHROME)
            page = b.new_page(viewport={"width": 1440, "height": 900})
            errors = []
            page.on("console", lambda m: errors.append(m.text)
                    if m.type == "error" and "ERR_TUNNEL_CONNECTION_FAILED" not in m.text and "503" not in m.text else None)
            page.on("requestfailed", lambda r: errors.append(r.url)
                    if "tile.openstreetmap" not in r.url and "fonts.g" not in r.url and "weather/google" not in r.url else None)
            page.goto("http://localhost:5173/forecast", wait_until="networkidle")
            page.wait_for_timeout(8000)
            body = page.locator("body").inner_text()
            results["phase_b"] = {
                "old_town_table": main_table_counts(page),
                "demo_badges": demo_badge_count(page),
                "google_unavailable_shown": "Google Weather unavailable" in body,
                "google_status_line": "Google Weather is not configured" in body,
                "unavailable_note": "UNAVAILABLE means neither the RAINWATCH model nor Google Weather" in body,
            }
            page.screenshot(path=str(OUT / "forecast-merged-nokey.png"), full_page=True)
            rows = export_main_csv(page, "forecast-merged-nokey.csv")
            header, data = rows[0], rows[1:]
            by_source = Counter(r[7] for r in data)
            unavail = [r for r in data if r[7] == "unavailable"]
            results["phase_b"]["main_csv"] = {
                "header_ok": header == EXPECTED_CSV_HEADER,
                "rows": len(data),
                "by_source": dict(by_source),
                # Unavailable rows must carry empty values, never zeros.
                "unavailable_empty_values": all(
                    r[1] == "" and r[2] == "" and r[3] == "" and r[4] == ""
                    and r[5] == "" and r[6] == "" for r in unavail),
                "unavailable_rows": len(unavail),
            }
            results["phase_b"]["console_errors"] = errors
            b.close()
    finally:
        stop(vite)
        stop(backend)


def main():
    run_phase_a()
    run_phase_b()
    print(json.dumps(results, indent=2))
    a = results["phase_a"]
    b = results["phase_b"]
    ok = (
        a["old_town_table"].get("MODEL") == 6
        and a["old_town_table"].get("GOOGLE WEATHER") == 18
        and a["old_town_table"].get("UNAVAILABLE") in (0, None)
        and a["demo_badges"] == 0
        and a["google_section_present"]
        and a["google_csv_button"] == 1
        and a["merged_note_present"]
        and a["main_csv"]["header_ok"]
        and a["main_csv"]["rows"] == 24
        and a["main_csv"]["by_source"].get("model") == 6
        and a["main_csv"]["by_source"].get("google_weather") == 18
        and a["main_csv"]["by_kind"].get("model_rate_mm_hr") == 6
        and a["main_csv"]["by_kind"].get("google_qpf_mm") == 18
        and a["mean_confidence"]["page"] == a["mean_confidence"]["api_model_only"]
        and a["brahmapur_table"].get("GOOGLE WEATHER") == 24
        and a["brahmapur_table"].get("MODEL") in (0, None)
        and a["brahmapur_demo_badges"] == 0
        and a["cuttack_table"].get("MODEL") == 6
        and a["cuttack_table"].get("GOOGLE WEATHER") == 18
        and not a["console_errors"]
        and b["old_town_table"].get("MODEL") == 6
        and b["old_town_table"].get("UNAVAILABLE") == 18
        and b["old_town_table"].get("GOOGLE WEATHER") in (0, None)
        and b["demo_badges"] == 0
        and b["google_unavailable_shown"]
        and b["google_status_line"]
        and b["unavailable_note"]
        and b["main_csv"]["header_ok"]
        and b["main_csv"]["rows"] == 24
        and b["main_csv"]["by_source"].get("model") == 6
        and b["main_csv"]["by_source"].get("unavailable") == 18
        and b["main_csv"]["unavailable_empty_values"]
        and b["main_csv"]["unavailable_rows"] == 18
        and not b["console_errors"]
    )
    print("VERDICT:", "PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
