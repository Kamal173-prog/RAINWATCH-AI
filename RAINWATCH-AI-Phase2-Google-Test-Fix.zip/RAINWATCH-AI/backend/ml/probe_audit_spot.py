"""Completeness-audit spot check (independent, fresh session).

Pages: forecast, flood-intelligence, overview (20 s settle), map,
data-sources. Plus: forecast CSV export, simulator run. Records
console errors, failed API requests, badge counts, key disclosure
strings. Screenshots to ~/workspace/audit-screenshots/.
"""
import json
import os

from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:5173"
OUT = "/home/hatch/workspace/audit-screenshots"
CHROME = "/home/hatch/.cache/ms-playwright/chromium-1255/chrome-linux64/chrome"
os.makedirs(OUT, exist_ok=True)

results = {}


def badges(page):
    return {label: page.get_by_text(label, exact=True).count()
            for label in ("MODEL", "DEMO", "UNKNOWN")}


def visit(page, path, name, wait_ms=12000):
    errors, failed = [], []
    page.on("pageerror", lambda e: errors.append(str(e)[:200]))
    page.on("console", lambda m: errors.append(m.text[:200]) if m.type == "error" else None)
    page.on("response", lambda r: failed.append(f"{r.status} {r.url[:100]}") if r.status >= 400 else None)
    page.on("requestfailed", lambda r: failed.append(f"FAILED {r.url[:100]}"))
    page.goto(f"{BASE}{path}", wait_until="networkidle")
    page.wait_for_timeout(wait_ms)
    body = page.locator("body").inner_text()
    detail = {
        "h1": page.locator("h1").first.inner_text() if page.locator("h1").count() else "(no h1)",
        "body_chars": len(body),
        "badges": badges(page),
        "console_errors": [e for e in errors if "ERR_TUNNEL_CONNECTION_FAILED" not in e and "tile.openstreetmap" not in e],
        "failed_requests": [f for f in failed if "tile.openstreetmap.org" not in f],
        "has_grid_cell_note": "Bhubaneswar grid cell" in body,
    }
    page.screenshot(path=f"{OUT}/{name}.png", full_page=True)
    results[name] = detail
    print(f"{name}: h1={detail['h1']!r} badges={detail['badges']} console={len(detail['console_errors'])} failed={len(detail['failed_requests'])} grid_note={detail['has_grid_cell_note']}")
    return body


with sync_playwright() as pw:
    browser = pw.chromium.launch(executable_path=CHROME)
    page = browser.new_page(viewport={"width": 1440, "height": 900})

    body = visit(page, "/forecast", "audit-forecast")
    assert "Single grid cell" in body and "including Cuttack and Puri" in body
    with page.expect_download() as dl:
        page.get_by_text("Export CSV", exact=True).first.click()
    dl.value.save_as("/tmp/audit-forecast.csv")
    lines = open("/tmp/audit-forecast.csv").read().strip().split("\n")
    srcs = [l.split(",")[-1] for l in lines[1:]]
    results["audit-forecast-csv"] = {"rows": len(lines) - 1, "model": srcs.count("model"), "demo": srcs.count("demo")}
    print(f"CSV: {len(lines)-1} rows, model={srcs.count('model')} demo={srcs.count('demo')}")

    visit(page, "/flood-intelligence", "audit-flood")
    visit(page, "/overview", "audit-overview", wait_ms=20000)
    visit(page, "/map", "audit-map")
    body = visit(page, "/data-sources", "audit-data-sources")
    assert "Live observation feeds" in body and "Archive" in body
    print("data-sources: Live observation feeds present, Archive present")

    # simulator run
    page.goto(f"{BASE}/simulator", wait_until="networkidle")
    page.wait_for_timeout(8000)
    page.get_by_text("Run Simulation", exact=True).first.click()
    page.wait_for_timeout(5000)
    body = page.locator("body").inner_text()
    results["audit-simulator"] = {"result_visible": "No simulation run yet" not in body}
    print("simulator result visible:", results["audit-simulator"]["result_visible"])

    browser.close()

with open(f"{OUT}/spot_results.json", "w") as f:
    json.dump(results, f, indent=2)
print("WROTE spot_results.json")
