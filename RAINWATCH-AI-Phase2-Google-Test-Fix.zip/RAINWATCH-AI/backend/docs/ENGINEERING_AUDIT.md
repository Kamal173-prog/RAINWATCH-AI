# RAINWATCH AI — Engineering Audit (2026-11-24)

Short audit before the test/robustness work. Everything below was read from
the code, not assumed. Frontend section filled in after the parallel
frontend audit.

## 1. Stack and layout

- **Backend:** FastAPI 0.115.6 + Uvicorn, Pydantic 2. `backend/app/main.py`
  (322 lines), engines in `backend/app/engine/` (rainfall, risk, weather,
  history, maps, alerts, simulator, datasources, locations, demo_state,
  rng), `backend/app/model_service.py` (model loading + status),
  `backend/ml/predict.py` (forecaster), `backend/ml/features*.py`.
  ML: XGBoost 3.4.1, LightGBM 4.7.0, scikit-learn 1.9.1, pandas 3.1.1,
  numpy 2.5.5, joblib. `backend/requirements.txt` (11 lines).
- **Frontend:** React 19 + Vite 8 + TypeScript 7, Tailwind 4, Recharts,
  Leaflet, react-router-dom 7. Pages in `hackathon/src/pages/` (11 pages).
  `hackathon/src/services/dataService.ts` mirrors every API route; on API
  failure it falls back to local demo computation and stamps
  `source: "demo"` (Stage 5).
- **Data:** `backend/data/processed/bhubaneswar_weather.csv` (ERA5 archive,
  hourly 2021–2025, 43,824 records); model artifacts in
  `backend/models/rainfall_xgb_v3{,_1,_2,_3}`; research data in
  `backend/data/research/`; docs in `backend/docs/` (MODEL_REPORT §§1–14,
  V31/V32/V33 series, IMD validation, AIKosh audit).
- **No version control:** the workspace is not a git repository.
- **No test suite:** zero pytest files for RAINWATCH AI (only
  `backend/ml/test_stacking.py`, an ad-hoc script, and the unrelated
  Ghostwriter project's tests). pytest/httpx were not installed
  (installed 2026-11-24 for this work: pytest 9.2.0, httpx 0.28.1).

## 2. API surface (actual, from `app/main.py`)

22 routes: 20 GET + 2 POST. API version 1.3.0.

| Method | Path | Notes |
|---|---|---|
| GET | `/api/health` | status, dataset block, `model` status block |
| GET | `/api/locations` | 21 locations |
| GET | `/api/weather`, `/api/weather/current` | demo series |
| GET | `/api/forecast`, `/api/forecast/intensity` | hours must be in (3,6,12,24,48,72) |
| GET | `/api/risk/records`, `/api/risk/summary`, `/api/risk/all` | horizonH in (6,24,72); level validated |
| GET | `/api/alerts`, `/api/alerts/upcoming` | 16 seeded demo alerts |
| GET | `/api/history/daily|monthly|annual|peaks|comparison` | real ERA5 for Bhubaneswar region, demo for Ganjam |
| GET | `/api/map/layers`, `/api/map/regions` | synthetic polygons |
| GET | `/api/data-sources` | static catalogue |
| GET | `/api/overview` | KPI bundle incl. forecast + risk |
| POST | `/api/simulate` | `SimulatorInputs` (pydantic bounds) |
| POST | `/api/demo/refresh` | bumps demo tick |

**Endpoint-name discrepancy (flagged, not fixed):** the task brief names
`/api/simulations/run` and `/api/simulations/compare`. **Neither exists.**
The real simulator endpoint is `POST /api/simulate` and there is no
compare endpoint at all. The test suite covers the real surface
(`/api/simulate`, `/api/overview`); adding `/api/simulations/*` would be
a product decision, not a test fix — left open for Kam.

## 3. Model selection and provenance (verified behaviour)

- `MODEL_VERSION` env flag (`app/model_service.py`): `rainfall-xgb-v3`
  (default/production), `rainfall-xgb-v3.2` (benchmark),
  `rainfall-xgb-v3.3` (demo). Any other value, or a v3.2/v3.3 load
  failure, falls back to v3. The reported version always comes from the
  actually loaded forecaster — verified live (bad flag → v3 served and
  reported as v3).
- v3.3 frozen artifacts: **15/15 SHA-256 hashes match
  `RELEASE_MANIFEST.json`** (checked 2026-11-24, before and after the
  demo work). Thresholds: v3.3 uses `thresholds_optimized.json`
  (2024+2025); `thresholds.json` is the freeze record.
- Regressors/P90 are shared across v3/v3.2/v3.3 (always loaded from v3);
  versions differ only in classifiers.
- Forecast: hours 1–6 `source: "model"` + `model_version` + `model` detail
  (Bhubaneswar region only); hours 7+ and all Ganjam `source: "demo"`.
  Risk: offsets 0/3/6 `source: "model"` (Bhubaneswar region); else demo.
  Frontend resolver (`src/utils/source.ts`): MODEL only when
  `source === "model"`; `model_version` alone never promotes;
  missing/unknown → UNKNOWN.
- Model loads lazily on first use (not at startup); the first request can
  take ~10–30 s. `/api/health` triggers the load.

## 4. Data flow

ERA5 CSV → `history.py` (daily/monthly/annual/peaks) and
`model_service.get_model_detail()` (via `ml/features.py` + `predict.py`)
→ `rainfall.py` forecast points / `risk.py` risk records → API →
frontend `dataService` (API-first, local demo fallback) → pages.
Demo-only engines (weather, maps, alerts, simulator) are deterministic
seeded-LCG formulas ported from the frontend's `src/data/*` modules, so
API and local fallback agree for the same demo tick. Demo tick is
process-global, in-memory, bumped by `POST /api/demo/refresh`.

## 5. Frontend

Merged from the parallel read-only frontend audit (2026-11-24) plus the
Stage 6 verification and fixes below. All fixes were verified live
against the v3.3 demo server (API :8001, vite :5173) unless noted.

**Shared infrastructure**
- `src/services/dataService.ts` is the only file with `fetch()` calls.
  `viaApi` silently swallows all errors and falls back to local demo
  computation — the UI never knew the backend was down. **Fixed (Stage
  6):** the Topbar clock dot now reflects `GET /api/health` via a new
  `demoApi.fetchHealth()` (no demo fallback; null = unreachable). Green
  = model loaded, amber = backend unreachable, tooltip names the API
  version and serving model version.
- Provenance stamping is inconsistent: only `fetchForecast`,
  `fetchRiskRecords`, `fetchRiskSummary`, `fetchAllRiskRecords` pass
  `stampDemoSource: true`. Other fetchers' local-fallback values carry
  no `source` field, so `resolveSource()` returns `unknown` for them —
  honest, but the CSVs on Historical and Live Weather had no Source
  column at all. **Fixed:** both CSVs now carry one (Historical:
  `era5-archive`/`demo` by location; Live Weather: constant `demo`,
  because the weather series is demo-generated for every location).
- `fetchOverview` hardcodes a fake activity feed ("Radar mosaic
  ingested", "Sample station telemetry validated", …). The UI labels
  the card "Demo data pipeline events", so it is presented as demo
  content, not real telemetry — left as is.
- Dead code: `fetchUpcomingAlerts` and `fetchCurrentWeather` are
  defined but never called. `dataService.ts` header comment "Everything
  returned here is SIMULATED DEMO DATA" is stale (viaApi calls the
  backend first) — left, it is a comment, not UI.

**Per page (audit finding → Stage 6 outcome)**
- **Overview:** MODEL forecast values appeared with no badge and a
  static DEMO header; "Live scan" label; "Last updated" showed
  page-open time. **Fixed:** header now shows `SourceMixBadge` from
  the bundle forecast plus a `Model: rainfall-xgb-v3.3` badge, "Demo
  scan", and no fake update time.
- **Rainfall Forecast:** best provenance in the app (mix badge, Source
  table column, Source CSV column, dynamic model footer). Charts and
  the summary strip still plot mixed MODEL+DEMO values without
  distinction — known limitation, charts were not redesigned.
- **Flood Intelligence:** per-record provenance correct. **Data bug
  fixed:** "Population potentially affected" summed `populationAtRisk`
  across ~25 hourly rows per location (~25× overcount). It now sums
  the peak per location; footnote says so. KPI strip and charts still
  aggregate mixed records without badges — known limitation.
- **Alerts:** `fetchAlerts()` was called and its return value
  discarded; the list is purely local (`SAMPLE_ALERTS` +
  localStorage). **Fixed:** the dead fetch was removed. The page is
  honestly labelled demo alerts; wiring it to `/api/alerts` is an open
  follow-up, not done here.
- **Historical Analysis:** three bugs fixed — (1) the default date
  range ended today while the real archive ends 2025-12-31, so the
  trend chart, summary cards and CSV export were empty for
  Bhubaneswar-region locations (now the range clamps to the loaded
  data; Reset does the same); (2) the trend chart rendered at 0 px
  (Recharts `ResponsiveContainer height="100%"` inside a flex-column
  card with no definite height — now an explicit `height={340}`);
  (3) the "All locations" filter was a no-op (data is always for one
  location) — the option was removed. Subtitle, header badge and
  footer are now location-aware (ERA5 archive vs demo generator).
- **Simulator:** copy claimed "entirely in the browser" / "Client-side
  demo calculation" / "local calc", but `runSimulation` POSTs
  `/api/simulate` when the backend is up. **Fixed:** subtitle, badge
  and result card now say "demo calculation" / "demo formula, not the
  ML model". The backend `/api/simulate` is itself a deterministic
  demo formula, not the ML model.
- **Inundation Map:** subtitle and legend are honest (synthetic
  geometry). The simulator overlay card had no DEMO badge — **fixed**
  (`DemoBadge compact` added). KPIs have no per-value badges
  (`RegionCondition` has no `source` field).
- **Live Weather:** presented demo series as "Current surface
  observations" / "Observed rainfall intensity" / "Station sample".
  **Fixed** to demo wording throughout; CSV gained a Source column.
- **Data Sources:** subtitle, banner and "Live connections: 0" all
  asserted no backend was connected. **Fixed:** copy rewritten for
  the integrated build; a `Live` status was added to the enum and the
  Historical Rainfall Records row now reports `Live`; summary cards
  are computed from the API with no invented fallbacks (7 / 1 / 2 / 2).
- **Settings:** "No external data source is connected" and "AI models
  and APIs are intentionally out of scope" — **fixed** to describe the
  integrated backend. **Control bug fixed:** the "Bell status" toggle
  was bound to `notificationsEnabled && severityPrefs.length > 0`
  while its onChange only flipped `notificationsEnabled`, so it looked
  unresponsive with zero severities selected; it now reflects the
  setting itself.
- **Landing:** "v2.6" tag, "Zero backend dependencies", "Nothing
  external connected", "Every module runs entirely in your browser",
  "Seven connected views" vs "Ten working modules", and hardcoded
  telemetry plates presented as live readings. **Fixed:** version tag
  is now API v1.3.0, backend claims rewritten, plates labelled SAMPLE,
  "SCANNING 14 SECTORS" → "21 MONITORING ZONES", module count unified
  at ten.
- **ML scope (verified live):** `/api/forecast` returns 6 MODEL + 18
  DEMO points for Cuttack and Puri as well as Old Town — the single
  Bhubaneswar grid-cell model is applied region-wide to 14 locations
  and the frontend badges each location's values MODEL. That matches
  the API contract, but a viewer can reasonably read it as a per-city
  model. The only in-app hints are the Forecast footer ("for the
  Bhubaneswar grid cell") and the health `scope` field. See
  KNOWN_LIMITATIONS.md. No "statewide"/"Odisha-wide" claims exist in
  `src/`; "real-time" appears only in a disclaimer.

## 6. Findings, debt and risks

1. **No tests, no CI, no git.** The whole test suite in this task is new.
2. **Missing endpoints named in the brief** (§2) — `/api/simulations/*`.
3. **Unbounded per-tick caches:** `rainfall.py` `_cache` /
   `_forecast_cache`, `history.py` `_daily_demo_cache`,
   `weather.py` `_cache` grow one entry per location per demo tick and
   are never evicted. Ticks only bump on manual refresh, so this is
   minor — but a long demo session with many refreshes grows memory.
4. **CORS allow-list is only `:5173`** (`config.py` default). Any other
   dev/preview origin silently falls back to labelled DEMO in the
   frontend. The demo MUST run on 5173.
5. **First-request model load** (~10–30 s) can exceed short client
   timeouts; `/api/health` is the trigger. No separate lightweight
   liveness probe exists.
6. **Stale docstrings:** `risk.py` header says "rainfall-xgb-v1";
   `main.py` description still names v3 as the model (true for the
   default, but the flag can serve v3.2/v3.3).
7. **`datasources.py` "history" status — FIXED in Stage 6.** A `Live`
   status was added to the enum (`schemas.py`, frontend type,
   `DataSources.tsx` map) and the Historical Rainfall Records row now
   reports `Live`; the summary cards are computed from the API. The
   ML model itself is not a row in that list (it is a consumer of the
   sources), so "Live connections" is now the count of Live rows (1),
   not a claim about the model.
8. **`history.py` caches "CSV missing" forever** (`_daily_cache = {}`):
   if the archive file appears later, the process must restart to pick
   it up (same for the model: `.env` is read only at startup).
9. **No `response_model=` on any route** — response shapes are not
   enforced by FastAPI; the tests validate shapes instead.
10. **Frontend toolchain quirks:** `node_modules` ships Windows native
    binaries (run `npm install --no-save --no-package-lock` once on
    Linux); the `vite` shim in `node_modules/.bin` is not executable
    (run via `node node_modules/vite/bin/vite.js`).
11. **Ganjam/Brahmapur archive still not fetched** (Open-Meteo HTTP 429,
    twice 2026-11-23) — Ganjam history stays demo. `fetch_brahmapur.py`
    to retry.
12. **`get_model_status()` loaded:false block hardcodes
    `model_version: "rainfall-xgb-v3"`** alongside `loaded: false` and an
    `error` field. Predictions then fall back to demo (DEMO badges), so
    nothing is mislabelled — but the label is a placeholder, not the
    attempted version.
13. **`MODEL_HORIZON_MAE` is v3-only** but feeds the indicative confidence
    for all versions (cosmetic; documented as a heuristic).
14. **Demo tick is in-memory and process-global** — a server restart
    resets it to 0; refresh state does not survive restarts.
15. **`.env.example` sets `MODEL_VERSION=rainfall-xgb-v3` explicitly**
    while the live `.env` has none — both resolve to v3, but the example
    invites copying a value that then looks "set".
