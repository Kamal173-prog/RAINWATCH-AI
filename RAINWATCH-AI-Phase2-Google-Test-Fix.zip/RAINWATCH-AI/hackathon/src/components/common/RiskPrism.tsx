import type { CSSProperties } from 'react'

/**
 * 3D risk prism: the cube's orientation is driven by the scenario risk
 * index while a slow CSS drift keeps it feeling like a live instrument.
 * Decorative companion to the numeric risk readout (never replaces it).
 */
export function RiskPrism({ riskIndex, color }: { riskIndex: number; color: string }) {
  const style = {
    '--prism-x': `${-16 - riskIndex / 6}deg`,
    '--prism-y': `${18 + riskIndex * 1.5}deg`,
    '--prism-color': color,
  } as CSSProperties

  return (
    <div className="instrument-stage flex h-28 w-28 shrink-0 items-center justify-center" aria-hidden>
      <div className="prism" style={style}>
        <span className="prism__face prism__face--front" />
        <span className="prism__face prism__face--back" />
        <span className="prism__face prism__face--right" />
        <span className="prism__face prism__face--left" />
        <span className="prism__face prism__face--top" />
        <span className="prism__face prism__face--bottom" />
        <span
          className="num absolute inset-0 flex items-center justify-center text-xl font-bold"
          style={{ color, transform: 'translateZ(39px)' }}
        >
          {Math.round(riskIndex)}
        </span>
      </div>
    </div>
  )
}
