# RAINWATCH AI — System Architecture

## Stack

| Layer | Technology |
|---|---|
| Backend | FastAPI (Python 3.12), Uvicorn, pandas, XGBoost + LightGBM + HistGradientBoosting (scikit-learn) |
| Frontend | React 19 + Vite 8 + TypeScript 7, Tailwind 4, Recharts, Leaflet, Framer Motion |
| Data | Open-Meteo ERA5 archive (CSV, Bhubaneswar grid cell), GFS forecast archive (CSV, used by v3.2/v3.3 classifiers), IMD daily gridded rainfall (research only, `data/research/`) |
| Tests | pytest + httpx (backend); Playwright probes (frontend, no unit suite) |

There is no database. There is no git repository and no CI. State is
files on disk plus in-memory caches.

## Repository layout

```
backend/
  app/
    main.py            # all 22 routes, CORS, health
    model_service.py   # lazy forecaster load, MODEL_VERSION selection, health model block
    schemas.py         # Pydantic models (incl. DataSource status enum)
    core/config.py     # settings: CORS origins, CSV paths, MODEL_VERSION default
    engine/            # one module per domain, all deterministic
      rainfall.py      # forecast series (model points + demo fallback)
      risk.py          # flood-risk records / susceptibility index
      history.py       # daily/monthly/annual/peaks/comparison (real CSV or demo)
      weather.py       # demo weather series (no observations feed)
      maps.py          # map layers / region conditions
      locations.py     # 21 locations, 14 Bhubaneswar-region + 7 Ganjam
      alerts.py        # seed alerts (the Alerts page does NOT use these — see below)
      datasources.py   # the 7 data-source rows
      simulator.py     # deterministic what-if formula (NOT the ML model)
      demo_state.py    # process-global demo tick
      rng.py           # seeded RNG so API and local fallback agree per tick
    routers/           # (present; routes live in main.py)
  ml/
    predict.py         # forecaster: loads a model dir, predicts 1/3/6h
    features.py        # 41-feature v3 table (tz-naive IST wall-clock)
    features_v33.py    # 94-feature v3.3 table
    evaluate_2026.py   # reserved-2026 evaluation (do not use for selection)
    validate_imd_daily.py  # IMD daily validation experiment
    probe_*.py         # Playwright integration probes (not product code)
  models/
    rainfall_xgb_v3/       # production v3 artifacts
    rainfall_xgb_v3_2/     # v3.2 benchmark artifacts
    rainfall_xgb_v3_3/frozen/  # v3.3 frozen artifacts + RELEASE_MANIFEST.json
  data/
    processed/locations/   # ERA5 (+GFS) per-location feature tables
    research/              # IMD gridded rainfall + audit (not served)
  tests/                   # pytest suite, 151 tests
  docs/                    # this file and the other Stage 6 docs
hackathon/
  src/
    pages/         # 12 routes (Landing, Overview, LiveWeather, RainfallForecast,
                   #   FloodIntelligence, InundationMap, Simulator, Alerts,
                   #   HistoricalAnalysis, DataSources, Settings, NotFound)
    services/dataService.ts   # the only file with fetch(); viaApi + local fallback
    utils/source.ts           # resolveSource / summarizeSources (Stage 5)
    components/common/Badge.tsx  # SourceBadge / SourceMixBadge / DemoBadge
    context/       # DemoContext (demo tick), LocationContext, AlertsContext,
                   #   SettingsContext (localStorage)
    data/          # local demo datasets (locations, alerts seeds, map layers)
```

## Request flow

```
Browser (:5173) ── VITE_API_URL ──► FastAPI (:8000 v3 / :8001 v3.3)
  │                                     │
  │  viaApi(path, fallback)             │  engine modules
  │   ├─ API answers → use it as-is    │   ├─ model points: predict.py
  │   └─ API fails → local demo calc    │   └─ demo points: seeded RNG
  │      (stamped source: "demo"        │
  │       for forecast/risk only)       └─► CSVs on disk / in-memory caches
```

- The frontend never calls `/api/health` except through the Topbar
  health dot (`demoApi.fetchHealth()`, no fallback).
- `POST /api/demo/refresh` bumps the process-global demo tick; the
  frontend's "Refresh Demo Data" button calls it, then reloads.
- The Alerts page does **not** use `/api/alerts`: it renders
  `SAMPLE_ALERTS` from `AlertsContext` (localStorage). The backend
  alerts endpoint exists and is tested, but nothing displays it.

## Model loading and version selection

- The forecaster loads **lazily on first request** (~10 s cold start
  measured 2026-11-24). `/api/health` is the trigger; the first call
  can exceed a 5 s client timeout, so warm the server before the demo.
- `MODEL_VERSION` is read from the environment at startup
  (`model_service.py`). Values: `rainfall-xgb-v3` (default),
  `rainfall-xgb-v3.2`, `rainfall-xgb-v3.3`. Anything else (including a
  typo) falls back to v3 and **reports v3** — never a v3.3 label over
  v3 predictions.
- The served label always comes from the actually-loaded forecaster's
  `model_version`, not from the flag. If v3.3 cannot load, the service
  loads v3 and says so.
- **Regressors are shared across v3/v3.2/v3.3** (always loaded from
  v3); versions differ only in their classifiers. Expected rainfall
  amounts are therefore identical across versions; only the
  heavy-rain probabilities and risk tiers differ.
- The model predicts for **one ERA5 grid cell (Bhubaneswar)** only.
  All 14 non-Ganjam locations share that cell's forecast; the 7
  Ganjam locations always get demo values. This is by design (one
  archive cell), not a bug — but see KNOWN_LIMITATIONS.md for how it
  reads on the Cuttack/Puri pages.

## Caching

- Forecast/risk/map responses are cached per (demo tick,
  `MODEL_VERSION_ENV`) — the version key was added in Stage 6 after
  the suite caught stale-label serving across version switches.
- Per-tick caches grow one entry per location per demo tick and are
  never evicted (minor: ticks only bump on manual refresh).
- `history.py` caches "CSV missing" forever (`_daily_cache = {}`):
  if the archive file appears later, restart the process.
- `.env` is read once at startup; changing it needs a restart.

## CORS

Allow-list is `http://localhost:5173,http://127.0.0.1:5173`
(`core/config.py` default). Any other origin gets no
`Access-Control-Allow-Origin` header, so the frontend silently falls
back to labelled DEMO. **The demo must run on :5173.** The map page
also needs internet for OpenStreetMap base tiles (overlays render
without them).

## Environment variables

| Variable | Meaning |
|---|---|
| `MODEL_VERSION` | Model to serve: `rainfall-xgb-v3` (default), `rainfall-xgb-v3.2`, `rainfall-xgb-v3.3`. The live `backend/.env` has none (default v3). |
| `BHUBANESWAR_CSV` | Path to the Bhubaneswar archive CSV. Missing file → health `dataset.loaded=false`, history falls back to demo rows. |
| `VITE_API_URL` | Frontend: backend base URL (demo: `http://localhost:8001` for v3.3, `http://localhost:8000` for v3). Unset → frontend-only demo mode. |

## Startup (exact commands)

```bash
# Production (v3, port 8000)
cd backend && .venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port 8000

# Hackathon demo (v3.3, port 8001) — warm it, then check health before presenting
cd backend && MODEL_VERSION=rainfall-xgb-v3.3 .venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port 8001
curl --max-time 30 http://127.0.0.1:8001/api/health   # wait for "loaded": true

# Frontend (must be :5173)
cd hackathon && VITE_API_URL=http://localhost:8001 node node_modules/vite/bin/vite.js --port 5173
```

Rollback from the demo is stopping the :8001 server; production on
:8000 is never touched by the demo run.
