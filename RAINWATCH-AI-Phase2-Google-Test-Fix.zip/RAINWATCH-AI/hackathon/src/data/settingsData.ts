import type { AlertSeverity, AppSettings } from '../types'
import { DEFAULT_LOCATION_ID } from './locationsData'
import { SEVERITY_ORDER } from '../utils/colors'

export interface AccentOption {
  id: string
  name: string
  primary: string
  secondary: string
  /** Darker variants used when the light theme is active (contrast). */
  onLight: string
  onLightSecondary: string
}

/** Signal-first palette. Default is the instrument lime, not generic AI blue. */
export const ACCENT_OPTIONS: AccentOption[] = [
  { id: 'signal', name: 'Signal', primary: '#CDE34B', secondary: '#6FD6C2', onLight: '#5C7410', onLightSecondary: '#0C7A6B' },
  { id: 'amber', name: 'Amber', primary: '#F2A93B', secondary: '#F5C878', onLight: '#9A5B05', onLightSecondary: '#A35C12' },
  { id: 'teal', name: 'Teal', primary: '#6FD6C2', secondary: '#A5E8DA', onLight: '#0B7465', onLightSecondary: '#147D70' },
  { id: 'ember', name: 'Ember', primary: '#F05A43', secondary: '#F49072', onLight: '#A92818', onLightSecondary: '#AB3A22' },
  { id: 'violet', name: 'Violet', primary: '#B19BFA', secondary: '#D4C7FF', onLight: '#5B3CB5', onLightSecondary: '#6849C4' },
  { id: 'steel', name: 'Steel', primary: '#A8BCC4', secondary: '#D2E0E5', onLight: '#3B5561', onLightSecondary: '#45616D' },
]

export const DEFAULT_SETTINGS: AppSettings = {
  theme: 'dark',
  accent: 'signal',
  density: 'comfortable',
  defaultLocationId: DEFAULT_LOCATION_ID,
  defaultTimeframe: '24h',
  defaultMapLayers: ['rainfall', 'riskZones', 'inundation', 'vulnerable', 'stations', 'scenario'],
  units: 'metric',
  notificationsEnabled: true,
  severityPrefs: [...SEVERITY_ORDER] as AlertSeverity[],
}

export function getAccent(id: string): AccentOption {
  return ACCENT_OPTIONS.find((a) => a.id === id) ?? ACCENT_OPTIONS[0]
}

export const TIMEFRAME_OPTIONS = [
  { id: '3h', label: 'Next 3 hours', hours: 3 },
  { id: '6h', label: 'Next 6 hours', hours: 6 },
  { id: '12h', label: 'Next 12 hours', hours: 12 },
  { id: '24h', label: 'Next 24 hours', hours: 24 },
  { id: '48h', label: 'Next 48 hours', hours: 48 },
  { id: '72h', label: 'Next 72 hours', hours: 72 },
] as const

export function timeframeHours(id: string): number {
  return TIMEFRAME_OPTIONS.find((t) => t.id === id)?.hours ?? 24
}
