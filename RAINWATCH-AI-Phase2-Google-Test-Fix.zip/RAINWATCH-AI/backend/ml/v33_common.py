"""Shared utilities for the rainfall-v3.3 experiments.

Covers: the classifier factory (v3.2 fixed hyperparameters), Platt
calibration, F-beta threshold optimisation, hour-level + event-level
metrics (storm detection rate, detection lead time, false alarms per
day), and the focal-loss custom objective for XGBoost.

Chronological discipline (non-negotiable):
- No random shuffling of sequential weather observations. All splits
  are chronological (expanding-window CV inside 2021-2024; 2025 is the
  benchmark; 2026 is the fresh evaluation, never used for selection).
- Resampling / reweighting is applied INSIDE training folds only, never
  to validation, benchmark or fresh-evaluation data.
- Every feature used at prediction time t is computed from data with
  valid time <= t (0-hour-lead GFS analysis values, or Previous-Runs
  forecasts whose init time = valid time - lead <= t).
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, brier_score_loss, roc_auc_score
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier
from lightgbm import LGBMClassifier
from xgboost import XGBClassifier

SEED = 42
TARGETS = ("y_3h_ge_10mm", "y_6h_ge_10mm", "y_3h_ge_5mm")
FAMILIES = ("xgb", "lgbm", "hgb")

# v3.2 fixed hyperparameters (from ml/train_rainfall_v32.py BEST_PARAMS).
BEST_PARAMS = {
    "y_3h_ge_10mm": {
        "xgb": {"max_depth": 4, "learning_rate": 0.05, "n_estimators": 300,
                "subsample": 0.8, "colsample_bytree": 0.8, "min_child_weight": 3,
                "reg_lambda": 10.0},
        "lgbm": {"max_depth": 4, "learning_rate": 0.05, "n_estimators": 300,
                 "subsample": 0.8, "colsample_bytree": 0.8, "min_child_samples": 30,
                 "reg_lambda": 10.0},
        "hgb": {"max_depth": 2, "learning_rate": 0.1, "max_iter": 300,
                "min_samples_leaf": 40, "l2_regularization": 20.0},
    },
    "y_6h_ge_10mm": {
        "xgb": {"max_depth": 5, "learning_rate": 0.1, "n_estimators": 300,
                "subsample": 0.9, "colsample_bytree": 0.9, "min_child_weight": 1,
                "reg_lambda": 5.0},
        "lgbm": {"max_depth": 5, "learning_rate": 0.1, "n_estimators": 300,
                 "subsample": 0.9, "colsample_bytree": 0.9, "min_child_samples": 20,
                 "reg_lambda": 5.0},
        "hgb": {"max_depth": 3, "learning_rate": 0.1, "max_iter": 300,
                "min_samples_leaf": 20, "l2_regularization": 5.0},
    },
    "y_3h_ge_5mm": {
        "xgb": {"max_depth": 5, "learning_rate": 0.1, "n_estimators": 300,
                "subsample": 0.9, "colsample_bytree": 0.9, "min_child_weight": 1,
                "reg_lambda": 5.0},
        "lgbm": {"max_depth": 5, "learning_rate": 0.1, "n_estimators": 300,
                 "subsample": 0.9, "colsample_bytree": 0.9, "min_child_samples": 20,
                 "reg_lambda": 5.0},
        "hgb": {"max_depth": 3, "learning_rate": 0.1, "max_iter": 300,
                "min_samples_leaf": 20, "l2_regularization": 5.0},
    },
}


def make_classifier(family: str, params: dict, pos_weight: float):
    """One classifier member. ``pos_weight`` = neg/pos in the training fold."""
    if family == "xgb":
        return XGBClassifier(
            max_depth=params["max_depth"], learning_rate=params["learning_rate"],
            n_estimators=params["n_estimators"], subsample=params["subsample"],
            colsample_bytree=params["colsample_bytree"],
            min_child_weight=params["min_child_weight"],
            reg_lambda=params["reg_lambda"], scale_pos_weight=pos_weight,
            eval_metric="logloss", random_state=SEED, n_jobs=-1,
        )
    if family == "lgbm":
        return LGBMClassifier(
            max_depth=params["max_depth"], learning_rate=params["learning_rate"],
            n_estimators=params["n_estimators"], subsample=params["subsample"],
            colsample_bytree=params["colsample_bytree"],
            min_child_samples=params["min_child_samples"],
            reg_lambda=params["reg_lambda"],
            class_weight={0: 1.0, 1: pos_weight},
            random_state=SEED, n_jobs=-1, verbose=-1,
        )
    return HistGradientBoostingClassifier(
        max_depth=params["max_depth"], learning_rate=params["learning_rate"],
        max_iter=params["max_iter"], min_samples_leaf=params["min_samples_leaf"],
        l2_regularization=params["l2_regularization"],
        class_weight={0: 1.0, 1: pos_weight}, random_state=SEED,
    )


# ----------------------------------------------------------------------
# Focal loss (XGBoost custom objective)
# ----------------------------------------------------------------------
def focal_objective(alpha: float = 0.25, gamma: float = 2.0):
    """Binary focal loss FL = -a(1-p)^g log p (y=1), -(1-a) p^g log(1-p) (y=0).

    Gradients / Hessians are w.r.t. the margin z (p = sigmoid(z)):
      y=1: g = a(1-p)^g (g p ln p + p - 1)
           h = a p (1-p)^g [-g (g p ln p + p - 1) + (1-p)(g ln p + g + 1)]
      y=0: g = (1-a) p^g (p - g (1-p) ln(1-p))
           h = (1-a) p^g (1-p) [g (p - g (1-p) ln(1-p)) + p (1 + g + g ln(1-p))]
    Verified: at gamma=0 the gradients reduce to the weighted logistic
    gradients (g = -a(1-p) for y=1, g = (1-a) p for y=0) and the Hessians
    to a p (1-p) / (1-a) p (1-p). Probabilities are clipped for stability.
    """
    def _obj(y_true: np.ndarray, y_pred: np.ndarray):
        p = 1.0 / (1.0 + np.exp(-np.clip(y_pred, -30, 30)))
        p = np.clip(p, 1e-6, 1 - 1e-6)
        y = y_true.astype(float)
        logp = np.log(p)
        log1p = np.log(1 - p)
        g = np.where(
            y == 1,
            alpha * (1 - p) ** gamma * (gamma * p * logp + p - 1),
            (1 - alpha) * p ** gamma * (p - gamma * (1 - p) * log1p),
        )
        h = np.where(
            y == 1,
            alpha * p * (1 - p) ** gamma * (
                -gamma * (gamma * p * logp + p - 1) + (1 - p) * (gamma * logp + gamma + 1)
            ),
            (1 - alpha) * p ** gamma * (1 - p) * (
                gamma * (p - gamma * (1 - p) * log1p) + p * (1 + gamma + gamma * log1p)
            ),
        )
        # Hessian must stay positive for XGBoost; clip tiny/negative values.
        h = np.clip(h, 1e-6, None)
        return g, h
    return _obj


def make_xgb_focal(params: dict, alpha: float = 0.25, gamma: float = 2.0):
    """XGBoost classifier with the focal-loss custom objective.

    Note: with a custom objective, scale_pos_weight is NOT used (the
    alpha parameter already balances the classes); the base margin is
    the raw logit, so predict_proba still returns calibrated-ish
    probabilities that are then Platt-calibrated like the other members.
    """
    return XGBClassifier(
        max_depth=params["max_depth"], learning_rate=params["learning_rate"],
        n_estimators=params["n_estimators"], subsample=params["subsample"],
        colsample_bytree=params["colsample_bytree"],
        min_child_weight=params["min_child_weight"],
        reg_lambda=params["reg_lambda"],
        objective=focal_objective(alpha=alpha, gamma=gamma),
        eval_metric="logloss", random_state=SEED, n_jobs=-1,
    )


# ----------------------------------------------------------------------
# Calibration
# ----------------------------------------------------------------------
def _sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-np.clip(x, -500, 500)))


def platt_fit(p_raw: np.ndarray, y: np.ndarray) -> tuple[float, float]:
    eps = 1e-6
    p = np.clip(p_raw, eps, 1 - eps)
    logit = np.log(p / (1 - p)).reshape(-1, 1)
    lr = LogisticRegression(C=1.0, solver="lbfgs", max_iter=1000)
    lr.fit(logit, y)
    return float(lr.coef_[0][0]), float(lr.intercept_[0])


def platt_apply(p_raw: np.ndarray, w: float, b: float) -> np.ndarray:
    eps = 1e-6
    p = np.clip(p_raw, eps, 1 - eps)
    return _sigmoid(w * np.log(p / (1 - p)) + b)


# ----------------------------------------------------------------------
# Threshold optimisation
# ----------------------------------------------------------------------
def fbeta(precision: float, recall: float, beta: float) -> float:
    b2 = beta * beta
    return (1 + b2) * precision * recall / max(1e-9, b2 * precision + recall)


def threshold_for_fbeta(y: np.ndarray, p: np.ndarray, beta: float,
                        recall_floor: float = 0.0) -> tuple[float, float, float]:
    """Threshold maximising F-beta, optionally subject to a recall floor.

    Returns (threshold, precision, recall). Scans 0.01..0.95 in 0.01 steps.
    """
    best = (0.5, 0.0, 0.0, -1.0)  # threshold, precision, recall, score
    for t in np.arange(0.01, 0.96, 0.01):
        pred = p >= t
        tp = int(((y == 1) & pred).sum())
        fp = int(((y == 0) & pred).sum())
        fn = int(((y == 1) & ~pred).sum())
        rec = tp / max(1, tp + fn)
        prec = tp / max(1, tp + fp)
        if rec < recall_floor:
            continue
        score = fbeta(prec, rec, beta)
        if score > best[3]:
            best = (float(t), float(prec), float(rec), float(score))
    return best[0], best[1], best[2]


def precision_at_recall(y: np.ndarray, p: np.ndarray, target_recall: float) -> float:
    """Max precision achievable at recall >= target (scanning thresholds)."""
    best = 0.0
    for t in np.arange(0.01, 0.96, 0.01):
        pred = p >= t
        tp = int(((y == 1) & pred).sum())
        fp = int(((y == 0) & pred).sum())
        fn = int(((y == 1) & ~pred).sum())
        rec = tp / max(1, tp + fn)
        if rec >= target_recall:
            best = max(best, tp / max(1, tp + fp))
    return best


def recall_at_precision(y: np.ndarray, p: np.ndarray, target_precision: float) -> float:
    """Max recall achievable at precision >= target (scanning thresholds)."""
    best = 0.0
    for t in np.arange(0.01, 0.96, 0.01):
        pred = p >= t
        tp = int(((y == 1) & pred).sum())
        fp = int(((y == 0) & pred).sum())
        fn = int(((y == 1) & ~pred).sum())
        prec = tp / max(1, tp + fp)
        if prec >= target_precision:
            best = max(best, tp / max(1, tp + fn))
    return best


# ----------------------------------------------------------------------
# Hour-level + event-level metrics
# ----------------------------------------------------------------------
def _events(arr: np.ndarray) -> list[tuple[int, int]]:
    """Contiguous blocks of 1s as (start_idx, end_idx) inclusive."""
    ev, start = [], None
    for i, v in enumerate(arr):
        if v == 1 and start is None:
            start = i
        elif v == 0 and start is not None:
            ev.append((start, i - 1))
            start = None
    if start is not None:
        ev.append((start, len(arr) - 1))
    return ev


def _events_merged(arr: np.ndarray, max_gap_h: int = 6) -> list[tuple[int, int]]:
    """Blocks of 1s merged across gaps of <= max_gap_h hours (storm level)."""
    blocks = _events(arr)
    if not blocks:
        return []
    merged = [list(blocks[0])]
    for s, e in blocks[1:]:
        if s - merged[-1][1] - 1 <= max_gap_h:
            merged[-1][1] = e
        else:
            merged.append([s, e])
    return [(s, e) for s, e in merged]


def hour_metrics(y: np.ndarray, p: np.ndarray, threshold: float) -> dict:
    pred = p >= threshold
    tp = int(((y == 1) & pred).sum())
    fp = int(((y == 0) & pred).sum())
    fn = int(((y == 1) & ~pred).sum())
    tn = int(((y == 0) & ~pred).sum())
    prec = tp / max(1, tp + fp)
    rec = tp / max(1, tp + fn)
    return {
        "threshold": float(threshold), "precision": round(prec, 4),
        "recall": round(rec, 4),
        "f1": round(fbeta(prec, rec, 1.0), 4),
        "f2": round(fbeta(prec, rec, 2.0), 4),
        "f3": round(fbeta(prec, rec, 3.0), 4),
        "tp": tp, "fp": fp, "fn": fn, "tn": tn,
        "alerts_per_100h": round(100.0 * (tp + fp) / max(1, len(y)), 2),
    }


def event_metrics(y: np.ndarray, p: np.ndarray, threshold: float,
                  n_days: float | None = None) -> dict:
    """Event-level metrics at one threshold.

    Hour-block events (strict contiguous, as in v3.2) AND storm-level
    events (blocks merged across gaps <= 6 h). Detection: a predicted
    block overlaps a true block. Lead time: for each detected true
    event, (first true hour + 1) - (first alert hour), i.e. hours
    between the alert being issued and the rain starting; the alert at
    issue hour a predicts the window (a, a+3], and the event's rain
    starts at its first positive hour + 1. An alert counts for an event
    when its window overlaps any of the event's windows, i.e. the alert
    hour a satisfies s-2 <= a <= e+2 for event block [s, e]. Negative
    lead times mean the first alert came after the rain started.
    """
    pred = (p >= threshold).astype(int)
    true = y.astype(int)
    true_ev = _events(true)
    pred_ev = _events(pred)
    hit = 0
    for s, e in true_ev:
        if any(ps <= e and pe >= s for ps, pe in pred_ev):
            hit += 1
    tp_ev = sum(1 for s, e in pred_ev if any(ts <= e and te >= s for ts, te in true_ev))
    out = {
        "n_true_events": len(true_ev),
        "n_pred_events": len(pred_ev),
        "tp_events": hit,
        "event_recall": round(hit / max(1, len(true_ev)), 4),
        "event_precision": round(tp_ev / max(1, len(pred_ev)), 4),
    }
    # Storm level (gap-merged) + lead time.
    true_storms = _events_merged(true, max_gap_h=6)
    pred_storms = _events_merged(pred, max_gap_h=6)
    detected = 0
    leads: list[float] = []
    for s, e in true_storms:
        # Alert hours whose 3 h window overlaps the storm's windows.
        cands = [a for a, _ in pred_ev if s - 2 <= a <= e + 2]
        if cands:
            detected += 1
            leads.append(float((s + 1) - min(cands)))
    out["n_true_storms"] = len(true_storms)
    out["storm_detection_rate"] = round(detected / max(1, len(true_storms)), 4)
    out["detected_storms"] = detected
    out["median_lead_time_h"] = round(float(np.median(leads)), 2) if leads else None
    out["mean_lead_time_h"] = round(float(np.mean(leads)), 2) if leads else None
    out["detected_with_lead_ge_1h"] = int(sum(1 for x in leads if x >= 1))
    if n_days:
        out["false_alarm_hours_per_day"] = round(
            int(((pred == 1) & (true == 0)).sum()) / n_days, 2)
        out["false_alarm_events_per_day"] = round(
            (len(pred_ev) - tp_ev) / n_days, 2)
    return out


def full_eval(y: np.ndarray, p: np.ndarray, thresholds: dict,
              n_days: float | None = None) -> dict:
    """PR-AUC, ROC-AUC, Brier + hour/event metrics at each threshold level."""
    out = {
        "pr_auc": round(float(average_precision_score(y, p)), 4),
        "roc_auc": round(float(roc_auc_score(y, p)), 4),
        "brier": round(float(brier_score_loss(y, p)), 4),
        "levels": {},
    }
    for level, t in thresholds.items():
        out["levels"][level] = {
            **hour_metrics(y, p, t),
            **event_metrics(y, p, t, n_days=n_days),
        }
    return out
