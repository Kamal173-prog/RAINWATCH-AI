import { classifyRainfall } from '../utils/colors'
import { clamp, createRng, hashSeed, round } from '../utils/rng'
import { getDemoTick } from '../services/demoState'
import type { ForecastPoint, RainfallBand } from '../types'
import { getLocation } from './locationsData'
import { RAINFALL_BANDS } from '../utils/colors'

/* ------------------------------------------------------------------
   Core rainfall series engine.
   Generates one deterministic hourly series per location per demo
   "tick" covering -72h … +72h around the current hour.  Every other
   module (weather, flood risk, forecast, map) derives from this, so
   the whole dashboard stays internally consistent.
------------------------------------------------------------------ */

export const PAST_HOURS = 72
export const FUTURE_HOURS = 72

const PAST = 24 * 3

export interface RainfallSeries {
  /** Hour offsets relative to now, -72 … +72 */
  offsets: number[]
  /** mm/hr at each offset */
  mmHr: number[]
}

interface CacheEntry {
  tick: number
  series: RainfallSeries
}

const cache = new Map<string, CacheEntry>()

function gaussian(x: number, mu: number, sigma: number): number {
  const d = (x - mu) / sigma
  return Math.exp(-0.5 * d * d)
}

export function getRainfallSeries(locationId: string): RainfallSeries {
  const tick = getDemoTick()
  const key = `${locationId}:${tick}`
  const hit = cache.get(key)
  if (hit && hit.tick === tick) return hit.series

  const loc = getLocation(locationId)
  const rng = createRng(hashSeed(locationId) ^ Math.imul(tick + 1, 0x9e3779b1))

  // Per-location storm exposure: coastal / low-lying zones amplify.
  const exposure = clamp(0.72 + loc.lowLyingPct / 240 + loc.riverProximity / 420, 0.6, 1.55)

  // Two synoptic events: one that just passed, one inbound.
  const pastPeak = -44 + rng() * 12
  const pastAmp = 24 + rng() * 46
  const pastSigma = 8 + rng() * 6

  const nextPeak = 9 + rng() * 18
  const nextAmp = 34 + rng() * 74
  const nextSigma = 6 + rng() * 7

  const phase1 = rng() * Math.PI * 2
  const phase2 = rng() * Math.PI * 2
  const phase3 = rng() * Math.PI * 2
  const micro = 0.35 + rng() * 0.8

  const offsets: number[] = []
  const mmHr: number[] = []

  for (let h = -PAST; h <= FUTURE_HOURS; h++) {
    const ambient =
      micro * (0.6 + 0.45 * Math.sin(h / 5.5 + phase1) + 0.3 * Math.sin(h / 13 + phase2))
    const showers = 1.5 * Math.max(0, Math.sin(h / 3.1 + phase3)) ** 2
    const past = pastAmp * gaussian(h, pastPeak, pastSigma)
    const next = nextAmp * gaussian(h, nextPeak, nextSigma)
    const raw = (Math.max(0, ambient) + showers + past + next) * exposure
    offsets.push(h)
    mmHr.push(round(clamp(raw, 0, 185), 1))
  }

  const series: RainfallSeries = { offsets, mmHr }
  cache.set(key, { tick, series })
  return series
}

/** Index inside the series for a given hour offset. */
export function offsetIndex(offset: number): number {
  return offset + PAST
}

export function rainfallAt(locationId: string, offset: number): number {
  const series = getRainfallSeries(locationId)
  const i = offsetIndex(offset)
  return series.mmHr[i] ?? 0
}

/* ---------------------------- Forecast ------------------------------ */

const forecastCache = new Map<string, ForecastPoint[]>()

export function getForecastSeries(locationId: string): ForecastPoint[] {
  const tick = getDemoTick()
  const key = `${locationId}:${tick}`
  const cached = forecastCache.get(key)
  if (cached) return cached

  const series = getRainfallSeries(locationId)
  const baseHour = hourAlignedNow()

  const points: ForecastPoint[] = []
  let accumulated = 0

  for (let i = offsetIndex(1); i <= offsetIndex(FUTURE_HOURS); i++) {
    const mm = series.mmHr[i] ?? 0
    accumulated += mm
    const offset = series.offsets[i] ?? 0
    const ts = new Date(baseHour.getTime() + offset * 3600_000)
    points.push({
      locationId,
      timestamp: ts.toISOString(),
      rainfallMmHr: mm,
      accumulatedMm: round(accumulated, 1),
      confidence: round(clamp(94 - Math.abs(offset) * 0.55 - (mm > 40 ? 5 : 0), 52, 96), 0),
      classification: classifyRainfall(mm),
    })
  }

  forecastCache.set(key, points)
  return points
}

export function getForecast(locationId: string, hours: number): ForecastPoint[] {
  return getForecastSeries(locationId).slice(0, hours)
}

/** Hour-aligned "now" — keeps generated series stable between renders. */
export function hourAlignedNow(): Date {
  const d = new Date()
  d.setMinutes(0, 0, 0)
  return d
}

/* --------------------- Intensity distribution ---------------------- */

export function getRainfallBands(): RainfallBand[] {
  return RAINFALL_BANDS
}

/**
 * Distribution of forecast hours across intensity classes for a
 * location/timeframe — feeds the intensity donut charts.
 */
export function getIntensityDistribution(
  locationId: string,
  hours: number,
): Array<{ label: string; hours: number; color: string }> {
  const points = getForecast(locationId, hours)
  return RAINFALL_BANDS.map((band) => ({
    label: band.label,
    hours: points.filter((p) => p.classification === band.label).length,
    color: band.color,
  }))
}
