"""Build out-of-sample probability sets for threshold optimization.

For each version (v3, v3.2, v3.3-frozen) and each target:
  * 2024: train-only models (fit on 2021-2023) scored on 2024, combined
    with the version's RECORDED ensemble weights and Platt calibration
    (both learned on 2024 validation from train-only models -- the same
    protocol every version was built with).
  * 2025: the DEPLOYED/refit artifacts (fit on 2021-2024) scored on 2025.

2026 is NEVER touched here. The 2025 probabilities are verified against
each version's recorded 2025 PR-AUC (deployed-artifact protocol).

Outputs: models/rainfall_xgb_v3_3/threshold_work/probs_{version}_{target}.csv
columns: timestamp, y, p_raw, p_cal, split
"""

import json
import logging
import os
import sys

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import evaluate_2026 as ev  # noqa: E402
from v33_common import BEST_PARAMS, make_classifier, platt_apply  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger("build_threshold_probs")

BACKEND = ev.BACKEND
OUT = os.path.join(BACKEND, "models", "rainfall_xgb_v3_3", "threshold_work")
TARGETS = ev.TARGETS
FAMILIES = ev.FAMILIES

# v3 used fixed (untrained) classifier hyperparameters.
V3_CLF_PARAMS = {
    "xgb": {"max_depth": 3, "learning_rate": 0.1, "n_estimators": 200},
    "lgbm": {"max_depth": 3, "learning_rate": 0.1, "n_estimators": 200},
    "hgb": {"max_depth": 3, "learning_rate": 0.1, "max_iter": 200},
}

VERSIONS = {
    "v3": {
        "table": "bhubaneswar_features.csv",
        "schema": os.path.join(BACKEND, "models", "rainfall_xgb_v3", "feature_schema.json"),
        "model_dir": os.path.join(BACKEND, "models", "rainfall_xgb_v3"),
        "params": V3_CLF_PARAMS,
    },
    "v3.2": {
        "table": "bhubaneswar_features_v32.csv",
        "schema": os.path.join(BACKEND, "models", "rainfall_xgb_v3_2", "feature_schema.json"),
        "model_dir": os.path.join(BACKEND, "models", "rainfall_xgb_v3_2"),
        "params": None,  # BEST_PARAMS per target
    },
    "v3.3": {
        "table": "bhubaneswar_features_v33.csv",
        "schema": os.path.join(BACKEND, "models", "rainfall_xgb_v3_3", "frozen",
                               "feature_schema.json"),
        "model_dir": os.path.join(BACKEND, "models", "rainfall_xgb_v3_3", "frozen"),
        "params": None,  # BEST_PARAMS per target
    },
}

# Recorded 2025 PR-AUC under the deployed-artifact protocol (used to
# verify the 2025 probabilities reproduce each version's own record).
EXPECTED_2025 = {
    "v3": {"y_3h_ge_10mm": 0.167, "y_6h_ge_10mm": 0.190, "y_3h_ge_5mm": 0.341},
    "v3.2": {"y_3h_ge_10mm": 0.2228, "y_6h_ge_10mm": 0.2371, "y_3h_ge_5mm": 0.3575},
    "v3.3": {"y_3h_ge_10mm": 0.1687, "y_6h_ge_10mm": 0.2743, "y_3h_ge_5mm": 0.3915},
}


def _params(version: str, target: str, fam: str) -> dict:
    if version == "v3":
        return dict(VERSIONS["v3"]["params"][fam])
    return dict(BEST_PARAMS[target][fam])


def _make(version: str, target: str, fam: str, pos_weight: float):
    """Build one classifier the way the version's own trainer does."""
    params = _params(version, target, fam)
    if version == "v3":
        import lightgbm as lgbm
        import xgboost as xgb
        from sklearn.ensemble import HistGradientBoostingClassifier
        if fam == "xgb":
            return xgb.XGBClassifier(**{**params, "scale_pos_weight": pos_weight})
        if fam == "lgbm":
            return lgbm.LGBMClassifier(**{**params, "scale_pos_weight": pos_weight})
        return HistGradientBoostingClassifier(**params)
    return make_classifier(fam, params, pos_weight)


def build_version(version: str) -> None:
    cfg = VERSIONS[version]
    feats = json.load(open(cfg["schema"]))["features"]
    weights = {ev._norm_key(k): v for k, v in
               json.load(open(os.path.join(cfg["model_dir"], "ensemble_weights.json"))).items()}
    platt = json.load(open(os.path.join(cfg["model_dir"], "platt.json")))
    df = pd.read_csv(os.path.join(BACKEND, "data", "model_ready", cfg["table"]),
                     parse_dates=["timestamp"])
    log.info("%s: table %s rows=%d features=%d", version, cfg["table"], len(df), len(feats))

    for target in TARGETS:
        w = weights[target]
        pl = platt[target]
        rows = []
        # --- 2024: train-only models (2021-2023) ---
        tr = df[df["timestamp"].dt.year.isin([2021, 2022, 2023])].reset_index(drop=True)
        va = df[df["timestamp"].dt.year == 2024].reset_index(drop=True)
        X_tr = tr[feats].to_numpy(dtype=float)
        y_tr = tr[target].to_numpy().astype(int)
        pw = max(1, int((1 - y_tr).sum())) / max(1, int(y_tr.sum()))
        X_va = va[feats].to_numpy(dtype=float)
        y_va = va[target].to_numpy().astype(int)
        ens = np.zeros(len(y_va))
        for fam in FAMILIES:
            m = _make(version, target, fam, pw)
            m.fit(X_tr, y_tr)
            ens += float(w[fam]) * m.predict_proba(X_va)[:, 1]
        cal = platt_apply(ens, float(pl["w"]), float(pl["b"]))
        pr24 = average_precision_score(y_va, cal)
        rows.append(pd.DataFrame({"timestamp": va["timestamp"], "y": y_va,
                                  "p_raw": ens, "p_cal": cal, "split": "2024-trainonly"}))
        # --- 2025: deployed/refit artifacts ---
        te = df[df["timestamp"].dt.year == 2025].reset_index(drop=True)
        X_te = te[feats].to_numpy(dtype=float)
        y_te = te[target].to_numpy().astype(int)
        ens25 = np.zeros(len(y_te))
        for fam in FAMILIES:
            if float(w[fam]) == 0:
                continue
            ens25 += float(w[fam]) * ev._predict(
                ev._load_member(cfg["model_dir"], target, fam), X_te)
        cal25 = platt_apply(ens25, float(pl["w"]), float(pl["b"]))
        pr25 = average_precision_score(y_te, cal25)
        exp = EXPECTED_2025[version][target]
        flag = "" if abs(pr25 - exp) <= 0.002 else "  <-- MISMATCH vs recorded"
        log.info("  %s %s: 2024 PR-AUC %.4f | 2025 PR-AUC %.4f (recorded %.4f)%s",
                 version, target, pr24, pr25, exp, flag)
        rows.append(pd.DataFrame({"timestamp": te["timestamp"], "y": y_te,
                                  "p_raw": ens25, "p_cal": cal25, "split": "2025-deployed"}))
        out = pd.concat(rows, ignore_index=True)
        out.to_csv(os.path.join(OUT, f"probs_{version}_{target}.csv"), index=False)
    log.info("saved %s probs", version)


def main() -> None:
    os.makedirs(OUT, exist_ok=True)
    for version in ("v3", "v3.2", "v3.3"):
        build_version(version)


if __name__ == "__main__":
    main()
