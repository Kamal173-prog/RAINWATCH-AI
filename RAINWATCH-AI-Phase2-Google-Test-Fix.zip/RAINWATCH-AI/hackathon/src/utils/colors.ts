import type {
  AlertSeverity,
  RainfallBand,
  RainfallClass,
  RiskLevel,
  UnitSystem,
} from '../types'

/* ---------------- Risk & intensity palettes ---------------- */

export const RISK_COLORS: Record<RiskLevel, string> = {
  Low: '#69D2A0',
  Moderate: '#F2A93B',
  High: '#F0823F',
  'Very High': '#F05A43',
  Critical: '#D93A5A',
}

export const RISK_ORDER: RiskLevel[] = ['Low', 'Moderate', 'High', 'Very High', 'Critical']

export const SEVERITY_COLORS: Record<AlertSeverity, string> = {
  Information: '#6FD6C2',
  Advisory: '#A8BCC4',
  Watch: '#F2A93B',
  Warning: '#F0823F',
  Critical: '#F05A43',
}

export const SEVERITY_ORDER: AlertSeverity[] = [
  'Information',
  'Advisory',
  'Watch',
  'Warning',
  'Critical',
]

/** IMD-style illustrative rainfall intensity bands. */
export const RAINFALL_BANDS: RainfallBand[] = [
  { label: 'Light', range: '< 2.5 mm/hr', min: 0, max: 2.5, color: '#69D2A0' },
  { label: 'Moderate', range: '2.5 – 15.5 mm/hr', min: 2.5, max: 15.6, color: '#6FD6C2' },
  { label: 'Heavy', range: '15.6 – 64.4 mm/hr', min: 15.6, max: 64.5, color: '#F2A93B' },
  { label: 'Very Heavy', range: '64.5 – 115.5 mm/hr', min: 64.5, max: 115.5, color: '#F0823F' },
  { label: 'Extremely Heavy', range: '> 115.5 mm/hr', min: 115.5, max: Infinity, color: '#F05A43' },
]

export function classifyRainfall(mmHr: number): RainfallClass {
  if (mmHr < 2.5) return 'Light'
  if (mmHr < 15.6) return 'Moderate'
  if (mmHr < 64.5) return 'Heavy'
  if (mmHr < 115.5) return 'Very Heavy'
  return 'Extremely Heavy'
}

export function rainfallColor(mmHr: number): string {
  return RAINFALL_BANDS.find((b) => mmHr >= b.min && mmHr < b.max)?.color ?? '#69D2A0'
}

export function classifyRisk(index: number): RiskLevel {
  if (index < 25) return 'Low'
  if (index < 45) return 'Moderate'
  if (index < 65) return 'High'
  if (index < 82) return 'Very High'
  return 'Critical'
}

export const RISK_HELP: Record<RiskLevel, string> = {
  Low: 'Limited surface runoff expected. Standard monitoring continues.',
  Moderate: 'Localised waterlogging possible in low-lying pockets.',
  High: 'Significant inundation likely in low-lying and poorly drained zones.',
  'Very High': 'Widespread inundation expected; vulnerable zones may be cut off.',
  Critical: 'Severe, potentially life-threatening inundation. Immediate action required.',
}

/* ---------------- Unit conversion --------------------------- */

export function celsiusToF(c: number): number {
  return c * 9 / 5 + 32
}

export function kmhToMph(kmh: number): number {
  return kmh * 0.621371
}

export function mmToInch(mm: number): number {
  return mm / 25.4
}

/* ---------------- Formatting ------------------------------- */

export function formatNumber(value: number, decimals = 1): string {
  return value.toLocaleString('en-IN', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })
}

export function formatCompact(value: number): string {
  return new Intl.NumberFormat('en-IN', { notation: 'compact', maximumFractionDigits: 1 }).format(
    value,
  )
}

export function formatDateTime(iso: string): string {
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return iso
  return d.toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  })
}

export function formatTime(iso: string): string {
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return iso
  return d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true })
}

export function formatDay(iso: string): string {
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return iso
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })
}

export function relativeTime(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime()
  const mins = Math.round(diff / 60000)
  if (mins < 1) return 'just now'
  if (mins < 60) return `${mins} min ago`
  const hours = Math.round(mins / 60)
  if (hours < 24) return `${hours} hr ago`
  const days = Math.round(hours / 24)
  return `${days} day${days > 1 ? 's' : ''} ago`
}

export function windDirectionLabel(deg: number): string {
  const dirs = [
    'N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE',
    'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW',
  ]
  return dirs[Math.round(((deg % 360) + 360) % 360 / 22.5) % 16]
}

/** Apply the user's unit preference to a rainfall value. */
export function rainfallLabel(mm: number, units: UnitSystem): string {
  return units === 'metric' ? `${formatNumber(mm, 1)} mm` : `${formatNumber(mmToInch(mm), 2)} in`
}

export function temperatureLabel(c: number, units: UnitSystem): string {
  return units === 'metric'
    ? `${formatNumber(c, 1)}°C`
    : `${formatNumber(celsiusToF(c), 1)}°F`
}

export function windLabel(kmh: number, units: UnitSystem): string {
  return units === 'metric'
    ? `${formatNumber(kmh, 1)} km/h`
    : `${formatNumber(kmhToMph(kmh), 1)} mph`
}
