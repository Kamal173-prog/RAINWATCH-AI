import { createRng, hashSeed, round } from '../utils/rng'
import { getDemoTick } from '../services/demoState'
import type { MapLayersPayload } from '../types'
import { LOCATIONS, REGIONS, getLocation } from './locationsData'
import { computeRiskRecord } from './floodRiskData'

/* ------------------------------------------------------------------
   Illustrative geospatial overlays for the inundation map (DEMO DATA).
   Polygons, depths and densities are synthetic shapes generated
   around known coordinates — they are NOT real flood boundaries.
------------------------------------------------------------------ */

/** Rough ring around a centre point, jittered deterministically. */
function makePolygon(
  lat: number,
  lng: number,
  radiusDeg: number,
  seed: string,
  points = 9,
): Array<[number, number]> {
  const rng = createRng(hashSeed(seed))
  const ring: Array<[number, number]> = []
  for (let i = 0; i < points; i++) {
    const angle = (i / points) * Math.PI * 2
    const r = radiusDeg * (0.62 + rng() * 0.72)
    ring.push([
      round(lat + Math.sin(angle) * r, 5),
      round(lng + Math.cos(angle) * r * 1.32, 5),
    ])
  }
  return ring
}

let cache: { tick: number; payload: MapLayersPayload } | null = null

export function getMapLayers(): MapLayersPayload {
  const tick = getDemoTick()
  if (cache && cache.tick === tick) return cache.payload

  const rng = createRng(hashSeed('map-layers') ^ Math.imul(tick + 1, 0x9e3779b1))

  /* Risk zones — one per location, severity from flood-risk model. */
  const riskZones = LOCATIONS.map((loc) => {
    const risk = computeRiskRecord(loc.id, 6, tick)
    return {
      id: `zone-${loc.id}`,
      name: `${loc.name} sector`,
      level: risk.riskLevel,
      polygon: makePolygon(loc.lat, loc.lng, 0.026 + loc.lowLyingPct / 5200, `zone-${loc.id}`),
      rainfallMmHr: round(risk.rainfallContribution * 0.9 + rng() * 4, 1),
    }
  })

  /* Inundation extents — synthetic ponding cells near low-lying zones. */
  const lowLying = LOCATIONS.filter((l) => l.lowLyingPct >= 40)
  const inundation = lowLying.map((loc) => {
    const depth = round((loc.lowLyingPct / 100) * (0.5 + rng() * 1.9), 2)
    return {
      id: `inund-${loc.id}`,
      name: `${loc.name} ponding cell`,
      polygon: makePolygon(
        loc.lat + (rng() - 0.5) * 0.012,
        loc.lng + (rng() - 0.5) * 0.012,
        0.014 + depth * 0.008,
        `inund-${loc.id}`,
        8,
      ),
      depthM: depth,
      confidencePct: Math.round(58 + rng() * 34),
    }
  })

  /* Automatic weather stations — sampled across both regions so every
     map view has local stations (5 per region, 10 total). */
  const stationLocs = [
    ...LOCATIONS.filter((l) => l.regionId !== 'ganjam').slice(0, 5),
    ...LOCATIONS.filter((l) => l.regionId === 'ganjam').slice(0, 5),
  ]
  const stations = stationLocs.map((loc, i) => {
    const statuses = ['online', 'online', 'online', 'maintenance', 'offline'] as const
    const status = i % 5 === 3 ? statuses[3] : i % 7 === 6 ? statuses[4] : statuses[i % 3]
    return {
      id: `st-${loc.id}`,
      name: `${loc.name} AWS`,
      lat: loc.lat + (rng() - 0.5) * 0.01,
      lng: loc.lng + (rng() - 0.5) * 0.01,
      rainfallMmHr: round(rng() * 46, 1),
      status,
      lastUpdate: new Date(Date.now() - (status === 'online' ? rng() * 12 : rng() * 240) * 60_000)
        .toISOString(),
    }
  })

  /* Population density cells across both demonstration regions. */
  const population: MapLayersPayload['population'] = []
  const rows = 7
  const cols = 8
  for (const region of REGIONS) {
    const [south, west, north, east] = region.bbox
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const lat = south + ((r + 0.5) / rows) * (north - south)
        const lng = west + ((c + 0.5) / cols) * (east - west)
        // Density falls off from the region core with organic variation.
        const dLat = (lat - region.center[0]) / ((north - south) / 2)
        const dLng = (lng - region.center[1]) / ((east - west) / 2)
        const dist = Math.sqrt(dLat * dLat + dLng * dLng)
        const density = Math.round(
          Math.max(350, (9800 * Math.exp(-dist * 1.45) + 420) * (0.7 + rng() * 0.75)),
        )
        population.push({
          id: `pop-${region.id}-${r}-${c}`,
          lat: round(lat, 5),
          lng: round(lng, 5),
          densityPerKm2: density,
          label: `${region.id === 'ganjam' ? 'G' : 'B'}${String.fromCharCode(65 + c)}${r + 1}`,
        })
      }
    }
  }

  /* Vulnerable sites shown as special markers. */
  const vulnerable = [
    { id: 'v1', name: 'SCB Medical Campus (demo)', type: 'Hospital' as const, locId: 'old-town' },
    { id: 'v2', name: 'Municipal High School (demo)', type: 'School' as const, locId: 'nayapalli' },
    { id: 'v3', name: 'Canal Road Slum Cluster (demo)', type: 'Slum Area' as const, locId: 'old-town' },
    { id: 'v4', name: 'Railway Underpass (demo)', type: 'Subway / Underpass' as const, locId: 'saheed-nagar' },
    { id: 'v5', name: 'Senior Care Home (demo)', type: 'Old-age Home' as const, locId: 'sishupalgarh' },
    { id: 'v6', name: 'Industrial Estate School (demo)', type: 'School' as const, locId: 'mancheswar' },
    { id: 'v7', name: 'Storm-drain Outfall Zone (demo)', type: 'Slum Area' as const, locId: 'rasulgarh' },
    { id: 'v8', name: 'Hill-slope Settlement (demo)', type: 'Slum Area' as const, locId: 'khandagiri' },
    { id: 'v9', name: 'Brahmapur City Hospital (demo)', type: 'Hospital' as const, locId: 'brahmapur' },
    { id: 'v10', name: 'Gopalpur Fishing Settlement (demo)', type: 'Slum Area' as const, locId: 'gopalpur' },
    { id: 'v11', name: 'Chhatrapur Underpass (demo)', type: 'Subway / Underpass' as const, locId: 'chhatrapur' },
    { id: 'v12', name: 'Coastal School (demo)', type: 'School' as const, locId: 'patrapur' },
  ].map((v) => {
    const loc = getLocation(v.locId)
    return {
      id: v.id,
      name: v.name,
      lat: round(loc.lat + (rng() - 0.5) * 0.016, 5),
      lng: round(loc.lng + (rng() - 0.5) * 0.016, 5),
      type: v.type,
      vulnerability: loc.vulnerability,
    }
  })

  const payload: MapLayersPayload = { riskZones, inundation, stations, population, vulnerable }
  cache = { tick, payload }
  return payload
}
