import { motion } from 'framer-motion'
import { Activity, Layers, MapPin, Radio, ShieldAlert, Waves } from 'lucide-react'
import { useState } from 'react'
import { toast } from 'sonner'
import { LAYER_DEFS, RainMap } from '../components/maps/RainMap'
import { Badge, DemoBadge } from '../components/common/Badge'
import { Button } from '../components/common/Button'
import { ChartCard } from '../components/common/ChartCard'
import { KpiCard } from '../components/common/KpiCard'
import { PageHeader } from '../components/common/PageHeader'
import { SkeletonCard } from '../components/common/Skeleton'
import { useDemo } from '../context/DemoContext'
import { useSelectedLocation } from '../context/LocationContext'
import { useSettings } from '../context/SettingsContext'
import { useAsyncData } from '../hooks/useAsyncData'
import { demoApi } from '../services/dataService'
import { regionOf } from '../data/locationsData'
import type { MapLayerId } from '../types'
import { RISK_COLORS } from '../utils/colors'

export function InundationMap() {
  const { locationId, setLocationId } = useSelectedLocation()
  const { version } = useDemo()
  const { settings, update } = useSettings()
  const [layers, setLayers] = useState<MapLayerId[]>(settings.defaultMapLayers)

  const { data: conditions, loading, reload } = useAsyncData(
    () => demoApi.fetchRegionConditions(),
    [version],
  )

  const toggleLayer = (next: MapLayerId[]) => {
    setLayers(next)
    update({ defaultMapLayers: next })
  }

  const worst = conditions ? [...conditions].sort((a, b) => b.riskIndex - a.riskIndex)[0] : null

  return (
    <div className="section-gap flex flex-col">
      <PageHeader
        title="Interactive Inundation Map"
        subtitle="Explore illustrative rainfall, flood-risk and inundation overlays across the demonstration region. Risk values for Bhubaneswar-region locations use the single Bhubaneswar grid-cell forecast (20.28°N, 85.84°E); all geometry is synthetic demo data."
        meta={
          <>
            <DemoBadge />
            <Badge tone="info" dot>{regionOf(locationId).shortName}</Badge>
            <Badge tone="muted">Region: {conditions?.find((c) => c.locationId === locationId)?.name ?? '—'}</Badge>
          </>
        }
      >
        <Button icon={<Layers size={14} />} onClick={() => toast.info('Use the layer switches on the map to toggle overlays.')}>
          {layers.length} layers active
        </Button>
        <Button icon={<Activity size={14} />} onClick={reload}>Refresh overlays</Button>
      </PageHeader>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {loading ? (
          Array.from({ length: 4 }).map((_, i) => <SkeletonCard key={i} lines={1} />)
        ) : (
          <>
            <KpiCard label="Max rainfall" value={worst?.rainfallMmHr ?? 0} unit="mm/hr" icon={Waves}
              tooltip="Highest current rainfall rate among the sample locations." delay={0.02} />
            <KpiCard label="Peak risk index" value={worst?.riskIndex ?? 0} unit="/100" icon={ShieldAlert}
              tooltip="Highest illustrative flood-risk index among sample locations."
              footnote={<Badge tone="warning">{worst?.riskLevel ?? '—'}</Badge>} delay={0.06} />
            <KpiCard label="Max inundation" value={worst?.inundationDepthM ?? 0} unit="m" decimals={2} icon={MapPin}
              tooltip="Largest estimated ponding depth from the demo inundation model." delay={0.1} />
            <KpiCard label="Stations" value={layers.includes('stations') ? 10 : 0} decimals={0} icon={Radio}
              tooltip="Toggle the Monitoring Stations layer on the map to display the sample network."
              delay={0.14}
              footnote={<Badge tone={layers.includes('stations') ? 'success' : 'muted'}>{layers.includes('stations') ? 'Layer on' : 'Layer off'}</Badge>} />
          </>
        )}
      </div>

      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.1 }}>
        <RainMap height={620} layers={layers} onLayersChange={toggleLayer} selectedLocationId={locationId} onSelectLocation={setLocationId} />
      </motion.div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <ChartCard title="Map layers" subtitle="Toggle each overlay directly from the map panel" icon={<Layers size={16} />} height={200}>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            {LAYER_DEFS.map((def) => {
              const on = layers.includes(def.id)
              const Icon = def.icon
              return (
                <button key={def.id} type="button"
                  onClick={() => toggleLayer(layers.includes(def.id) ? layers.filter((x) => x !== def.id) : [...layers, def.id])}
                  aria-pressed={on}
                  className={`flex items-center gap-2.5 rounded-xl border px-3 py-2 text-left transition-all ${
                    on ? 'border-accent/40 bg-accent/8' : 'border-line bg-surface/50 hover:border-line'
                  }`}>
                  <span className="flex h-7 w-7 items-center justify-center rounded-lg" style={{ background: `${def.color}20`, color: def.color }}>
                    <Icon size={14} aria-hidden />
                  </span>
                  <span className="min-w-0 flex-1 truncate text-xs font-medium text-ink">{def.label}</span>
                  <span className={`h-2 w-2 rounded-full ${on ? 'dot-live' : ''}`} style={{ background: on ? def.color : 'var(--rw-muted)' }} aria-hidden />
                </button>
              )
            })}
          </div>
        </ChartCard>

        <ChartCard title="Location risk snapshot" subtitle="Sample risk levels used to colour the polygons" icon={<ShieldAlert size={16} />} height={200} className="lg:col-span-2">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5">
            {(['Low', 'Moderate', 'High', 'Very High', 'Critical'] as const).map((lvl) => (
              <div key={lvl} className="rounded-xl border border-line bg-surface p-2.5">
                <span className="mb-2 block h-1.5 w-full rounded-full" style={{ background: RISK_COLORS[lvl] }} />
                <p className="text-xs font-semibold text-ink">{lvl}</p>
                <p className="num text-[11px] text-muted">{conditions?.filter((c) => c.riskLevel === lvl).length ?? 0} zones</p>
              </div>
            ))}
          </div>
          <p className="mt-3 text-[11px] leading-relaxed text-muted">
            Polygons, ponding cells and station telemetry shown on this map are synthetic shapes
            generated for interface demonstration. They are not validated inundation boundaries or
            a real-time operational forecast.
          </p>
        </ChartCard>
      </div>
    </div>
  )
}
