# RAINWATCH AI v3.3 — Matched Comparison vs v3.2 (and v3)

Date: 2026-11-24. Evidence: pooled out-of-sample 2024+2025 probabilities
only (`ml/build_threshold_probs.py`). 2026 was not used. Scripts:
`ml/optimize_thresholds.py`, `ml/matched_comparison.py`.
Outputs: `models/rainfall_xgb_v3_3/threshold_work/matched_comparison.json`.

## 1. Optimized operating points (pooled 2024+2025)

| Event | Level | v3.2 (t, P, R, F1, F2, FA/100 h) | v3.3 (t, P, R, F1, F2, FA/100 h) |
|---|---|---|---|
| 3 h >= 10 mm | Watch | 0.060, 0.123, 0.411, 0.189, 0.280, 3.53 | 0.070, 0.121, 0.389, 0.185, 0.270, 3.39 |
| 3 h >= 10 mm | Warning | 0.080, 0.164, 0.324, 0.218, 0.271, 2.09 | 0.125, 0.203, 0.216, 0.209, 0.213, 1.12 |
| 6 h >= 10 mm | Watch | 0.075, 0.131, 0.723, 0.222, 0.380, 17.42 | 0.085, 0.157, 0.723, 0.258, 0.420, 14.56 |
| 6 h >= 10 mm | Warning | 0.165, 0.238, 0.335, 0.278, 0.309, 4.43 | 0.185, 0.287, 0.372, 0.324, 0.351, 4.09 |
| 3 h >= 5 mm | Watch | 0.090, 0.222, 0.742, 0.342, 0.505, 12.99 | 0.125, 0.262, 0.686, 0.379, 0.518, 10.21 |
| 3 h >= 5 mm | Warning | 0.165, 0.321, 0.565, 0.409, 0.490, 6.84 | 0.225, 0.370, 0.487, 0.420, 0.458, 5.12 |

Reading:
- **6 h >= 10 mm: v3.3 wins at both levels.** Watch F2 0.420 vs 0.380
  at the same recall (0.723), with fewer false alarms (14.56 vs 17.42
  per 100 h). Warning F1 0.324 vs 0.278, precision 0.287 vs 0.238.
- **3 h >= 5 mm: v3.3 wins on F-scores, loses a little recall.**
  Watch F2 0.518 vs 0.505 at higher precision (0.262 vs 0.222) but
  lower recall (0.686 vs 0.742); Warning F1 0.420 vs 0.409. False
  alarms are lower at both levels (10.21 vs 12.99; 5.12 vs 6.84).
- **3 h >= 10 mm: v3.2 wins, narrowly.** Watch F2 0.280 vs 0.270;
  Warning F1 0.218 vs 0.209. v3.3's Warning buys precision (0.203 vs
  0.164) at a recall cost (0.216 vs 0.324) and fires about half as often
  (1.12 vs 2.09 per 100 h).

## 2. Matched recall (v3.3 threshold reproducing v3.2's recall)

| Event | Level | v3.2 recall | v3.3 threshold | v3.3 precision | v3.2 precision | ΔP |
|---|---|---|---|---|---|---|
| 3 h >= 10 mm | Watch | 0.411 | 0.060 | 0.099 | 0.123 | −0.024 |
| 3 h >= 10 mm | Warning | 0.324 | 0.080 | 0.128 | 0.164 | −0.036 |
| 6 h >= 10 mm | Watch | 0.723 | 0.085 | 0.157 | 0.131 | +0.026 |
| 6 h >= 10 mm | Warning | 0.335 | 0.200 | 0.306 | 0.238 | +0.068 |
| 3 h >= 5 mm | Watch | 0.742 | 0.095 | 0.224 | 0.222 | +0.002 |
| 3 h >= 5 mm | Warning | 0.565 | 0.180 | 0.316 | 0.321 | −0.005 |

## 3. Matched precision (v3.3 threshold reproducing v3.2's precision)

| Event | Level | v3.2 precision | v3.3 threshold | v3.3 recall | v3.2 recall | ΔR |
|---|---|---|---|---|---|---|
| 3 h >= 10 mm | Watch | 0.123 | 0.070 | 0.389 | 0.411 | −0.022 |
| 3 h >= 10 mm | Warning | 0.164 | 0.100 | 0.270 | 0.324 | −0.054 |
| 6 h >= 10 mm | Watch | 0.131 | 0.065 | 0.803 | 0.723 | +0.080 |
| 6 h >= 10 mm | Warning | 0.238 | 0.155 | 0.427 | 0.335 | +0.092 |
| 3 h >= 5 mm | Watch | 0.222 | 0.095 | 0.748 | 0.742 | +0.006 |
| 3 h >= 5 mm | Warning | 0.321 | 0.185 | 0.562 | 0.565 | −0.003 |

The matched analysis agrees with the optimized points: v3.3 is better
on 6 h >= 10 mm by both measures (+0.026 / +0.068 precision at matched
recall, +0.080 / +0.092 recall at matched precision), essentially tied
on 3 h >= 5 mm, and worse on 3 h >= 10 mm (−0.024 / −0.036 precision
at matched recall, −0.022 / −0.054 recall at matched precision).

## 4. Ranking (PR-AUC, pooled 2024+2025 is not a single number — per year)

| Event | v3 2024 / 2025 | v3.2 2024 / 2025 | v3.3 2024 / 2025 |
|---|---|---|---|
| 3 h >= 10 mm | 0.0629 / 0.1669 | 0.0883 / 0.2228 | 0.1114 / 0.1687 |
| 6 h >= 10 mm | 0.1670 / 0.1902 | 0.1748 / 0.2371 | 0.2602 / 0.2743 |
| 3 h >= 5 mm | 0.3069 / 0.3415 | 0.3509 / 0.3575 | 0.3589 / 0.3915 |

v3.3 has the best 2024 ranking on all three events and the best 2025
ranking on 6 h >= 10 mm and 3 h >= 5 mm. The single exception is
3 h >= 10 mm on 2025, where v3.2 (0.2228) is far ahead of v3.3
(0.1687) — and 2025 is the year with more weight in the pooled
optimization, which is why v3.3 loses the 3 h >= 10 mm matched
comparison. The v3.3 features help ranking on 2024 but did not
translate into a 2025 win for the hardest event.

## 5. Against v3 (production)

At optimized points on pooled 2024+2025, v3.3 beats v3 on every
F-score: 3 h >= 10 mm F2 0.270 vs 0.254 / F1 0.209 vs 0.161;
6 h >= 10 mm F2 0.420 vs 0.350 / F1 0.324 vs 0.241;
3 h >= 5 mm F2 0.518 vs 0.434 / F1 0.420 vs 0.310. It also fires
less often than v3 at Watch for 6 h >= 10 mm (14.56 vs 15.49) and
3 h >= 5 mm (10.21 vs 16.01). The one place v3 wins is storm
detection at its own (much lower) optimized thresholds — see
V33_STORM_DETECTION.md: that is a firing-frequency effect, not a
ranking win.

## 6. Bottom line

v3.3 is a genuine improvement over v3 and a mixed bag against v3.2:
clearly better on 6 h >= 10 mm, tied on 3 h >= 5 mm, narrowly worse
on 3 h >= 10 mm. The 3 h >= 10 mm gap is a ranking gap (2025
PR-AUC), not a threshold gap — no threshold choice closes it.
