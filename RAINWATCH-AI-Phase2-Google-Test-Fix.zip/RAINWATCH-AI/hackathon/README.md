# RAINWATCH AI — Predict. Prepare. Protect.

Integrated disaster-intelligence dashboard: a React frontend over a FastAPI backend
(API v1.3.0) serving a trained XGBoost rainfall ensemble (v3 production, v3.3
flag-gated demo model) on real ERA5 reanalysis data, with optional Google Weather
forecasts. The Forecast page shows genuine values only — MODEL predictions where the
ML model covers, Google Weather where it does not, UNAVAILABLE otherwise; synthetic
DEMO rainfall values are never presented as forecasts there. Other pages still use
clearly-labelled demo data where noted.

> ⚠️ Early-warning signal, not a confirmed forecast. Do not use any output for real
> emergency decisions.

## Run it

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # strict TypeScript check + production bundle
npm run preview  # serve the production build
```

## Design language — "Tactical Instrument"

The v2 redesign replaces the default rounded-blue-glow SaaS look with an instrument-console identity:

- **Geometry:** hard 90° surfaces with a single clipped corner on buttons/chips; corner brackets and hard offset plates instead of diffuse shadows.
- **Palette:** graphite/ink substrates, warm phosphor text, **signal lime** as the single UI accent, instrument teal for secondary data, amber/red reserved for genuine severity. Light mode uses darker accent variants for contrast.
- **Type:** Space Grotesk display, Manrope body, IBM Plex Mono for all telemetry labels and readouts.
- **3D:** pointer-driven tilt on KPI cards, a live radar/orbit instrument on the overview, a risk-driven rotating 3D prism in the simulator, tilted pipeline nodes and 3D page transitions. All motion is disabled under `prefers-reduced-motion`.

Every change is visual only — no page, route, control, filter, export or persistence behaviour was removed.

### Landing page & simulation → map

`/` is a standalone cinematic landing page with a 3D radar instrument, capability bento, animated
pipeline and an "Enter Command Center" CTA into `/overview`. The sidebar brand and profile menu link
back to it.

Running a what-if scenario stores the result in `DemoContext`. The Inundation Map adds a seventh
layer, **Simulation Overlay**: a risk-coloured dashed warning radius, an inner inundation circle, a
pulsing warning marker with popup, and a dismissible status card. The map flies to the scenario
location, and "View on map" / the toast action navigate there without losing the result. The overlay
is deliberately session-only — a full browser reload clears it.

## Branding

The supplied RAINWATCH emblem is used as the app favicon and through a shared `BrandLogo` component
in the sidebar, landing navigation and hero, top-bar profile menu, Settings "About" panel, Data
Sources pipeline, 404 page and landing footer. The source artwork was resized to a transparent
512 px app asset (`src/assets/rainwatch-logo.png`) and a 64 px favicon (`public/favicon.png`).

## Stack

React 19 · Vite 8 · TypeScript (strict) · Tailwind CSS v4 · Framer Motion 14 · Lucide React ·
Recharts 3 · React Leaflet 5 / Leaflet · React Router 7 · Sonner.

## Pages

| Route | Page |
| --- | --- |
| `/` | Public landing page — "Predict. Prepare. Protect." |
| `/overview` | Overview / command centre |
| `/live-weather` | Current observations & trends |
| `/forecast` | Rainfall forecast (3–72 h) |
| `/flood-intelligence` | Illustrative composite risk assessment |
| `/map` | Interactive inundation map (OpenStreetMap + overlay layers, two regions) |
| `/simulator` | What-if scenario simulator (local deterministic maths) |
| `/alerts` | Early-warning alert management |
| `/historical` | Historical rainfall / risk analytics |
| `/data-sources` | Planned source integrations & data pipeline |
| `/settings` | Appearance, defaults, units, notifications, data management |

## Architecture

```
src/
  components/
    common/     reusable UI kit (cards, charts wrappers, controls, modal, table…)
    layout/     sidebar, top bar, app shell
    maps/       reusable React Leaflet map with togglable demo overlays
  context/      settings, alerts, selected location, demo-refresh state
  data/         deterministic demo data generators + source catalogue
  hooks/        async data loading, counters, clock, localStorage
  pages/        one module per route
  services/     demoApi — the single data-access layer (calls the FastAPI
                backend when VITE_API_URL is set, local demo data otherwise)
  types/        shared TypeScript interfaces
  utils/        colours/classification, formatting, CSV export, seeded RNG
```

All pages read data exclusively through `demoApi` (`src/services/dataService.ts`) using
`useAsyncData`. When `VITE_API_URL` is set (see `.env.example`), demoApi calls the
FastAPI backend (API v1.3.0); otherwise it uses local demo data. The Forecast page
uses the merged forecast endpoint (`GET /api/forecast/merged`) and never falls back
to demo values — if the backend is unreachable it shows an error, and hours Google
Weather cannot cover show as UNAVAILABLE.

Persistence uses `localStorage` for settings, alert status, selected location, sidebar state and
demo-map layers. The "Refresh Demo Data" button re-seeds every generated series so the entire
dashboard changes consistently.

## Accessibility & motion

Semantic controls with ARIA labels, keyboard-operable modal/dropdowns, visible focus rings,
responsive down to mobile, and full support for `prefers-reduced-motion` via Framer Motion's
`MotionConfig` plus CSS fallbacks.

## Map fallback

The map uses public OpenStreetMap tiles. If tiles cannot load (offline demo), it automatically
switches to a styled schematic background while keeping all demo overlays, markers, popups and
layer switches fully interactive.
