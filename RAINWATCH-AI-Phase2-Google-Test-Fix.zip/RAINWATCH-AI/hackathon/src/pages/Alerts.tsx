import { AnimatePresence, motion } from 'framer-motion'
import {
  Bell,
  BellOff,
  CheckCheck,
  ChevronRight,
  MapPin,
  Search,
  Trash2,
  Undo2,
  X,
} from 'lucide-react'
import { useMemo, useState } from 'react'
import { toast } from 'sonner'
import { Badge, DemoBadge, SeverityBadge } from '../components/common/Badge'
import { Button } from '../components/common/Button'
import { Modal } from '../components/common/Modal'
import { PageHeader } from '../components/common/PageHeader'
import { SegmentedControl } from '../components/common/SegmentedControl'
import { Select } from '../components/common/Select'
import { StatePanel } from '../components/common/Skeleton'
import { useAlerts } from '../context/AlertsContext'
import type { Alert, AlertSeverity } from '../types'
import { formatDateTime, relativeTime, SEVERITY_COLORS, SEVERITY_ORDER } from '../utils/colors'

type StatusTab = 'all' | 'active' | 'acknowledged' | 'dismissed'

const STATUS_TABS = [
  { value: 'all', label: 'All' },
  { value: 'active', label: 'Active' },
  { value: 'acknowledged', label: 'Acknowledged' },
  { value: 'dismissed', label: 'Dismissed' },
]

export function Alerts() {
  const {
    alerts, activeCountValue, dismissedCount,
    acknowledge, dismiss, restore, acknowledgeAll, clearDismissed, resetAlerts,
  } = useAlerts()

  const [severities, setSeverities] = useState<AlertSeverity[]>([...SEVERITY_ORDER])
  const [location, setLocation] = useState('all')
  const [query, setQuery] = useState('')
  const [status, setStatus] = useState<StatusTab>('all')
  const [detail, setDetail] = useState<Alert | null>(null)

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    return alerts.filter((a) => {
      if (!severities.includes(a.severity)) return false
      if (location !== 'all' && a.locationId !== location) return false
      if (status !== 'all' && a.status !== status) return false
      if (q && !`${a.title} ${a.description} ${a.id} ${a.locationName} ${a.category}`.toLowerCase().includes(q)) return false
      return true
    }).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
  }, [alerts, severities, location, query, status])

  const counts = useMemo(() => ({
    all: alerts.length,
    active: alerts.filter((a) => a.status === 'active').length,
    acknowledged: alerts.filter((a) => a.status === 'acknowledged').length,
    dismissed: alerts.filter((a) => a.status === 'dismissed').length,
    critical: alerts.filter((a) => a.severity === 'Critical' && a.status !== 'dismissed').length,
  }), [alerts])

  const locations = useMemo(() => {
    const map = new Map<string, string>()
    for (const a of alerts) map.set(a.locationId, a.locationName)
    return [...map.entries()].map(([id, name]) => ({ value: id, label: name }))
  }, [alerts])

  const toggleSeverity = (s: AlertSeverity) => {
    setSeverities((prev) => prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s])
  }

  const resetFilters = () => {
    setSeverities([...SEVERITY_ORDER])
    setLocation('all')
    setQuery('')
    setStatus('all')
    toast.info('Alert filters reset')
  }

  return (
    <div className="section-gap flex flex-col">
      <PageHeader
        title="Early Warning Alerts"
        subtitle="Acknowledge, inspect and manage sample early-warning messages. Changes persist locally in this browser."
        meta={<><DemoBadge /><Badge tone="muted">Local state + localStorage</Badge></>}
      >
        <Button icon={<CheckCheck size={14} />} onClick={() => { acknowledgeAll(); toast.success('All active alerts acknowledged') }} disabled={counts.active === 0}>
          Mark all acknowledged
        </Button>
        <Button icon={<Trash2 size={14} />} onClick={() => { clearDismissed(); toast.success('Dismissed alerts cleared') }} disabled={dismissedCount === 0}>
          Clear dismissed
        </Button>
      </PageHeader>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {[
          { label: 'Total alerts', value: counts.all, color: '#6FD6C2', icon: Bell },
          { label: 'Active', value: counts.active, color: '#F2A93B', icon: Bell },
          { label: 'Acknowledged', value: counts.acknowledged, color: '#69D2A0', icon: CheckCheck },
          { label: 'Dismissed', value: counts.dismissed, color: '#8B9996', icon: BellOff },
          { label: 'Critical', value: counts.critical, color: '#F05A43', icon: Bell },
        ].map((s, i) => {
          const Icon = s.icon
          return (
            <motion.div key={s.label} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
              className="rounded-2xl border border-line bg-card p-[var(--rw-card-pad)]">
              <div className="flex items-center justify-between"><span className="text-[10px] font-semibold tracking-wider text-muted uppercase">{s.label}</span><Icon size={14} style={{ color: s.color }} /></div>
              <p className="num mt-2 text-xl font-bold" style={{ color: s.color }}>{s.value}</p>
            </motion.div>
          )
        })}
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-3 rounded-2xl border border-line bg-card p-[var(--rw-card-pad)]">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative min-w-[220px] flex-1">
            <Search size={14} className="absolute top-1/2 left-3 -translate-y-1/2 text-muted" aria-hidden />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search alerts by title, id, location…" aria-label="Search alerts"
              className="h-9 w-full rounded-lg border border-line bg-surface pr-3 pl-9 text-xs text-ink placeholder:text-muted focus:border-accent/60 focus:outline-none" />
          </div>
          <Select label="Location" options={[{ value: 'all', label: 'All locations' }, ...locations]} value={location} onValueChange={setLocation} compact className="w-[190px]" />
          <Button size="sm" variant="ghost" onClick={resetFilters}>Reset filters</Button>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <div>
            <p className="mb-1.5 text-[10px] font-semibold tracking-wider text-muted uppercase">Severity</p>
            <div className="flex flex-wrap gap-1.5">
              {SEVERITY_ORDER.map((s) => {
                const on = severities.includes(s)
                const color = SEVERITY_COLORS[s]
                return (
                  <button key={s} type="button" onClick={() => toggleSeverity(s)} aria-pressed={on}
                    className="cut-br inline-flex items-center gap-1.5 border px-2.5 py-1 text-[11px] font-medium transition-all"
                    style={{ borderColor: on ? `${color}60` : 'var(--rw-border)', background: on ? `${color}18` : 'transparent', color: on ? color : 'var(--rw-muted)' }}>
                    <span className="h-1.5 w-1.5 rounded-full" style={{ background: on ? color : 'transparent', border: on ? 'none' : '1px solid var(--rw-muted)' }} />
                    {s}
                  </button>
                )
              })}
            </div>
          </div>
          <div className="ms-auto">
            <SegmentedControl ariaLabel="Alert status" size="sm" value={status} onChange={(v) => setStatus(v as StatusTab)}
              options={STATUS_TABS.map((t) => ({ value: t.value, label: `${t.label} (${counts[t.value as StatusTab]})` }))} />
          </div>
        </div>
      </div>

      {/* Alert list */}
      <div className="grid grid-cols-1 gap-3">
        <AnimatePresence mode="popLayout">
          {filtered.map((a, i) => (
            <motion.div
              key={a.id}
              layout
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, transition: { duration: 0.2 } }}
              transition={{ delay: Math.min(i * 0.04, 0.3) }}
              whileHover={{ y: -2 }}
              className={`relative overflow-hidden rounded-2xl border bg-card p-[var(--rw-card-pad)] transition-colors ${
                a.status === 'dismissed' ? 'border-line opacity-60' : 'border-line hover:border-accent/35'
              }`}
            >
              <span className="absolute inset-y-0 left-0 w-1" style={{ background: SEVERITY_COLORS[a.severity] }} aria-hidden />
              <div className="flex flex-col gap-3 pl-2 sm:flex-row sm:items-start sm:justify-between">
                <div className="min-w-0">
                  <div className="mb-2 flex flex-wrap items-center gap-2">
                    <SeverityBadge severity={a.severity} />
                    <Badge tone="muted">{a.category}</Badge>
                    {a.status === 'active' ? <Badge tone="warning" dot>Active</Badge> : null}
                    {a.status === 'acknowledged' ? <Badge tone="success" dot>Acknowledged</Badge> : null}
                    {a.status === 'dismissed' ? <Badge tone="muted">Dismissed</Badge> : null}
                  </div>
                  <h3 className="text-sm font-semibold text-ink">{a.title}</h3>
                  <p className="mt-1.5 line-clamp-2 text-xs leading-relaxed text-muted">{a.description}</p>
                  <div className="mt-2 flex flex-wrap items-center gap-3 text-[11px] text-muted">
                    <span className="flex items-center gap-1"><MapPin size={11} /> {a.locationName}</span>
                    <span>{relativeTime(a.timestamp)}</span>
                    <span className="num opacity-70">{a.id}</span>
                  </div>
                </div>
                <div className="flex shrink-0 flex-wrap items-center gap-2">
                  <Button size="sm" variant="secondary" icon={<ChevronRight size={13} />} onClick={() => setDetail(a)}>View details</Button>
                  {a.status === 'active' ? (
                    <Button size="sm" variant="outline" icon={<CheckCheck size={13} />} onClick={() => { acknowledge(a.id); toast.success('Alert acknowledged', { description: a.title }) }}>Acknowledge</Button>
                  ) : null}
                  {a.status !== 'dismissed' ? (
                    <Button size="sm" variant="ghost" icon={<X size={13} />} onClick={() => { dismiss(a.id); toast.info('Alert dismissed', { description: a.title }) }}>Dismiss</Button>
                  ) : (
                    <Button size="sm" variant="ghost" icon={<Undo2 size={13} />} onClick={() => { restore(a.id); toast.success('Alert restored') }}>Restore</Button>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {filtered.length === 0 ? (
        <StatePanel title="No alerts match your filters" message="Try clearing the search box, re-enabling severities or selecting a different status tab." actionLabel="Reset filters" onAction={resetFilters} />
      ) : null}

      <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-line bg-surface/50 px-4 py-2.5 text-[11px] text-muted">
        <span>Showing {filtered.length} of {alerts.length} demo alerts · {activeCountValue} active</span>
        <Button size="sm" variant="ghost" onClick={() => { resetAlerts(); toast.success('Alert demo data reset') }}>Reset alert demo data</Button>
      </div>

      <p className="rounded-xl border border-warning/25 bg-warning/8 px-4 py-2.5 text-[11px] text-warning">
        Demo alerts — simulated for interface validation; not operational bulletins.
      </p>

      {/* Detail modal */}
      <Modal
        open={detail !== null}
        onClose={() => setDetail(null)}
        title={detail?.title ?? ''}
        subtitle={detail ? `${detail.category} · ${detail.id}` : undefined}
        footer={detail ? (
          <>
            <Button variant="ghost" onClick={() => setDetail(null)}>Close</Button>
            {detail.status === 'active' ? (
              <Button variant="primary" icon={<CheckCheck size={14} />} onClick={() => { acknowledge(detail.id); setDetail({ ...detail, status: 'acknowledged' }); toast.success('Alert acknowledged') }}>Mark acknowledged</Button>
            ) : null}
            {detail.status !== 'dismissed' ? (
              <Button variant="danger" icon={<X size={14} />} onClick={() => { dismiss(detail.id); setDetail({ ...detail, status: 'dismissed' }); toast.info('Alert dismissed') }}>Dismiss</Button>
            ) : null}
          </>
        ) : undefined}
      >
        {detail ? (
          <div className="space-y-4">
            <div className="flex flex-wrap gap-2">
              <SeverityBadge severity={detail.severity} />
              <Badge tone="muted">{detail.category}</Badge>
              <Badge tone={detail.status === 'active' ? 'warning' : detail.status === 'acknowledged' ? 'success' : 'muted'}>{detail.status}</Badge>
            </div>
            <div className="grid grid-cols-2 gap-3 rounded-xl border border-line bg-surface/60 p-3 text-xs sm:grid-cols-4">
              <div><p className="text-[10px] text-muted">Location</p><p className="mt-0.5 font-semibold text-ink">{detail.locationName}</p></div>
              <div><p className="text-[10px] text-muted">Issued</p><p className="mt-0.5 font-semibold text-ink">{formatDateTime(detail.timestamp)}</p></div>
              <div><p className="text-[10px] text-muted">Severity</p><p className="mt-0.5 font-semibold" style={{ color: SEVERITY_COLORS[detail.severity] }}>{detail.severity}</p></div>
              <div><p className="text-[10px] text-muted">ID</p><p className="num mt-0.5 font-semibold text-ink">{detail.id}</p></div>
            </div>
            <div>
              <p className="mb-1 text-[10px] font-semibold tracking-wider text-muted uppercase">Description</p>
              <p className="text-sm leading-relaxed text-ink">{detail.description}</p>
            </div>
            <div className="rounded-xl border border-accent/25 bg-accent/8 p-3">
              <p className="mb-1 text-[10px] font-semibold tracking-wider text-accent uppercase">Suggested action (demo)</p>
              <p className="text-sm leading-relaxed text-ink">{detail.guidance}</p>
            </div>
          </div>
        ) : null}
      </Modal>
    </div>
  )
}
