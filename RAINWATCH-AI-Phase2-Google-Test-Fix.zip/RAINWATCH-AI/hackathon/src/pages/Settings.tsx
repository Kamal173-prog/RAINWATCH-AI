import {
  Bell,
  Check,
  Clipboard,
  Database,
  Gauge,
  Info,
  Layers,
  MapPin,
  Moon,
  Palette,
  RotateCcw,
  Sun,
  Trash2,
} from 'lucide-react'
import { useState } from 'react'
import { toast } from 'sonner'
import { ACCENT_OPTIONS } from '../context/SettingsContext'
import { Badge, DemoBadge } from '../components/common/Badge'
import { BrandLogo } from '../components/common/BrandLogo'
import { Button } from '../components/common/Button'
import { Card, CardHeader } from '../components/common/Card'
import { Modal } from '../components/common/Modal'
import { PageHeader } from '../components/common/PageHeader'
import { SegmentedControl } from '../components/common/SegmentedControl'
import { Select } from '../components/common/Select'
import { Toggle } from '../components/common/Toggle'
import { useAlerts } from '../context/AlertsContext'
import { useDemo } from '../context/DemoContext'
import { useSelectedLocation } from '../context/LocationContext'
import { useSettings } from '../context/SettingsContext'
import { useAsyncData } from '../hooks/useAsyncData'
import { demoApi } from '../services/dataService'
import { LAYER_DEFS } from '../components/maps/RainMap'
import { SEVERITY_COLORS, SEVERITY_ORDER } from '../utils/colors'
import { TIMEFRAME_OPTIONS } from '../data/settingsData'

const SECTIONS = [
  { id: 'appearance', label: 'Appearance', icon: Palette },
  { id: 'dashboard', label: 'Dashboard', icon: Gauge },
  { id: 'notifications', label: 'Notifications', icon: Bell },
  { id: 'application', label: 'Application', icon: Database },
]

export function Settings() {
  const { settings, update, reset, clearPreferences, accent } = useSettings()
  const { setLocationId } = useSelectedLocation()
  const { refresh, refreshing } = useDemo()
  const { alerts, resetAlerts } = useAlerts()
  const { data: locations } = useAsyncData(() => demoApi.listLocations(), [])
  const [confirmClear, setConfirmClear] = useState(false)
  const [activeSection, setActiveSection] = useState('appearance')

  const scrollTo = (id: string) => {
    setActiveSection(id)
    document.getElementById(`settings-${id}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  const toggleSeverity = (s: typeof SEVERITY_ORDER[number]) => {
    const next = settings.severityPrefs.includes(s)
      ? settings.severityPrefs.filter((x) => x !== s)
      : [...settings.severityPrefs, s]
    update({ severityPrefs: next })
  }

  const toggleLayer = (id: typeof settings.defaultMapLayers[number]) => {
    const next = settings.defaultMapLayers.includes(id)
      ? settings.defaultMapLayers.filter((x) => x !== id)
      : [...settings.defaultMapLayers, id]
    update({ defaultMapLayers: next })
  }

  const copyPrefs = async () => {
    const text = JSON.stringify(settings, null, 2)
    try {
      await navigator.clipboard.writeText(text)
      toast.success('Preferences copied to clipboard')
    } catch {
      const ta = document.createElement('textarea')
      ta.value = text
      document.body.appendChild(ta)
      ta.select()
      document.execCommand('copy')
      document.body.removeChild(ta)
      toast.success('Preferences copied to clipboard')
    }
  }

  return (
    <div className="section-gap flex flex-col">
      <PageHeader
        title="Settings"
        subtitle="Personalise the RAINWATCH AI experience. Preferences persist in this browser via localStorage."
        meta={<><DemoBadge /><Badge tone="muted">{accent.name} accent · {settings.density} layout</Badge></>}
      >
        <Button icon={<RotateCcw size={14} />} onClick={() => { reset(); toast.success('Settings restored to defaults') }}>Reset settings</Button>
      </PageHeader>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[200px_1fr]">
        {/* In-page nav */}
        <nav aria-label="Settings sections" className="lg:sticky lg:top-20 lg:self-start">
          <div className="flex gap-1.5 overflow-x-auto rounded-xl border border-line bg-card p-1.5 lg:flex-col lg:overflow-visible">
            {SECTIONS.map((s) => {
              const Icon = s.icon
              const active = activeSection === s.id
              return (
                <button key={s.id} type="button" onClick={() => scrollTo(s.id)}
                  className={`flex items-center gap-2.5 whitespace-nowrap rounded-lg px-3 py-2 text-left text-xs font-medium transition-all ${
                    active ? 'bg-accent/12 text-accent' : 'text-muted hover:bg-surface hover:text-ink'
                  }`}>
                  <Icon size={15} aria-hidden /> {s.label}
                </button>
              )
            })}
          </div>
        </nav>

        <div className="flex min-w-0 flex-col gap-4">
          {/* Appearance */}
          <Card id="settings-appearance" className="scroll-mt-20">
            <CardHeader title="Appearance" subtitle="Theme, accent colour and layout density" icon={<Palette size={16} />} />
            <div className="space-y-5">
              <div>
                <p className="mb-2 text-[11px] font-semibold tracking-wider text-muted uppercase">Colour theme</p>
                <SegmentedControl ariaLabel="Theme" value={settings.theme}
                  onChange={(v) => { update({ theme: v }); toast.info(`${v === 'dark' ? 'Dark' : 'Light'} theme applied`) }}
                  options={[{ value: 'dark', label: <><Moon size={13} /> Dark</> }, { value: 'light', label: <><Sun size={13} /> Light</> }]} />
              </div>

              <div>
                <p className="mb-2 text-[11px] font-semibold tracking-wider text-muted uppercase">Accent colour</p>
                <div className="flex flex-wrap gap-2.5">
                  {ACCENT_OPTIONS.map((a) => {
                    const active = settings.accent === a.id
                    return (
                      <button key={a.id} type="button" onClick={() => { update({ accent: a.id }); toast.info(`${a.name} accent applied`) }}
                        aria-label={`${a.name} accent`} aria-pressed={active}
                        className={`flex h-9 w-9 items-center justify-center rounded-full border-2 transition-transform hover:scale-110 ${active ? 'border-ink' : 'border-transparent'}`}
                        style={{ background: `linear-gradient(135deg, ${a.primary}, ${a.secondary})` }}>
                        {active ? <Check size={15} className="text-[var(--rw-on-accent)]" /> : null}
                      </button>
                    )
                  })}
                </div>
                <p className="mt-2 text-[11px] text-muted">Selected: <span className="font-medium text-ink">{accent.name}</span> — affects buttons, charts, highlights and instrument accents across the app.</p>
              </div>

              <div className="border-t border-line pt-4">
                <Toggle checked={settings.density === 'compact'} onChange={(v) => { update({ density: v ? 'compact' : 'comfortable' }); toast.info(`${v ? 'Compact' : 'Comfortable'} layout applied`) }}
                  label="Compact layout" description="Tighter card padding and denser tables across the dashboard." />
                <div className={`mt-3 rounded-xl border border-line bg-surface/60 p-3 ${settings.density === 'compact' ? 'p-2' : ''}`}>
                  <p className="text-[10px] font-semibold tracking-wider text-muted uppercase">Live card preview</p>
                  <p className="mt-1 text-xs text-ink">Card padding: {settings.density === 'compact' ? '0.75rem' : '1.1rem'} · Row height: {settings.density === 'compact' ? '36px' : '44px'}</p>
                </div>
              </div>
            </div>
          </Card>

          {/* Dashboard */}
          <Card id="settings-dashboard" className="scroll-mt-20">
            <CardHeader title="Dashboard Preferences" subtitle="Defaults applied when you open the dashboard" icon={<Gauge size={16} />} />
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <Select label="Default location" options={(locations ?? []).map((l) => ({ value: l.id, label: `${l.name} · ${l.zone}` }))}
                value={settings.defaultLocationId}
                onValueChange={(v) => { update({ defaultLocationId: v }); setLocationId(v); toast.success('Default location updated') }} />
              <Select label="Default forecast timeframe" options={TIMEFRAME_OPTIONS.map((t) => ({ value: t.id, label: t.label }))}
                value={settings.defaultTimeframe} onValueChange={(v) => { update({ defaultTimeframe: v as typeof settings.defaultTimeframe }); toast.success('Default timeframe updated') }} />
              <div className="sm:col-span-2">
                <p className="mb-2 flex items-center gap-1.5 text-[11px] font-semibold tracking-wider text-muted uppercase"><Layers size={12} /> Default map layers</p>
                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
                  {LAYER_DEFS.map((def) => {
                    const on = settings.defaultMapLayers.includes(def.id)
                    const Icon = def.icon
                    return (
                      <button key={def.id} type="button" onClick={() => toggleLayer(def.id)} aria-pressed={on}
                        className={`flex items-center gap-2.5 rounded-xl border px-3 py-2 text-left transition-all ${on ? 'border-accent/40 bg-accent/8' : 'border-line bg-surface/50'}`}>
                        <span className="flex h-7 w-7 items-center justify-center rounded-lg" style={{ background: `${def.color}20`, color: def.color }}><Icon size={14} /></span>
                        <span className="min-w-0 flex-1 truncate text-xs font-medium text-ink">{def.label}</span>
                        <span className={`flex h-4 w-4 items-center justify-center rounded border ${on ? 'border-accent bg-accent text-[var(--rw-on-accent)]' : 'border-line'}`}>{on ? <Check size={11} /> : null}</span>
                      </button>
                    )
                  })}
                </div>
              </div>
              <div className="sm:col-span-2 border-t border-line pt-4">
                <p className="mb-2 text-[11px] font-semibold tracking-wider text-muted uppercase">Measurement units</p>
                <SegmentedControl ariaLabel="Units" value={settings.units}
                  onChange={(v) => { update({ units: v }); toast.info(`${v === 'metric' ? 'Metric' : 'Imperial'} units applied`) }}
                  options={[{ value: 'metric', label: 'Metric (mm, °C, km/h)' }, { value: 'imperial', label: 'Imperial (in, °F, mph)' }]} />
              </div>
            </div>
          </Card>

          {/* Notifications */}
          <Card id="settings-notifications" className="scroll-mt-20">
            <CardHeader title="Notification Preferences" subtitle="Control which demo alerts appear in the notification bell" icon={<Bell size={16} />} />
            <div className="space-y-4">
              <Toggle checked={settings.notificationsEnabled} onChange={(v) => { update({ notificationsEnabled: v }); toast.info(v ? 'Demo notifications enabled' : 'Demo notifications disabled') }}
                label="Enable demo notifications" description="Show the notification bell and active alert count in the top bar." />
              <div className="border-t border-line pt-4">
                <p className="mb-2 text-[11px] font-semibold tracking-wider text-muted uppercase">Alert severities to notify</p>
                <div className="flex flex-wrap gap-2">
                  {SEVERITY_ORDER.map((s) => {
                    const on = settings.severityPrefs.includes(s)
                    return (
                      <button key={s} type="button" onClick={() => toggleSeverity(s)} aria-pressed={on}
                        className="cut-br inline-flex items-center gap-2 border px-3 py-1.5 text-xs font-medium transition-all"
                        style={{ borderColor: on ? `${SEVERITY_COLORS[s]}70` : 'var(--rw-border)', background: on ? `${SEVERITY_COLORS[s]}18` : 'transparent', color: on ? SEVERITY_COLORS[s] : 'var(--rw-muted)' }}>
                        <span className="h-2 w-2 rounded-full" style={{ background: on ? SEVERITY_COLORS[s] : 'transparent', border: on ? 'none' : '1px solid var(--rw-muted)' }} />
                        {s}
                        {on ? <Check size={12} /> : null}
                      </button>
                    )
                  })}
                </div>
                <p className="mt-3 rounded-lg border border-line bg-surface/60 px-3 py-2 text-[11px] text-muted">
                  Live preview — you will be notified for: <span className="font-medium text-ink">{settings.severityPrefs.length ? settings.severityPrefs.join(', ') : 'no severities'}</span>.
                </p>
              </div>
              <div className="border-t border-line pt-4">
                <Toggle checked={settings.notificationsEnabled} onChange={() => { update({ notificationsEnabled: !settings.notificationsEnabled }); }}
                  label="Bell status" description={`Currently ${settings.notificationsEnabled ? 'enabled' : 'disabled'} with ${settings.severityPrefs.length} severities selected. ${alerts.filter((a) => a.status === 'active' && settings.severityPrefs.includes(a.severity)).length} matching active alerts.`} />
              </div>
            </div>
          </Card>

          {/* Application */}
          <Card id="settings-application" className="scroll-mt-20">
            <CardHeader title="Application" subtitle="About, demo information and data management" icon={<Database size={16} />} />
            <div className="space-y-4">
              <div className="relative overflow-hidden rounded-xl border border-accent/25 bg-gradient-to-br from-accent/12 via-transparent to-accent-2/10 p-4 gradient-pan">
                <div className="flex items-center gap-2"><BrandLogo size={30} /><p className="font-display text-base font-bold text-ink">RAINWATCH AI</p></div>
                <p className="mt-1 text-xs font-semibold tracking-[0.16em] text-accent uppercase">Predict. Prepare. Protect.</p>
                <p className="mt-2 max-w-2xl text-xs leading-relaxed text-muted">
                  Integrated Heavy Rainfall Early Warning and Inundation Prediction System — frontend demonstration
                  of a premium disaster-intelligence command centre. The interface is fully interactive, served by
                  the integrated backend (trained ML ensemble + ERA5 archive) with local sample datasets where noted;
                  satellite, radar and station feeds are out of scope for this build.
                </p>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div className="rounded-xl border border-line bg-surface/60 p-3">
                  <p className="flex items-center gap-1.5 text-xs font-semibold text-ink"><Info size={13} className="text-accent" /> Demo mode</p>
                  <p className="mt-1 text-[11px] leading-relaxed text-muted">Rainfall forecasts and flood-risk records for Bhubaneswar-region locations come from the trained ML ensemble via the backend; Ganjam locations, alerts and inundation geometry use simulated demo values.</p>
                </div>
                <div className="rounded-xl border border-line bg-surface/60 p-3">
                  <p className="flex items-center gap-1.5 text-xs font-semibold text-ink"><MapPin size={13} className="text-accent" /> Region</p>
                  <p className="mt-1 text-[11px] leading-relaxed text-muted">Demonstration regions: Bhubaneswar and the Brahmapur–Gopalpur coast (Ganjam), Odisha, India. Sample overlays are synthetic geometry, not real flood boundaries.</p>
                </div>
              </div>

              <div className="flex flex-wrap gap-2 border-t border-line pt-4">
                <Button icon={<RotateCcw size={14} />} loading={refreshing} onClick={async () => { await refresh(); resetAlerts(); toast.success('Demo data reset', { description: 'Series regenerated and alert statuses cleared.' }) }}>Reset demo data</Button>
                <Button variant="danger" icon={<Trash2 size={14} />} onClick={() => setConfirmClear(true)}>Clear saved preferences</Button>
                <Button variant="outline" icon={<Clipboard size={14} />} onClick={copyPrefs}>Copy preferences</Button>
              </div>

              <div className="rounded-xl border border-line bg-surface/60 p-3">
                <p className="mb-2 text-[11px] font-semibold tracking-wider text-muted uppercase">Stored preferences</p>
                <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-[11px] sm:grid-cols-3">
                  {[
                    ['Theme', settings.theme], ['Accent', accent.name], ['Density', settings.density],
                    ['Location', settings.defaultLocationId], ['Timeframe', settings.defaultTimeframe],
                    ['Units', settings.units], ['Notifications', settings.notificationsEnabled ? 'On' : 'Off'],
                    ['Map layers', `${settings.defaultMapLayers.length}/6`], ['Severities', `${settings.severityPrefs.length}/5`],
                  ].map(([k, v]) => (
                    <div key={k} className="flex justify-between gap-2"><span className="text-muted">{k}</span><span className="num font-semibold text-ink">{v}</span></div>
                  ))}
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>

      <Modal open={confirmClear} onClose={() => setConfirmClear(false)} title="Clear saved preferences?"
        subtitle="This removes settings, alert statuses, demo location and map layers from localStorage."
        size="sm"
        footer={<>
          <Button variant="ghost" onClick={() => setConfirmClear(false)}>Cancel</Button>
          <Button variant="danger" icon={<Trash2 size={14} />} onClick={() => { clearPreferences(); resetAlerts(); setConfirmClear(false); toast.success('Saved preferences cleared') }}>Clear everything</Button>
        </>}>
        <p className="text-sm leading-relaxed text-muted">
          Your preferences will be restored to factory defaults and the app will immediately adopt the dark theme,
          metric units and the default demonstration region. This cannot be undone.
        </p>
      </Modal>
    </div>
  )
}
