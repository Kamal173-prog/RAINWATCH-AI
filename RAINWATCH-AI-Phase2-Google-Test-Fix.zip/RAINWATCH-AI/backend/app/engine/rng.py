"""Deterministic pseudo-random helpers — a faithful port of
``hackathon/src/utils/rng.ts`` and the classify helpers from
``hackathon/src/utils/colors.ts``.

The frontend demo data is generated from a seeded LCG, so the API
returns values from the same distributions (and, for the same demo
tick, the same values) as the local demo engine.
"""

import math

MASK32 = 0xFFFFFFFF


def imul(a: int, b: int) -> int:
    """32-bit integer multiplication (JS Math.imul) — low 32 bits."""
    return (a * b) & MASK32


def create_rng(seed: int):
    """LCG identical to the frontend's createRng.

    Returns a callable producing floats in [0, 1).
    """
    s = (seed & MASK32) or 1

    def rng() -> float:
        nonlocal s
        s = ((s * 1664525) + 1013904223) & MASK32
        return s / 4294967296

    return rng


def hash_seed(text: str) -> int:
    """FNV-1a 32-bit hash (JS hashSeed). ASCII ids hash identically."""
    h = 2166136261
    for ch in text:
        h ^= ord(ch)
        h = (h * 16777619) & MASK32
    return h & MASK32


def clamp(value: float, low: float, high: float) -> float:
    return min(high, max(low, value))


def js_round(value: float, decimals: int = 1) -> float:
    """JS Math.round semantics (round half up), unlike Python's banker's
    rounding. Matches the frontend's ``round()`` helper."""
    f = 10 ** decimals
    return math.floor(value * f + 0.5) / f


# ------------------------------------------------------------------
# Classification helpers (src/utils/colors.ts)
# ------------------------------------------------------------------

RAINFALL_BANDS = [
    {"label": "Light", "range": "< 2.5 mm/hr", "min": 0, "max": 2.5, "color": "#69D2A0"},
    {"label": "Moderate", "range": "2.5 – 15.5 mm/hr", "min": 2.5, "max": 15.6, "color": "#6FD6C2"},
    {"label": "Heavy", "range": "15.6 – 64.4 mm/hr", "min": 15.6, "max": 64.5, "color": "#F2A93B"},
    {"label": "Very Heavy", "range": "64.5 – 115.5 mm/hr", "min": 64.5, "max": 115.5, "color": "#F0823F"},
    {"label": "Extremely Heavy", "range": "> 115.5 mm/hr", "min": 115.5, "max": float("inf"), "color": "#F05A43"},
]

RISK_LEVELS = ["Low", "Moderate", "High", "Very High", "Critical"]

SEVERITY_ORDER = ["Information", "Advisory", "Watch", "Warning", "Critical"]


def classify_rainfall(mm_hr: float) -> str:
    if mm_hr < 2.5:
        return "Light"
    if mm_hr < 15.6:
        return "Moderate"
    if mm_hr < 64.5:
        return "Heavy"
    if mm_hr < 115.5:
        return "Very Heavy"
    return "Extremely Heavy"


def classify_risk(index: float) -> str:
    if index < 25:
        return "Low"
    if index < 45:
        return "Moderate"
    if index < 65:
        return "High"
    if index < 82:
        return "Very High"
    return "Critical"
