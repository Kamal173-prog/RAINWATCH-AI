"""Hackathon demonstration replay: the 2021-07-21 monsoon event.

Scores the frozen v3.3 model (with the optimized thresholds) hour by
hour through the monsoon replay window, using the prebuilt v33 feature
table and the frozen artifacts directly -- the same values the API
serves (ml/verify_v33_inference.py proves the live inference path
reproduces the table exactly).

For each hour the replay records: model version, prediction timestamp,
expected rainfall (1h/3h/6h), P90 upper bounds, heavy-event
probabilities, Watch/Warning tier + plain-language explanation,
provenance (ERA5 + GFS sources), the number of GFS features that were
missing (NaN) at that hour, and the ACTUAL rainfall that followed
(ERA5 reanalysis) so the demo can show prediction vs reality honestly.

A second check scores one hour inside the GFS archive gap
(2022-11-29 -> 2022-12-14, 345 h with no GFS data) through the live
RainfallForecaster to demonstrate the missing-data fallback: the
GFS features come back NaN and the model still returns values.

Output: docs/V33_DEMO_REPLAY.json
"""

import json
import logging
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import evaluate_2026 as ev  # noqa: E402
from ml.predict import _load_member as _load_pred, _model_predict  # noqa: E402
from v33_common import platt_apply  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger("demo_replay")

BACKEND = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FROZEN = os.path.join(BACKEND, "models", "rainfall_xgb_v3_3", "frozen")
TARGETS = ["y_3h_ge_10mm", "y_6h_ge_10mm", "y_3h_ge_5mm"]
KEYS = {"y_3h_ge_10mm": "3h_ge_10mm", "y_6h_ge_10mm": "6h_ge_10mm",
        "y_3h_ge_5mm": "3h_ge_5mm"}

TIER_EXPLANATIONS = {
    "high": ("WARNING: the model gives a high probability of heavy rain "
             "in the next 3-6 hours. Prepare for waterlogging on low-lying "
             "roads; avoid travel through underpasses."),
    "elevated": ("WATCH: conditions favour heavy rain in the next 3-6 hours. "
                 "Stay alert for updates; keep drainage clear and plan "
                 "travel with a buffer."),
    "moderate": ("Conditions are slightly above normal for rain. No action "
                 "needed beyond the usual monsoon care."),
    "low": ("No heavy rain expected in the next 6 hours from this grid cell."),
}


def _tier(probs: dict, thr: dict) -> str:
    if (probs["3h_ge_10mm"] >= thr["y_3h_ge_10mm"]["high"]
            or probs["6h_ge_10mm"] >= thr["y_6h_ge_10mm"]["high"]):
        return "high"
    if (probs["3h_ge_10mm"] >= thr["y_3h_ge_10mm"]["elevated"]
            or probs["6h_ge_10mm"] >= thr["y_6h_ge_10mm"]["elevated"]
            or probs["3h_ge_5mm"] >= thr["y_3h_ge_5mm"]["elevated"]):
        return "elevated"
    if (probs["3h_ge_10mm"] >= 0.5 * thr["y_3h_ge_10mm"]["elevated"]
            or probs["3h_ge_5mm"] >= 0.5 * thr["y_3h_ge_5mm"]["elevated"]):
        return "moderate"
    return "low"


def main() -> None:
    feats = json.load(open(os.path.join(FROZEN, "feature_schema.json")))["features"]
    weights = json.load(open(os.path.join(FROZEN, "ensemble_weights.json")))
    platt = json.load(open(os.path.join(FROZEN, "platt.json")))
    thr = json.load(open(os.path.join(FROZEN, "thresholds_optimized.json")))
    reg_weights = json.load(open(os.path.join(
        BACKEND, "models", "rainfall_xgb_v3", "ensemble_weights.json")))
    reg_feats = json.load(open(os.path.join(
        BACKEND, "models", "rainfall_xgb_v3", "feature_schema.json")))["features"]

    table = pd.read_csv(os.path.join(BACKEND, "data", "model_ready",
                                     "bhubaneswar_features_v33.csv"),
                        parse_dates=["timestamp"])
    weather = pd.read_csv(os.path.join(BACKEND, "data", "processed",
                                       "bhubaneswar_weather.csv"),
                          parse_dates=["timestamp"])
    rain = weather.set_index("timestamp")["precipitation_mm"]

    # --- Monsoon replay window: 2021-07-21 00:00 -> 2021-07-22 12:00 ---
    window = table[(table["timestamp"] >= "2021-07-21 00:00")
                   & (table["timestamp"] <= "2021-07-22 12:00")].reset_index(drop=True)
    hours = []
    for _, row in window.iterrows():
        ts = row["timestamp"]
        X = row[feats].to_numpy(dtype=float).reshape(1, -1)
        Xr = row[reg_feats].to_numpy(dtype=float).reshape(1, -1)
        probs = {}
        for target in TARGETS:
            ens = sum(float(weights[target][fam]) * ev._predict(
                ev._load_member(FROZEN, target, fam), X) for fam in ev.FAMILIES)
            ens_scalar = float(np.asarray(ens).ravel()[0])
            cal = platt_apply(np.array([ens_scalar]), float(platt[target]["w"]),
                              float(platt[target]["b"]))
            probs[KEYS[target]] = round(float(np.asarray(cal).ravel()[0]), 4)
        expected = {}
        for h in (1, 3, 6):
            ens = 0.0
            for fam in ev.FAMILIES:
                m = _load_pred(f"reg_{h}h", fam,
                               os.path.join(BACKEND, "models", "rainfall_xgb_v3"))
                ens += float(reg_weights[f"reg_{h}h"][fam]) * _model_predict(m, Xr)
            expected[f"{h}h"] = round(max(float(ens), 0.0), 2)
        p90 = {}
        for h in (3, 6):
            ens = 0.0
            for fam in ev.FAMILIES:
                m = _load_pred(f"p90_{h}h", fam,
                               os.path.join(BACKEND, "models", "rainfall_xgb_v3"))
                ens += float(reg_weights[f"p90_{h}h"][fam]) * _model_predict(m, Xr)
            p90[f"{h}h"] = round(max(float(ens), 0.0), 2)
        # Actual rain that followed (ERA5 reanalysis, not a forecast).
        actual = {}
        for h in (1, 3, 6):
            fut = rain.loc[ts + pd.Timedelta(hours=1): ts + pd.Timedelta(hours=h)]
            actual[f"{h}h"] = round(float(fut.sum()), 2) if len(fut) == h else None
        tier = _tier(probs, thr)
        nan_gfs = int(sum(1 for c in feats if c.startswith("gfs_") and pd.isna(row[c])))
        hours.append({
            "timestamp": str(ts),
            "model_version": "rainfall-xgb-v3.3",
            "expected_mm": expected,
            "upper_bound_p90_mm": p90,
            "heavy_rain_probability": probs,
            "heavy_risk_tier": tier,
            "tier_explanation": TIER_EXPLANATIONS[tier],
            "decision_thresholds": thr,
            "actual_rain_mm_next": actual,
            "gfs_features_missing": nan_gfs,
            "provenance": "ERA5 reanalysis (Bhubaneswar grid) + GFS Historical "
                          "Forecast API (Open-Meteo); predictions are "
                          "reanalysis-based hindcasts, not live forecasts",
        })
    log.info("replay: %d hours; tiers: %s", len(hours),
             {t: sum(1 for h in hours if h["heavy_risk_tier"] == t)
              for t in ("low", "moderate", "elevated", "high")})
    peak = max(hours, key=lambda h: h["actual_rain_mm_next"]["6h"] or 0)
    log.info("peak actual 6h rain in window: %s -> %.1f mm (tier %s, "
             "expected 6h %.2f mm, P90 %.2f mm)",
             peak["timestamp"], peak["actual_rain_mm_next"]["6h"],
             peak["heavy_risk_tier"], peak["expected_mm"]["6h"],
             peak["upper_bound_p90_mm"]["6h"])

    # --- Missing-data check: one hour inside the GFS archive gap ---
    from ml import features as feat
    from ml.predict import V33_MODEL_DIR, RainfallForecaster
    hourly = feat.load_hourly(os.path.join(
        BACKEND, "data", "processed", "bhubaneswar_weather.csv"))
    fc = RainfallForecaster(model_dir=V33_MODEL_DIR)
    gap_ts = pd.Timestamp("2022-12-05 12:00")
    sub = hourly[pd.to_datetime(hourly["timestamp"]) <= gap_ts].reset_index(drop=True)
    row = fc._features_at(sub)
    nan_gfs = [c for c in fc.features if c.startswith("gfs_") and pd.isna(row[c].iloc[0])]
    gap_out = fc.predict_with_provenance(sub)
    gap_check = {
        "timestamp": str(gap_ts),
        "gfs_features_missing": len(nan_gfs),
        "gfs_features_total": sum(1 for c in fc.features if c.startswith("gfs_")),
        "model_version": gap_out["model_version"],
        "expected_mm": gap_out["expected_mm"],
        "heavy_rain_probability": gap_out["heavy_rain_probability"],
        "heavy_risk_tier": gap_out["heavy_risk_tier"],
        "note": "GFS archive has a 345-hour gap 2022-11-29 -> 2022-12-14; "
                "the model still returns values with the GFS features NaN "
                "(XGBoost/LightGBM/HistGB handle NaN natively).",
    }
    log.info("gap check %s: %d/%d GFS features missing; tier %s; "
             "probs %s", gap_ts, gap_check["gfs_features_missing"],
             gap_check["gfs_features_total"], gap_check["heavy_risk_tier"],
             gap_check["heavy_rain_probability"])

    out = {
        "model_version": "rainfall-xgb-v3.3",
        "thresholds": thr,
        "replay_event": "2021-07-21 monsoon (actual 3h 13.7 mm, 6h 32.8 mm at 16:00)",
        "window": "2021-07-21 00:00 to 2021-07-22 12:00",
        "hours": hours,
        "missing_data_check": gap_check,
        "honesty_notes": [
            "Predictions are hindcasts from ERA5 reanalysis + archived GFS, "
            "not live forecasts: the model input is the last available "
            "archive hour, not the current weather.",
            "Actual rainfall shown is ERA5 reanalysis (a model product), "
            "not rain-gauge observations.",
            "Scope is one Bhubaneswar grid cell, not the whole of Odisha.",
            "A 'high' tier is an early-warning signal, not a confirmed forecast.",
        ],
    }
    json.dump(out, open(os.path.join(BACKEND, "docs", "V33_DEMO_REPLAY.json"), "w"),
              indent=2)
    log.info("saved docs/V33_DEMO_REPLAY.json")


if __name__ == "__main__":
    main()
