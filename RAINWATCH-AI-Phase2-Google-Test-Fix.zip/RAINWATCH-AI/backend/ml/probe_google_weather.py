"""Playwright probe for the Google Weather integration.

Two phases, run against live servers started by this script:
  Phase A — MOCKED Google success: the backend runs with an httpx
    MockTransport (see ml/mock_google_server.py) returning the
    documented 24h fixture. The Forecast page must show the GOOGLE
    WEATHER badge/section, the Google CSV must export google_weather
    rows, and the Data Sources card must show Live + last-retrieval
    time. The RAINWATCH table must still show 6 MODEL + 18 DEMO.
  Phase B — NO KEY: the real backend with no key configured. The
    Forecast page must show "Google Weather unavailable — key not
    configured", no fake Live anywhere, and the RAINWATCH forecast
    must still work (6 MODEL + 18 DEMO).

No live Google call is made in either phase (no real key exists).
Exits non-zero on any failure.
"""

import json
import subprocess
import sys
import time
import urllib.request
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

BACKEND = Path.home() / "workspace" / "backend"
HACKATHON = Path.home() / "workspace" / "hackathon"
VENV_PY = BACKEND / ".venv" / "bin" / "python"
OUT = Path.home() / "workspace" / "google-probe-screenshots"
OUT.mkdir(parents=True, exist_ok=True)
results: dict = {}


def wait_up(url, timeout=60):
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=5) as r:
                if r.status == 200:
                    return True
        except Exception:
            time.sleep(1)
    return False


def start_backend_mock(port):
    env = {"MODEL_VERSION": "rainfall-xgb-v3.3"}
    import os
    full_env = dict(os.environ, **env)
    full_env.pop("GOOGLE_WEATHER_API_KEY", None)
    return subprocess.Popen(
        [str(VENV_PY), "ml/mock_google_server.py", str(port)],
        cwd=BACKEND, env=full_env,
        stdout=open(OUT / "mock-backend.log", "w"),
        stderr=subprocess.STDOUT)


def start_backend_real(port):
    import os
    full_env = dict(os.environ)
    full_env.pop("GOOGLE_WEATHER_API_KEY", None)
    full_env["MODEL_VERSION"] = "rainfall-xgb-v3.3"
    return subprocess.Popen(
        [str(VENV_PY), "-m", "uvicorn", "app.main:app",
         "--host", "127.0.0.1", "--port", str(port)],
        cwd=BACKEND, env=full_env,
        stdout=open(OUT / "real-backend.log", "w"),
        stderr=subprocess.STDOUT)


def start_vite(api_base):
    import os
    full_env = dict(os.environ, VITE_API_URL=api_base)
    return subprocess.Popen(
        ["node", "node_modules/vite/bin/vite.js", "--port", "5173"],
        cwd=HACKATHON, env=full_env,
        stdout=open(OUT / "vite.log", "w"),
        stderr=subprocess.STDOUT)


def stop(proc):
    if proc and proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()


def table_source_counts(page):
    """Source badges in the RAINWATCH Forecast Data Table (last column)."""
    tables = page.locator("table")
    counts = Counter()
    for t in range(tables.count()):
        rows = tables.nth(t).locator("tbody tr")
        for i in range(rows.count()):
            cells = rows.nth(i).locator("td")
            if cells.count():
                counts[cells.nth(cells.count() - 1).inner_text().strip().upper()] += 1
    return counts


def run_phase_a():
    """Mocked Google success."""
    from playwright.sync_api import sync_playwright
    backend = start_backend_mock(8009)
    vite = None
    try:
        assert wait_up("http://127.0.0.1:8009/api/health"), "mock backend did not start"
        vite = start_vite("http://localhost:8009")
        assert wait_up("http://127.0.0.1:5173/"), "vite did not start"
        with sync_playwright() as p:
            b = p.chromium.launch()
            page = b.new_page()
            errors = []
            page.on("console", lambda m: errors.append(m.text)
                    if m.type == "error" and "ERR_TUNNEL_CONNECTION_FAILED" not in m.text and "503" not in m.text else None)
            page.on("requestfailed", lambda r: errors.append(r.url)
                    if "tile.openstreetmap" not in r.url and "fonts.g" not in r.url and "weather/google" not in r.url else None)
            # Forecast page
            page.goto("http://localhost:5173/forecast", wait_until="networkidle")
            page.wait_for_timeout(4000)
            body = page.locator("body").inner_text()
            results["phase_a"] = {
                "google_section_present": "Google Weather" in body,
                "google_unavailable_shown": "Google Weather unavailable" in body,
                "google_badges": page.locator('text="GOOGLE WEATHER"').count(),
                "table_sources": dict(table_source_counts(page)),
            }
            page.screenshot(path=str(OUT / "forecast-google-mocked.png"), full_page=True)
            # Google CSV export (second CSV button on the page)
            csv_buttons = page.get_by_text("Export Google CSV")
            assert csv_buttons.count() == 1, "Export Google CSV button missing"
            with page.expect_download() as dl:
                csv_buttons.first.click()
            dl.value.save_as(str(OUT / "google-export.csv"))
            lines = (OUT / "google-export.csv").read_text().strip().splitlines()
            sources = [ln.rsplit(",", 1)[-1].strip() for ln in lines[1:]]
            results["phase_a"]["google_csv"] = {
                "rows": len(lines) - 1,
                "google_weather_rows": sources.count("google_weather"),
            }
            # Data Sources page
            page.goto("http://localhost:5173/data-sources", wait_until="networkidle")
            page.wait_for_timeout(3000)
            ds_body = page.locator("body").inner_text()
            results["phase_a"]["data_sources"] = {
                "google_card_present": "Google Weather API" in ds_body,
                # Exact-text "Live": only a Live status badge matches;
                # the "Live observation feeds" summary label does not.
                "live_badges": page.locator('text="Live"').count(),
                "last_retrieved_shown": "Last retrieved" in ds_body,
            }
            page.screenshot(path=str(OUT / "datasources-google-live.png"), full_page=True)
            results["phase_a"]["console_errors"] = errors
            b.close()
    finally:
        stop(vite)
        stop(backend)


def run_phase_b():
    """No key configured."""
    from playwright.sync_api import sync_playwright
    backend = start_backend_real(8001)
    vite = None
    try:
        assert wait_up("http://127.0.0.1:8001/api/health"), "real backend did not start"
        vite = start_vite("http://localhost:8001")
        assert wait_up("http://127.0.0.1:5173/"), "vite did not start"
        with sync_playwright() as p:
            b = p.chromium.launch()
            page = b.new_page()
            errors = []
            page.on("console", lambda m: errors.append(m.text)
                    if m.type == "error" and "ERR_TUNNEL_CONNECTION_FAILED" not in m.text and "503" not in m.text else None)
            page.goto("http://localhost:5173/forecast", wait_until="networkidle")
            page.wait_for_timeout(4000)
            body = page.locator("body").inner_text()
            results["phase_b"] = {
                "unavailable_message": "Google Weather unavailable" in body,
                "key_not_configured": "key not configured" in body,
                "google_badges": page.locator('text="GOOGLE WEATHER"').count(),
                "table_sources": dict(table_source_counts(page)),
            }
            page.screenshot(path=str(OUT / "forecast-google-nokey.png"), full_page=True)
            page.goto("http://localhost:5173/data-sources", wait_until="networkidle")
            page.wait_for_timeout(3000)
            ds_body = page.locator("body").inner_text()
            results["phase_b"]["data_sources"] = {
                "google_card_present": "Google Weather API" in ds_body,
                "live_badges": page.locator('text="Live"').count(),
                "not_connected_shown": "NOT CONNECTED" in ds_body,
            }
            results["phase_b"]["console_errors"] = errors
            b.close()
    finally:
        stop(vite)
        stop(backend)


def main():
    run_phase_a()
    run_phase_b()
    print(json.dumps(results, indent=2))
    a = results["phase_a"]
    b = results["phase_b"]
    ok = (
        a["google_section_present"]
        and not a["google_unavailable_shown"]
        and a["google_badges"] == 24
        and a["table_sources"].get("MODEL") == 6
        and a["table_sources"].get("DEMO") == 18
        and a["table_sources"].get("GOOGLE WEATHER") == 24
        and a["google_csv"]["google_weather_rows"] == 24
        and a["data_sources"]["google_card_present"]
        and a["data_sources"]["live_badges"] >= 1
        and a["data_sources"]["last_retrieved_shown"]
        and not a["console_errors"]
        and b["unavailable_message"]
        and b["key_not_configured"]
        and b["google_badges"] == 0
        and b["table_sources"].get("MODEL") == 6
        and b["table_sources"].get("DEMO") == 18
        and b["table_sources"].get("GOOGLE WEATHER") is None
        and b["data_sources"]["live_badges"] == 0
        and b["data_sources"]["not_connected_shown"]
        and not b["console_errors"]
    )
    print("VERDICT:", "PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
