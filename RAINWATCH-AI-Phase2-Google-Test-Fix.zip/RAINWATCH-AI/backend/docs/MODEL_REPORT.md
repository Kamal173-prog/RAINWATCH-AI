# RAINWATCH AI — Rainfall Model: Training & Evaluation Report

**Model:** `rainfall-xgb-v3` (Spatial-Thermodynamic Ensemble: XGBoost + LightGBM + HistGradientBoosting)
**Date trained:** 23 November 2026 (v3; v2 and v1 same day)
**Status:** Trained, evaluated, reproducible, **integrated into the API (23 Nov 2026, API v1.3.0)** — see §9.
**Supersedes:** `rainfall-xgb-v2` (single-family XGBoost two-stage). v3 keeps the v2 two-stage architecture and adds a multi-family ensemble, spatial look-ahead from the Puri Coast / Offshore Bay grids, and dual operating thresholds (Watch / Warning).

---

## 1. What this model is

A genuine trained machine-learning forecaster that predicts rainfall
accumulation over the next **1 h, 3 h and 6 h** for the Bhubaneswar ERA5
grid cell, plus the **probability of heavy/moderate events** and a
**90th-percentile upper bound**. It is trained on the real Open-Meteo
ERA5 archive — not on the demo generator, and not on fabricated data.

**Why v3 (ensemble + spatial):** v2 hit a precision ceiling (3 h ≥ 10 mm
Precision 0.09) because it used a single grid point and a single model
family. v3 adds (a) upwind spatial look-ahead — Puri Coast and Offshore
Bay of Bengal grids ~50 km SE, where heavy bursts advect onshore from;
(b) wind direction (vector wind, onshore moisture flux); and (c) a
multi-family ensemble (XGBoost + LightGBM + HistGradientBoosting) with
validation-learned weights, which improves probability calibration and
cuts false alarms. **CAPE is not used** — Open-Meteo returned it as all
nulls for this region (see §2).

**Why two stages (v2, kept):** a plain regressor predicts the conditional
mean, which averages rare convective bursts with dry outcomes and stays
below 10 mm — so v1 could not detect heavy events at all (3 h ≥ 10 mm
F1 0.0). v2/v3 keep the mean regressors untouched in role (they still give
the expected accumulation) and add a decoupled second stage: dedicated
binary classifiers for heavy/moderate events, and P90 quantile regressors
for an upper envelope.

**Scope (read this first):** Bhubaneswar grid cell only
(lat 20.281195, lng 85.843376). The training data is a single point plus
two upwind points, so the model must not be presented as state-wide, and
it must not be presented as an operational warning system. It is a
research/hackathon forecaster with the limitations in §6.

## 2. Data

| Item | Value |
|---|---|
| Source | Open-Meteo Historical Weather API, ERA5 reanalysis |
| File | `data/processed/bhubaneswar_weather.csv` (43,824 hourly rows, 2021–2025; 18 columns incl. convective + thermodynamic) |
| Upwind file | `data/processed/upwind_spatial.csv` (43,824 hourly rows, 2021–2025; Puri Coast + Offshore Bay) |
| Feature table | `data/model_ready/bhubaneswar_features.csv` (43,747 rows, 62 features + 3 targets + 3 binary targets; 41 kept after pruning) |
| Variables | temperature, humidity, precipitation, wind speed + direction, pressure, cloud cover + convective: wind gusts, low/mid/high cloud cover, vapour pressure deficit + thermodynamic: dew point (2 m), surface pressure + upwind: precip, pressure, wind, humidity at Puri Coast and Offshore Bay |
| Quality | 0 missing values in every column **except `tcwv_kg_m2`** (4,368 missing, 2024-01-01 → 2024-07-01, a 6-month gap in the source) **and `cape_jkg` / `coast_cape_jkg` / `bay_cape_jkg`** (all null — CAPE not populated by Open-Meteo; see below) |
| Ganjam / Brahmapur | Not available (Open-Meteo rate-limited, HTTP 429, twice on 23 Nov 2026). The model is Bhubaneswar-only until that archive lands. |
| Not used as features | `showers` (all zeros at this grid cell), `tcwv` (6-month gap), `cape` (all nulls). See data/README.md. |

**CAPE unavailable:** the Open-Meteo archive API returned `cape` as all
nulls (0 non-null out of 43,824) for all three grid cells. v3 therefore
uses surface-based instability proxies (dew-point depression,
moisture-flux proxy, wind-direction-derived onshore flux, theta_e proxy)
instead of CAPE. Do not claim CAPE features exist.

**Target characteristics (the honest picture):**
- Precipitation is 80.8% dry hours. Mean 3-h accumulation is 0.6 mm.
- Maximum hourly precipitation in 5 years is **22.3 mm**. There is **no
  hour above 25 mm** and only 68 hours above 10 mm.
- IMD "Very Heavy" (≥ 64.5 mm/hr) and "Extremely Heavy" (≥ 115.5 mm/hr)
  **never occur in this data** — a classifier for those classes cannot be
  trained here, and none was attempted.
- ERA5 is reanalysis, not station observations: it smooths convective
  extremes, so real gauge data would show higher peaks.

## 3. Features (62 total, 41 kept after pruning)

All features use data at time `t` or earlier. Targets are strictly in the
future (`t+1` onwards). No leakage.

- **Lagged precipitation:** 1 / 3 / 6 / 12 / 24 h ago.
- **Rolling precipitation:** sums over the last 3 / 6 / 12 / 24 / 72 h,
  maxima over the last 6 / 24 h, 24-h mean.
- **Current meteorology:** temperature, humidity, wind speed, pressure,
  cloud cover, dew point (Magnus formula).
- **Lagged meteorology + tendencies:** temperature / humidity / pressure
  6 h and 24 h ago; pressure tendency (6 h, 24 h); temperature tendency (6 h).
- **Time:** hour-of-day and day-of-year as sin/cos pairs, month,
  monsoon flag (Jun–Sep).
- **v2 instability features:** dew point depression (temp − dew point);
  onshore moisture flux proxy (wind × saturation vapour pressure × humidity);
  1 h and 3 h pressure drops; pressure acceleration.
- **v2 convective features:** wind gusts, low / mid / high cloud cover,
  vapour pressure deficit, gust factor (gusts − wind), deep-convection
  flag (low cloud > 60% AND high cloud > 60%).
- **v3 vector wind & onshore flux:** zonal (u) and meridional (v) wind
  components from speed + direction; onshore SE flux (wind projected onto
  the SE-to-NW onshore vector × specific humidity q); saturation-weighted
  moisture convergence proxy (onshore flux × saturation).
- **v3 thermodynamic:** dew point (2 m, direct), surface pressure (direct),
  equivalent potential temperature proxy (theta_e).
- **v3 spatial look-ahead:** upwind Puri Coast and Offshore Bay
  precipitation (current and 3 h sums) and the spatial rain lead
  (coast 3 h sum − Bhubaneswar 3 h sum).
- **v3 sea-to-land gradients:** bay − Bhubaneswar and coast − Bhubaneswar
  pressure; bay and coast humidity excess over Bhubaneswar.

**Feature pruning (v3):** permutation importance on the 2024 validation
set for a baseline XGBoost 3 h regressor (MAE) and a 3 h ≥ 10 mm classifier
(PR-AUC). A feature was pruned only when its importance was ≤ 0 for BOTH
tasks. **21 features pruned, 41 kept.** Notably, the pruning removed the
wind components (`wind_u`, `wind_v`), the onshore flux, and the Bay
precipitation columns — the baseline XGBoost did not use them — while
keeping the coast precipitation, spatial rain lead, pressure gradients,
humidity excess, theta_e and the v2 instability features. The pruned list
is in `models/rainfall_xgb_v3/permutation_importance.csv`. Pruning is
conservative (it only removes features that help neither task), but it is
based on a single-family baseline, so it may understate what the ensemble
could use.

Targets: `y_1h` (precip at t+1), `y_3h` (sum t+1..t+3), `y_6h`
(sum t+1..t+6), all in mm. Binary targets for the classifiers:
`y_3h_ge_10mm`, `y_6h_ge_10mm`, `y_3h_ge_5mm`.

## 4. Protocol

- **Chronological split** (no shuffling): train 2021–2023 (26,209 rows),
  validation 2024 (8,784 rows), test 2025 (8,754 rows).
- **Ensemble members** use fixed hyperparameters (no per-family tuning):
  XGBoost (v2 best params as a starting point), LightGBM (matching
  depth/lr/trees), HistGradientBoosting (matching depth/lr/iterations).
  The ensemble, not per-family tuning, is what v3 adds. Note: v2 tuned
  its single XGBoost via random search (16 configs), so v3's fixed
  hyperparameters are a deliberate trade-off — see §5.1.
- **Ensemble weights** learned on validation only (grid search over the
  weight simplex, step 0.1, non-negative, sum to 1): MAE for regressors,
  PR-AUC for classifiers, pinball loss for P90.
- **Classifiers:** `scale_pos_weight = neg/pos` (XGBoost, LightGBM),
  `class_weight="balanced"` (HistGB), shallow trees (max_depth 3,
  reg_lambda 10, subsample 0.8). Probabilities Platt-calibrated (sigmoid)
  on the 2024 validation set — implemented manually (logistic regression
  on logit of the raw probability) because
  `CalibratedClassifierCV(cv="prefit")` was removed in sklearn 1.8+.
  **Two decision thresholds per event**, tuned on validation only:
  `elevated` (Watch, maximises F2) and `high` (Warning, maximises F1).
- **Baselines** for an honest comparison:
  - *Persistence* — the accumulation over the last H hours repeats.
  - *Climatology* — the mean accumulation for the same (month, hour),
    computed from the training set only.
- **Reproducibility:** fixed seeds; re-running `ml/train_rainfall.py`
  reproduces the test metrics (the training script is deterministic;
  the ensemble weight grid search is exhaustive, not random).

## 5. Results (2025 test set, 8,754 hours) — v3 vs v2

### 5.1 Rainfall amounts — MAE / RMSE (mm)

| Horizon | v3 ensemble | v2 XGBoost | Persistence | Climatology | v3 ensemble weights |
|---|---|---|---|---|---|
| 1 h | **0.209 / 0.748** | 0.224 / 0.762 | 0.275 / 1.114 | 0.282 / 0.864 | HistGB 1.0 |
| 3 h | **0.631 / 1.676** | 0.622 / 1.699 | 0.744 / 2.293 | 0.746 / 1.869 | XGB 0.3, HistGB 0.7 |
| 6 h | **1.211 / 2.862** | 1.172 / 2.823 | 1.565 / 4.014 | 1.333 / 3.013 | XGB 0.5, LightGBM 0.5 |

**The honest picture on regression is mixed.** v3 improves the 1 h
forecast (MAE −7% vs v2) and the 3 h RMSE, but the 3 h MAE is slightly
worse (+1.4%) and the 6 h MAE/RMSE are worse (+3.3% / +1.4%). The likely
cause is that v3 used fixed hyperparameters for the ensemble members,
while v2 tuned its single XGBoost via random search — the ensemble gain
did not fully offset the untuned members at the longer horizons. The
model still beats persistence and climatology at every horizon by a wide
margin. The next step for regression is per-family hyperparameter tuning
inside the ensemble, not more features.

### 5.2 Heavy-event detection — the v3 win (2025 test)

| Event | v3 PR-AUC | v2 PR-AUC | v3 ROC-AUC | v2 ROC-AUC |
|---|---|---|---|---|
| 3 h ≥ 10 mm | **0.168** | 0.101 | 0.913 | 0.900 |
| 6 h ≥ 10 mm | **0.207** | 0.178 | 0.888 | 0.890 |
| 3 h ≥ 5 mm | **0.323** | 0.290 | 0.915 | 0.904 |

PR-AUC improves for all three events — **+66% for 3 h ≥ 10 mm**, the
headline heavy-event metric. The ensemble (and the spatial features that
survived pruning) give the classifier substantially better ranking of
rare events.

**Dual thresholds (v3) vs the single v2 threshold:**

| Event | Threshold | Precision | Recall | F1 | Caught |
|---|---|---|---|---|---|
| 3 h ≥ 10 mm | **elevated** (Watch, t=0.07) | 0.149 | 0.299 | 0.198 | **26 / 87** |
| 3 h ≥ 10 mm | **high** (Warning, t=0.08) | 0.161 | 0.218 | 0.185 | **19 / 87** |
| 3 h ≥ 10 mm | v2 (t=0.06) | 0.088 | 0.299 | 0.136 | 26 / 87 |
| 6 h ≥ 10 mm | **elevated** (Watch, t=0.04) | 0.108 | 0.860 | 0.191 | **222 / 258** |
| 6 h ≥ 10 mm | **high** (Warning, t=0.15) | 0.185 | 0.291 | 0.226 | **75 / 258** |
| 6 h ≥ 10 mm | v2 (t=0.08) | 0.145 | 0.667 | 0.239 | 172 / 258 |
| 3 h ≥ 5 mm | **elevated** (Watch, t=0.12) | 0.225 | 0.707 | 0.341 | **224 / 317** |
| 3 h ≥ 5 mm | **high** (Warning, t=0.22) | 0.290 | 0.432 | 0.347 | **137 / 317** |
| 3 h ≥ 5 mm | v2 (t=0.10) | 0.183 | 0.707 | 0.291 | 224 / 317 |

At the same recall as v2, v3's elevated threshold has **much better
precision**: 3 h ≥ 10 mm 0.088 → 0.149 (same 26/87 caught), 3 h ≥ 5 mm
0.183 → 0.225 (same 224/317 caught). The 6 h ≥ 10 mm elevated threshold
catches far more events (222/258, Recall 0.86 vs v2's 172/258) at lower
precision (0.11 vs 0.15) — a genuine recall/precision trade-off the dual
thresholds now make explicit. The `high` (Warning) threshold is the
stricter, higher-precision operating point: use it when a false alarm is
costly, `elevated` (Watch) when missing an event is costly.

**The honest limitation, still:** precision is low in absolute terms —
at 3 h ≥ 10 mm only ~15% of elevated alarms are real heavy events.
The classifiers have real signal (ROC-AUC ~0.91, PR-AUC 5–17× the base
rate) but the events are rare and the point features do not carry strong
precursors. **Treat a "high" tier as an early-warning signal that warrants
attention, not a confirmed forecast of heavy rain.** The 3 h heavy-event
problem is improved, not solved; the correct next step is better input
data (radar, satellite, NWP), not more tuning.

### 5.3 P90 upper-bound envelope (2025 test)

| Horizon | v3 coverage (target 0.90) | v3 mean P90 | v2 coverage | v2 mean P90 |
|---|---|---|---|---|
| 3 h | 0.938 | 1.38 mm | 0.939 | 1.18 mm |
| 6 h | 0.932 | 2.74 mm | 0.932 | 2.73 mm |

Coverage is essentially unchanged from v2 (slightly above 0.90, so the
envelope is a little conservative). It is an upper bound, not a point
forecast: it will overestimate on most hours and still miss the most
extreme bursts (e.g. the 2021-07-21 monsoon case, where the actual 6 h
accumulation of 32.8 mm exceeded the P90 bound of 14.4 mm).

### 5.4 Monsoon replay — 2021-07-21 16:00 (actual: 3 h 13.7 mm, 6 h 32.8 mm)

| Output | v3 | v2 | Actual |
|---|---|---|---|
| Expected 1 h / 3 h / 6 h | 0.77 / 5.2 / 17.0 mm | 0.14 / 3.8 / 14.1 mm | 0.1 / 13.7 / 32.8 mm |
| P90 upper bound 3 h / 6 h | 6.9 / 14.4 mm | 4.0 / 6.6 mm | 13.7 / 32.8 mm |
| P(3 h ≥ 10 mm) / P(6 h ≥ 10 mm) / P(3 h ≥ 5 mm) | 0.073 / 0.148 / 0.272 | 0.071 / 0.106 / 0.231 | (event occurred) |
| **Heavy-risk tier** | **elevated** | high | — |

v3's expected rainfall is closer to the actual (3 h 5.2 vs v2's 3.8;
6 h 17.0 vs v2's 14.1) and its P90 envelope is wider (6 h 14.4 vs 6.6).
The tier is **elevated** (Watch), not high — because v3's `high`
(Warning) thresholds are stricter than v2's single F2 threshold: the
3 h probability (0.073) clears the elevated threshold (0.07) but not the
high one (0.08), and the 6 h probability (0.148) clears elevated (0.04)
but not high (0.15). That is the dual-threshold design working as
intended: the event warrants a Watch, and the stricter Warning bar is
(only just) not met.

## 6. Limitations (do not omit when presenting this model)

1. Bhubaneswar grid cell only (plus two upwind points). Not state-wide,
   not transferable to other districts without retraining on their data.
2. ERA5 reanalysis, not station observations. Extremes are underestimated.
3. Heavy-event detection is improved but still limited: 3 h ≥ 10 mm
   elevated Precision 0.15 at Recall 0.30 (F1 0.198); 6 h ≥ 10 mm
   elevated Precision 0.11 at Recall 0.86 (F1 0.191). A "high" tier is an
   early-warning signal, not a confirmed forecast. The P90 envelope still
   misses the most extreme bursts.
4. Regression at 3 h / 6 h is slightly worse than v2 (MAE +1.4% / +3.3%)
   because v3 used fixed hyperparameters for the ensemble members while
   v2 tuned its single XGBoost. Per-family tuning is the next step.
5. CAPE is not used (all nulls from Open-Meteo for this region).
   Instability is captured only via surface proxies.
6. No live data path: predictions are made from the archive's last
   timestamp (2025-12-31 23:00). A live feed is required before any claim of
   "current" forecasting.
7. No flood modelling: this model predicts rainfall only. Flood risk and
   inundation remain separate, unvalidated work (Phase 4).

## 7. Artifacts

```
models/rainfall_xgb_v3/
  reg_1h_xgb.json / reg_1h_lgbm.txt / reg_1h_hgb.pkl
  reg_3h_xgb.json / reg_3h_lgbm.txt / reg_3h_hgb.pkl
  reg_6h_xgb.json / reg_6h_lgbm.txt / reg_6h_hgb.pkl
                                              mean regressors (one per family)
  clf_y_3h_ge_10mm_xgb.json / _lgbm.txt / _hgb.pkl
  clf_y_6h_ge_10mm_xgb.json / _lgbm.txt / _hgb.pkl
  clf_y_3h_ge_5mm_xgb.json / _lgbm.txt / _hgb.pkl
                                              classifier boosters (one per family)
  p90_3h_xgb.json / p90_3h_lgbm.txt / p90_3h_hgb.pkl
  p90_6h_xgb.json / p90_6h_lgbm.txt / p90_6h_hgb.pkl
                                              P90 quantile regressors
  ensemble_weights.json                     non-negative weights per task
  platt.json                                Platt calibration params (w, b) per event
  thresholds.json                           dual thresholds (elevated / high) per event
  feature_schema.json                       pruned feature list (41), targets, families
  permutation_importance.csv                per-feature importance (MAE + PR-AUC)
  metadata.json                             version, data source, split, families
  evaluation.json                           full test metrics + baselines + event metrics
```
The v2 artifacts in `models/rainfall_xgb/` are left untouched.

## 8. How to reproduce / use

```bash
# Rebuild the feature table
cd backend
.venv/bin/python -c "
import sys; sys.path.insert(0, 'ml')
import features
df = features.load_hourly('data/processed/bhubaneswar_weather.csv')
features.build_features(df).to_csv('data/model_ready/bhubaneswar_features.csv', index=False)"

# Retrain (seeded; reproduces the reported metrics)
.venv/bin/python ml/train_rainfall.py

# Retrain without feature pruning (keeps all 62 features)
.venv/bin/python ml/train_rainfall.py --skip-pruning

# Predict from the latest hourly data
.venv/bin/python ml/predict.py
```

Inference from Python:

```python
from ml.predict import RainfallForecaster
fc = RainfallForecaster()
fc.predict(hourly_df)                 # {"1h": mm, "3h": mm, "6h": mm}
fc.predict_with_provenance(hourly_df) # expected_mm + P90 + probabilities + tier
fc.heavy_rain_probability(hourly_df)  # {"3h_ge_5mm": p, "3h_ge_10mm": p, "6h_ge_10mm": p}
fc.upper_bound_p90(hourly_df)         # {"3h": mm, "6h": mm}
fc.heavy_risk_tier(hourly_df)         # "low" | "moderate" | "elevated" | "high"
```

## 9. API integration (v3, 23 Nov 2026, API v1.3.0)

The model is loaded once at startup by `app/model_service.py` and serves
two endpoints. If the model files are missing or inference fails, the API
falls back to the demo engine and keeps working.

- **`GET /api/forecast`** — hours 1–6 use the model (Bhubaneswar region
  only); hours 7+ use the demo engine. Hourly rates are derived from the
  model's accumulations: hour 1 = y_1h; hours 2–3 = (y_3h − y_1h)/2;
  hours 4–6 = (y_6h − y_3h)/3. Each point carries `source` (`"model"` /
  `"demo"`) and `model_version` when model. Model points also carry a
  `model` object with `expected_mm`, `upper_bound_p90_mm`,
  `heavy_rain_probability` and `heavy_risk_tier`. The `decision_thresholds`
  in the model object are now dual (`elevated` / `high` per event).
  Model-point confidence is an indicative value from the horizon's test
  MAE (93 / 87 / 80 for 1h / 3h / 6h, v3).
- **`GET /api/risk/records` (and `/risk/all`, `/risk/summary`)** — the
  rainfall input for offsets 0 / 3 / 6 h comes from the model (Bhubaneswar
  region); offsets ≥ 9 h use the demo series. Each record carries `source`
  and `model_version` when model, plus the same `model` object with the
  v3 detail. The risk formula itself is unchanged —
  it is a susceptibility index, and `inundationDepthM` / `areaInundatedHa`
  remain illustrative, derived from the index.
- **Ganjam locations** always use the demo engine (no archive yet).
- **`GET /api/health`** reports model status (`loaded`, version, horizons,
  data source, `model_input_as_of`, scope, `heavy_risk_tier`).
- **Current behaviour note:** the model input is the last available
  observations (2025-12-31T23:00Z, a dry December evening), so the model
  currently predicts ~0 mm for the next 6 h with tier "low". That is the
  correct output for the latest data, not a bug. Verified: on a rainy
  monsoon input (2021-07-21 16:00) the model predicts 1h 0.77 / 3h 5.2 /
  6h 17.0 mm (actual 0.1 / 13.7 / 32.8) and flags tier "elevated"
  (P(3h≥10mm) 0.073, P(6h≥10mm) 0.148 — both above their elevated
  thresholds, just below the high ones).
  A live feed would make the model respond to current conditions.

All 22 endpoints re-verified after integration (23 Nov 2026): all 200,
correct 404/400, zero server errors. No endpoint contract was broken —
`source`, `model_version` and the `model` object are additive optional fields.

## 10. v3.1 — precision-focused classifier upgrade (23 Nov 2026, evaluated, NOT deployed)

**Status: evaluated, NOT deployed.** The API still serves v3
(`rainfall-xgb-v3`, API v1.3.0). v3.1 lives in `models/rainfall_xgb_v3_1/`
and is a classifier-only upgrade; the regressors are unchanged from v3.
Full detail: `docs/V31_TECHNICAL.md`; external-data investigation:
`docs/V31_EXTERNAL_DATA.md`.

**What v3.1 tried:** per-family hyperparameter tuning via expanding-window
chronological CV (PR-AUC); 41 vs 62 feature comparison (41 wins for every
family); feature-group ablations (spatial is the most important group,
−0.024 PR-AUC when removed; convective −0.021; thermodynamic −0.007);
imbalance strategies compared (neg_sample_50 best on CV, 0.1587 mean);
thresholds optimised for max precision subject to recall floors
(3h≥10mm Watch ≥0.25 / Warning ≥0.20; 6h≥10mm 0.50/0.25; 3h≥5mm 0.50/0.30);
event-level metrics for overlapping windows; calibration preserved.

**2025 test results (honest):**
- **3 h ≥ 10 mm — primary objective NOT met.** PR-AUC 0.157 (v3: 0.168);
  elevated P 0.144 / R 0.299 (v3: 0.149 / 0.299); high P 0.154 / R 0.241
  (v3: 0.161 / 0.218). The tuned hyperparameters and neg_sample_50 did
  not generalise to 2025 for this event. A control (tuned + `balanced`)
  gave PR-AUC 0.1625 — also below v3. **Do not replace v3 for this event.**
- **6 h ≥ 10 mm — mixed.** PR-AUC 0.211 (v3: 0.207); precision up
  (+0.054 elevated, +0.059 high) but recall down sharply at elevated
  (0.86 → 0.55). Event-level recall at elevated is still 0.891 (49/55 events).
- **3 h ≥ 5 mm — clear win.** PR-AUC 0.358 (v3: 0.323, +11%); precision
  +0.093 elevated (0.318) and +0.132 high (0.422); recall down. This gain
  comes from the tuned hyperparameters, not neg sampling.

**External data (investigated, not integrated):** IMD radar not public;
NASA GPM IMERG needs a free Earthdata account (best satellite candidate
for v3.2); IMDAA ends 2020 (misaligned with 2021–2025); Open-Meteo GFS
Historical Forecast API tested live for 2024 — CAPE is populated, but
GFS precip correlates only 0.11 with ERA5 and CAPE shows only a weak
heavy-event signal, so GFS was NOT integrated. IMD daily rainfall is
daily-only and cannot align to hourly windows.

**Recommendation:** keep v3 in production. The next step for 3 h ≥ 10 mm
is better input data (GPM IMERG, needs Kam's Earthdata account), not more
tuning — the current features are at their ceiling for this event.

---

## 11. v3.2 — multi-source data integration (23 Nov 2026, evaluated, integrated behind a flag, NOT switched to production)

**Idea:** v3.1 showed the v3 features are at their ceiling for 3 h ≥ 10 mm.
v3.2 adds *new information* instead of more tuning: 12 GFS (Global Forecast
System) features from the Open-Meteo Historical Forecast API, on top of the
v3 41 features (53 total). Regressors and P90 quantiles are unchanged from
v3; only the classifiers are retrained. Full detail:
`docs/V32_TECHNICAL.md`, `docs/V32_DATA_SOURCES.md`,
`docs/V32_DATA_QUALITY.md`, `docs/V32_EXPERIMENTS.md`,
`docs/V32_EXTERNAL_ACCESS.md`.

**Sources investigated (in priority order):**
- **INSAT-3D/3DR (MOSDAC)** — catalog search is public and confirms granules
  exist for 2021–2025 (3DIMG_L2B_HEM/IMC, 3RIMG_L2B_HEM/IMC, ~10 MB each,
  half-hourly), but download needs a free MOSDAC account + OAuth2 token.
  **Blocked on Kam's registration.**
- **IMD AWS/ARG stations** — no public keyless historical hourly API;
  needs registration + IP whitelisting. **Blocked.**
- **MSWEP V3** — needs a request at gloh2o.org (they email a Drive link).
  **Blocked.**
- **JAXA GSMaP V8** — needs Google Earth Engine signup or JAXA G-Portal
  registration. **Blocked.**
- **ERA5-Land** — needs a Copernicus CDS account + API token. **Blocked.**
- **ECMWF IFS (Open-Meteo Historical Forecast API, keyless)** — fetched, but
  **unusable**: data only exists from 2024-02-02 (2021–2023 all nulls), so
  all 12 IFS features were dropped and the IFS variant reduces to base.
- **GFS (same API, keyless)** — fetched 2021-03-23 → 2026-11-23 (one ~15-day
  gap 2022-11-29 → 2022-12-14). **This is the source that worked.**

**Evaluation protocol change (important):** 2025 was used repeatedly for
model selection in v3 and v3.1, so it is **not** a clean holdout any more —
it is a historical benchmark. **2026 (Jan–Nov, 7,771 rows, never used for
selection) is the fresh evaluation period.** 2026 has more heavy events
than 2025 (3 h ≥ 10 mm: 185 vs 87).

**Results — PR-AUC (v3.2-GFS vs retrained v3 base):**

| Event | 2025 benchmark | 2026 fresh |
|---|---|---|
| 3 h ≥ 10 mm | 0.1625 → **0.2228** (+0.060) | 0.2556 → **0.2983** (+0.043) |
| 6 h ≥ 10 mm | 0.2002 → **0.2371** (+0.037) | 0.3957 → **0.4293** (+0.034) |
| 3 h ≥ 5 mm | 0.3385 → **0.3575** (+0.019) | 0.4396 → **0.4898** (+0.050) |

v3.2 beats the base on **all three events on both periods** — the first
version to do so. On 2025, precision AND recall both improve for the heavy
events. On 2026, 6 h ≥ 10 mm high (P 0.404 → 0.442, R 0.409 → 0.480) and
3 h ≥ 5 mm (elevated P 0.358 → 0.393; high P 0.476 → 0.522) improve on
both. The one caveat: 3 h ≥ 10 mm operating-point precision on 2026 drops
at the 2024-optimised thresholds (elevated P 0.280 → 0.226, R 0.373 →
0.535) — at matched thresholds the GFS model gives higher recall at the
same precision, so this is a **threshold-calibration effect, not a model
deficiency**. `gfs_precip_6h_sum` is the #2 feature by permutation
importance (+0.175 PR-AUC drop when removed).

**Phase 11 — feature-flag integration (DONE):** `MODEL_VERSION` env var
in `.env` selects the served model (`rainfall-xgb-v3` default,
`rainfall-xgb-v3.2` to enable); any other value or a v3.2 load failure
falls back to v3. Verified live with the flag on (all 22 endpoints 200,
forecast/risk carry the v3.2 model detail, 404/400 intact, zero errors),
then **production was reverted to v3**. **Correction (found during the
v3.3 Phase 1 reproduction, 23 Nov 2026): the Phase 11 live verification
ran with a weights bug** — `ml/predict.py` merged v3's `clf_*` ensemble
weights over v3.2's, so the v3.2 classifiers silently used v3's weights
({xgb 0.6, hgb 0.4} instead of v3.2's {lgbm 0.3, hgb 0.7}); the bug was
masked because the test day was dry (probabilities ~0). Fixed (the merge
now takes only `reg_*`/`p90_*` keys from v3) and v3.2 now reproduces
`evaluation.json` exactly via `ml/reproduce_v32.py`. Production v3 was
never affected. Before switching production traffic, re-optimise the
operating thresholds on a validation set that includes 2025 — never
optimise thresholds on 2026. The remaining high-value step is the blocked
satellite data: INSAT (MOSDAC account) or GPM IMERG (Earthdata account)
— both need Kam's registration.

**Precision is still low in absolute terms** (3 h ≥ 10 mm elevated
precision 0.23 on the fresh 2026 evaluation). A "high" tier remains an
early-warning signal, not a confirmed forecast. Do not present v3.2 as a
reliable heavy-rainfall warning system.

## 12. v3.3 — heavy-rain recall and F1 (23–24 Nov 2026, experimental, evaluated, NOT deployed)

**Idea:** improve the ranking itself — more GFS features (multi-lead
precipitation, CAPE/CIN, humidity profile, upper-level wind, vertical
velocity), plus class-weight / cost-sensitive / hard-negative / event-aware
/ focal-loss variants, a Random Forest challenger, stacking, and a
location-aware investigation. Full detail: `docs/V33_TECHNICAL.md`,
`docs/V33_EXPERIMENTS.md`, `docs/V33_RANDOM_FOREST_EXPERIMENT.md`.

**What was tried and what happened:** the 54 new GFS features win on
out-of-fold PR-AUC for all three events (+18% / +29% / +8%) but LOSE to
v3.2 on the 2025 benchmark for 3h ≥ 10 mm (0.1687 vs 0.2228) — an honest
negative result that 2026 later reverses. Focal loss is the best 2025
arm for 3h ≥ 10 mm (0.1824) but still below v3.2. Random Forest is NOT
adopted (four-family 0.2011 on 2025, but the block-bootstrap CI includes
zero and it detects significantly fewer storms at the F1 operating
point). Stacking across the v3.2+v3.3 feature sets scores 0.4153 on
2025 for 3h ≥ 5 mm (best of any approach) but fails the 2024-OOF gate
and is not adopted. Pooling 5 Odisha locations beats single-location
training but stays below v3.2.

**Frozen config:** the base arm — three-family ensemble on the pruned
94-feature set, weights/Platt/thresholds from 2024 validation, members
refit on 2021–2024. Frozen before any 2026 evaluation
(`ml/freeze_v33.py`); the frozen artifacts reproduce the variants.json
2025 PR-AUC exactly.

**Final 2026 evaluation (fresh, 7,771 hours, scored once) — PR-AUC:**

| Event | v3 | v3.1 | v3.2 | **v3.3 frozen** |
|---|---|---|---|---|
| 3 h ≥ 10 mm | 0.2364 | 0.2304 | 0.2983 | **0.2998** |
| 6 h ≥ 10 mm | 0.4006 | 0.4336 | 0.4293 | **0.4774** |
| 3 h ≥ 5 mm | 0.4514 | 0.4640 | 0.4898 | **0.4956** |

v3.3 has the best ranking and the best calibration (Brier, ECE) on all
three events, and is clearly better than production v3. But against
v3.2 it is a tie on 3h ≥ 10 mm (+0.001) and 3h ≥ 5 mm (+0.006) and a
+0.047 lean on 6h ≥ 10 mm — paired block bootstrap (1,000 resamples):
only the 6h ≥ 10 mm gap vs v3 excludes zero. At the saved operating
thresholds v3.3 does NOT lead on F1 for 3h ≥ 10 mm (v3.2: 0.318/0.331
vs v3.3: 0.305/0.308) or on storm detection for that event (v3.3
detects 26/46 storms at elevated vs v3's 35/46). Thresholds were
learned on 2024 validation and never re-optimised on 2026 — that
re-optimisation (on validation including 2025) is the next step before
any production switch. Shared regressors on 2026: 1h MAE 0.3256 /
RMSE 1.4209, 3h 0.9736 / 3.7535, 6h 1.8106 / 6.6006 (worse than 2025
because 2026 is a heavier year).

**Bottom line:** v3.3 is the best model built so far by ranking, but the
margin over v3.2 is not established. Production stays on v3. No API or
frontend change was made. *(Superseded 2026-11-24 — see §13: v3.3 is
now wired into the API behind the `MODEL_VERSION` flag; production
still v3.)*

## 13. v3.3 threshold optimization and hackathon readiness (24 Nov 2026, frozen, flag-gated, NOT deployed)

**Task:** optimize the frozen v3.3 model's Watch/Warning thresholds on
chronological 2024+2025 development evidence only, investigate the
2026 storm-detection gap, freeze and hash the release, wire v3.3 into
the API behind the flag, and prepare an honest hackathon demo.
Full detail: `docs/V33_THRESHOLDS.md`, `docs/V33_COMPARISON.md`,
`docs/V33_STORM_DETECTION.md`, `docs/V33_CALIBRATION.md`,
`docs/V33_READINESS.md`, `docs/V33_CALIBRATION_DIAGRAM.html`,
`docs/V33_DEMO_REPLAY.json`.

**Protocol (the guardrail):** out-of-sample probability sets for v3,
v3.2 and v3.3 on pooled 2024+2025 (17,520 hours) — 2024 scored by
train-only models (2021–2023) with recorded weights/Platt, 2025 scored
by the deployed artifacts (`ml/build_threshold_probs.py`). Every 2025
PR-AUC reproduces the version's recorded number exactly. **2026 was
not used for threshold selection, calibration, or any validation claim,
and the new thresholds were not re-scored on 2026.**

**Operating thresholds** (`frozen/thresholds_optimized.json`; the
frozen `thresholds.json` is untouched): 3 h >= 10 mm 0.070 / 0.125;
6 h >= 10 mm 0.085 / 0.185; 3 h >= 5 mm 0.125 / 0.225. Rules: Watch
maximizes F2, Warning maximizes F1, subject to the v3.1 recall floors
(0.25/0.20, 0.50/0.25, 0.50/0.30) and precision floors (0.10/0.15).
Pooled 2024+2025 at the new thresholds (v3.3): 3 h >= 10 mm Watch
F2 0.270 (P 0.121 / R 0.389), Warning F1 0.209 (P 0.203 / R 0.216);
6 h >= 10 mm Watch F2 0.420 (P 0.157 / R 0.723), Warning F1 0.324
(P 0.287 / R 0.372); 3 h >= 5 mm Watch F2 0.518 (P 0.262 / R 0.686),
Warning F1 0.420 (P 0.370 / R 0.487). The thresholds are year-stable:
2024 vs 2025 precision/recall agree within ~0.04 / ~0.13 at every
operating point — the most stable of the three versions. v3's
3 h >= 10 mm Watch and Warning collapse to the same threshold (0.040):
no threshold satisfies its Warning rule on pooled 2024+2025.

**Matched comparison (v3.3 vs v3.2, pooled 2024+2025):** v3.3 wins on
6 h >= 10 mm (+0.026 precision at matched recall, +0.080 recall at
matched precision, Watch), ties on 3 h >= 5 mm (+0.002 / +0.006), and
loses on 3 h >= 10 mm (−0.024 / −0.022). The 3 h >= 10 mm gap is a
ranking gap (2025 PR-AUC 0.1687 vs 0.2228), not a threshold gap.

**Storm detection:** the 2026 symptom (v3.3 26/46 vs v3 35/46 at old
thresholds) does NOT reproduce on 2024+2025, where v3.3 beats v3 on
all three events (37 vs 22, 54 vs 45, 125 vs 100) — it is
year-specific, not a systematic v3.3 weakness vs v3. The real gap is
v3.3 vs v3.2 on 3 h >= 10 mm (significant in the paired storm-event
bootstrap: −0.132, CI [−0.232, −0.043]), driven by genuinely lower
probabilities on short marginal storms. A second mechanism is the
block-start artifact: many "missed" 6 h >= 10 mm / 3 h >= 5 mm storms
have v3.3 probabilities far above threshold (up to 0.83) but their
alert event started before the detection window — the metric rewards
late/intermittent firing and penalizes early, sustained firing. The
new thresholds recover 7/50 and 2/51 old misses on the other two
events without increasing false alarms, and nothing on 3 h >= 10 mm
(threshold unchanged).

**Calibration (pooled 2024+2025):** Brier v3.3 0.0097 / 0.0263 / 0.0294
(best or tied on all three); ECE 0.0016 / 0.0074 / 0.0036. The Platt
calibration transfers from 2024 to 2025 without visible degradation.

**Freeze:** `frozen/RELEASE_MANIFEST.json` — SHA-256 of all 15 frozen
files, the threshold-selection record, and the pooled metrics at the
operating thresholds. Weights and features unchanged.

**API integration:** `ml/predict.py` gains v3.3 support
(`V33_MODEL_DIR`, inference-time v33 GFS features via
`ml/features_v33.py: build_v33_features_at`, operating thresholds
from `thresholds_optimized.json` when present) and
`app/model_service.py` accepts `MODEL_VERSION=rainfall-xgb-v3.3`
(same fallback-to-v3 pattern as v3.2). Verified by
`ml/verify_v33_inference.py`: the live forecaster reproduces the
prebuilt table exactly (94/94 features match, probabilities to 4 dp).
Live server with the flag on: all 20 GET endpoints 200, both POSTs
200, unknown location 404, bad hours 400, zero server errors;
forecast items carry `model_version: rainfall-xgb-v3.3` with the exact
standalone probabilities. **Then reverted: `.env` restored (no
`MODEL_VERSION`), server restarted, `/api/health` verified serving
`rainfall-xgb-v3`. Production is untouched. No frontend change.**

**Demo:** `docs/V33_DEMO_REPLAY.json` — 37 hourly predictions for the
2021-07-21 monsoon (20 high, 17 elevated tiers). At 16:00: expected
0.77 / 5.18 / 16.97 mm, P90 6.89 / 14.35, tier high; actual 0.1 /
13.7 / 32.8 mm — the tier was right, the amount was underestimated
and the P90 envelope was exceeded. Missing-data check: inside the
345-hour GFS gap the model still returns values with 12/55 GFS
features missing.

**Recommendation (see V33_READINESS.md):** demo with v3.3 as the
primary hackathon candidate (v3.2 as benchmark, v3 as production),
presented as an early-warning signal with the precision numbers on
the slide. Do NOT switch production to v3.3: the production bar — a
validated improvement on 3 h >= 10 mm — is not met.

## 14. Hackathon demo selection (2026-11-24)

Kam selected **v3.3 as the primary model for the hackathon demonstration**
(v3.2 benchmark, v3 production + rollback). Full verification record:
`docs/V33_DEMO_READINESS.md`.

- Frozen artifacts re-verified against `RELEASE_MANIFEST.json`: **15/15
  hashes match**, before and after the demo work. Nothing retrained,
  modified or regenerated; thresholds untouched; 2026 untouched.
- Demo runs via the existing `MODEL_VERSION` flag (demo API on port 8001,
  frontend on :5173 pointed at it). Verified live: `/api/health` reports
  `rainfall-xgb-v3.3`; forecast and risk carry `model_version:
  rainfall-xgb-v3.3` on Bhubaneswar-region values only; Ganjam is all DEMO.
- No-silent-fallback rule verified: an invalid flag value falls back to v3
  and is **reported as v3**; labels always follow the actually loaded model.
- Frontend badges verified by browser probe: MODEL badges carry the
  `rainfall-xgb-v3.3` tooltip on Bhubaneswar locations, zero MODEL badges
  on Brahmapur, zero UNKNOWN anywhere.
- Validation slide added to the HACK-KALP deck as slide 5 (deck now 6
  slides); the IMD report's source is now labelled **IMD daily gridded
  rainfall data** throughout, not "gauge data".
- Production re-verified on v3 after the demo servers stopped; `.env`
  has no `MODEL_VERSION`. Nothing deployed.
