# RAINWATCH AI v3.3 — Hackathon Readiness Report

Date: 2026-11-24. Model: `rainfall-xgb-v3.3` (frozen). API: v1.3.0.
Production: `rainfall-xgb-v3` (unchanged). v3.3 is the hackathon
candidate, behind the `MODEL_VERSION` flag — NOT deployed.

## 1. Recommendation

**Yes — demo with v3.3 as the primary hackathon candidate, with
v3.2 as the benchmark and v3 as production.** Three conditions:

1. Present v3.3 as an **early-warning signal**, with the precision
   numbers on the slide (see §4). Never call it a confirmed forecast.
2. Lead with its real strengths — **6 h >= 10 mm and 3 h >= 5 mm** —
   and do not oversell 3 h >= 10 mm, where v3.2 is better.
3. Keep v3.2 visible as the benchmark on the comparison slide. Do NOT
   switch production to v3.3: the production bar is a validated
   improvement on the headline heavy-rain event (3 h >= 10 mm), and
   v3.3 does not beat v3.2 there.

The case for v3.3 as the demo candidate: best 2026 PR-AUC of all four
versions on all three events (0.2998 / 0.4774 / 0.4956), best Brier
and ECE on all three on 2026, best 2024 ranking on all three events,
year-stable optimized thresholds, and a working end-to-end demo
replay. The case against switching production: the 3 h >= 10 mm gap
vs v3.2 (below), and the thresholds have not been independently
validated on 2026 by design — the brief forbids claiming that.

## 2. What was frozen and hashed

`models/rainfall_xgb_v3_3/frozen/RELEASE_MANIFEST.json` (SHA-256 of all
15 frozen files): base three-family ensemble on the pruned 94-feature
set, refit on 2021–2024; weights and Platt from 2024 validation;
operating thresholds from `thresholds_optimized.json`
(3 h >= 10 mm 0.070 / 0.125; 6 h >= 10 mm 0.085 / 0.185;
3 h >= 5 mm 0.125 / 0.225), selected on pooled out-of-sample
2024+2025 evidence only. **2026 was not used for threshold selection
or calibration, and the new thresholds were not re-scored on 2026.**
`thresholds.json` is untouched as the freeze record.

## 3. Demo replay (2021-07-21 monsoon)

Full record: `docs/V33_DEMO_REPLAY.json` (37 hourly predictions,
2021-07-21 00:00 → 2021-07-22 12:00). Script: `ml/demo_replay.py`.

- Tiers across the window: 20 high, 17 elevated — the model was
  warning for the whole event, which is correct for this storm.
- At 16:00 (the reference hour): expected 0.77 / 5.18 / 16.97 mm,
  P90 6.89 / 14.35 mm, probabilities 0.284 / 0.429 / 0.331,
  tier **high**. Actual ERA5 rain that followed: 0.1 / 13.7 / 32.8 mm.
  The tier was right and the warning was already high at 13:00
  (6 h probability 0.350), three hours before the reference hour —
  but the model underestimated the 6 h magnitude (17 vs 33 mm) and
  the P90 envelope (14.35 mm) was exceeded by the actual 32.8 mm.
  Say this out loud in the demo: it caught the event, it did not
  nail the amount.
- At 19:00: expected 10.15 / 15.45 mm vs actual 19.1 / 19.3 mm —
  closer as the storm developed.
- GFS features were available at every replay hour (0 missing).
- Missing-data check (separate): at 2022-12-05 12:00, inside the
  345-hour GFS archive gap (2022-11-29 → 2022-12-14), 12 of 55 GFS
  features were missing and the model still returned values
  (tier low, probabilities 0.0006 / 0.0020 / 0.0001). The API never
  crashes on missing GFS data — it falls back to NaN, which the
  gradient-boosting members handle natively.

Honesty notes for the demo (also in the replay JSON): predictions are
hindcasts from ERA5 reanalysis + archived GFS, not live forecasts;
actual rainfall shown is ERA5 reanalysis, not rain-gauge observations;
scope is one Bhubaneswar grid cell, not all of Odisha; a "high" tier
is an early-warning signal.

## 4. Numbers to put on the slides (all from 2024+2025 evidence unless noted)

| Claim | Number | Source |
|---|---|---|
| 6 h >= 10 mm Watch F2 | 0.420 (v3.2: 0.380, v3: 0.350) | V33_THRESHOLDS.md |
| 6 h >= 10 mm Warning F1 | 0.324 (v3.2: 0.278) | V33_THRESHOLDS.md |
| 3 h >= 5 mm Watch F2 | 0.518 (v3.2: 0.505) | V33_THRESHOLDS.md |
| 3 h >= 10 mm Watch F2 | 0.270 (v3.2: 0.280 — v3.2 better) | V33_THRESHOLDS.md |
| 3 h >= 10 mm Watch precision | 0.121 at recall 0.389 | V33_THRESHOLDS.md |
| 2026 PR-AUC (frozen model, old thresholds) | 0.2998 / 0.4774 / 0.4956, best of 4 versions | V33_TECHNICAL.md §12 |
| 2026 3 h >= 10 mm storm detection | 26/46 (v3: 35/46) — old thresholds | V33_TECHNICAL.md §12 |

Do NOT put on a slide: any claim that the new thresholds are validated
on 2026 (they are not — by design), or that v3.3 beats v3.2 on
3 h >= 10 mm (it does not).

## 5. API verification (flag-gated, then reverted)

- `ml/predict.py` and `app/model_service.py` accept
  `MODEL_VERSION=rainfall-xgb-v3.3` (same pattern as v3.2; fallback to
  v3 on any load failure). `.env.example` documents the option.
- Inference path verified by `ml/verify_v33_inference.py`: the live
  forecaster reproduces the prebuilt table exactly — **94/94 features
  match** at 2025-12-31 17:00, probabilities match to 4 decimals at
  spot checks, 0 NaN features at normal timestamps.
- Live server with the flag on: `/api/health` reports
  `rainfall-xgb-v3.3`, API 1.3.0. All 20 GET endpoints 200, POST
  `/api/demo/refresh` 200, POST `/api/simulate` 200 (complete body),
  unknown locationId 404, bad hours 400. Forecast items carry
  `source: "model"`, `model_version: "rainfall-xgb-v3.3"` and the full
  `model` detail object; at the archive end the live probabilities
  (0.0010 / 0.0024 / 0.0003) match the standalone forecaster exactly.
  Zero ERROR/Traceback lines in the server log.
- **Reverted**: `.env` restored (no `MODEL_VERSION`), server restarted,
  `/api/health` verified serving `rainfall-xgb-v3`, loaded: true.
  Production is untouched.

## 6. How to run the demo

```
# 1. Switch the flag (do not edit code):
cp .env /tmp/env_backup_demo && printf '\nMODEL_VERSION=rainfall-xgb-v3.3\n' >> .env
# 2. Restart the backend:
.venv/bin/uvicorn app.main:app --port 8000
# 3. Check: curl localhost:8000/api/health  -> model_version rainfall-xgb-v3.3
# 4. Demo the replay: docs/V33_DEMO_REPLAY.json has every hour with
#    expected rainfall, P90, probabilities, tier + plain-language
#    explanation, actual rain that followed, and provenance.
# 5. After the demo, restore production:
cp /tmp/env_backup_demo .env   # then restart; health must show rainfall-xgb-v3
```

## 7. Known limits to state in the demo

- Precision is low in absolute terms: at Watch, roughly 1 in 8
  alerts for 3 h >= 10 mm is a real heavy event (0.121), 1 in 6 for
  6 h >= 10 mm (0.157), 1 in 4 for 3 h >= 5 mm (0.262). A "high" tier
  is an early-warning signal, not a confirmed forecast.
- 3 h >= 10 mm is the weakest event for v3.3 relative to v3.2:
  2025 PR-AUC 0.1687 vs 0.2228; storm detection significantly lower
  than v3.2 on 2024+2025 (see V33_STORM_DETECTION.md).
- The storm-detection metric rewards frequent firing; v3.3's
  detection at new thresholds is 0.536 / 0.567 / 0.722 (Watch).
- The model is a Bhubaneswar-grid-cell forecaster, not state-wide.
  Flood susceptibility is not inundation; depths/areas in the UI are
  illustrative, derived from the index.
- The 2026 storm-detection gap vs v3 (26/46 vs 35/46, old thresholds)
  is a year-specific observation that does not reproduce on 2024+2025
  development data — say so if asked; do not hide it.

## 8. What remains before production (not for the hackathon)

- An independent validation of the new thresholds on data that played
  no role in selection (the prospective 2027 monsoon, or 2026 used
  strictly as a held-out check with no further threshold changes).
- The 3 h >= 10 mm ranking gap vs v3.2 needs better input data
  (GPM IMERG is the best candidate — needs a free Earthdata account),
  not more tuning (v3.1/v3.3 both showed tuning does not close it).
- Stage 5 (frontend Model vs Demo badges) is still held at Kam's
  instruction; Stage 6 (pytest suite + full handoff docs) is not yet
  approved.
