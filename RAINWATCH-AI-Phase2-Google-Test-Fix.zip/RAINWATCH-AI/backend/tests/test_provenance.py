"""Provenance tests: MODEL / DEMO / UNKNOWN labelling.

Rules under test (Stage 5 contract):
- A value is MODEL only when the backend says ``source == "model"``.
- ``model_version`` alone never promotes a value to MODEL.
- Missing/unknown ``source`` must resolve to UNKNOWN (frontend resolver),
  never silently to MODEL.
- Ganjam locations are always DEMO — never labelled with a model version.
- Every model point carries ``model_version`` and the ``model`` detail
  object; demo points carry neither.
"""

import os

from conftest import VERSION_V3, VERSION_V32, VERSION_V33


def _sources(points):
    from collections import Counter
    return Counter(p.get("source") for p in points)


def test_forecast_bhubaneswar_mixed_sources(v3_client):
    points = v3_client.get(
        "/api/forecast?locationId=patia&hours=24").json()
    counts = _sources(points)
    assert counts["model"] == 6
    assert counts["demo"] == 18
    model_points = [p for p in points if p["source"] == "model"]
    # Model points are exactly hours 1-6 (first six, ascending time).
    assert points[:6] == model_points
    assert all(p["model_version"] == VERSION_V3 for p in model_points)
    for p in model_points:
        assert "model" in p
        detail = p["model"]
        assert set(detail) >= {"expected_mm", "upper_bound_p90_mm",
                               "heavy_rain_probability", "heavy_risk_tier",
                               "model_version"}
        assert detail["model_version"] == VERSION_V3
    demo_points = [p for p in points if p["source"] == "demo"]
    assert all("model_version" not in p for p in demo_points)
    assert all("model" not in p for p in demo_points)


def test_forecast_ganjam_all_demo(v3_client):
    points = v3_client.get(
        "/api/forecast?locationId=brahmapur&hours=24").json()
    assert len(points) == 24
    assert _sources(points) == {"demo": 24}
    assert all("model_version" not in p for p in points)
    assert all("model" not in p for p in points)


def test_forecast_all_bhubaneswar_locations_have_model_hours(v3_client):
    locs = v3_client.get("/api/locations").json()
    bbsr = [loc["id"] for loc in locs if loc.get("regionId") != "ganjam"]
    assert len(bbsr) == 14
    for loc_id in bbsr:
        points = v3_client.get(
            f"/api/forecast?locationId={loc_id}&hours=24").json()
        assert _sources(points)["model"] == 6, loc_id


def test_forecast_all_ganjam_locations_all_demo(v3_client):
    locs = v3_client.get("/api/locations").json()
    ganjam = [loc["id"] for loc in locs if loc.get("regionId") == "ganjam"]
    assert len(ganjam) == 7
    for loc_id in ganjam:
        points = v3_client.get(
            f"/api/forecast?locationId={loc_id}&hours=24").json()
        assert _sources(points) == {"demo": 24}, loc_id


def test_forecast_model_points_identical_across_bhubaneswar_locations(v3_client):
    """Single-cell regression (integrity check 2026-11-24): the ML
    ensemble predicts for ONE Bhubaneswar ERA5 grid cell, so the six
    MODEL points must be byte-identical for every Bhubaneswar-region
    location — Cuttack and Puri included. Only the DEMO points may
    differ per location (they are seeded per location). If this test
    fails, the model has silently become per-location, and the UI
    copy that says "single grid cell" is wrong."""
    series = {}
    for loc_id in ("old-town", "patia", "cuttack", "puri"):
        points = v3_client.get(
            f"/api/forecast?locationId={loc_id}&hours=24").json()
        model_points = [p for p in points if p["source"] == "model"]
        assert len(model_points) == 6, loc_id
        series[loc_id] = [
            (p["timestamp"], p["rainfallMmHr"], p["model_version"],
             p["model"]["expected_mm"]) for p in model_points]
    assert series["cuttack"] == series["old-town"]
    assert series["puri"] == series["old-town"]
    assert series["patia"] == series["old-town"]
    # Sanity: the comparison is not vacuous — demo values DO differ
    # across locations, so identical MODEL points mean a shared cell.
    demo_old = [p["rainfallMmHr"] for p in v3_client.get(
        "/api/forecast?locationId=old-town&hours=24").json()
        if p["source"] == "demo"]
    demo_cut = [p["rainfallMmHr"] for p in v3_client.get(
        "/api/forecast?locationId=cuttack&hours=24").json()
        if p["source"] == "demo"]
    assert demo_old != demo_cut


def test_risk_records_bhubaneswar_mixed(v3_client):
    recs = v3_client.get("/api/risk/records?locationId=old-town").json()
    counts = _sources(recs)
    assert counts["model"] == 3  # offsets 0, 3, 6
    assert counts["demo"] == 22
    model_recs = [r for r in recs if r["source"] == "model"]
    assert all(r["model_version"] == VERSION_V3 for r in model_recs)
    assert all("model" in r for r in model_recs)
    assert all("model_version" not in r for r in recs if r["source"] == "demo")


def test_risk_records_ganjam_all_demo(v3_client):
    recs = v3_client.get("/api/risk/records?locationId=brahmapur").json()
    assert _sources(recs) == {"demo": 25}
    assert all("model_version" not in r for r in recs)


def test_risk_all_counts(v3_client):
    recs = v3_client.get("/api/risk/all").json()
    counts = _sources(recs)
    # 14 Bhubaneswar-region locations x 3 model offsets each.
    assert counts["model"] == 42
    assert counts["demo"] == 483
    assert counts["model"] + counts["demo"] == 525


def test_model_detail_object_shape(v3_client):
    points = v3_client.get(
        "/api/forecast?locationId=patia&hours=6").json()
    detail = points[0]["model"]
    assert set(detail["expected_mm"]) == {"1h", "3h", "6h"}
    assert set(detail["upper_bound_p90_mm"]) == {"3h", "6h"}
    assert set(detail["heavy_rain_probability"]) == {
        "3h_ge_10mm", "6h_ge_10mm", "3h_ge_5mm"}
    assert detail["heavy_risk_tier"] in ("low", "moderate", "elevated", "high")
    for v in detail["expected_mm"].values():
        assert isinstance(v, (int, float)) and v >= 0
    for v in detail["upper_bound_p90_mm"].values():
        assert isinstance(v, (int, float)) and v >= 0
    for v in detail["heavy_rain_probability"].values():
        assert 0.0 <= v <= 1.0


def test_model_detail_is_identical_across_locations(v3_client):
    """The model predicts one grid cell; every Bhubaneswar location
    shows the same model detail (only the demo series differs)."""
    a = v3_client.get("/api/forecast?locationId=patia&hours=6").json()
    b = v3_client.get("/api/forecast?locationId=old-town&hours=6").json()
    assert a[0]["model"] == b[0]["model"]
    assert a[0]["rainfallMmHr"] == b[0]["rainfallMmHr"]


def test_forecast_model_hours_unchanged_by_demo_refresh(v3_client, tick_guard):
    """Model hours come from the fixed archive end; only demo values
    change when the demo tick bumps."""
    before = v3_client.get("/api/forecast?locationId=patia&hours=24").json()
    v3_client.post("/api/demo/refresh")
    after = v3_client.get("/api/forecast?locationId=patia&hours=24").json()
    assert [p["rainfallMmHr"] for p in before[:6]] == [
        p["rainfallMmHr"] for p in after[:6]]
    assert [p["rainfallMmHr"] for p in before[6:]] != [
        p["rainfallMmHr"] for p in after[6:]]


def test_v33_model_version_on_points(v33_client):
    points = v33_client.get("/api/forecast?locationId=patia&hours=24").json()
    model_points = [p for p in points if p["source"] == "model"]
    assert len(model_points) == 6
    assert all(p["model_version"] == VERSION_V33 for p in model_points)
    assert all(p["model"]["model_version"] == VERSION_V33 for p in model_points)
    # Ganjam still all demo under v3.3.
    ganjam = v33_client.get("/api/forecast?locationId=brahmapur&hours=24").json()
    assert _sources(ganjam) == {"demo": 24}


def test_v32_model_version_on_points(v32_client):
    points = v32_client.get("/api/forecast?locationId=patia&hours=24").json()
    model_points = [p for p in points if p["source"] == "model"]
    assert len(model_points) == 6
    assert all(p["model_version"] == VERSION_V32 for p in model_points)


def test_frontend_source_resolver_never_infers_from_version(tmp_path):
    """The frontend resolver rule, tested at the source: a payload with
    model_version but no source must not be treated as MODEL. This
    mirrors the resolver's unit check from Stage 5, compiled and run
    here so the rule is covered by the backend suite too."""
    import subprocess
    hack = os.path.join(os.path.dirname(__file__), "..", "..", "hackathon")
    script = os.path.join(hack, "src", "utils", "source.ts")
    outdir = tmp_path / "ts_out"
    # Invoke tsc via node directly: the node_modules/.bin/tsc shim lost
    # its exec bit on this Linux VM (Windows native binaries shipped in
    # node_modules — see docs/ENGINEERING_AUDIT.md §6.10).
    tsc = os.path.join(hack, "node_modules", "typescript", "bin", "tsc")
    r = subprocess.run(
        ["node", tsc, script, "--outDir", str(outdir),
         "--module", "commonjs", "--target", "es2020", "--ignoreConfig"],
        cwd=hack, capture_output=True, text=True, timeout=120)
    assert r.returncode == 0, r.stderr
    probe = (
        "const {resolveSource} = require(%r);"
        "const cases=[[{source:'model'},'model'],[{source:'demo'},'demo'],"
        "[{source:'google_weather'},'google_weather'],"
        "[{source:'unavailable'},'unavailable'],"
        "[{source:'UNAVAILABLE'},'unknown'],"
        "[{source:'GOOGLE_WEATHER'},'unknown'],"
        "[{source:'MODEL'},'unknown'],"
        "[{model_version:'rainfall-xgb-v3.3'},'unknown'],"
        "[{source:'model',model_version:'rainfall-xgb-v3.3'},'model'],"
        "[{source:'google_weather',model_version:'rainfall-xgb-v3.3'},'google_weather'],"
        "[{},'unknown'],[null,'unknown']];"
        "for(const [input,want] of cases){const got=resolveSource(input);"
        "if(got!==want){console.error(JSON.stringify(input),'->',got,'want',want);process.exit(1);}}"
        "console.log('resolver OK');"
    ) % str(outdir / "source.js")
    p = subprocess.run(["node", "-e", probe], capture_output=True,
                       text=True, timeout=60)
    assert p.returncode == 0, p.stderr
    assert "resolver OK" in p.stdout
